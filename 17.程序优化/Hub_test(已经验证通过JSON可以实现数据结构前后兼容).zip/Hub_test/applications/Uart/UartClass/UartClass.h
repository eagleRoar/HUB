/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-01-04     Administrator       the first version
 */
#ifndef APPLICATIONS_UART_UARTCLASS_UARTCLASS_H_
#define APPLICATIONS_UART_UARTCLASS_UARTCLASS_H_

#include "Uart.h"
#include "SeqList.h"

typedef struct taskList{
    //1.数值
    Node *list;

    //2.函数接口
    Node*(*GetList)(void);              //返回关注列表
    void(*AddToList)(KV, u8);           //加入到关注列表
    void(*DeleteToList)(KV);            //从关注列表中删除
    u8(*KeyHasExist)(KV);               //检查列表中是否存在key
    u8(*CheckDataCorrect)(KV);          //检查数据是否存在关注列表中

}type_taskList;

typedef struct ctrlInfo{
    u16     value;
    u32     uuid;
    time_t  time;
}ctrl_info;

typedef struct uartClass{
    //1.数值
    rt_device_t     *dev;
    type_taskList   taskList;           //任务列表
    type_taskList   checkList;          //核对列表

    //函数接口
    void(*ConfigureUart)(rt_device_t*); //注册实际的串口
    void(*Ctrl)(u8, u16, u8*, u8);      //发送串口数据
    void(*RecvCmd)(u8*, u8);            //接收串口数据
    void(*SendCmd)(void);               //实际发送数据
    void(*CheckListHandle)(void);

} type_uart_class;


type_uart_class *GetUart2Object(void);
#endif /* APPLICATIONS_UART_UARTCLASS_UARTCLASS_H_ */
