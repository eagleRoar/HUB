/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-01-04     Administrator       the first version
 */
#include "UartClass.h"
#include "SeqList.h"
#include "UartEventType.h"
#include "Command.h"

//设备类型
static type_uart_class *uart2Object = RT_NULL;

seq_key_t LongToSeqKey(long a)
{
    static long b;

    b = ((a & 0xFF000000) >> 24) | ((a & 0x00FF0000) >> 8)
            | ((a & 0x0000FF00) << 8) | ((a & 0x000000FF) << 24);

    return *(seq_key_t *)&b;
}

long SeqKeyToLong(seq_key_t a)
{
    static long b;

    b = *(long *)&a;

    b = ((b & 0xFF000000) >> 24) | ((b & 0x00FF0000) >> 8)
             | ((b & 0x0000FF00) << 8) | ((b & 0x000000FF) << 24);

    return *(long *)&b;
}

/****************Check List START***************************************************************/
static Node *GetCheckList (void)
{
    return uart2Object->checkList.list;
}

//加入到关注列表
static void AddToCheckList(KV keyData, u8 keyUnique)
{
    //LOG_D("---------- AddToCheckList");
    CreatTail(&uart2Object->checkList.list, keyData, keyUnique);
}

static void DeleteToCheckList(KV keyData)
{
    if(YES == KeyExist(uart2Object->checkList.list, keyData))
    {
        DeleteNode(&uart2Object->checkList.list, keyData);
    }
}

static u8 KeyHasExistInCheckList(KV keyData)
{
    return KeyExist(uart2Object->checkList.list, keyData);
}

//检查数据是否存在关注列表中
static u8 CheckDataInCheckList(KV keyData)
{
    if(YES == KeyExist(uart2Object->checkList.list, keyData))
    {
        if(YES == DataCorrect(uart2Object->checkList.list, keyData))
        {
            return YES;
        }
    }

    return NO;
}

/****************Check List END*****************************************************************/

/****************Task List START****************************************************************/
static Node *GetTaskList (void)
{
    return uart2Object->taskList.list;
}

//加入到关注列表
static void AddToTaskList(KV keyData, u8 keyUnique)
{
    CreatTail(&uart2Object->taskList.list, keyData, keyUnique);
}

static void DeleteToTaskList(KV keyData)
{
    if(YES == KeyExist(uart2Object->taskList.list, keyData))
    {
        DeleteNode(&uart2Object->taskList.list, keyData);
    }
}

static u8 KeyHasExistInTaskList(KV keyData)
{
    return KeyExist(uart2Object->taskList.list, keyData);
}

//检查数据是否存在关注列表中
static u8 CheckDataInTaskList(KV keyData)
{
    if(YES == KeyExist(uart2Object->taskList.list, keyData))
    {
        if(YES == DataCorrect(uart2Object->taskList.list, keyData))
        {
            return YES;
        }
    }

    return NO;
}

/****************Task List END******************************************************************/

static void ConfigureUart2(rt_device_t *dev)
{
    uart2Object->dev = dev;
}

/**传入参数
 *
 * @param addr      设备485地址
 *        reg_addr  寄存器地址
 *        reg_data  寄存器实际值
 *        reg_size  控制的寄存器值的数量
 */
static void Uart2Ctrl(u8 addr, u16 reg_addr, u8 *reg_data, u8 reg_size)
{
    u8 data[8];
    KV keyValue;
    seq_key_t seq_key;

    //1.判断是否已经注册了串口
    if(RT_NULL != uart2Object->dev)
    {
        rt_memset(data, 0, 8);

        //2.发送控制命令
        data[0] = addr;
        data[1] = 0x06;
        data[2] = reg_addr >> 8;
        data[3] = reg_addr;
        if(1 == reg_size)//Justin debug 要增加多个
        {
            data[4] = reg_data[0];
            data[5] = reg_data[1];
        }

        data[6] = usModbusRTU_CRC(data, 6);
        data[7] = usModbusRTU_CRC(data, 6) >> 8;

        //3.添加到taskList,之后会在统一接口中实现数据的发送
        seq_key.addr = addr;
        seq_key.regH = reg_addr >> 8;
        seq_key.regL = reg_addr;
        seq_key.regSize = reg_size;
        keyValue.key = SeqKeyToLong(seq_key);
        keyValue.dataSegment.len = 8;
        keyValue.dataSegment.data = rt_malloc(keyValue.dataSegment.len);
        if(keyValue.dataSegment.data)
        {
            //4.复制实际数据
            rt_memcpy(keyValue.dataSegment.data, data, keyValue.dataSegment.len);

            uart2Object->taskList.AddToList(keyValue, NO);
            //5.回收空间
            rt_free(keyValue.dataSegment.data);
            keyValue.dataSegment.data = RT_NULL;
        }
    }
}

void RecvCmd(u8* data, u8 len)
{
    KV          keyValue;
    seq_key_t   key;
    device_t    *device = GetDeviceByAddr(GetMonitor(), data[0]);

    //1.是否是注册信息
    if((REGISTER_CODE == data[0]) || (device))
    {
        //2.判断是否是已经注册的设备
        if(device)
        {
            key.addr = data[0];
            key.regH = data[2];
            key.regL = data[3];
            key.regSize = 1;

            keyValue.key = SeqKeyToLong(key);
        }
        else if(REGISTER_CODE == data[0])
        {
            keyValue.key = REGISTER_CODE << 24;
        }

        keyValue.dataSegment.len = len;
        keyValue.dataSegment.data = rt_malloc(keyValue.dataSegment.len);
        if(keyValue.dataSegment.data)
        {
            rt_memcpy(keyValue.dataSegment.data, data, len);
            uart2Object->checkList.AddToList(keyValue, NO);
            //回收空间
            rt_free(keyValue.dataSegment.data);
            keyValue.dataSegment.data = RT_NULL;
        }
    }
}

void SendCmd(void)
{
    if(uart2Object->taskList.list)
    {
        //1.将任务列表的任务发送出去
        rt_device_write(*uart2Object->dev,
                        0,
                        uart2Object->taskList.list->keyData.dataSegment.data,
                        uart2Object->taskList.list->keyData.dataSegment.len);

        //2.将这个任务从任务列表中移出去
        uart2Object->taskList.DeleteToList(uart2Object->taskList.list->keyData);
    }
}

//处理返回数据的列表
void CheckListHandle(void)
{
    Node        *tail = uart2Object->checkList.list;
    device_t    *device;

    while(tail)
    {
        //Justin debug 仅仅测试 //判断数据是属于开关寄存器的还是类型寄存器
        if(REGISTER_CODE == tail->keyData.key)
        {
            //响应注册事件

        }
        else
        {
            device = GetDeviceByAddr(GetMonitor(), LongToSeqKey(tail->keyData.key).addr);

            if(device)
            {
                //判断是否是开关寄存器
                if(device->ctrl_addr ==
                        (LongToSeqKey(tail->keyData.key).regH << 8) | (LongToSeqKey(tail->keyData.key).regL))
                {
                    //判断寄存器的数量
                    if(1 == LongToSeqKey(tail->keyData.key).regSize)
                    {
                        //Justin debug  要增加一个对原始数据转化的函数
                        device->port[0].ctrl.d_state = (tail->keyData.dataSegment.data[4] << 8) | tail->keyData.dataSegment.data[5];
                    }
                    else
                    {
                        //Justin debug 还要判断多个寄存器的
                    }
                }
                //Justin debug 还要判断其他寄存器，比如类型寄存器
            }
        }

        tail = tail->next;
    }
}

//Justin debug以下要做互斥锁保护以防多线程导致实例化的对象有多个,单例模式
type_uart_class *GetUart2Object(void)
{
    if(RT_NULL == uart2Object)
    {
        uart2Object = rt_malloc(sizeof(type_uart_class));

        //1.接口实现
        if(RT_NULL != uart2Object)
        {
            //2.初始化相关数据
            uart2Object->dev = RT_NULL;
            uart2Object->checkList.list = RT_NULL;
            uart2Object->taskList.list = RT_NULL;

            //3.实例化相关接口
            uart2Object->ConfigureUart = ConfigureUart2;
            uart2Object->Ctrl = Uart2Ctrl;
            uart2Object->SendCmd = SendCmd;
            uart2Object->RecvCmd = RecvCmd;
            uart2Object->CheckListHandle = CheckListHandle;

            uart2Object->checkList.GetList = GetCheckList;       //获取核对关注列表
            uart2Object->checkList.AddToList = AddToCheckList;   //添加到关注列表中,数据接收的时候就
            uart2Object->checkList.DeleteToList = DeleteToCheckList;
            uart2Object->checkList.CheckDataCorrect = CheckDataInCheckList;
            uart2Object->checkList.KeyHasExist = KeyHasExistInCheckList;

            uart2Object->taskList.GetList = GetTaskList;       //获取核对关注列表
            uart2Object->taskList.AddToList = AddToTaskList;   //添加到关注列表中,数据接收的时候就
            uart2Object->taskList.DeleteToList = DeleteToTaskList;
            uart2Object->taskList.CheckDataCorrect = CheckDataInTaskList;
            uart2Object->taskList.KeyHasExist = KeyHasExistInTaskList;


            return uart2Object;
        }
    }
    else
    {
        return uart2Object;
    }

    return uart2Object;
}
