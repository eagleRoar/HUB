/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-01-12     Qiuyijie     the first version
 */

/*所有的设备类都需要在周期内发送询问状态等指令保持连接，设备的周期在10秒，从机询问周期要低于10秒，在6秒询问一次*/

#include "Uart.h"
#include "Ethernet.h"
#include "Command.h"
#include "InformationMonitor.h"
#include "UartDataLayer.h"
#include "UartBussiness.h"
#include "Sdcard.h"
#include "CloudProtocol.h"
#include "Module.h"
#include "Recipe.h"
#include "TcpProgram.h"
#include "Oled1309.h"
#include "OledBusiness.h"
#include "UartClass.h"
#include "SeqList.h"
#include "UartEventType.h"

__attribute__((section(".ccmbss"))) type_monitor_t monitor;
__attribute__((section(".ccmbss"))) u8 uart_task[1024 * 6];
__attribute__((section(".ccmbss"))) struct rt_thread uart_thread;

struct rx_msg uart1_msg;                      //接收串口数据以及相关消息
struct rx_msg uart2_msg;                      //接收串口数据以及相关消息
struct rx_msg uart3_msg;                      //接收串口数据以及相关消息

rt_device_t     uart2_serial;
rt_device_t     uart1_serial;
rt_device_t     uart3_serial;

/**
 * @brief  : 接收回调函数
 * @para   : dev   ：接收数据部分等
 *         : size  : 接收的数据长度
 * @author : Qiuyijie
 * @date   : 2022.01.12
 */
static rt_err_t Uart1_input(rt_device_t dev, rt_size_t size)
{
    u16 crc16 = 0x0000;

    uart1_msg.dev = dev;
    uart1_msg.size = size;
    rt_device_read(uart1_msg.dev, 0, uart1_msg.data, uart1_msg.size);

    if(2 > size)
    {
        return RT_ERROR;
    }
    crc16 |= uart1_msg.data[uart1_msg.size-1];
    crc16 <<= 8;
    crc16 |= uart1_msg.data[uart1_msg.size-2];
    if(crc16 == usModbusRTU_CRC(uart1_msg.data, uart1_msg.size - 2))
    {
        uart1_msg.messageFlag = ON;
        return RT_EOK;
    }
    else
    {
        return RT_ERROR;
    }
}

static rt_err_t Uart2_input(rt_device_t dev, rt_size_t size)
{
    u16 crc16 = 0x0000;

    uart2_msg.dev = dev;
    uart2_msg.size = size;
    rt_device_read(uart2_msg.dev, 0, uart2_msg.data, uart2_msg.size);

//    for(u8 i = 0; i < uart2_msg.size; i++)
//    {
//        rt_kprintf("%x ",uart2_msg.data[i]);
//    }
//    rt_kprintf("\r\n");

    if(2 > size)
    {
        return RT_ERROR;
    }
    crc16 |= uart2_msg.data[uart2_msg.size-1];
    crc16 <<= 8;
    crc16 |= uart2_msg.data[uart2_msg.size-2];
    if(crc16 == usModbusRTU_CRC(uart2_msg.data, uart2_msg.size - 2))
    {
        uart2_msg.messageFlag = ON;
        return RT_EOK;
    }
    else
    {
        return RT_ERROR;
    }
}

static rt_err_t Uart3_input(rt_device_t dev, rt_size_t size)
{
    u16 crc16 = 0x0000;

    uart3_msg.dev = dev;
    uart3_msg.size = size;
    rt_device_read(uart3_msg.dev, 0, uart3_msg.data, uart3_msg.size);

    if(2 > size)
    {
        return RT_ERROR;
    }
    crc16 |= uart3_msg.data[uart3_msg.size-1];
    crc16 <<= 8;
    crc16 |= uart3_msg.data[uart3_msg.size-2];
    if(crc16 == usModbusRTU_CRC(uart3_msg.data, uart3_msg.size - 2))
    {
        uart3_msg.messageFlag = ON;
        return RT_EOK;
    }
    else
    {
        return RT_ERROR;
    }
}

//注册串口
void UartRegister(void)
{
    /* 查找串口设备 */
    uart1_serial = rt_device_find(DEVICE_UART1);
    rt_device_open(uart1_serial, RT_DEVICE_FLAG_DMA_RX);
    rt_device_set_rx_indicate(uart1_serial, Uart1_input);

    uart2_serial = rt_device_find(DEVICE_UART2);
    rt_device_open(uart2_serial, RT_DEVICE_FLAG_DMA_RX);
    rt_device_set_rx_indicate(uart2_serial, Uart2_input);

    uart3_serial = rt_device_find(DEVICE_UART3);
    rt_device_open(uart3_serial, RT_DEVICE_FLAG_DMA_RX);
    rt_device_set_rx_indicate(uart3_serial, Uart3_input);
}

void uart2Test()
{
    type_uart_class             *uart2          = GetUart2Object();
    u8                          test[8];

    test[0] = 0x01;
    test[1] = 0x06;
    test[2] = 0x01;
    test[3] = 0x00;
//            if(cnt++ % 2)
    {
        test[4] = 0x61;
    }
//            else
//            {
//                test[4] = 0x60;
//            }
    test[5] = 0;
    test[6] = usModbusRTU_CRC(test, 6);
    test[7] = usModbusRTU_CRC(test, 6) >> 8;

    uart2->Ctrl(test[0], 0x0100, &test[4], 1);
}

/**
 * @brief  : 传感器类串口线程入口
 */
void SensorUart2TaskEntry(void* parameter)
{
    static      u8              Timer1sTouch    = OFF;
    static      u8              Timer3sTouch    = OFF;
    static      u8              Timer60sTouch   = OFF;
    static      u16             time1S = 0;
    static      u16             time3S = 0;
    static      u16             time60S = 0;
    static      u8              cnt     = 0;
    type_uart_class             *uart2          = GetUart2Object();
    KV          testKv;

    UartRegister();
    //需要指定device
    uart2->ConfigureUart(&uart2_serial);

    while (1)
    {
        time1S = TimerTask(&time1S, 1000/UART_PERIOD, &Timer1sTouch);                       //1s定时任务
        time3S = TimerTask(&time3S, 3000/UART_PERIOD, &Timer3sTouch);                       //3s定时任务
        time60S = TimerTask(&time60S, 60000/UART_PERIOD, &Timer60sTouch);                   //5s定时任务

        //测试
        if(ON == uart2_msg.messageFlag)
        {
            uart2->RecvCmd(uart2_msg.data, uart2_msg.size);
            uart2_msg.messageFlag = OFF;
        }

        //50ms 任务
        {
            if(OFF == uart2_msg.messageFlag)
            {
                //实际发送串口
                uart2->SendCmd();
                //
            }
        }

        if(ON == Timer1sTouch)
        {
            uart2Test();
            uart2->CheckListHandle();
        }

        rt_thread_mdelay(UART_PERIOD);
    }
}

/**
 * @brief  : 传感器类串口线程
 * @para   : NULL
 * @author : Qiuyijie
 * @date   : 2022.01.17
 */
void SensorUart2TaskInit(void)
{
    if(RT_EOK != rt_thread_init(&uart_thread, UART_TASK, SensorUart2TaskEntry, RT_NULL, uart_task, sizeof(uart_task), UART_PRIORITY, 10))
    {
        LOG_E("uart thread fail");
    }
    else
    {
        rt_thread_startup(&uart_thread);
    }
}

void initMonitor(void)
{
    rt_memset((u8 *)&monitor, 0, sizeof(type_monitor_t));
    monitor.crc = usModbusRTU_CRC((u8 *)&monitor, sizeof(type_monitor_t) - 2);
}

type_monitor_t *GetMonitor(void)
{
    return &monitor;
}
