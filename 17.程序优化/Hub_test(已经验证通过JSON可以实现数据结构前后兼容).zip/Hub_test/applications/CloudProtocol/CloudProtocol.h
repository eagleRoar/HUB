/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-06-08     Administrator       the first version
 */
#ifndef APPLICATIONS_CLOUDPROTOCOL_CLOUDPROTOCOL_H_
#define APPLICATIONS_CLOUDPROTOCOL_CLOUDPROTOCOL_H_

#include "Gpio.h"
#include "mqtt_client.h"
#include "CloudProtocolBusiness.h"
#include "TcpProgram.h"

#pragma pack(4)//因为cjson 不能使用1字节对齐

typedef void(*PAGE_CB)(u8);

void initCloudSet(void);
void initCloudProtocol(void);
char *GetSnName(char *,u8);
void tempProgram(type_monitor_t *);
void timmerProgram(type_monitor_t *);
void co2Program(type_monitor_t *, u16);
void humiProgram(type_monitor_t *);
//void warnProgram(type_monitor_t *, sys_set_t *);
void analyzeCloudData(char *,u8 );
rt_err_t ReplyDataToCloud(mqtt_client *, u8 *, u16 *, u8);
hub_t *GetHub(void);
rt_err_t SendDataToCloud(mqtt_client *, char *, u8 , u16 , u8 *, u16 *, u8, u8);
void lineProgram(type_monitor_t *, u8, u16);
void lineProgram_new(type_monitor_t *, u8 , u16);
time_t ReplyTimeStamp(void);
u16 getVpd(void);
void initSysTank(void);
time_t changeTmTotimet(struct tm *);
struct tm* getTimeStampByDate(time_t *);
//void pumpProgram(type_monitor_t *, sys_tank_t *);
void pumpDoing(u8, u8);
//void GetNowSysSet(proTempSet_t *, proCo2Set_t *, proHumiSet_t *, proLine_t *, proLine_t *);
struct sys_tank *GetSysTank(void);
void initOfflineFlag(void);
void initHubinfo(void);
struct sysSet *GetSysSet(void);
void autoBindPumpTotank(type_monitor_t *, struct sys_tank *);
u8 *ReplyDataToCloud1(mqtt_client *, u8 *,u16 *, u8);
void co2Calibrate(type_monitor_t *monitor, int *data, u8 *do_cal_flg, u8 *saveFlg, PAGE_CB cb);
void sendwarnningInfo(void);
void sendOfflinewarnning(type_monitor_t *);
void resetSysSetPhCal(u32);
void resetSysSetEcCal(u32);
//void autoValveClose(type_monitor_t *, sys_tank_t *);
#endif /* APPLICATIONS_CLOUDPROTOCOL_CLOUDPROTOCOL_H_ */
