/*
 * Copyright (c) 2006-2022, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-01-07     Qiuyijie    first version
 */

#include <rtthread.h>
#include "Gpio.h"
#include "Ethernet.h"
#include "Oled1309.h"
#include "SDCard.h"
#include "Uart.h"
#include "Spi.h"
#include "ButtonTask.h"
#include "UartDataLayer.h"
#include "mqtt_client.h"
#include "CloudProtocol.h"
#include "module.h"
#include "TcpProgram.h"

#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>

extern struct ethDeviceStruct *eth;
extern int tcp_sock;
extern const u8    HEAD_CODE[4];

extern rt_uint8_t GetEthDriverLinkStatus(void);            //获取网口连接状态

int main(void)
{
    rt_uint8_t      ethStatus           = LINKDOWN;
    u16             length              = 0;
    u8              *buf                = RT_NULL;
    u8              res                 = 0;
    static u8       sensor_size         = 0;
    static u8       device_size         = 0;
    static u8       line_size           = 0;
    static u8       cnt                 = 0;
    static u8       start_warn_flg      = NO;
    static u8       Timer100msTouch     = OFF;
    static u8       Timer1sTouch        = OFF;
    static u8       Timer10sTouch       = OFF;
    static u8       Timer60sTouch       = OFF;
    static u8       TimerInitTouch      = OFF;
    static u16      time100mS           = 0;
    static u16      time1S              = 0;
    static u16      time10S             = 0;
    static u16      time60S             = 0;
    static u16      timeInit            = 0;
    type_sys_time   time;

    //初始化GPIO口
    GpioInit();

    //灯光
//    LedTaskInit();
//
//    //按键线程初始化
//    ButtonTaskInit();
//
//    //oled1309屏线程初始化
//    OledTaskInit();
//
//    //等待网络部分初始化完成 */
//    do {
//        timeInit = TimerTask(&timeInit, 100, &TimerInitTouch);         //10秒任务定时器
//        ethStatus = GetEthDriverLinkStatus();
//        LOG_D("waitting for eth init...");
//
//        if(ON == TimerInitTouch)
//        {
//            LOG_E("Ethernet divice init fail......");
//            break;
//        }
//        rt_thread_mdelay(100);
//    } while (LINKDOWN == ethStatus);
//
//    if(LINKUP == ethStatus)
//    {
//        /*初始化网络线程，处理和主机之间的交互，Tcp和Udp协议*/
//        EthernetTaskInit();
//    }
//
    rt_thread_mdelay(10000);//Justin debug
    //初始化SD卡处理线程
    SDCardTaskInit();
//
    //初始化串口接收传感器类线程
    SensorUart2TaskInit();
//
//    //MQTT线程
//    mqtt_start();

    while(1)
    {
        time100mS = TimerTask(&time100mS, 5, &Timer100msTouch);             //100毫秒任务定时器
        time1S = TimerTask(&time1S, 50, &Timer1sTouch);                     //1秒任务定时器
        time10S = TimerTask(&time10S, 500, &Timer10sTouch);                 //1秒任务定时器
        time60S = TimerTask(&time60S, 3000, &Timer60sTouch);                //60秒任务定时

        rt_thread_mdelay(20);
    }

    return RT_EOK;
}


void ReadUniqueId(u32 *id)
{
    u8      data[12]    = {0};
    u32     id1         = 0;
    u32     id2         = 0;
    u32     id3         = 0;

    id1 = *(__IO u32*)(ID_ADDR1);
    id2 = *(__IO u32*)(ID_ADDR2);
    id3 = *(__IO u32*)(ID_ADDR3);

    rt_memcpy(&data[0], (u8 *)&id1, 4);
    rt_memcpy(&data[4], (u8 *)&id2, 4);
    rt_memcpy(&data[8], (u8 *)&id3, 4);

    *id = crc32_cal(data, 12);
}

/**
 * @brief  : 计时器功能
 * @param  : time      计时器
 * @param  : touchTime 实际上定时的时间,单位ms
 * @param  ：flag ON 定时器到了; OFF 还未达到定时器设定时间
 * @return : 当前的计时器数
 */
u16 TimerTask(u16 *time, u16 touchTime, u8 *flag)
{
    u16 temp = 0;

    temp = *time;

    if(*time < touchTime)
    {
        temp++;
        *time = temp;
        *flag = OFF;
    }
    else
    {
        *flag = ON;
        *time = 0;
    }

    return *time;
}

/*
 * INPUT:
 * pucData: input the data for CRC16
 * ulLen : the length of the data
 *
 * OUTPUT: the value for (CRC16)
*/
u16 usModbusRTU_CRC(const u8* pucData, u32 ulLen)
{
    u8 ucIndex = 0U;
    u16 usCRC = 0xFFFFU;

    while (ulLen > 0U) {
        usCRC ^= *pucData++;
        while (ucIndex < 8U) {
            if (usCRC & 0x0001U) {
                usCRC >>= 1U;
                usCRC ^= 0xA001U;
            } else {
                usCRC >>= 1U;
            }
            ucIndex++;
        }
        ucIndex = 0U;
        ulLen--;
    }
    return usCRC;
}


