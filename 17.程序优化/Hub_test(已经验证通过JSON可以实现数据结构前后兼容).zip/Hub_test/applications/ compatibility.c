/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-01-13     Administrator       the first version
 */

#include "compatibility.h"
#include "SDCardBusiness.h"
#include "CloudProtocolBusiness.h"

extern u8 CheckDirectory(char*);

//存入版本2
void saveToSDTest()
{
    jtest2 test;
    char    *str        = RT_NULL;
    cJSON *json = cJSON_CreateObject();

    strncpy(test.name,"hell",5);
    strncpy(test.name1,"o",2);
    test.age = 20;

    CheckDirectory(CJSON_DIR);

    if(json)
    {
        cJSON_AddStringToObject(json, "name", test.name);
        cJSON_AddStringToObject(json, "name1", test.name1);
        cJSON_AddNumberToObject(json, "age", test.age);

        str = cJSON_PrintUnformatted(json);
        cJSON_Delete(json);

        LOG_I("saveToSDTest memory = %d",rt_strlen(str));

        //1.save to sd
        if(RT_EOK == WriteSdData(CJSON_FILE, (u8 *)str, 0, rt_strlen(str)))
        {
            LOG_W("----------------------------- save test ok");
        }
    }

}

//向前兼容
void readFromSDtest_Forward()
{
    u8 data[100];//Justin debug 仅仅测试 暂时使用
    jtest1 test;
    cJSON *json = RT_NULL;

    if(RT_EOK == ReadSdData(CJSON_FILE, data, 0, 100))
    {
        json = cJSON_Parse(data);

        if(json)
        {
            GetValueByC16(json, "name", test.name, 5);
            GetValueByInt(json, "age", &test.age);

            cJSON_Delete(json);
        }
    }

    LOG_D("-----------name = %s",test.name);
    LOG_D("-----------age = %d",test.age);
}

//向后兼容
void readFromSDtest_Backward()
{
    u8 data[100];//Justin debug 仅仅测试 暂时使用
    jtest3 test;
    cJSON *json = RT_NULL;

    rt_memset(&test, 0, sizeof(jtest3));

    if(RT_EOK == ReadSdData(CJSON_FILE, data, 0, 100))
    {
        json = cJSON_Parse(data);

        if(json)
        {
            GetValueByC16(json, "name", test.name, 5);
            GetValueByC16(json, "name1", test.name1, 2);
            GetValueByInt(json, "age", &test.age);
            GetValueByU8(json, "num", &test.num);

            cJSON_Delete(json);
        }
    }

    LOG_D("---------------name = %s",test.name);
    LOG_D("---------------name1 = %s",test.name1);
    LOG_D("---------------age = %d",test.age);
    LOG_D("---------------num = %d",test.num);
}
