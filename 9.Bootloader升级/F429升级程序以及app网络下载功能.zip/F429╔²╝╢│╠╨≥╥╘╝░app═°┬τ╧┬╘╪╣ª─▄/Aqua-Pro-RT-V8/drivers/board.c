/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-07-16     RealThread   first version
 */

#include <board.h>
#include <drv_common.h>
#include <rtthread.h>

/* Justin debug 添加一下代码，为了偏移开始地址*/
#define RT_APP_PART_ADDR 0x08020000
/**
* Justin debug
Function ota_app_vtor_reconfig
Description Set Vector Table base location to the start addr of app(RT_APP_PART_ADDR).
*/
static int ota_app_vtor_reconfig(void)
{

#define NVIC_VTOR_MASK 0x3FFFFF80
/* Set the Vector Table base location by user application firmware definition */
SCB->VTOR = RT_APP_PART_ADDR & NVIC_VTOR_MASK;

return 0;
}
INIT_BOARD_EXPORT(ota_app_vtor_reconfig);

RT_WEAK void rt_hw_board_init()
{
    extern void hw_board_init(char* clock_src, int32_t clock_src_freq, int32_t clock_target_freq);

    /* Heap initialization */
#if defined(RT_USING_HEAP)
    rt_system_heap_init((void*)HEAP_BEGIN, (void*)HEAP_END);
#endif

    hw_board_init(BSP_CLOCK_SOURCE, BSP_CLOCK_SOURCE_FREQ_MHZ, BSP_CLOCK_SYSTEM_FREQ_MHZ);

    /* Set the shell console output device */
#if defined(RT_USING_DEVICE) && defined(RT_USING_CONSOLE)
    rt_console_set_device(RT_CONSOLE_DEVICE_NAME);
#endif

    /* Board underlying hardware initialization */
#ifdef RT_USING_COMPONENTS_INIT
    rt_components_board_init();
#endif
}

#if 0
#include <rtdevice.h>
#include "uuzGPIO.h"
void phy_reset(void)
{
    rt_pin_mode(ETH_RST_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(ETH_RST_PIN, PIN_HIGH);
    rt_thread_mdelay(50);
    rt_pin_write(ETH_RST_PIN, PIN_LOW);
    rt_thread_mdelay(50);
    rt_pin_write(ETH_RST_PIN, PIN_HIGH);
}
#endif
