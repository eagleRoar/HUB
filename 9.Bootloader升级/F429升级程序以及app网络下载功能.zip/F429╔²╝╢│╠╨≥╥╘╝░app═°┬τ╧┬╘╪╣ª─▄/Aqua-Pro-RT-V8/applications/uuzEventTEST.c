/*
 * @Copyright (c) 2006-2018 RT-Thread Development Team:  
 * @SPDX-License-Identifier: Apache-2.0:  
 * @Date: 2020-01-01 09:23:03
 * @LastEditors  : Zhou Xiaomin
 * @LastEditTime : 2020-01-17 01:39:48
 * @Note:  
 */
/*include***********************************************************************/
#include <rtthread.h>
#include <string.h>
/******************************************************************************/
#include "uuzOpt.h"
#include "uuzEVENT.h"
#include "uuzINIT.h"
#include "uuzHMI_UI.h"
/******************************************************************************/
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
/******************************************************************************/
#include "uuzConfigDEV.h"
#include "uuzDevID.h"
#include "uuzEventDevID.h"
/******************************************************************************/
#include "uuzEventTEST.h"
/*log----------------------------------------------------------*/
#define DBG_TAG "e.test"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/******************************************************************************/
#if (_TEST_DATA)
/**
 * @brief:  初始化测试相关操作反馈函数，每500ms一个循环
 * @returns:  int
 */
int test_rp_init(void)
{
    rt_err_t ret = RT_EOK;
    /* 创建界面刷新事件事件内容 */
    eventTEST = rt_event_create("text ent", RT_IPC_FLAG_FIFO);
    /* 创建 serial 线程 */
    rt_thread_t thread = rt_thread_create("ttt_rd", test_rp_thread_entry,
    RT_NULL, 2048, (RT_THREAD_PRIORITY_MAX * 2 / 3 - 1), 20);

    /* 创建成功则启动线程 */
    if (thread != RT_NULL) {
        rt_thread_startup(thread);
        LOG_I("start Thread [test reply]");
    } else {
        LOG_E("start Thread [test reply] failed");
        ret = RT_ERROR;
    }

    return ret;
}

/**
 * @brief 设备读取传感器数据和设备状态函数
 * 
 * @param parameter 
 */
void test_rp_thread_entry(void* parameter)
{
    static u32 countSync = 0;

    while (1) {
        //UI初始化状态
        if (xSysSTA.hmi_init >= 5) {
            //测试数据反馈
            hmi_test_cache_sync();  //同步相关数据
            countSync++;
        }
        xSysSTA.test_data[19] = countSync;
        //每个循环500ms
        rt_thread_delay(500);
    }
}

/**
 * @brief 显示测试数据的状态
 */
void hmi_test_cache_sync(void)
{
    char cmd[10];

    //n0-n19
    for (u8 index = 0; index < 20; index++) {
        rt_sprintf(cmd, "n%d", index);
        hmi_val_send("val", cmd, xSysSTA.test_data[index]);
    }

    //n20-n29
    hmi_val_send("val", "n20", xSysSTA.hmi_init);
    hmi_val_send("val", "n21", xSysSTA.progRunning);
    hmi_val_send("val", "n22", xSysSTA.state_brd[0]);
    hmi_val_send("val", "n28", xSysCFG.dynamic_id);
    hmi_val_send("val", "n29", xSysCFG.fixed_id);
}
#endif
