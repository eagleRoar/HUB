/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-07-16     RT-Thread    first version
 */

/*rtthread-include---------------------------------------------*/
#include <rtthread.h>
/*user-include---------------------------------------------*/
#include <uuzGPIO.h>
#include <uuzRTC.h>
#include <uuzINIT.h>
#include <uuzPIN.h>
#include "uuzHMI_UI.h"
#include <uuzEventTCP.h>
/*define---------------------------------------------*/
#define uuzRUNNING_COUNT (360)
/*log---------------------------------------------*/
#define DBG_TAG "u.main"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/*extern---------------------------------------------*/
extern int clock_information(void);
extern void GetUpdataFileFromWeb(void);//Justin debug
/*private---------------------------------------------*/
//定义信号控制量
void uuz_main(u32 count);
/*function---------------------------------------------*/
/**
 * @brief 打印相关调试信息
 * @param count
 */
void uuz_main(u32 count)
{
    if ((count > 0) && ((count - 1) % uuzRUNNING_COUNT == 0)) {
        rt_rtc_info();      //RTC时钟信息
    }
}

/**
 * @brief 主线程
 * @return
 */
int main(void)
{

    clock_information();  //输出系统时钟
    rt_gpio_init();  //初始化GPIO端口
    hmi_hw_reset();  //重启HMI屏幕
    rt_rtc_get();  //获取当前时间
    local_config_init();  //初始化参数配置
    rt_thread_mdelay(5000);//网络部分必要的延时时间
    GetUpdataFileFromWeb();//Justin debug
    int count = 1;
    while (count++) {  //进入定时循环状态
        rt_rtc_get();    //每秒获取同步一次时间
        uuz_main(count);    //时间定时检测函数
        auto_lock_sync();   //自动锁定逻辑判断
        //pause_state_sync();  //暂停自动时间计算
        if (count == 2) {    //启动第2秒后打印初始化提示
            LOG_I("----->Start Running Program!<-------");
        }

        rt_thread_mdelay(1000);    //定时延时1000ms
    }

    return RT_EOK;
}
