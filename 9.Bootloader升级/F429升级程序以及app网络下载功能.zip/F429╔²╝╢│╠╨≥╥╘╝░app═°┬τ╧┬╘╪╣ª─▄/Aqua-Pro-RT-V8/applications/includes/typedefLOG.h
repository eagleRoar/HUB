/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-01   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_LOG_H
#define __TYPEDEF_LOG_H

#include "board.h"
#include "typedefBASE.h"

#define uuzLOGS_TIME_MAX (10U) //10分钟1次
#define uuzLOGS_LIST_MAX (24 * 60 / 10) //最多存255个数据

enum {
    _LOGS_SYS = 0U, //系统日志
    _LOGS_OPT, //操作日志
    _LOGS_ALM, //报警日志
    _LOGS_DEV1, //数据信息-1
    //_LOGS_DEV2, //数据信息-2
    //_LOGS_DEV3, //数据信息-3
    //_LOGS_DEV4, //数据信息-4
    _LOGS_LV1, //水位信息-1
    _LOGS_LV2, //水位信息-2
    _LOGS_LV3, //水位信息-3
    _LOGS_MAX
};

#define uuzLOG_D_LEN (10U)

//数据记录
typedef struct logs_t {
    u16 n; //0~65535
    u8 d[uuzLOGS_LIST_MAX][uuzLOG_D_LEN]; //0~255 * 10

} LOGS_Typedef_t;

#define uuzLOGS_T_LEN (sizeof(LOGS_Typedef_t))

#endif // __TYPEDEF_LOG_H
