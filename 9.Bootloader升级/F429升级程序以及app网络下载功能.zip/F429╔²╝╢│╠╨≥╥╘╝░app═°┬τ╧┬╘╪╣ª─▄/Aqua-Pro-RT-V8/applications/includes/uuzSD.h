/*
 * @Copyright (c) 2006-2018 RT-Thread Development Team:  
 * @SPDX-License-Identifier: Apache-2.0:  
 * @Change Logs: 
 * @Date: 2020-02-11 08:54:29
 * @LastEditors: Zhou Xiaomin
 * @LastEditTime : 2020-02-14 15:20:55
 * @Description:  
 */
#ifndef UUZ_SDIO_H
#define UUZ_SDIO_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief SD处理线程初始化
 * @return
 */
int sd_dfs_event_init(void);

/**
 * @brief SD卡相关处理处理事件
 *
 * @param parameter
 */
void sd_dfs_event_entry(void* parameter);

/**
 * @brief SD卡相关处理处理事件
 *
 * @param parameter
 */
void sd_log_event_entry(void* parameter);

/**
 * @brief 读取SD卡相关信息，如果是低电平，表示SD正常
 * 
 * @return int SD正常：返回1；SD卡异常，返回0
 */
int sd_card_is_vaild(void);

/**
 * @brief 检测dfs文件环境，如果没有相应文件夹，则重新建立
 * 
 * @return int 返回操作是否成功（如果失败会重试3次
 */
int sd_dfs_init(void);

/**
 * @brief 初始化文件系统
 * 
 */
void sd_file_init(void);

/**
 * @brief 检测文件夹是否存在，如果不存在，则新建相应文件夹
 * 
 * @param name 需要新建的文件夹名称
 */
u8 rt_access_dir(char* name);

/**
 * @brief 检测文件是否存在,并获取文件长度
 * @param name:相关文件名称
 * @return 返回相关文件长度
 */
u32 length_file(char* name);

/**
 * @brief 创建数据文件
 *
 * @param name 写入的文件名称
 * @param text 写入数据的数量
 * @param l 写入默认数据长度
 * @return
 */
u8 create_log_data(char* name, u8* text, u32 l);

/**
 * @brief 将数据写入相应的LOG文件
 *
 * @param name
 * @param text
 */
u8 write_log_data(char* name, u8* text, u32 l);

/**
 * @brief 从文件中读取到固定位置的数据
 * 
 * @param name 需要读取的文件
 * @param text 返回的数据
 * @param s 文件读取的起始位置
 * @param l 文件读取的长度
 * @return u8 
 */
u8 read_log_data(char* name, u8* text, u32 l);
#ifdef __cplusplus
}
#endif
#endif // UUZ_SDIO_H
