#ifndef __UUZ_CONFIG_EEPROM_H
#define __UUZ_CONFIG_EEPROM_H

#include <rtthread.h>
#include "uuzConfigDEV.h"
#include "typedefIRR.h"
#include "typedefPROG.h"
#include "typedefBRD.h"
#include "typedefCFG.h"
#include "typedefLGT.h"
#include "typedefVALVE.h"

//----------->I2C Device Address<--------------
#define uuzEEPROM_I2C_BUS_NAME "i2c2" /* 传感器连接的I2C总线设备名称 */
#define uuzREBOOT_COUNT (3U) //i2c重启次数
//----------->System Config Address<--------------
#define uuzEEPROM_ADDR_SYSTEM (0U) //Addr:256bytes
#define uuzEEPROM_ADDR_HMI (uuzEEPROM_ADDR_SYSTEM + 256) //Addr:128bytes
//----------->Device ID Map<---------------
#define uuzEEPROM_ADDR_MAP (uuzEEPROM_ADDR_HMI + 128) //LEN:1024bytes (实际大小: 64 * 16 = 1024 | 1K)
//----------->Config Address<--------------
#if 0
#define uuzEEPROM_ADDR_CFG (uuzEEPROM_ADDR_MAP + 1024) //LEN:3584bytes
#define uuzEEPROM_ADDR_PROG (uuzEEPROM_ADDR_CFG)
#define uuzEEPROM_ADDR_IRRCFG (uuzEEPROM_ADDR_PROG + uuzPROG_CONFIG_LEN)
#define uuzEEPROM_ADDR_AERO (uuzEEPROM_ADDR_IRRCFG + uuzIRR_CONFIG_LEN)
#define uuzEEPROM_ADDR_TOPFEED (uuzEEPROM_ADDR_AERO + uuzIRR_AERO_LEN)
#define uuzEEPROM_ADDR_FLOWEBB (uuzEEPROM_ADDR_TOPFEED + uuzIRR_TOPFEED_LEN)
#define uuzEEPROM_ADDR_IRRCUSTOM (uuzEEPROM_ADDR_FLOWEBB + uuzIRR_FLOW_EBB_LEN)
#define uuzEEPROM_ADDR_LGTCUSTOM (uuzEEPROM_ADDR_IRRCUSTOM + uuzIRR_CUSTOM_LEN)
#define uuzEEPROM_ADDR_VALVE (uuzEEPROM_ADDR_LGTCUSTOM + uuzLGT_CUSTOM_LEN)
#define uuzEEPROM_ADDR_AUX (uuzEEPROM_ADDR_VALVE + uuzVALVE_CONFIG_LEN)
#define uuzEEPROM_ADDR_SCH (uuzEEPROM_ADDR_AUX + uuzAUX_CONFIG_LEN)
#else
#define uuzEEPROM_ADDR_CFG (uuzEEPROM_ADDR_MAP + 1024) //LEN:3584bytes
#define uuzEEPROM_ADDR_DATA (uuzEEPROM_ADDR_CFG + uuzCONFIG_DATA_LEN)
#define uuzEEPROM_ADDR_PROG (uuzEEPROM_ADDR_CFG)
#define uuzEEPROM_ADDR_IRRCFG (uuzEEPROM_ADDR_PROG + uuzPROG_CONFIG_LEN)
//#define uuzEEPROM_ADDR_AERO (uuzEEPROM_ADDR_IRRCFG + uuzIRR_CONFIG_LEN)
//#define uuzEEPROM_ADDR_TOPFEED (uuzEEPROM_ADDR_AERO + uuzIRR_AERO_LEN)
//#define uuzEEPROM_ADDR_FLOWEBB (uuzEEPROM_ADDR_TOPFEED + uuzIRR_TOPFEED_LEN)
//#define uuzEEPROM_ADDR_IRRCUSTOM (uuzEEPROM_ADDR_FLOWEBB + uuzIRR_FLOW_EBB_LEN)
//#define uuzEEPROM_ADDR_LGTCUSTOM (uuzEEPROM_ADDR_IRRCUSTOM + uuzIRR_CUSTOM_LEN)
#define uuzEEPROM_ADDR_LGTCUSTOM (uuzEEPROM_ADDR_IRRCFG + uuzPROG_CONFIG_LEN)
//#define uuzEEPROM_ADDR_VALVE (uuzEEPROM_ADDR_LGTCUSTOM + uuzLGT_CUSTOM_LEN)
#define uuzEEPROM_ADDR_AUX (uuzEEPROM_ADDR_VALVE + uuzVALVE_CONFIG_LEN)
#define uuzEEPROM_ADDR_SCH (uuzEEPROM_ADDR_AUX + uuzAUX_CONFIG_LEN)
//-----------------
//      MAP ID
//     1024bytes
//-----------------
//      CFG
//     310bytes
//-----------------
//      BRD
//     1024bytes
//-----------------
#endif

#endif // __UUZ_CONFIG_EEPROM_H
