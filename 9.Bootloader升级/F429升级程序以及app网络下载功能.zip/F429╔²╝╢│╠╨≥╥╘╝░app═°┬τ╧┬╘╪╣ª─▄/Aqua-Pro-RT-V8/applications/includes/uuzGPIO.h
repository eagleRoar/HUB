/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-26   ZhouXiaomin     first version
 */

#ifndef _UUZ_GPIO_H_
#define _UUZ_GPIO_H_

//#include "uuzUart_Config.h"
#include <board.h>

/* EXT的IO设置 */
#define EXT1_PIN GET_PIN(E, 9)
#define EXT2_PIN GET_PIN(E, 8)
#define EXT3_PIN GET_PIN(E, 7)
#define EXT4_PIN GET_PIN(G, 1)
#define EXT5_PIN GET_PIN(G, 0)
#define EXT6_PIN GET_PIN(F, 15)
#define EXT7_PIN GET_PIN(F, 14)
#define EXT8_PIN GET_PIN(F, 13)
#define EXT9_PIN GET_PIN(F, 12)
#define EXT10_PIN GET_PIN(F, 11)

#if defined(uuzCONFIG_USART_RS485_OPT_ENABLE)
/* RS485的上升脚位 */
#define RS485_CLK_PIN GET_PIN(B, 12)
#endif
/* HMI的启动设置 */
#define HMI_RST_PIN GET_PIN(B, 12)
/* 扬声器的设置 */
#define BEEP_PIN GET_PIN(D, 1)
/* 网口初始化 */
#define ETH_RST_PIN GET_PIN(A, 0)
/* WIFI初始化 */
#define WIFI_RST_PIN GET_PIN(G, 10)
/* SD检测初始化 */
#define SD_INT_PIN GET_PIN(A, 15)
#define SD_CHK_PIN GET_PIN(G, 9)
/* 启动初始化*/
#define BOOT_PIN GET_PIN(B, 2)

#ifdef __cplusplus
extern "C" {
#endif

/**
 *
 * @brief GPIO的状态初始化
 */
void rt_gpio_init(void);

#ifdef __cplusplus
}
#endif

#endif /* _UUZ_GPIO_H_ */
