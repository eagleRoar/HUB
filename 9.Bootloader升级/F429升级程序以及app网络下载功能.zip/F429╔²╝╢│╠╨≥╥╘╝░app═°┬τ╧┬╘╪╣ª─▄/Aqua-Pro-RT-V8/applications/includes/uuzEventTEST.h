/*
 * @Copyright (c) 2006-2018 RT-Thread Development Team:  
 * @SPDX-License-Identifier: Apache-2.0:  
 * @Date: 2020-01-01 09:23:03
 * @LastEditors  : Zhou Xiaomin
 * @LastEditTime : 2020-01-06 14:36:52
 * @Description:  
 */
#ifndef __UUZ_TEST_EVENT_H
#define __UUZ_TEST_EVENT_H

#include <board.h>

#define _TEST_DATA (0U)

#ifdef __cplusplus
extern "C" {
#endif

#if (_TEST_DATA)
//测试相关数据数据读取
int test_rp_init(void);
void test_rp_thread_entry(void* parameter);
#endif

#ifdef __cplusplus
}
#endif

#endif // __UUZ_TEST_EVENT_H
