/*
 * @Copyright (c) 2006-2018 RT-Thread Development Team:  
 * @SPDX-License-Identifier: Apache-2.0:  
 * @Change Logs: 
 * @Date: 2020-02-11 08:54:29
 * @LastEditors: Zhou Xiaomin
 * @LastEditTime : 2020-02-14 15:20:55
 * @Description:  
 */
#ifndef UUZ_LOG_H
#define UUZ_LOG_H

#include "typedefLOG.h"
#include "typedefPHEC.h"

extern LOGS_Typedef_t logs[_LOGS_MAX];

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 获取文件的数据数量
 * 
 * @param name 需要获取数据的文件名称
 * @return u32 返回数据的内容数量
 */
u32 file_list_get(u8 tlog, char* num);
/**
 * @brief Get the file name object
 *
 * @param tlog log类型
 * @param y 年份
 * @param m 月份
 * @param d 天数据
 * @param id 设备编号
 * @param name 返回的文件名
 */
void get_file_name(u8 tlog, int y, int m, int d, int id, char* name);

/**
 * @brief 系统数据生成并保存
 * 
 * @param state 
 * @param state: 0-poweroff;1-reboot
 * @return u8 写入成功返回 RT_EOK
 */
u8 save_data_by_sys(u8 state);

/**
 * @brief 读取相关系统相关数据
 *
 * @return 返回是否保存成功记录,成功为RT_EOK
 */
u8 read_data_by_sys(u32 y);

/**
 * @brief 读取文件中的相关数据
 * 
 * @param num 
 * @param cmd 
 * @return u8 
 */
u8 sys_data_read(void);

/**
 * @brief 保存相关记录操作数据生成
 *
 * @param opt:01-Dosing/02-220V/03-24V
 * @param state:00-OFF/01-ON
 * @return 返回是否保存成功记录,成功为RT_EOK
 */
u8 save_data_by_opt(u8 opt, u8 state);

/**
 * @brief 读取相关操作数据
 *
 * @param y:年份
 * @param m:月份
 * @return 返回是否保存成功记录,成功为RT_EOK
 */
u8 read_data_by_opt(u32 y, u32 m);

/**
 * @brief 保存相关记录报警数据生成
 *
 * @param alm
 * @param state:00-OFF/01-ON
 * @return 返回是否保存成功记录,成功为RT_EOK
 */
u8 save_data_by_alm(u8 alm, u8 state);

/**
 * @brief 读取相关报警数据
 *
 * @param y:年份
 * @param m:月份
 * @return 返回是否保存成功记录,成功为RT_EOK
 */
u8 read_data_by_alm(u32 y, u32 m);

/**
 * @brief 保存相关设备的实时数据
 *
 * @param addr：设备的编号
 * @param xValue:EC/pH/水Ta温度相关
 * @return
 */
u8 save_data_by_dev(u8 addr, PHECB2_Value_Typedef_t * xValue);

/**
 * @brief 读取相关设备实时数据
 *
 * @param y:年份
 * @param m:月份
 * @param m:月份
 * @param m:月份
 * @return 返回是否保存成功记录,成功为RT_EOK
 */
u8 read_data_by_dev(u8 addr, u32 y, u32 m, u32 d);

#ifdef __cplusplus
}
#endif
#endif // UUZ_LOG_H
