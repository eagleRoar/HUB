/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-29   ZhouXiaomin     first version
 */
#ifndef __UUZ_DEF_DEV_CONFIG_H
#define __UUZ_DEF_DEV_CONFIG_H

/* ----------------------- Defines ------------------------------------------*/
//串口编号
#define uuzUART_7 (0x00U) //Hydro-sensor  Aqua-sensor-in/output
#define uuzUART_8 (0x01U) //Hydro-device  Aqua-device-output
#define uuzUART_3 (0x02U) //Hydro-line1   Aqua-power port
#define uuzUART_2 (0x03U) //Hydro-line2   Aqua-dosing
#define uuzUART_1 (0x04U) //Hydro-HMI     Aqua-HMI
#define uuzUART_6 (0x06U) //Hydro-debug/wifi
#define uuzUART_MAX (6U) //串口数量

//温度属性
#define uuzTA_C (0x00U) //摄氏度
#define uuzTA_F (0x01U) //华氏度

//水位属性
#define uuzLV_MM (0x00U) //厘米
#define uuzLV_INCH (0x01U) //英寸

// Max Device List
//Hypic-Pro总设备数为246 = 246个
//#define uuzDEV_MAX (0xF6U)
//Aqua-Pro总设备数为64个
#define uuzDEV_MAX (64U)
//待注册设备数量
#define uuzDEV_WAIT_REG_MAX (8U) //最多同时等待注册设备数量

//设备最大连接数
#define uuzDEV_CO2_SR_NUM (4U) //CO2传感器当前设备数
#define uuzDEV_HT_SR_NUM (4U) //温湿度传感器当前设备数

//Controller List
#define uuzDEV_ST_NUM (40U) //AC/DC Station  连接设备
#define uuzDEV_L1_NUM (20U) //灯光相关设备
#define uuzDEV_L2_NUM (20U) //灯光相关设备
#define uuzDEV_EX_NUM (24U) //外部设备

#define uuzDEV_P220_NUM (4U) //220V电源输出外部设备
#define uuzDEV_P24_NUM (5U) //24V电源输出外部设备

//设备相关可扩展最大值
#define uuzDEV_BASE_ID (0x02U) //基础位
#define uuzDEV_BOARD_ID (0x10U) //电源板基础位
//Sensor List
#define uuzDEV_SR_MAX (64U) //全部传感器最大数量64个
#define uuzDEV_CO2_SR_MAX (4U) //CO2传感器最大设备数
#define uuzDEV_HT_SR_MAX (4U) //温湿度传感器最大设备数
//External Sensor&Device List
#define uuzDEV_PHEC_B2_MAX (1U) //PHEC-B2设备的最大数量1个(Hydro-Pro-Plus)/1个(Aqua-Pro)
#define uuzDEV_SIN_P260_MAX (3U) //水位传感器SIN-P260最大数量1个(Hydro-Pro)/3个(Aqua-Pro)
#define uuzDEV_T003_MAX (6U) //空调设备T-003最大数量3个
#define uuzDEV_YC10S_MAX (6U) //除湿设备YC-10S最大数量6个
#define uuzDEV_DF34B_MS_MAX (6U) //排气扇DF34B-MS最大数量3个
//Controller List
#define uuzDEV_ST_MAX (64U) //AC/DC Station  连接设备
#define uuzDEV_LT1_MAX (20U) //灯光LINE-1相关设备
#define uuzDEV_LT2_MAX (20U) //灯光LINE-2相关设备
#define uuzDEV_EXT_MAX (uuzDEV_MAX \
    - uuzDEV_SR_MAX                \
    - uuzDEV_ST_MAX                \
    - uuzDEV_LT1_MAX               \
    - uuzDEV_LT2_MAX) //灯光LINE-2相关设备
//Aqua-Pro设备相关
#define uuzDEV_DOS_MAX (8U) //Dosing设备的总数量
#define uuzDEV_BRD_MAX (1U) //高低压设备板的总数量
#define uuzDEV_IO6_MAX (4U) //外置IO 6 Station的总数量
#define uuzDEV_IO12_MAX (4U) //外置IO 12 Station的总数量
#define uuzDEV_ACS_MAX (8U) //AC Station单独模块的总数量
#define uuzDEV_ACS4_MAX (4U) //AC Station 4单独模块的总数量
#define uuzDEV_AUX_MAX (12U) //Aqua-Pro端口合并数量
//灌溉相关的端口数据
#define uuzDEV_IRR_OUT_MAX (16U) //Aqua-Pro端口灌溉
#define uuzDEV_IRR_IN_MAX (8U) //Aqua-Pro端口输入
#define uuzDEV_IRR_DRAIN_MAX (8U) //Aqua-Pro端口回水
//灯光相关的端口数据
#define uuzDEV_LGT_MAX (8U) //Aqua-Pro端口灯光信息

//设备存储的起始位置
//Device Info Site (Max Boxs:246)
//#define uuzDEV_BASE_SITE (0U) //数据存储起始位置
//#define uuzDEV_SR_SITE (0U) //数据存储起始位置(最大64组)
//#define uuzDEV_ST_SITE (uuzDEV_SR_SITE + uuzDEV_SR_MAX) //读取起始位置64(最大40组)
//#define uuzDEV_LT1_SITE (uuzDEV_ST_SITE + uuzDEV_ST_MAX) //数据存储起始位置(最大20组)
//#define uuzDEV_LT2_SITE (uuzDEV_LT1_SITE + uuzDEV_LT1_MAX) //数据存储起始位置(最大20组)
//#define uuzDEV_EXT_SITE (uuzDEV_LT2_SITE + uuzDEV_LT2_MAX) //数据存储起始位置(最大62组)
//#define uuzDEV_END_SITE (uuzDEV_MAX) //设备信息的结束位置
//#define uuzDEV_SR_END (uuzDEV_ST_SITE) //数据存储结束位置(最大64组)
//#define uuzDEV_ST_END (uuzDEV_LT1_SITE) //数据存储结束位置(最大64组)
//#define uuzDEV_LT1_END (uuzDEV_LT2_SITE) //数据存储结束位置(最大20组)
//#define uuzDEV_LT2_END (uuzDEV_EXT_SITE) //数据存储结束位置(最大20组)
//#define uuzDEV_EXT_END (uuzDEV_END_SITE) //数据存储结束位置(最大62组)
//设备注册状态
#define uuzDEV_UNREG (0x00U) //未连接状态
#define uuzDEV_REG_OK (0x01U) //已连接已确认
#define uuzDEV_REG_NOT (0x02U) //已连接未注册
#define uuzDEV_REG_WAIT (0x03U) //已连接已发送注册未回复
//连接错误次数
#define uuzDEV_CONNECT_OK (0U) //连接OK提示
#define uuzDEV_CONNECT_ERR (4U) //2s错误提示
//连接错误重新注册次数
#define uuzDEV_REG_ERR (3U) //2s * 3 = 6s重新注册
//设备连接状态
#define uuzDEV_NOCONNECT (0x00U) //设备未连接
#define uuzDEV_CONNECTED (0x01U) //设备已连接
//Device Type
#define uuzDEV_MT (0x01U) //主机
#define uuzDEV_ST (0x02U) //副机
#define uuzDEV_TEST (0xFFU) //测试模块
//常用设备默认ID
#define uuzDEV_ID_DOS (0x02U) //蠕动泵(1-8)默认ID:2/3/4/5/6/7/8/9/10/11/12/13
#define uuzDEV_ID_BRD (0x10U) //电源板默认ID:16
#define uuzDEV_ID_TEST (0xFFU) //测试模块ID

// DEVICE SLAVE TYPE(设备从机类型)
#define uuzDEV_SL_SHT30 (0x01U) //HT模块  SHT30
#define uuzDEV_SL_SCD30 (0x02U) //CO2模块 SCD30
#define uuzDEV_SL_S8 (0x03U) //CO2模块 S8的CO2模块
#define uuzDEV_SL_DOS (0x08U) //设备蠕动泵相关// AQUA-PRO设备相关设备
#define uuzDEV_SL_BRD (0x09U) //设备高压240V/低压24V// AQUA-PRO设备相关设备
#define uuzDEV_SL_GESA2 (0x21U) //GESA2
#define uuzDEV_SL_LDA1 (0x22U) //LDA-1的灯光模块
#define uuzDEV_SL_ACO (0x41U) //AC Station by CO2
#define uuzDEV_SL_ATA (0x42U) //AC Station by H&T Temperature+ /Heat
#define uuzDEV_SL_AHT (0x43U) //AC Station by H&T Humidity
#define uuzDEV_SL_ADH (0x44U) //AC Station by H&T DeHumidity
#define uuzDEV_SL_ACT (0x45U) //AC Station by H&T Temperature-  /Cool
#define uuzDEV_SL_IO12 (0x7EU) //IO Station 类型 (12-IO)
#define uuzDEV_SL_IO6 (0x7FU) //IO Station 类型 (6-IO)
#define uuzDEV_SL_PORT (0x80U) //Port Station 类型 (0-10)
#define uuzDEV_SL_DCO (0x81U) //DC Station by CO2
#define uuzDEV_SL_DTA (0x82U) //DC Station by H&T Temperature
#define uuzDEV_SL_DHT (0x83U) //DC Station by H&T Humidity
#define uuzDEV_SL_DDH (0x84U) //DC Station by H&T DeHumidity
#define uuzDEV_SL_DCT (0x85U) //DC Station by H&T Temperature-  /Cool
#define uuzDEV_SL_TRAY (0xB1U) //红外的温度控制模块
#define uuzDEV_SL_HRAY (0xB2U) //红外的湿度控制模块
//------------------------
#define uuzDEV_SL_PHECB2 (0xF2U) //PHEC-B2
#define uuzDEV_SL_P260 (0xF3U) //SIN-P260
#define uuzDEV_SL_YC10S (0xF4U) //SIN-YC-10S
#define uuzDEV_SL_T003 (0xF5U) //SIN-T-003
#define uuzDEV_SL_DF34B (0xF6U) //DF34B-MS
#define uuzDEV_SL_MASTAR (0xF7U) //MASTER
#define uuzDEV_SL_CFKT (0xF8U) //百奥（PARKOO）智能除湿机CF6DK~CF8TK
#define uuzDEV_SL_FLAR (0xF9U) //中央控制面板FC-AR(FL)
#define uuzDEV_SL_SL1600F (0xFAU) //SL1600F合之宝温湿度空调机
#define uuzDEV_SL_HVAC (0xFBU) //加拿大特殊空调机
// SFK-PRO设备相关设备
#define uuzDEV_SL_SFKA (0xA1U) //SFK-A旧大田
#define uuzDEV_SL_SFKB (0xA2U) //SFK-B水培
#define uuzDEV_SL_SFKC (0xA3U) //SFK-C大田
#define uuzDEV_SL_SFKD (0xA4U) //SFK-D混合式
#define uuzDEV_SL_SFKE (0xA5U) //SFK-E基质培

#define uuzCH1 (0x00U) //Light Channel-1
#define uuzCH2 (0x01U) //Light Channel-2
#define uuzLINE1 (0x00U) //LDA-1 LINE1
#define uuzLINE2 (0x01U) //LDA-1 LINE2

#define uuzDEV_SL_TEST (0xFFU) //测试模块

#define uuzDEV_SELF_CHECK_TIME (30 * 2U) //等待30秒后进入正常工作状态

//---------------->Modbus-RTU Address
//Hydro-Pro
typedef enum
{

    uuzADDR_R_TEST_CONNECT = (0x0000U),

    //Device INFO
    uuzADDR_R_FIRMWARE_VER1 = (0x0001U),
    uuzADDR_R_FIRMWARE_VER2 = (0x0002U),
    uuzADDR_R_DEVICE_NAME1 = (0x0003U),
    uuzADDR_R_DEVICE_NAME2 = (0x0004U),
    uuzADDR_RW_COMMUNICATION = (0x0005U),
    uuzADDR_RW_DEVICE_MODBUS_ID = (0x0006U),

    //SCD30 CO2
    uuzADDR_R_SCD30_CURR_DATA = (0x0010U),
    uuzADDR_RW_SCD30_CONFIG = (0x0011U),

    //SHT30 HT
    uuzADDR_R_SHT30_CURR_DATA = (0x0020U),
    uuzADDR_RW_SHT30_CONFIG = (0x0021U),

    //AC STATION
    uuzADDR_RW_ACS_STA_DATA = (0x0040U),

    //GEAS2/LDA-1 LIGHT
    uuzADDR_RW_LT_STA_DATA = (0x0060U),

    //Scene Info
    uuzADDR_RW_SCENE_STA_SET = (0x0F00U),
    uuzADDR_RW_SCENE_OPT_STA = (0x1000U),    //1: 0x10000U  255: 0x10FFU

} MODBUS_RTU_ADDRESS;

//PHEC-B2读取位置Address
#define uuzADDR_RW_PHEC_B2_STA (0x0000U)
//SIN-P260读取实际位置
#define uuzADDR_R_SIN_P260_STA (0x0004U)
//T003-空调设备相关命令
#define uuzADDR_RW_T003_ENABLE (0x0027U)
#define uuzADDR_R_T003_TA (0x00D2U)
#define uuzADDR_RW_T003_TARGET (0x0015U)
#define uuzADDR_RW_T003_MODBUS_ID (0x005DU)
//YC10S相关命令
#define uuzADDR_RW_YC10S_MODE (0x0010U)
#define uuzADDR_RW_YC10S_POWER (0x0013U)
#define uuzADDR_RW_YC10S_TARGET (0x0014U)
//DF34B-MS相关命令
#define uuzADDR_R_DF34B_STATE (0x0000U)
//Addr-0:Mode,Addr-1:Temperature,Addr-2:Humidity
#define uuzADDR_RW_DF34B_MODE (0x0000U)
#define uuzADDR_RW_DF34B_TEMP (0x0001U)
#define uuzADDR_RW_DF34B_HUMIDITY (0x0002U)

#endif // __UUZ_DEF_DEV_CONFIG_H
