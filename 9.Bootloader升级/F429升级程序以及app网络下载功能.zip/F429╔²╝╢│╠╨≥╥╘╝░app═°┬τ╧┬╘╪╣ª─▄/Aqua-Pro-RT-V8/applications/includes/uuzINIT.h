#ifndef __UUZ_INIT_H
#define __UUZ_INIT_H

#include "typedefINIT.h"
#include "typedefDEVID.h"
#include "logHISTORY.h"
#include <board.h>

#define _INNOVATION_SINGLE (1U)
//存放到EEPROM的数据
//extern EE_Config_Typedef_t xEEConfig;
extern System_Config_Typedef_t xSysCFG;
extern DevState_Typedef_t xSysSTA;  //设备的缓存数据

#ifdef __cplusplus
extern "C" {
#endif

void local_config_init(void);

void system_config_init(u8 ucMask);
void device_config_from_eeprom(void);

void device_config_default_init(void);
void device_state_init(void);

/**
 * @brief 启动手动定时状态
 */
void pause_state_start(u8 state, u32 time);

/**
 * @brief 检查手动状态
 */
void pause_state_sync(void);

#ifdef __cplusplus
}
#endif

#endif // __UUZ_INIT_H
