﻿#ifndef UUZ_IWDG_H
#define UUZ_IWDG_H

#ifdef __cplusplus
 extern "C" {
#endif

int iwdg_init(void);

#ifdef __cplusplus
}
#endif
#endif // UUZ_IWDG_H
