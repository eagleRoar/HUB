﻿#ifndef UUZ_PIN_H
#define UUZ_PIN_H

#include "uuzINIT.h"

#ifdef __cplusplus
extern "C" {
#endif

#define uuzPIN_KEY_CNT (3433)    //密码3433
#define uuzPIN_TIM_MAX (60*3)    //持续3分钟后自动锁定

/**
 * @brief 设置锁定屏幕密码
 */
void unlock_pin_set(u32 newpin);

/**
 * @brief 检查自动锁定逻辑
 */
void auto_lock_sync(void);

#ifdef __cplusplus
}
#endif
#endif // UUZ_PIN_H
