﻿#ifndef UUZ_ID_H
#define UUZ_ID_H

#include "uuzINIT.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化DEV设备的CPU-ID
 */
void cpu_id_init(DevID_Typedef_t * dev);

#ifdef __cplusplus
}
#endif
#endif // UUZ_ID_H
