#ifndef __UUZ_CONFIG_SD_H
#define __UUZ_CONFIG_SD_H

#define uuzPATH_LOG_SYS "logs/"
#define uuzPATH_LOG_OPT "logs/"
#define uuzPATH_LOG_EC "logs/"
#define uuzPATH_LOG_PH "logs/"
#define uuzPATH_LOG_TA "logs/"
#define uuzPATH_LOG_LV "logs/"
#define uuzPATH_ALM_DATA "alarm/"

#endif // __UUZ_CONFIG_SD_H
