/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-01   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_INIT_H
#define __TYPEDEF_INIT_H

#include "board.h"
#include "typedefBASE.h"
#include "typedefHMI.h"
#include "typedefCFG.h"
#include "uuzConfigDEV.h"
#include "uuzEvent.h"

typedef struct devid
{

    u8 en;  //1-设备工作状态
    u8 uart;  //2-设备连接串口号
    u8 count;  //3-连接计数
    u8 isconnect;  //4-设备和主机的连接状态
    u8 id;  //5-设备的Modbus-ID
    u8 type;  //6-设备的类型
    u8 delay;  //11-延时开启计数
    u8 reg_en;  //12-注册状态
    u8 map;  //13-对应数据表位置
    u8 cpuid[4];  //7-10-CPU-ID(4)
    u8 cmd[3];  //14-16-空余数据(3)

}__attribute__ ((__packed__)) DevID_Typedef_t;  //size = 16U
#define _DEV_LEN (sizeof(DevID_Typedef_t))

//设备的相关信息
typedef struct system_config
{

    u16 version;    //信息版本号
    u16 state_init;  //初始化状态
    //---------重启相关信息
    u16 boot_count;  //重启次数
    u32 boot_day;  //重启时的天数-YYYY-MM-DD-HH:MM:SS (总seconds)
    u32 boot_time;  //重启时的时间-YYYY-MM-DD-HH:MM:SS (总seconds)
    //---------本机设备ID相关参数
    DevID_Typedef_t dev;  //本机ID参数
    //---------屏幕相关设置
    u16 language;  //初始化语言状态
    //---------单位相关
    u16 unit_ec;  //EC单位:EC/CF-TDS(x500)-PPM(x700)
    u16 unit_ta;  //温度单位：C-F
    u16 unit_lv;  //温度单位：0:cm-1:inch
    u16 unit_date;  //MM/DD/YY-DD/MM/YY-YY/MM/DD
    u16 unit_time;  //24/12时制
    //---------亮度设置
    u16 bk_mode;  //背光开关状态1-Manual/0-Auto
    u16 bk_level;  //背光亮度0~100%
    u16 bk_time;  //自动熄屏时间（15--180s）
    //---------白天黑夜相关设置
    u16 day_mode;  //白天黑夜的判断模式设置:0-Manual/1-Auto
    u16 day_on;  //白天的启动时间:480=8:00
    u16 day_off;  //白天的关闭时间:1080=18:00
    //---------工作程序
    u16 running_mode;  //运行模式(0-监视模式/1-程序模式/2-周期表)
    u16 single_mode;  //运行模式(0-定量程序模式/1-动态程序模式/)
    u16 fixed_id;  //如果是1-定量程序模式，对应的程序编号(1-9),如果是0表示未选择
    u16 dynamic_id;  //2-动态程序模式，编号(1-9）,如果是0表示未选择
    //---------主界面显示的相关设备
    u16 pehc_id;  //主界面通用的PHEC-B2的编号(0/1/2/3...
    u16 board_id;  //主界面下显示的内置传感器板的传感器编号ID
    u16 pool_id[2];  //主界面下显示的水池-Sin-P260的传感器编号ID
    u16 dosing_num;  //设置的蠕动泵相关数据(0-8)
    //---------主界面上锁的相关参数
    u16 lock_pin;   //上锁密码

    u16 crc;    //末尾校正数据，0x3545U 如果不是，则重置前面的数据

}__attribute__ ((__packed__)) System_Config_Typedef_t;

#define _UUZ_SYSTEM_CONFIG_LEN (sizeof(System_Config_Typedef_t))

typedef struct dev_state
{
    u32 hmi_init;  //0-HMI初始化阶段相关参数
    u32 waiting_state;  //1-启动设备初始化标记
    u32 waiting_time;  //2-启动设备初始化计数
    //报警相关缓存数据
    u32 alarm_ec;  //EC实时报警状态  0:不动作/1:High/2:Low/255:Clean
    u32 alarm_ph;  //PH实时报警状态 0:不动作/1:High/2:Low/255:Clean
    u32 alarm_ta;  //TA实时报警状态 0:不动作/1:High/255:Clean
    u32 alarm_level;  //水位实时报警状态 0-NOR/1-High/2-Low
    //主界面图的水池显示临时状态
    u32 irr_pool_sta;   //显示水池的相关
    u32 irr_sta;  //灌溉状态:0-OFF/1-ON
    u32 irr_stop_time;  //停止灌溉持续时间
    u32 irr_out_sta;  //灌溉输出:0-OFF/1-ON
    u32 irr_back_sta;  //灌溉回水:0-OFF/1-ON
    u32 irr_in_sta;  //灌溉输入:0-OFF/1-ON
    //主界面的数据刷新状态(是否第一次刷新)
    u32 sync_phec;  //PHEC-B2传感器数据刷新状态
    u32 sync_pool;  //SIN-P260传感器刷新状态(水池
    //Valve的端口数量
    u32 aux_num;  //端口输出设备总数量
    //u32 value_sta;  //内置端口相关数据
    //程序配置运行数据
    u32 progType;  //正在运行的程序类型   (0-定量配肥|1-动态配肥）
    u32 progRunning;  //正在运行的程序编号    (0-无运行数据|1-
    //状态界面页码缓存
    u32 currPage;  //当前页缓存
    u32 prevProType;  //程序运行阶段 0:无程序运行/1-6:对应运行阶段
    u32 prevProgram;  //程序运行阶段 0:无程序运行/1-6:对应运行阶段
    u32 currProType;  //程序运行阶段 0:无程序运行/1-6:对应运行阶段
    u32 currProgram;  //程序运行阶段 0:无程序运行/1-6:对应运行阶段
    //EC/pH的工作状态记录(Fixed模式）
    u32 need_dosing_fixed;    //需要进入EC定量加肥阶段
    u32 dosing_fixed_state;    //EC加肥模式状态
    u32 dosing_en[uuzDEV_DOS_MAX];  //EC是否需要执行工作,通过是否存在蠕动泵判断
    u32 dosing_sta[uuzDEV_DOS_MAX];  //EC蠕动泵的工作状态，0-关闭|1-开启
    u32 dosing_max[uuzDEV_DOS_MAX];  //EC的执行总时间
    u32 dosing_tim[uuzDEV_DOS_MAX];  //EC的工作持续时间
    //EC/pH的工作状态记录(Dynamic模式）
    u32 dosing_ec_dynamic_opt;  //EC是否需要执行工作,通过是否存在蠕动泵判断
    u32 dosing_ec_dynamic_sta;  //EC的工作状态
    u32 dosing_pha_dynamic_opt;  //pH+是否需要执行工作
    u32 dosing_phd_dynamic_opt;  //pH-是否需要执行工作
    u32 dosing_ph_dynamic_sta;  //pH的工作状态
    //Light的工作状态记录
    u32 light_opt;  //灯光的执行状态
    u32 light_sta;  //灯光的工作状态
    //灌溉端口状态显示类型工作状态
    u32 irr_type;  //设备状态显示编号
    //设备状态显示类型工作状态
    u32 state_type;  //设备状态显示编号
    //查找设备水位ID
    u32 state_find;  //设备水位查找状态
    //端口Power Broad板相关设备信息
    u32 state_brd[uuzDEV_BRD_MAX];  //对应设备板的数据
    u32 state_opt[uuzDEV_BRD_MAX];  //对应设备板的数据-另一个状态数据
    //当前选择的index
    u32 curr_wls;    //临时缓存回水相关数据
    //Event_Typedef_t event;    //缓存事件数据
    //密码缓存数据缓存参数
    u32 is_lock;        //是否上锁数据
    u32 tim_lock;       //上锁时间计算
    //当前复位状态
    u32 is_init_data;    //是否正在进行复位
    //手动操作界面临时暂停动作
    u32 f_m_pasue;  //手动操作界面临时暂停状态
    u32 t_m_pasue;  //手动操作界面临时暂停状态时间
    //设备数据相关操作缓存
    Config_Data_Typedef_t length;    //数据长度
    void* addr_config;  //配置总数据地址
    DevID_Typedef_t * dev;  //界面上正在操作的设备相关地址

    u16 test_data[30];

} DevState_Typedef_t;

#define _UUZ_DEV_STATE_LEN (sizeof(DevState_Typedef_t))

#endif // __TYPEDEF_INIT_H
