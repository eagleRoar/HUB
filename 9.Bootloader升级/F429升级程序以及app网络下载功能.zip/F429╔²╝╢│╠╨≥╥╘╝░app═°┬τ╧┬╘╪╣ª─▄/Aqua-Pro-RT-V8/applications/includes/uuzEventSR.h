/*
 * @Copyright (c) 2006-2018 RT-Thread Development Team:  
 * @SPDX-License-Identifier: Apache-2.0:  
 * @Date: 2020-01-01 09:23:03
 * @LastEditors  : Zhou Xiaomin
 * @LastEditTime : 2020-01-06 14:36:52
 * @Description:  
 */
#ifndef __UUZ_SENSOR_EVENT_H
#define __UUZ_SENSOR_EVENT_H

#include <board.h>

#ifdef __cplusplus
extern "C" {
#endif

//传感器数据读取
int sensor_read_init(void);
void sensor_rd_thread_entry(void* parameter);
//设备连接状态检查
void device_state_isconnected(void);
u8 device_isconnected(DevID_Typedef_t * xDev);
void cmd_set(u8 ucUart, u8* ucData, u8 ucLen);
void cmd_read(u8 uart);  //传感器相关命令的读取
void sensor_cmd_set(void);
void board_cmd_set(void);
void dosing_cmd_set(void);

#ifdef __cplusplus
}
#endif

#endif // __UUZ_SENSOR_EVENT_H
