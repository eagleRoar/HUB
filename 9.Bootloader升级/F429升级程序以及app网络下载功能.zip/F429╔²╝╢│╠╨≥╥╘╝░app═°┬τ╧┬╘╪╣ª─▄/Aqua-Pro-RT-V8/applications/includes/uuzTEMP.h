﻿#ifndef _UUZ_TEMP_H
#define _UUZ_TEMP_H

#include <typedefBASE.h>
#include <uuzINIT.h>

#ifdef __cplusplus
extern "C" {
#endif

u16 uuz_usTempC2F_ConvCplt(u16 usT);
u16 uuz_usTempF2C_ConvCplt(u16 usT);
u16 uuz_usTemp2Int_ConvCplt(u16 usT);

#ifdef __cplusplus
}
#endif

#endif // UUZ_TEMP_H
