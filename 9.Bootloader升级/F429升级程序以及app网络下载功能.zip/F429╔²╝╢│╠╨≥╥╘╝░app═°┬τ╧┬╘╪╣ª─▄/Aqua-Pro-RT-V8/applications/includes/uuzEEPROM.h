/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-29   ZhouXiaomin     first version
 */
#ifndef __UUZ_EEPROM_H
#define __UUZ_EEPROM_H

#include "at24cxx.h"
#include "typedefBASE.h"
#include "uuzConfigEEPROM.h"

#ifdef __cplusplus
extern "C" {
#endif

void device_eeprom_init(void);
void eeprom_to_config(u16 ReadAddr, u8* pBuffer, u16 NumToRead);
void config_to_eeprom(u16 WriteAddr, u8* pBuffer, u16 NumToRead);

#if 0
//设备信息相关函数
void uuz_vIDConfigToEEClearAll(void);


void uuz_vEEClearAll(void);
#endif

#ifdef __cplusplus
}
#endif

#endif // UUZ_EEPROM_H
