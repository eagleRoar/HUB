/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-29   ZhouXiaomin     first version
 */
#ifndef __UUZ_EVENT_H
#define __UUZ_EVENT_H

#include <board.h>
#include <rtdevice.h>
#include "typedefBASE.h"
#include "uuzEventTEST.h"

extern rt_event_t eventALM;
extern rt_event_t eventDATA;
extern rt_event_t eventOPT;
extern rt_event_t eventVALVE;
#if (_TEST_DATA)
extern rt_event_t eventTEST;
#endif

//--------------------------------->
//主界面报警界面的事件描述
#define EC_H_EVENT (0x01U << 0) //EC高报警
#define PH_H_EVENT (0x01U << 1) //pH高报警
#define PH_L_EVENT (0x01U << 2) //pH低报警
#define TA_H_EVENT (0x01U << 3) //(水)温度高报警
#define LV_H_EVENT (0x01U << 4) //主水箱水位高报警
#define LV_L_EVENT (0x01U << 5) //主水箱水位低报警
#define EC_NULL_EVENT (0x01U << 8) //EC无报警数据
#define PH_NULL_EVENT (0x01U << 9) //pH无报警数据
#define TA_NULL_EVENT (0x01U << 10) //(水)温度无报警数据
#define LV_NULL_EVENT (0x01U << 11) //水位正常状态
//界面实时刷新信息
#define UI_DATA_SYNC (0x01U << 0) //实时刷新界面相关数据(EC/pH/Ta./Lv.Val/Lv.Sta)
#define UI_STA_SYNC (0x01U << 1) //实时状态刷新界面相关数据(Dosing State)
//蠕动泵实际执行动作信息
//---->EC
#define OPT_EC_ON (0x01U << 0) //打开蠕动泵EC事件
#define OPT_EC_OFF (0x01U << 8) //打开蠕动泵EC事件
//---->pH
#define OPT_PHA_ON (0x01U << 1) //打开蠕动泵pH+事件
#define OPT_PHD_ON (0x01U << 2) //打开蠕动泵pH-事件
#define OPT_PH_OFF (0x01U << 9) //关闭蠕动泵pH+/pH-事件
//端口实际执行动作信息
#if 0
//---->Light
#define OPT_LGT_ON (0x0001U << 0) //打开灯光事件
#define OPT_LGT_OFF (0x0001U << 16) //关闭灯光事件
//---->Irrgration
#define OPT_IRR_OUT_ON (0x0001U << 1) //打开灌溉事件
#define OPT_IRR_OUT_OFF (0x0001U << 17) //关闭灌溉事件
//---->Return Water
#define OPT_IRR_BACK_ON (0x0001U << 2) //打开回水事件
#define OPT_IRR_BACK_OFF (0x0001U << 18) //关闭回水事件
//---->Auto Filling Water
#define OPT_IRR_IN_ON (0x0001U << 3) //打开补水事件
#define OPT_IRR_IN_OFF (0x0001U << 19) //关闭补水事件
//---->Auto Mix Water
#define OPT_IRR_MIX_ON (0x0001U << 4) //打开混合泵事件
#define OPT_IRR_MIX_OFF (0x0001U << 20) //关闭混合泵事件
//---->Auto Pump Water
#define OPT_IRR_PUMP_ON (0x0001U << 5) //打开混合泵事件
#define OPT_IRR_PUMP_OFF (0x0001U << 21) //关闭混合泵事件
//---->Flow-Ebb
//FLOW:OPT_IRR_OUT_ON|OPT_IRR_BACK_OFF  //涨潮状态
//EBB:OPT_IRR_OUT_OFF|OPT_IRR_BACK_ON  //落潮状态
//---->集装箱灌溉数据
//OUT ON:OPT_IRR_IN_OFF|OPT_IRR_OUT_ON|OPT_IRR_IRR_MIX_ON
#define OPT_INN_OUT_ON (OPT_IRR_PUMP_ON|OPT_IRR_MIX_OFF|OPT_IRR_IRR_IN_OFF|OPT_IRR_OUT_ON)
#define OPT_INN_OUT_OFF (OPT_IRR_PUMP_OFF|OPT_IRR_MIX_OFF|OPT_IRR_IRR_IN_OFF|OPT_IRR_OUT_OFF)
#else
//---->Light
#define OPT_LGT_ENT (0x0001U << 0) //打开|关闭灯光事件
//---->Irrgration
#define OPT_IRR_OUT_ENT (0x0001U << 1) //打开灌溉事件
//---->Return Water
#define OPT_IRR_BACK_ENT (0x0001U << 2) //打开回水事件
//---->Auto Filling Water
#define OPT_IRR_IN_ENT (0x0001U << 3) //打开补水事件
//---->Auto Mix Water
#define OPT_IRR_MIX_ENT (0x0001U << 4) //打开混合泵事件
//---->Auto Pump Water
#define OPT_IRR_PUMP_ENT (0x0001U << 5) //打开输出泵事件
#endif
//--------------------------------->
#define OPT_VLV_1_OFF (0x0001U << 0) //关闭端口1事件
#define OPT_VLV_1_ON (0x0001U << 1) //打开端口1事件
#define OPT_VLV_2_OFF (0x0001U << 2) //关闭端口2事件
#define OPT_VLV_2_ON (0x0001U << 3) //打开端口2事件
#define OPT_VLV_3_OFF (0x0001U << 4) //关闭端口3事件
#define OPT_VLV_3_ON (0x0001U << 5) //打开端口3事件
#define OPT_VLV_4_OFF (0x0001U << 6) //关闭端口4事件
#define OPT_VLV_4_ON (0x0001U << 7) //打开端口4事件
#define OPT_VLV_5_OFF (0x0001U << 8) //关闭端口5事件
#define OPT_VLV_5_ON (0x0001U << 9) //打开端口5事件
#define OPT_VLV_6_OFF (0x0001U << 10) //关闭端口6事件
#define OPT_VLV_6_ON (0x0001U << 11) //打开端口6事件
#define OPT_VLV_7_OFF (0x0001U << 12) //关闭AC端口事件
#define OPT_VLV_7_ON (0x0001U << 13) //打开AC端口事件
//--------------------------------->
#if 0
typedef struct valve_event
{
    u16 pro;
    u16 sta;
} Event_Typedef_t;
#endif
//--------------------------------->
#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif // UUZ_EVENT_H
