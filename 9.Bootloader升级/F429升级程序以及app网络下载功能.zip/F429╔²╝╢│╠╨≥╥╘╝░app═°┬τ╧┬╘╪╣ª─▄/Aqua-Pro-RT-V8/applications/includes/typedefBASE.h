/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-25   ZhouXiaomin     first version
 */
#ifndef _TYPEDEF_BASE_H
#define _TYPEDEF_BASE_H
#include "stm32f4xx_hal.h"
//#include "stm32f1xx_hal.h"
//#include "stm32f0xx_hal.h"

#include <rtthread.h>

typedef int32_t s32;
typedef int16_t s16;
typedef int8_t s8;

typedef const int32_t sc32;
typedef const int16_t sc16;
typedef const int8_t sc8;

typedef __IO int32_t vs32;
typedef __IO int16_t vs16;
typedef __IO int8_t vs8;

typedef __I int32_t vsc32;
typedef __I int16_t vsc16;
typedef __I int8_t vsc8;

typedef rt_uint32_t u32;
typedef rt_uint16_t u16;
typedef rt_uint8_t u8;

typedef const uint32_t uc32;
typedef const uint16_t uc16;
typedef const uint8_t uc8;

typedef __IO uint32_t vu32;
typedef __IO uint16_t vu16;
typedef __IO uint8_t vu8;

typedef __I uint32_t vuc32;
typedef __I uint16_t vuc16;
typedef __I uint8_t vuc8;

/**
 * @brief 定时结构组
 *
 */
typedef struct timer_t
{
    u8 en;  //0-off/1-on
    u32 on;  //08:00=8*60mins
    u32 off;  //09:00=9*60mins

}__attribute__ ((__packed__)) Timer_Typedef_t;

/**
 * @brief 循环结构组
 *
 */
typedef struct cycle_t
{
    u32 on;  //15sec/5min
    u32 off;  //15sec/5min

}__attribute__ ((__packed__)) Cycle_Typedef_t;

typedef enum
{
    _M_MANUAL = 0,  //手动模式
    _M_CYCLE,  //循环模式
    _M_TIMER,  //定时模式
    _M_AUTO,  //自动模式
    _M_NONE = 255  //无效模式

} WORK_MODE;

typedef struct _io_t   //配置数据地址信息
{
    u8 en;    //IO使能
    u8 t;    //模块类型
    u8 id;    //模块ID
    u8 io;    //模块对应IO

}__attribute__ ((__packed__)) IO_Typedef_t;
#define uuzIO_ADDR_LEN (sizeof(IO_Typedef_t))

typedef struct item
{

    u8 curr;  //current state
    u8 prev;  //previous state
    u32 count;  //current count
    u32 max;  //max current
    u8 opt;  //执行状态
    u8 sta;  //上次状态
    u32 time;  //工作持续时间

}__attribute__ ((__packed__)) Item_Typedef_t;

/**
 * @brief 循环状态操作数
 * 
 */
typedef struct cycle_item
{

    u8 opt;  //执行状态
    u8 sta;  //上次状态
    u32 time;  //工作持续时间(sec)

}__attribute__ ((__packed__)) Cycle_Item_Typedef_t;

#endif // _TYPEDEF_BASE_H
