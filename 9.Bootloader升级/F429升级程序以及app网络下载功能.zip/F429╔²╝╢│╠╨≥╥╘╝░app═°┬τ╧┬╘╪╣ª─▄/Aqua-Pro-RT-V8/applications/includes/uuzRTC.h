/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-09   ZhouXiaomin     first version
 * 2020-07-19   ZhouXiaomin     更新使用公共变量rTm
 */
#ifndef UUZ_RTC_H
#define UUZ_RTC_H

#include "board.h"
#include "typedefBASE.h"
#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

extern struct tm rTm;

/**
 * @brief 获取设备当前实时时间,并放如公共变量rTm中
 * 
 */
void rt_rtc_get(void);

/**
 * @brief 设置系统的RTC数据
 * 
 * @param year :输入的参数-年
 * @param mon :输入的参数-月
 * @param day :输入的参数-日
 * @param hour :输入的参数-时
 * @param min :输入的参数-分
 * @param sec :输入的参数-秒
 */
void rt_rtc_set(u16 year, u16 mon, u16 day, u16 hour, u16 min, u16 sec);
/**
 * @brief 获取当前的实时分钟数-1天
 * 
 * @return u16 返回的分钟数据（0~1440）
 */
u16 uuz_usRTC_GetMinutes(void);

/**
 * @brief 获取当前的实时秒数-1天
 * 
 * @return u32 返回的秒数据（0~84600）
 */
u32 uuz_ulRTC_GetSeconds(void);

/**
 * @brief 打印实时的时间到串口
 * 
 */
void rt_rtc_info(void);

#ifdef __cplusplus
}
#endif
#endif // UUZ_RTC_H
