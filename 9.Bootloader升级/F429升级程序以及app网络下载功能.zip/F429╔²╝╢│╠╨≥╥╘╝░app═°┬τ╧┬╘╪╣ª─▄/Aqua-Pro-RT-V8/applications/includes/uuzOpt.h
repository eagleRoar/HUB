#ifndef __UUZ_OPT_H
#define __UUZ_OPT_H

#include "typedefBASE.h"

#define optUUZ_MAX(a, b) ((a > b) ? (a) : (b))
#define optUUZ_MIN(a, b) ((a <= b) ? (a) : (b))
#define optUUZ_COMPARE(a, b) ((a == b) ? (1U) : (0U))

/*the operate is for bit */
#define optUUZ_SET_BIT(a, b) ((a) |= (1 << b))
#define optUUZ_CLEAR_BIT(a, b) ((a) &= ~(1 << b))
#define optUUZ_IS_BIT_SET(a, b) ((a) & (1 << b))

#define uuzLSB (0x00U)
#define uuzMSB (0x01U)

#define uuzFALSE (0x00U)
#define uuzTRUE (!uuzFALSE)

/* CR+LF : 0D 0A */
#define uuzCR (0x0D)
#define uuzLF (0x0A)

/* Daytime : 0-白天/1-黑夜 */
#define uuzDAY (0x00U)
#define uuzNIGHT (0x01U)

/* Light: 0-OFF/1-ON/255-NULL */
#define uuzOPT_OFF (0x00U)
#define uuzOPT_ON (0x01U)
#define uuzOPT_NULL (0xFFU)

/* Light: 0-RUN OFF/1-RUN ON */
#define uuzRUN_OFF (0x00U)
#define uuzRUN_ON (0x01U)

/* Activate: 0-enable/1-disable*/
#define uuzENABLE (0x00U)
#define uuzDISABLE (0x01U)

#define _INVALID (0x00U)
#define uuzCONFIG_RAND_OPT (!_INVALID)

#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------------*/
/**
 * @brief StringToHex
 * @param str
 * @param out
 * @return
 */
int StringToHex(char* str, u8* out);

/*
 * INPUT:
 * pucValue: input the data by (uint8_t)
 * ucMode : [MSB] or [LSB]
 *
 * OUTPUT: the data by (uint16_t)
 */
u16 usU8ToU16(u8* pucValue, u8 ucMode);
/*
 * INPUT:
 * usValue: input the data by (uint16_t)
 * ucMode : [MSB] or [LSB]
 *
 * OUTPUT: void
 *         ucHex  output the data by (uint8_t)
 */
void vU16ToU8(u8* pucHex, u16 usValue, u8 ucMode);
/*
 * INPUT:
 * pucData: input the data for SUM-CRC
 * ulLen :  the length for data
 *
 * OUTPUT: the value for data (SUM-CRC)
 */
/*
 * INPUT:
 * pucValue: input the data by (uint8_t)
 * ucMode : [MSB] or [LSB]
 *
 * OUTPUT: the data by (uint32_t)
 */
u32 ulU8ToU32(const u8* pucValue, u8 ucMode);

/*
 * INPUT:
 * ulValue: input the data by (uint32_t)
 * ucMode : [MSB] or [LSB]
 *
 *
 * OUTPUT: void
 *         ucHex  output the data by (uint8_t)
 */
void vU32ToU8(u8* pucHex, u32 ulValue, u8 ucMode);

/**
 * @brief 获取总页面数据
 * @param max:每页最多数量
 * @param num:当前设备总数
 * @return 返回总页面数据
 */
u8 ucPageGet(u8 ucMax, u8 ucNum);

u8 ucSUM_CRC(const u8* pucData, u32 ulLen);
/*
 * INPUT:
 * pucData: input the data for CRC16
 * ulLen :  the length for data
 *
 * OUTPUT: the value for data (CRC16)
 */
u16 usModbusRTU_CRC(const u8* pucData, u32 ulLen);

/**
 * @brief 判断协议末端是否换行符（0d 0a)
 * @param data
 * @return
 */
rt_err_t crc_data_end_is_assert(u8 * data);

/**
 * @brief 数据对比API
 * @param item:缓存数据
 * @param state:返回对比值
 */
void item_analysis(Item_Typedef_t* item, u16 state);

/**
 * @brief 转换cm和inch
 * @param type:需要转换的方向 0:mm->inch| 1:inch->mm
 * @param level:需要转换的数据
 * @return
 */
u32 mm_and_inch_to(u8 type, u32 level);

#ifdef __cplusplus
}
#endif
#endif // __UUZ_OPT_H
