/**
 * @file uuzInit.c
 * @author Zhou Xiaomin (zxm123465@gmail.com)
 * @brief 
 * @version 0.1
 * @date 2020-07-24
 * 
 * @copyright Copyright (c) 2020
 * 
 */
/******************************************************************************/
/* rt-thread -----------------------------------------*/
#include <rtthread.h>
/* config --------------------------------------------*/
#include "uuzConfigDEV.h"
#include "uuzID.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzRTC.h"
#include "uuzPIN.h"
/* device id -------------------------------------------*/
#include "uuzDevID.h"
/* sd card -------------------------------------------*/
#include "uuzSD.h"
/* eeprom --------------------------------------------*/
#include "uuzEEPROM.h"
/* uart -------------------------------------------*/
#include "uuzEventUART.h"
/* device config -------------------------------------------*/
#include "uuzDevCfg.h"
/* hmi -------------------------------------------*/
#include "uuzEventHMI.h"
/* sersor -------------------------------------------*/
#include "uuzEventIRR.h"
#include "uuzEventLGT.h"
#include "uuzEventP260.h"
#include "uuzEventPHEC.h"
#include "uuzEventPROG.h"
#include "uuzEventSR.h"
#include "uuzEventCFG.h"
#include "uuzEventFixed.h"
#include "uuzEventTEST.h"
#include "uuzEventTIM.h"
/* network -------------------------------------------*/
#include "uuzEventMQTT.h"
#include "uuzEventTCP.h"
/* log -----------------------------------------------*/
#define DBG_TAG "c.init"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/******************************************************/
#define uuzDEVICE_VERSION (1010U)
#define uuzCONFIG_EE_VERSION (0x0001U)
System_Config_Typedef_t xSysCFG;
DevState_Typedef_t xSysSTA;  //设备的缓存数据
/*******************************************************/
/**
 * @brief local_config_init
 * @param argument
 */
void local_config_init(void)
{
    uart_common_init();  //打开相关的串口
    device_eeprom_init();  //初始化EEPROM设备配置数据
    system_config_init(0);  //读取配置相关参数
    device_map_state_init();  //初始化设备ID相关属性
    device_map_init(0);  //读取设备ID相关参数
    config_addr_init(0);  //配置数据地址读取及初始化
    device_state_init();    //更新设备缓存数据
    /* Program Data相关函数 */
    prog_cache_init();    //初始化运行过程相关缓存
    prog_dosing_running_sync();  //运行程序解析处理
    prog_dosing_config_sync();    //初始化蠕动泵相关信息
    /* Thread entry相关函数 */
    /* 初始化传感器数据读取函数，500ms */
    sensor_read_init();    //传感器数据读取函数
#if 0
    data_sync_init();    // 蠕动泵操作事件启动函数
    opt_event_init();
    //valve_event_init();    // 端口操作事件启动函数
    alarm_sync_init();    // 报警数据事件触发函数
    //mqtt_start(1, 0);//启动MQTT服务器
    ui_sync_init();    // 界面刷新线程
    //sd_dfs_event_init();    //等待初始化完成,启动SD读取
    hmi_sync_start();    //开始初始化HMI屏幕
#endif
    //输出
    netdev_list_get();    // 网络硬件初始化
    //mqtt_start(1, 0);    //启动MQTT服务器
    //net_opt_init();
    //netdev_list_if();   //网络IP数据
}

/**
 * @brief system_config_init
 * @param ucMask
 */
void system_config_init(u8 ucMask)
{
    if (!ucMask) {
        system_config_read();  //读取存EEPROM数据
    }

    //检查EEPROM的内容数据是否正确
    if ((xSysCFG.crc != 0x3545U) || (ucMask)) {  //如果版本结尾错误|强制刷新,初始化数据
        device_config_default_init();
        LOG_D("Reset to device default configuration.");
    } else {
        LOG_D("Read configuration is Success[%d].", xSysCFG.boot_count);  // 更新重启数据
    }

#if (uuzDEVICE_TYPE == _DEV_INNOVALTION_ONLY)
    xSysCFG.single_mode = 0;    //锁定为定量配肥
#else
    xSysCFG.single_mode = 1;    //锁定为动态配肥
#endif

    system_config_save();  //保存EEPROM数据
}

/**
 * @brief device_config_default_init
 */
void device_config_default_init(void)
{
    xSysCFG.version = uuzCONFIG_EE_VERSION;  //配置版本号
    xSysCFG.state_init = 1;  //初始化状态
    //重启相关信息
    xSysCFG.boot_count = 1;  //重启次数记录
    xSysCFG.boot_day = 0;  //重启时的天数-YYYY-MM-DD(总Days)
    xSysCFG.boot_time = 0;  //重启时的时间-HH:MM:SS (总Seconds)
    //HMI设备参数默认设置
    xSysCFG.language = 0U;  //0-EN; 1-CH
    xSysCFG.unit_ec = 0U;  //0-EC/CF; 1-TDS(500); 2-ppm(700);
    xSysCFG.unit_ta = uuzTA_C;  //0-C; 1-F;
    xSysCFG.unit_lv = uuzLV_MM;  //0-cm; 1-inch;
    xSysCFG.unit_date = 0U;  //0-MM/DD/YY; 1-DD/MM/YY; 2-YY/MM/DD
    xSysCFG.unit_time = 0U;  //0-24H; 1-12H
    xSysCFG.bk_mode = 0;  //1: Manual; 0: Auto
    xSysCFG.bk_level = 100;  //30~100%
    xSysCFG.bk_time = 30;  //30sec
    //白天黑夜相关设置
    xSysCFG.day_mode = 0;  //白天黑夜的判断模式设置:0-Manual/1-Auto
    xSysCFG.day_on = 480;  //白天的启动时间:480=8:00
    xSysCFG.day_off = 1080;  //白天的关闭时间:1080=18:00
    //工作程序设置
    xSysCFG.running_mode = 1;  //运行模式(0-监视模式/1-程序模式/2-周期表)
#if (uuzDEVICE_TYPE==_DEV_INNOVATION_ONLY)
    xSysCFG.single_mode = 0;  //运行模式(0-定量模式/1-动态模式)
#else
            xSysCFG.single_mode = 1;  //运行模式(0-定量模式/1-动态模式)
#endif
    xSysCFG.fixed_id = 0;  //如果是1-程序模式，对应的程序编号(0-8),一共9个
    xSysCFG.dynamic_id = 0;  //如果是2-程序模式，对应的程序编号(0-8),一共9个
    //主界面显示的相关设备
    xSysCFG.pehc_id = uuzDEV_BASE_ID;  //主界面通用的PHEC-B2的MODBUS-ID
    xSysCFG.board_id = 0;  //主界面下显示的内置传感器板的传感器的队列序号
    xSysCFG.pool_id[0] = uuzDEV_BASE_ID + 0x01U;  //主界面下显示的水池-Sin-P260的传感器的MODBUS-ID(02H)
    xSysCFG.pool_id[1] = uuzDEV_BASE_ID + 0x02U;  //主界面下显示的水池-Sin-P260的传感器的MODBUS-ID(03H)
    xSysCFG.dosing_num = 4U;  //默认设置4个蠕动泵
    //设备RS485模块信息
    rt_memset(&xSysCFG.dev, 0x00U, _DEV_LEN);    //清空缓存数据
    xSysCFG.dev.en = uuzDEV_REG_OK;            //默认注册状态
    xSysCFG.dev.uart = uuzUART_6;            //通讯端口-无效
    xSysCFG.dev.count = uuzDEV_CONNECT_OK;            //连接状态计数
    xSysCFG.dev.isconnect = uuzDEV_CONNECTED;            //已连接状态
    xSysCFG.dev.id = uuzDEV_SL_MASTAR;            //设备编号
    xSysCFG.dev.type = uuzDEV_SL_MASTAR;            //设备类型
    //密码输入界面
    xSysCFG.lock_pin = uuzPIN_KEY_CNT;    //初始化密码
    cpu_id_init(&xSysCFG.dev);            //重新读取设备CPU的ID数据,并赋值给主机ID

    //结尾符号
    xSysCFG.crc = 0x3545U;  //结尾CRC
}

/**
 * @brief device_state_init
 */
void device_state_init(void)
{
    rt_memset(&xSysSTA, 0x00U, _UUZ_DEV_STATE_LEN);  //初始化缓存数据
    phec_value_init();  //phec 传感器相关信息初始化
    sinp260_value_init();  //sin-p260 传感器相关信息初始化
    //NOTE:集装箱版本没有灯光数据
#if (uuzDEVICE_TYPE==_DEV_INNOVATION_ONLY)
    fixed_cache_init();  //定量加肥状态缓存
#else
    lgt_cache_init();  //Light状态信息初始化
#endif
    tim_cache_init();  //Timer状态信息初始化
    irr_cache_init();  //灌溉状态信息初始化
    alarm_cache_init();  //报警状态参数初始化
}
