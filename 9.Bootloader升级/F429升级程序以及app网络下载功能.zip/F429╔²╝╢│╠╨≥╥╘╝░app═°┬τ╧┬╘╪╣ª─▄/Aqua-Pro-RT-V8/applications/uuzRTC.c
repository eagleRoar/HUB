/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-09   ZhouXiaomin     first version
 */
/* Includes ------------------------------------------------------------------*/
#include <rtthread.h>
#include <string.h>
/* ------------------------------------------------------------------*/
#include "uuzINIT.h"
#include "uuzRTC.h"
/*log---------------------------------------------*/
#define DBG_TAG "u.rtc"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/* ------------------------------------------------------------------*/
#ifdef BSP_USING_ONCHIP_RTC
/* ------------------------------------------------------------------*/
struct tm rTm;
/* ---------------------------------------------------------------------------*/
/**
 * @brief 获取系统的RTC数据
 */
void rt_rtc_get(void)
{
    time_t now;
    struct tm* p_tm;

    /* get current time */
    now = time(RT_NULL);
    /* lock scheduler. */
    rt_enter_critical();
    /* converts calendar time time into local time. */
    p_tm = localtime(&now);
    /* copy the statically located variable */
    rt_memcpy(&rTm, p_tm, sizeof(struct tm));
    /* unlock scheduler. */
    rt_exit_critical();
}

/**
 * @brief 设置系统的RTC数据
 * 
 * @param year :输入的参数-年
 * @param mon :输入的参数-月
 * @param day :输入的参数-日
 * @param hour :输入的参数-时
 * @param min :输入的参数-分
 * @param sec :输入的参数-秒
 */
void rt_rtc_set(u16 year, u16 mon, u16 day, u16 hour, u16 min, u16 sec)
{
    time_t now;
    struct tm tm_new;
    rt_device_t device;
    rt_err_t ret;

    /* update date. */
    tm_new.tm_year = year - 1900;
    tm_new.tm_mon = mon - 1;
    tm_new.tm_mday = day;
    tm_new.tm_hour = hour;
    tm_new.tm_min = min;
    tm_new.tm_sec = sec;

    /* converts the local time in time to calendar time. */
    now = mktime(&tm_new);

    device = rt_device_find("rtc");
    if (device == RT_NULL) {
        LOG_E("open RTC failed");
    } else {
        /* update to RTC device. */
        ret = rt_device_control(device, RT_DEVICE_CTRL_RTC_SET_TIME, &now);
        if (ret != RT_NULL) {
            LOG_E("opt RTC failed");
        }
    }

    rt_thread_mdelay(10);
    //刷新rTm的实时时间
    rt_rtc_get();
}

/**
 * @brief 计算当前的分钟数据
 * @return  u16 mins
 */
u16 uuz_usRTC_GetMinutes(void)
{
    return (rTm.tm_hour * 60 + rTm.tm_min);
}

/**
 * @brief 计算当前的秒数
 * @return  u32 seconds
 */
u32 uuz_ulRTC_GetSeconds(void)
{
    return (uuz_usRTC_GetMinutes() * 60 + rTm.tm_sec);
}

/**
 * @brief rt_rtc_info
 */
void rt_rtc_info(void)
{
    LOG_I("Current:[%04d-%02d-%02d %02d:%02d:%02d]", rTm.tm_year + 1900, rTm.tm_mon + 1, rTm.tm_mday, rTm.tm_hour,
            rTm.tm_min, rTm.tm_sec);
}
#endif
/*-----------------------------------------------------------------*/
