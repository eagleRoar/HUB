/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-01   ZhouXiaomin     first version
 */
/* Includes ------------------------------------------------------------------*/
#include "rtdef.h"
#include "uuzID.h"
/*Log---------------------------------------------*/
#define DBG_TAG "id.cpu"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/* Private---------------------------------------------------------------------------*/
CRC_HandleTypeDef hcrc;
/* ---------------------------------------------------------------------------*/
/**
 * @brief 打印设备的CPU ID信息
 */
void uuz_id(DevID_Typedef_t * dev)
{
    LOG_D("ID : %02X%02X%02X%02X",
            dev->cpuid[0], dev->cpuid[1],
            dev->cpuid[2], dev->cpuid[3]);
}

/**
 * @brief 初始化DEV设备的CPU-ID
 */
void cpu_id_init(DevID_Typedef_t * dev)
{
    u32 ulCpuID[3];
    //获取硬件固定ID
    ulCpuID[0] = HAL_GetUIDw0();
    ulCpuID[1] = HAL_GetUIDw1();
    ulCpuID[2] = HAL_GetUIDw2();
    LOG_D("CPU-ID:%X-%X-%X", ulCpuID[0], ulCpuID[1], ulCpuID[2]);

    //计算CRC
    u32 ulCRCValue = HAL_CRC_Accumulate(&hcrc, (uint32_t*) ulCpuID, 3);

    //计算设备ID
    u8 index;
    for (index = 0; index < 4; ++index) {
        dev->cpuid[index] = (ulCRCValue >> index) & 0xFF;
    }

    uuz_id(dev);   //打印相关数据
}
/* 导出到 msh 命令列表中 */
MSH_CMD_EXPORT(uuz_id, Get Device ID);
/*-----------------------------------------------------------------*/
