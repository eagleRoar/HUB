/* Includes ------------------------------------------------------------------*/
#include "uuzTEMP.h"
#include "math.h"
#include "uuzGPIO.h"
#include <rtthread.h>
/* logs  ----------------------------------------------------------*/
#define DBG_TAG "e.ta"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/* ----------------------------------------------------------------*/
/**
 * @brief 将摄氏度转换成华氏度
 * @param usT
 * @return
 */
u16 uuz_usTempC2F_ConvCplt(u16 usT)
{
    u32 ulTmpT = usT;
    /* 摄氏度->华氏度转换 */
    ulTmpT = (ulTmpT * 9 / 5) + 320;
    return (u16) ulTmpT;
}

/**
 * @brief 将华氏度转换成摄氏度
 * @param usT
 * @return
 */
u16 uuz_usTempF2C_ConvCplt(u16 usT)
{
    u32 ulTmpT = usT;
    if (ulTmpT < 320) {
        //如果是0下温度
        ulTmpT = 0;
    } else {
        /* 华氏度->摄氏度转换 */
        ulTmpT = (ulTmpT - 320) * 5 / 9;
    }
    return (u16) ulTmpT;
}

/**
 * @brief 配置数据精度为0.1，数据求整显示
 * @param usT
 * @return
 */
u16 uuz_usTemp2Int_ConvCplt(u16 usT)
{
    u32 ulTmpT = usT;

    /* 华氏度->摄氏度转换 */
    if ((ulTmpT % 10) >= 5) {
        ulTmpT = ulTmpT / 10 + 1;
    } else {
        ulTmpT = ulTmpT / 10;
    }
    ulTmpT *= 10;
    return (u16) ulTmpT;
}
