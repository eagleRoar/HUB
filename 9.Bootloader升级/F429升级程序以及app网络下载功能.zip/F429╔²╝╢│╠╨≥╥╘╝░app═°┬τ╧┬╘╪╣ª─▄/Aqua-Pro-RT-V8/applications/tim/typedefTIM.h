/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_TIM_H
#define __TYPEDEF_TIM_H

// include ---------------------------------------------
#include "typedefBASE.h"
#include "typedefDEVID.h"
#include "uuzConfigDEV.h"
#include "uuzOpt.h"
// ------- ---------------------------------------------
#define _TIM_CFG_MAX (2U)   //最多同时操作2组定时数据
typedef struct timer_config_t
{
    u8 en;  //配置有效性
    u8 md;  //Manual:工作模式
    u8 sta;  //手动状态：0-off/1-on
    //cycle-time
    Cycle_Typedef_t t_cycle;  //:second
    //timer-time
    Timer_Typedef_t t_timer[5];  //5组定时器:mins

    u16 end;    //0xBBBBU

}__attribute__ ((__packed__)) Tim_Config_Typedef_t;
#define uuzTIM_CFG_LEN (sizeof(Tim_Config_Typedef_t))

typedef struct tim_pro_t
{
    Tim_Config_Typedef_t *cfg[_TIM_CFG_MAX];   //配置地址

}__attribute__ ((__packed__)) Tim_Pro_Typedef_t;

#endif // __TYPEDEF_LGT_H
