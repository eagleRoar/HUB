/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
/*include*****************************************************************************/
#include <math.h>
#include <string.h>
/******************************************************************************/
#include "uuzEEPROM.h"
#include "uuzEVENT.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzRTC.h"
/* modbus---------------------------------------------*/
#include "uuzConfigBBL.h"
#include "uuzConfigHMI.h"
#include "uuzConfigMBR.h"
/* device id---------------------------------------------*/
#include "typedefBASE.h"
#include "typedefDEVID.h"
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
/* event---------------------------------------------*/
#include "uuzEventTIM.h"
#include "uuzEventVALVE.h"
/* log---------------------------------------------*/
#define DBG_TAG "e.tim"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/******************************************************************************/
Tim_Pro_Typedef_t xTimPro;  //灯光配置数据列表
Cycle_Item_Typedef_t xTimSta[_TIM_CFG_MAX];   //数据对应缓存
/******************************************************************************/
/**
 * @brief 定时缓存数据
 */
void tim_cache_init(void)
{
    //定时循环参数处理
    for (u8 index = 0; index < _TIM_CFG_MAX; index++) {
        rt_memset(&xTimSta[index], 0x00U, sizeof(Cycle_Item_Typedef_t));
    }
}

/**
 * @brief 初始化定时的Project配置数据
 */
void tim_config_add(Tim_Config_Typedef_t * xTimCfg)
{
    u16 index = 0;

    if (xTimCfg != RT_NULL) {

        xTimCfg->en = uuzTRUE;  //数据有效
        xTimCfg->md = _M_MANUAL;    //手动模式
        xTimCfg->sta = uuzOPT_OFF;  //手动模式-关闭状态

        //Cycle模式
        xTimCfg->t_cycle.on = 120;  //min:120min=2hour
        xTimCfg->t_cycle.off = 60;  //min:60=1hour

        //定时模式
        for (index = 0; index < 5; index++) {
            xTimCfg->t_timer[index].en = 0;  //0-off/1-on
            xTimCfg->t_timer[index].on = 8 * 60;  //8:00
            xTimCfg->t_timer[index].off = 18 * 60;  //18:00
        }

        xTimCfg->end = 0xBBBBU;  //结束符
        LOG_D("Init Timer Config");
    }
}

/**
 * @brief 释放定时的Project配置数据
 * @param xTimCfg
 */
void tim_config_init(Tim_Config_Typedef_t * xTimCfg)
{
    u16 index = 0;

    if (xTimCfg != RT_NULL) {

        xTimCfg->en = uuzFALSE;  //数据无效
        xTimCfg->md = _M_NONE;
        xTimCfg->sta = uuzOPT_OFF;

        //Cycle模式
        xTimCfg->t_cycle.on = 120;  //min:120min=2hour
        xTimCfg->t_cycle.off = 60;  //min:60=1hour

        //定时模式
        for (index = 0; index < 5; index++) {
            xTimCfg->t_timer[index].en = 0;  //0-off/1-on
            xTimCfg->t_timer[index].on = 8 * 60;//8:00
            xTimCfg->t_timer[index].off = 18 * 60;//18:00
        }

        xTimCfg->end = 0xBBBBU;  //结束符

        LOG_D("Init Timer Config");
    }
}

/**
 * @brief 定时事件判断处理
 */
void tim_opt_event(void)
{
    for (u8 index = 0; index < _TIM_CFG_MAX; index++) {
        tim_opt_judge(xTimPro.cfg[index], &xTimSta[index], index);
    }
}

/**
 * @brief 单路定时数据处理操作
 */
/**
 * @brief 单路定时数据处理
 * @param cfg:数据地址
 * @param index:数据位置
 */
void tim_opt_judge(Tim_Config_Typedef_t * cfg, Cycle_Item_Typedef_t * sta, u8 index)
{
    u8 ui_sync = 0;

    if (cfg->md == _M_MANUAL) {                //手动模式
        LOG_D("sta:%d-cfg:%d", sta->sta, cfg->sta);
        sta->sta = valve_single_state_get(index + 4);   //读取相关数据
        if (sta->sta != cfg->sta) {                //更新手动数据
            //rt_event_send(eventVALVE, valve_opt_single((index + 4), cfg->sta));  //发送运行事件
#if 0
            if (cfg->sta == uuzOPT_ON) {
                rt_event_send(eventVALVE, (OPT_VLV_5_ON << (2 * index)));
            } else {
                rt_event_send(eventVALVE, (OPT_VLV_5_OFF << (2 * index)));
            }
#endif
            valve_opt(0, (4 + index), cfg->sta);  //独立关闭
            sta->sta = cfg->sta;
            ui_sync = 1;    //刷新界面
        }
    } else if (cfg->md == _M_CYCLE) {  //循环模式
        LOG_D("[%d]opt:%d-sta:%d-time:%d", index, sta->opt, sta->sta, sta->time);
        if (sta->opt == uuzRUN_OFF) {    //判断是否处于执行阶段
            //开启定时运行状态
            sta->time = 0;  //清除计时
            //rt_event_send(eventVALVE, valve_opt_single((index + 4), uuzOPT_ON));  //发送运行事件
            //rt_event_send(eventVALVE, OPT_VLV_5_ON << (2 * index));
            valve_opt(0, (4 + index), uuzOPT_ON);  //开启
            sta->sta = uuzOPT_ON;  //打开定时
            sta->opt = uuzRUN_ON;  //启动运行
            ui_sync = 1;    //刷新界面
        } else {  //如果是开启状态，时间计数
            if (sta->sta == uuzOPT_ON) {  //已经达到循环开启定时状态
                if (sta->time >= cfg->t_cycle.on * 60) {  //开启灯光运行状态-关闭
                    sta->time = 0;  //清除计时
                    sta->sta = uuzOPT_OFF;  //关闭定时
                    //rt_event_send(eventVALVE, valve_opt_single((index + 4), uuzOPT_OFF));  //发送运行事件
                    //rt_event_send(eventVALVE, OPT_VLV_5_OFF << (2 * index));
                    valve_opt(0, (4 + index), uuzOPT_OFF);  //关闭
                    ui_sync = 1;    //刷新界面
                } else {
                    sta->time++;  //延时计数
                }
            } else {  //已经达到循环开启灯光状态
                if (sta->time >= cfg->t_cycle.off * 60) {  //开启灯光运行状态-开启
                    sta->time = 0;  //清除计时
                    //rt_event_send(eventVALVE, valve_opt_single((index + 4), uuzOPT_ON));  //发送运行事件
                    //rt_event_send(eventVALVE, OPT_VLV_5_ON << (2 * index));
                    valve_opt(0, (4 + index), uuzOPT_ON);  //开启
                    sta->sta = uuzOPT_ON;  //打开灯光
                    ui_sync = 1;    //刷新界面
                } else {
                    sta->time++;  //延时计数
                }
            }
        }
    } else if (cfg->md == _M_TIMER) {  //定时模式
        u32 time = uuz_usRTC_GetMinutes() * 60;  //获取当前事件-分
        u32 dayON = 0;
        u32 dayOFF = 0;
        u8 isValid = 0;

        sta->sta = valve_single_state_get(index + 4);   //读取相关数据
        for (u8 s_index = 0; s_index < 5; s_index++) {  //使用完整定时的阶段数据处理开启时间
            if (cfg->t_timer[s_index].en == 1) {  //定时数据有效获取最小开启时间和最大结束时间
                dayON = cfg->t_timer[s_index].on * 60;
                dayOFF = cfg->t_timer[s_index].off * 60;
                if ((time >= dayON) && (time <= dayOFF)) {  //为开启数据
                    isValid = 1;    //ON
                    break;
                }
            }
        }

        if (isValid) {  //有开启相关数据
            if (sta->sta == uuzOPT_OFF) {  //灯光状态为关闭
                sta->sta = uuzOPT_ON;  //灯光未开启,开启灯光
                //rt_event_send(eventVALVE, valve_opt_single((index + 4), sta->sta));  //发送运行事件
                //rt_event_send(eventVALVE, OPT_VLV_5_ON << (2 * index));
                valve_opt(0, (4 + index), uuzOPT_ON);  //开启
                ui_sync = 1;    //刷新界面
            }
        } else {  //为关闭数据
            if (sta->sta == uuzOPT_ON) {  //灯光状态为开启
                sta->sta = uuzOPT_OFF;  //灯光未开启,关闭灯光
                //rt_event_send(eventVALVE, valve_opt_single((index + 4), sta->sta));  //发送运行事件
                //rt_event_send(eventVALVE, OPT_VLV_5_OFF << (2 * index));
                valve_opt(0, (4 + index), uuzOPT_OFF);  //开启
                ui_sync = 1;    //刷新界面
            }
        }
    }

    if (ui_sync) {
        rt_event_send(eventDATA, UI_DATA_SYNC);  //发送界面刷新
    }
}
