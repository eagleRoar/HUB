/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __UUZ_TIM_EVENT_H
#define __UUZ_TIM_EVENT_H

#include "typedefTIM.h"
#include "typedefMBR.h"

extern Tim_Pro_Typedef_t xTimPro;  //灯光配置数据列表
extern Cycle_Item_Typedef_t xTimSta[_TIM_CFG_MAX];   //数据对应缓存

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 定时缓存数据
 */
void tim_cache_init(void);

/**
 * @brief 初始化定时的Project配置数据
 */
void tim_config_add(Tim_Config_Typedef_t * xTimCfg);

/**
 * @brief 释放定时的Project配置数据
 * @param xTimCfg
 */
void tim_config_init(Tim_Config_Typedef_t * xTimCfg);

/**
 * @brief 定时事件判断处理
 */
void tim_opt_event(void);

/**
 * @brief 单路定时数据处理操作
 */
void tim_opt_judge(Tim_Config_Typedef_t * cfg, Cycle_Item_Typedef_t * sta, u8 index);

#ifdef __cplusplus
}
#endif

#endif // __UUZ_TIM_EVENT_H
