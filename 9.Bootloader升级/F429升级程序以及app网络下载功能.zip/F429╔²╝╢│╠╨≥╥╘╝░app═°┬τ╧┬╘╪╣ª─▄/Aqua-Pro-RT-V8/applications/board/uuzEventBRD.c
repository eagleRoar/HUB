/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-28   ZhouXiaomin     first version
 */
//-------------------------------------------------------------------
#include <rtdevice.h>
#include <rtthread.h>
//-------------------------------------------------------------------
#include "uuzEVENT.h"
#include "uuzGPIO.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzEEPROM.h"
//-------------------------------------------------------------------
#include "typedefMBR.h"
#include "uuzConfigMBR.h"
//-------------------------------------------------------------------
#include "uuzDevCfg.h"
#include "uuzDevID.h"
#include "uuzEventSR.h"
#include "uuzEventPORT.h"
#include "uuzEventTEST.h"
//-------------------------------------------------------------------
#include "typedefLGT.h"
#include "uuzEventLGT.h"
//-------------------------------------------------------------------
#include "typedefBRD.h"
#include "uuzConfigBRD.h"
#include "uuzEventBRD.h"
/*log----------------------------------------------------------*/
#define DBG_TAG "e.brd"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/******************************************************************************/
/**
 * @brief 电源板的通讯协议
 */
MODBUS_RTU_CODE broad_opt_code[3] =
            {
                        { _CODE_R, 0x0011U, 0x0001U },  //Get Modbus-ID
                        { _CODE_RW, 0x0005U, 0x0001U },  //Read/Write Value
                        { _CODE_W, 0x0006U, 0x0001U }  //设置端口数据1-9:0x06-0x0F
            };
Board_Config_Typedef_t * xBoardCFG;    //输出控制板的配置数据地址
/******************************************************************************/

/**
 * @brief 初始化BOARD配置数据
 */
void board_config_init(void)
{
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
    board_init(&xBoardCFG->valve[0], 1, uuzPORT_IRR_MIX);
    board_init(&xBoardCFG->valve[1], 1, uuzPORT_IRR_FLOOD);
    board_init(&xBoardCFG->valve[2], 1, uuzPORT_IRR_IN);
    board_init(&xBoardCFG->valve[3], 1, uuzPORT_IRR_IN);
    board_init(&xBoardCFG->valve[4], 1, uuzPORT_IRR_FLOOD);
    board_init(&xBoardCFG->valve[5], 1, uuzPORT_IRR_FLOOD);
    LOG_D("_DEV_INNOVATION_ONLY");
#else
    board_init(&xBoardCFG->valve[0], 1, uuzPORT_IRR_FLOOD);
    board_init(&xBoardCFG->valve[1], 1, uuzPORT_IRR_DRAIN);
    board_init(&xBoardCFG->valve[2], 1, uuzPORT_IRR_IN);
    board_init(&xBoardCFG->valve[3], 1, uuzPORT_LIGHT);
    board_init(&xBoardCFG->valve[4], 1, uuzPORT_TIMER);
    board_init(&xBoardCFG->valve[5], 1, uuzPORT_TIMER);
    LOG_D("OTHER");
#endif
    xBoardCFG->ver = uuzDEVICE_TYPE;   //版本号
    xBoardCFG->end = 0xBBBBU;   //设置结束符
}

/**
 * @brief 接口初始参数
 * @param valve:需要设置的参数结构
 * @param en:接口状态
 * @param type:接口类型
 */
void board_init(Valve_Single_Typedef_t* valve, u16 en, u16 type)
{
    valve->en = en;
    valve->t = type;
}

/**
 * @brief 添加数据到板的端口列表
 * @param 暂时不用该函数
 */
void value_cache_init(void)
{
    u16 index = 0;
    u16 drain_count = 0;
    u16 flood_count = 0;
    u16 in_count = 0;
    u16 lgt_count = 0;

    for (index = 0; index < uuzDEV_BRD_VALVE_MAX; index++) {
        if (xBoardCFG->valve[index].en) {
            //LOG_D("V.en[%d]-V.t[%d]", xBoardCFG->valve[index].en, xBoardCFG->valve[index].t);
            if (xBoardCFG->valve[index].t == uuzPORT_IRR_FLOOD) {
                xDevSTA.xIrrOUT[flood_count].en = 1;
                xDevSTA.xIrrOUT[flood_count].t = uuzDEV_SL_BRD;
                xDevSTA.xIrrOUT[flood_count].io = index;
                xDevSTA.xIrrOUT[flood_count].id = xDevSTA.xBrd[xSysCFG.board_id].id;
                flood_count++;
            } else if (xBoardCFG->valve[index].t == uuzPORT_IRR_DRAIN) {
                xDevSTA.xIrrDRAIN[drain_count].en = 1;
                xDevSTA.xIrrDRAIN[drain_count].t = uuzDEV_SL_BRD;
                xDevSTA.xIrrDRAIN[drain_count].io = index;
                xDevSTA.xIrrDRAIN[drain_count].id = xDevSTA.xBrd[xSysCFG.board_id].id;
                drain_count++;
            } else if (xBoardCFG->valve[index].t == uuzPORT_IRR_IN) {
                xDevSTA.xIrrIN[in_count].en = 1;
                xDevSTA.xIrrIN[in_count].t = uuzDEV_SL_BRD;
                xDevSTA.xIrrIN[in_count].io = index;
                xDevSTA.xIrrIN[in_count].id = xDevSTA.xBrd[xSysCFG.board_id].id;
                in_count++;
            } else if (xBoardCFG->valve[index].t == uuzPORT_LIGHT) {
                xDevSTA.xLGT[lgt_count].en = 1;
                xDevSTA.xLGT[lgt_count].t = uuzDEV_SL_BRD;
                xDevSTA.xLGT[lgt_count].io = index;
                xDevSTA.xLGT[lgt_count].id = xDevSTA.xBrd[xSysCFG.board_id].id;
                //LOG_D("BRD-ID[%d]", xDevSTA.xBrd[xSysCFG.board_id].id);
                lgt_count++;
            }
        }
    }

    //灌溉端口数量计算
    xDevSTA.usCountIRROUT = flood_count;
    xDevSTA.usCountIRRDRAIN = drain_count;
    xDevSTA.usCountIRRIN = in_count;
    //灯光端口数量计算
    xDevSTA.usCountLGT = lgt_count;
    LOG_D(
            "OUT[%d]-DRAIN[%d]-IN[%d]-LGT[%d]",
            xDevSTA.usCountIRROUT,
            xDevSTA.usCountIRRDRAIN,
            xDevSTA.usCountIRRIN,
            xDevSTA.usCountLGT);
}
