#ifndef __UUZ_BOARD_EVENT_H
#define __UUZ_BOARD_EVENT_H

#include "typedefBASE.h"
#include "typedefBRD.h"
#include "typedefMBR.h"
#include "uuzConfigBRD.h"
#include <board.h>

extern MODBUS_RTU_CODE broad_opt_code[3];
extern Board_Config_Typedef_t * xBoardCFG;    //输出控制板的配置数据地址
#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化BOARD配置数据
 */
void board_config_init(void);

/**
 * @brief 添加数据到板的端口列表
 */
void value_cache_init(void);

/**
 * @brief 接口初始参数
 * @param valve:需要设置的参数结构
 * @param en:接口状态
 * @param type:接口类型
 */
void board_init(Valve_Single_Typedef_t* valve, u16 en, u16 type);

#ifdef __cplusplus
}
#endif

#endif // __UUZ_BOARD_EVENT_H
