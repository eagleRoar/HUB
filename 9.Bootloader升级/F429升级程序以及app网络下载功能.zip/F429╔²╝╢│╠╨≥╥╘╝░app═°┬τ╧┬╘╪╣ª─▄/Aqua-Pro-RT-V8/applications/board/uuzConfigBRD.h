#ifndef __UUZ_CONFIG_BOARD_H
#define __UUZ_CONFIG_BOARD_H

//单板工作端口数量
#define uuzDEV_BRD_VALVE_MAX (6U) //Aqua-Pro内部控制板端口总数

#endif // __UUZ_CONFIG_BOARD_H
