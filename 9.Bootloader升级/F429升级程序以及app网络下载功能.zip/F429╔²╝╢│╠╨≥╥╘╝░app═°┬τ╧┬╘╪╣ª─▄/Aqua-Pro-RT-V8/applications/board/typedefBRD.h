/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-03   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_BOARD_H
#define __TYPEDEF_BOARD_H

#include "typedefBASE.h"
#include "typedefVALVE.h"   //端口结构
#include "uuzConfigBRD.h"

/**
 * @brief 输出板的配置数据
 */
typedef struct board_config_t
{
    Valve_Single_Typedef_t valve[uuzDEV_BRD_VALVE_MAX];  //板上的端口状态

    u16 ver;    //数据版本
    u16 end;    //结束符0xBBBB;

}__attribute__ ((__packed__)) Board_Config_Typedef_t;

#define uuzBRD_CONFIG_LEN (sizeof(Board_Config_Typedef_t))

#endif // __TYPEDEF_BOARD_H
