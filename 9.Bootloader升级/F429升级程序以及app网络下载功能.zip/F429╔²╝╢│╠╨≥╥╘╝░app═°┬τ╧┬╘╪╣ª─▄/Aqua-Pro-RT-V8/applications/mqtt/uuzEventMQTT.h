#ifndef __UUZ_EVENT_MQTT_H
#define __UUZ_EVENT_MQTT_H

#include "typedefPORT.h"
#include "uuzConfigPORT.h"
#include <board.h>

#ifdef __cplusplus
extern "C" {
#endif

int mqtt_start(int argc, char **argv);
int mqtt_publish(int argc, char **argv);

#ifdef __cplusplus
}
#endif

#endif // __UUZ_EVENT_MQTT_H
