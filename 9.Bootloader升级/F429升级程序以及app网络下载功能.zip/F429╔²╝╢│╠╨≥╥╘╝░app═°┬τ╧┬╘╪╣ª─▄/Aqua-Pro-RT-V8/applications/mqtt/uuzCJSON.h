﻿#ifndef UUZ_CJSON_H
#define UUZ_CJSON_H

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif
#endif // UUZ_CJSON_H
