/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-01   ZhouXiaomin     first version
 */
/* Includes ------------------------------------------------------------------*/
#include "rtdef.h"
#include "uuzInit.h"

#define DBG_ENABLE
#define DBG_SECTION_NAME "CJSON"
#define DBG_LEVEL DBG_LOG
#define DBG_COLOR
#include <rtdbg.h>
/* ---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------*/
