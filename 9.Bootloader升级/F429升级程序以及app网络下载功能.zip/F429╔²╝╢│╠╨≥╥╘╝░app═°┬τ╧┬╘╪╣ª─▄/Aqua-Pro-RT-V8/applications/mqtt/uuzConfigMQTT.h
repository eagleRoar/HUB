/*
 * @Copyright (c) 2006-2018 RT-Thread Development Team:  
 * @SPDX-License-Identifier: Apache-2.0:  
 * @Date: 2020-01-01 09:23:03
 * @LastEditors  : Zhou Xiaomin
 * @LastEditTime : 2020-01-17 04:55:09
 * @Description:  
 */
#ifndef __UUZ_CONFIG_MQTT_H
#define __UUZ_CONFIG_MQTT_H

#define uuzNET_CLOUD_DEFAULT "192.168.0.128"
#define uuzNET_CLOUD_AMAZON "guardian.pro-leaf.com"
#define uuzNET_CLOUD_ALIYUN "120.78.138.133"

#define uuzMQTT_AMAZON_CLOUD "tcp://guardian.pro-leaf.com:1883"
#define uuzMQTT_LAZYFARM_CLOUD "tcp://18.188.119.246:1883"

/**
 * MQTT URI farmat:
 * domain mode
 * tcp://iot.eclipse.org:1883
 *
 * ipv4 mode
 * tcp://192.168.10.1:1883
 * ssl://192.168.10.1:1884
 *
 * ipv6 mode
 * tcp://[fe80::20c:29ff:fe9a:a07e]:1883
 * ssl://[fe80::20c:29ff:fe9a:a07e]:1884
 */
#define MQTT_URI                "tcp://192.168.0.253:1883"
//#define MQTT_URI                uuzMQTT_LAZYFARM_CLOUD
//#define MQTT_URI                uuzMQTT_AMAZON_CLOUD
#define MQTT_USERNAME           "test"
#define MQTT_PASSWORD           "test"
#define MQTT_SUBTOPIC           "/010001/state"
//#define MQTT_SUBTOPIC           "/CA4aec5776164a23/state"
#define MQTT_PUBTOPIC           "/mqtt/test"
#define MQTT_WILLMSG            "Goodbye!"

#endif // __UUZ_CONFIG_MQTT_H
