#include <board.h>
#include <rtdevice.h>
#include <uuzGPIO.h>

#define DBG_TAG "u.gpio"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>

void rt_gpio_init(void)
{
#if defined(uuzCONFIG_USART_RS485_ENABLE)
    /* RS485的设置 */
    rt_pin_mode(RS485_CLK_PIN, PIN_MODE_OUTPUT);
#endif
    /* HMI的启动设置 */
    rt_pin_mode(HMI_RST_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(HMI_RST_PIN, PIN_HIGH);
    /* 网口 */
    rt_pin_mode(ETH_RST_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(ETH_RST_PIN, PIN_HIGH);
    /*Wifi*/
    rt_pin_mode(WIFI_RST_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(WIFI_RST_PIN, PIN_HIGH);
    /*Beep*/
    rt_pin_mode(BEEP_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(BEEP_PIN, PIN_HIGH);
    /* set gpio pin mode */
    rt_pin_mode(EXT1_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(EXT2_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(EXT3_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(EXT4_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(EXT5_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(EXT6_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(EXT7_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(EXT8_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(EXT9_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(EXT10_PIN, PIN_MODE_OUTPUT);
    /* set gpio pin to value */
    rt_pin_write(EXT1_PIN, PIN_HIGH);
    rt_pin_write(EXT2_PIN, PIN_HIGH);
    rt_pin_write(EXT3_PIN, PIN_HIGH);
    rt_pin_write(EXT4_PIN, PIN_HIGH);
    rt_pin_write(EXT5_PIN, PIN_HIGH);
    rt_pin_write(EXT6_PIN, PIN_HIGH);
    rt_pin_write(EXT7_PIN, PIN_HIGH);
    rt_pin_write(EXT8_PIN, PIN_HIGH);
    rt_pin_write(EXT9_PIN, PIN_HIGH);
    rt_pin_write(EXT10_PIN, PIN_HIGH);

    /*SD卡初始化和检测*/
    rt_pin_mode(SD_INT_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(SD_INT_PIN, PIN_LOW);
    rt_pin_mode(SD_CHK_PIN, PIN_MODE_INPUT);
}

void phy_reset(void)
{
    rt_pin_mode(ETH_RST_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(ETH_RST_PIN, PIN_HIGH);
    rt_thread_mdelay(50);
    rt_pin_write(ETH_RST_PIN, PIN_LOW);
    rt_thread_mdelay(50);
    rt_pin_write(ETH_RST_PIN, PIN_HIGH);
}
