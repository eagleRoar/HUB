/*
 * File      : httpclient.c
 *
 * Copyright (c) 2006-2022, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date             Author      Notes
 * 2018-07-20     flybreak     first version
 * 2018-09-05     flybreak     Upgrade API to webclient latest version
 */

#include <webclient.h>  /* 使用 HTTP 协议与服务器通信需要包含此头文件 */
#include <sys/socket.h> /* 使用BSD socket，需要包含socket.h头文件 */
#include <netdb.h>
#include <cJSON.h>
//#include <finsh.h>
#include "typedefBASE.h"
#include <dfs_posix.h>
#include <rtdbg.h>
#include "uuzSD.h"

#define DOWNLOAD                "/download"
#define DOWNLOAD_FILE           "/download/downloadFile.bin"

#define GET_HEADER_BUFSZ        1024        //头部大小
#define GET_RESP_BUFSZ          1024        //响应缓冲区大小

/**
 * @brief  SD处理初始化
 * @return RT_ERROR 初始化失败
 *         RT_EOK   初始化成功
 */
rt_err_t SDInit(void)
{
    rt_device_t dev;
    rt_err_t ret;

    //SD卡结构初始化
    if (sd_card_is_vaild()) //检查SD卡是否有插
    {
        dev = rt_device_find("sd0");
        if (dev != RT_NULL)
        {
            if (dfs_mount("sd0", "/", "elm", 0, 0) == 0)
            {
                rt_kprintf("sd card mount to / success!\r\n");
                rt_access_dir(DOWNLOAD);

                ret = RT_EOK;
            }
            else
            {
                rt_kprintf("sd card mount to / failed!\r\n");
                ret = RT_ERROR;
            }
        }
        else
        {
            rt_kprintf("find sd0 failed!\r\n");
            ret =  RT_ERROR;
        }
    }
    else
    {
        rt_kprintf("find sd card failed!\r\n");
        ret =  RT_ERROR;
    }

    return ret;
}

/**
 * @brief 将数据写入相应文件
 *
 * @param name 写入的文件名称
 * @param text 需要写入的数据内容
 * @param l 写入长度
 * @return
 */
rt_err_t write_data(char* name, u8* text, u32 offset, u32 l)
{
    int fd;

    if (text != NULL) {
        /*生成文件名称*/
        /* 以创建和读写模式打开 name 文件，如果该文件不存在则创建该文件*/
        fd = open(name, O_WRONLY | O_CREAT);
        if (fd >= 0) {
            lseek(fd,offset,SEEK_SET);//设置偏移地址
            write(fd, text, l);
            close(fd);
            //rt_kprintf("Write done.\n");
            return RT_EOK;
        }
    }
    return RT_ERROR;
}

/**
 * @brief 删除相应文件
 *
 * @param name 文件名称
 * @return RT_ERROR 删除失败
 * @return RT_EOK   删除成功
 */
rt_err_t deleteFile(char* name)
{
    int ret;
    ret = rmdir(name);
    if(0 == ret)
    {
        return RT_EOK;
    }
    else
    {
        return RT_ERROR;
    }

}

void GetUpdataFileFromWeb(void)
{
    rt_uint8_t *buffer = RT_NULL;
    int resp_status;
    struct webclient_session *session = RT_NULL;
    char *weather_url = "http://pic.pro-leaf.com/down/aqua_pro.bin";//Justin debug
    int content_length = -1, bytes_read = 0;
    u32 content_pos = 0;
    static rt_err_t sdInitFlag = RT_ERROR;

    /* 创建会话并且设置响应的大小 */
    session = webclient_session_create(GET_HEADER_BUFSZ);
    if (session == RT_NULL)
    {
        rt_kprintf("No memory for get header!\n");
        goto __exit;
    }

    /* 发送 GET 请求使用默认的头部 */
    if ((resp_status = webclient_get(session, weather_url)) != 200)
    {
        rt_kprintf("webclient GET request failed, response(%d) error.\n", resp_status);
        goto __exit;
    }

    /* 分配用于存放接收数据的缓冲 */
    buffer = rt_calloc(1, GET_RESP_BUFSZ);
    if (buffer == RT_NULL)
    {
        rt_kprintf("No memory for data receive buffer!\n");
        goto __exit;
    }

    sdInitFlag = SDInit();

    content_length = webclient_content_length_get(session);
    rt_kprintf("get connect data length = %d-----------------\r\n",content_length);//Justin debug

    if(RT_EOK == sdInitFlag)
    {
        /* 删除原来位置的文件 */
        if(RT_EOK == deleteFile(DOWNLOAD_FILE))
        {
            rt_kprintf("delete file successful\r\n");
        }
        else
        {
            rt_kprintf("delete file faile\r\n");
        }

        if (content_length < 0)
        {
            /* 返回的数据是分块传输的. */
            do
            {
                bytes_read = webclient_read(session, buffer, GET_RESP_BUFSZ);
                if (bytes_read <= 0)
                {
                    break;
                }

                /* 将数据存入SD卡 */
                write_data(DOWNLOAD_FILE,buffer,0,bytes_read);
            }while (1);
        }
        else
        {
            do
            {
                bytes_read = webclient_read(session, buffer,
                                            content_length - content_pos > GET_RESP_BUFSZ ?
                                            GET_RESP_BUFSZ : content_length - content_pos);

                if (bytes_read <= 0)
                {
                    break;
                }

                /* 将数据存入SD卡 */
                write_data(DOWNLOAD_FILE,buffer,content_pos,bytes_read);

                content_pos += bytes_read;
                rt_kprintf("save file data %d\r\n",content_pos);
            }while (content_pos < content_length);
        }
    }
    else
    {
        rt_kprintf("sd init fail\r\n");
    }

__exit:

    /* 关闭会话 */
    if (session != RT_NULL)
        webclient_close(session);
    /* 释放缓冲区空间 */
    if (buffer != RT_NULL)
        rt_free(buffer);
}

