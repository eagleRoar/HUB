/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-03   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_VALVE_H
#define __TYPEDEF_VALVE_H

#include "typedefBASE.h"
#include "uuzConfigDEV.h"
#include "uuzConfigBRD.h"

typedef struct valve_single_t
{
    u16 en;  //开关ON|OFF
    u16 t;  //类型

} Valve_Single_Typedef_t;

/**
 * @brief 板上的接口数量
 */
typedef struct valve_config_t
{
    /**
     * @note 板上的端口状态
     */
    Valve_Single_Typedef_t valve[uuzDEV_BRD_VALVE_MAX];
    /**
     * @note 外设的端口状态
     */
    Valve_Single_Typedef_t aux[uuzDEV_AUX_MAX];

    u8 ucEnd;

} Valve_Config_Typedef_t;

#define uuzVALVE_CONFIG_LEN (sizeof(Valve_Config_Typedef_t))

#endif // __TYPEDEF_VALVE_H
