#ifndef __UUZ_CONFIG_VALVE_H
#define __UUZ_CONFIG_VALVE_H

//Value的类型
typedef enum
{
    //Controler相关
    uuzVALVE_CO2 = 0x00U,  //输出CO2
    uuzVALVE_HEAT = 0x01U,  //输出加热
    uuzVALVE_COOL = 0x02U,  //输出制冷
    uuzVALVE_HUMI = 0x03U,  //输出加湿
    uuzVALVE_DEHUMI = 0x04U,  //输出除湿
    uuzVALVE_CH1_LIGHT = 0x05U,  //输出灯光
    uuzVALVE_CH2_LIGHT = 0x06U,  //输出灯光
    uuzVALVE_ALARM = 0x07U,  //输出报警
    //灌溉相关
    uuzVALVE_IRR_OUT = 0x10U,  //输出灌溉阀/泵
    uuzVALVE_IRR_BACK = 0x11U,  //输出回水阀/泵
    uuzVALVE_IRR_IN = 0x12U,  //输出清水阀/泵
    uuzVALVE_IRR_MIX = 0x13U,  //输出混合/取样泵
    //定时或循环
    uuzVALVE_CYCLE = 0x14U,  //输出循环模式
    uuzVALVE_TIMER = 0x15U,  //输出定时模式
    //电压相关
    uuzVALVE_AUX_H,  //输出220V
    uuzVALVE_AUX_L,  //输出24V
    //空白
    uuzVALVE_NULL = 0xFFU  //NULL
} ENMU_TYPE_VALVE;

#endif // __UUZ_CONFIG_VALVE_H
