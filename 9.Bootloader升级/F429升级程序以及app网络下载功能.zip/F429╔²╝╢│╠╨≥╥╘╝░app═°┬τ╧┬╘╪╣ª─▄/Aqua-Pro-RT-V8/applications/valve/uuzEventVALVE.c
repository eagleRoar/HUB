/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-28   ZhouXiaomin     first version
 */
//-------------------------------------------------------------------
#include <rtdevice.h>
#include <rtthread.h>
//-------------------------------------------------------------------
#include "uuzEVENT.h"
#include "uuzGPIO.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
//-------------------------------------------------------------------
#include "typedefMBR.h"
#include "uuzConfigMBR.h"
//-------------------------------------------------------------------
#include "typedefVALVE.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
#include "uuzEventSR.h"
#include "uuzEventVALVE.h"
#include "uuzEventBRD.h"
/*log----------------------------------------------------------*/
#define DBG_TAG "e.valve"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/******************************************************************************/
MODBUS_RTU_CODE aux_opt_code[3] =
            {
                        { _CODE_R, 0x0010U, 0x0001U },  //Get Modbus-ID
                        { _CODE_RW, 0x00FFU, 0x0001U },  //Read/Write Value
                        { _CODE_RW, 0x0036U, 0x0001U }  //Set Modbus-ID
            };
/******************************************************************************/
/**
 * @brief 获取内部Broad板的ID数据
 * @return u16 返回内部Broad板的唯一ID
 */
u16 valve_broad_id_get(void)
{
#if 1
    for (u8 index = 0; index < uuzDEV_BRD_MAX; index++) {
        if (xDevSTA.xBrd[index].en == uuzDEV_REG_OK) {
            if (xDevSTA.xBrd[index].type == uuzDEV_SL_BRD) {
                //获取内部Broad的ID
                //只有一个内部Broad板的ID
                return index;
            }
        }
    }
    return (0xFFU);
#else
    return 0;
#endif
}

/**
 * @brief 接口初始参数
 * @param valve:需要设置的参数结构
 * @param en:接口状态
 * @param type:接口类型
 */
void valve_init(Valve_Single_Typedef_t* valve, u16 en, u16 type)
{
    valve->en = en;
    valve->t = type;
}

/**
 * @brief Board设备实时数据处理
 * @param data 需要处理的设备实时数据
 */
void valve_board_resolve(u8* data)
{
    u16 ucLenCommand = 3;

    if (data != NULL) {
        u16 tmpState = usU8ToU16(data + ucLenCommand, uuzMSB);
#if 0
        u8 is_need_update = 0;
        if (tmpState != (u16) xSysSTA.state_brd[0]) {                //NOTE:如果接收数据和缓存数据不一致
            xSysSTA.state_brd[0] = tmpState;
            is_need_update = 1;
        }

        if (is_need_update == 1) {                //NOTE:需要更新数据发送相关信号
            rt_event_send(eventDATA, UI_DATA_SYNC);
        }
#else
        xSysSTA.state_brd[0] = tmpState;
        rt_event_send(eventDATA, UI_DATA_SYNC);
#endif
    }
}

/**
 * @brief Board板的操作回复数据处理
 * @param data
 */
void valve_board_opt_replay(u8* data)
{
    u16 ucLenCommand = 4;

    if (data != NULL) {
        u16 tmpState = usU8ToU16(data + ucLenCommand, uuzMSB);
#if 0
        u8 is_need_update = 0;

        if (tmpState != (u16) xSysSTA.state_brd[0]) {                //NOTE:如果接收数据和缓存数据不一致
            xSysSTA.state_brd[0] = tmpState;
            is_need_update = 1;
        }

        if (is_need_update == 1) {                //NOTE:需要更新数据发送相关信号
            rt_event_send(eventDATA, UI_DATA_SYNC);
        }
#else
        xSysSTA.state_brd[0] = tmpState;
        rt_event_send(eventDATA, UI_DATA_SYNC);
#endif
    }
}

/**
 * @brief 将设备状态数据转换成单板数据
 * @param state: xSysSTA.state_brd[0]
 * @return
 */
u16 valve_board_trans(void)
{
    int single_state = 0;
    u16 state = 0;
    int index = 0;

    //Port 1
    for (index = 0; index < uuzDEV_BRD_VALVE_MAX; index++) {
        single_state = (xSysSTA.state_brd[0] >> index) & (0x0001U);
        if (single_state == uuzOPT_ON) {
            state = state | (OPT_VLV_1_ON << index * 2);
        } else {
            state = state | (OPT_VLV_1_OFF << index * 2);
        }
    }

    return state;
}

/**
 * @brief 将设备单个数据端口输出
 * @param index
 * @return :uuzOPT_ON/uuzOPT_OFF
 */
u16 valve_single_state_get(u16 index)
{
    return ((xSysSTA.state_brd[0] >> index) & 0x01U);
}

/**
 * @brief 单独打开一个端口
 * @param index:端口编号
 * @param sta:执行状态
 * @return 返回端口操作值
 */
u16 valve_opt_single(u16 index, u16 sta)
{
    u16 state = 0;

    state = valve_board_trans();    //获取基础数据
    LOG_D("trans[%d]", state);
    if (sta == uuzOPT_OFF) {                //Manual-Single-OFF
        state |= (0x0001U << (index * 2));  //OFF
        state &= ~(0x0001U << ((index * 2) + 1));  //ON
    } else {  //Manual-Single-ON
        state &= ~(0x0001U << (index * 2));    //OFF
        state |= (0x0001U << ((index * 2) + 1));   //ON
    }

    LOG_D("opt[%d]", state);
    return state;
}

/**
 * @brief 按类型开启和关闭端口设备
 *
 * @param type 需要操作的类型
 * @param sta 操作开启和关闭:(0-OFF/1-ON)
 */
void valve_opt_group(u8 type, u16 sta)
{
#if 0
    //按类型操作端口数据
    for (u8 index = 0; index < uuzDEV_BRD_VALVE_MAX; index++) {
        if (xBoardCFG->valve[index].en == 1) {  //判断端口数据
            if (xBoardCFG->valve[index].t == type) {  //判断灯光数据
                valve_opt(xSysCFG.board_id, index, sta);  //直接操作数据
                LOG_D("valve[%d]:%d", type, sta);
            }
        }
    }
#else
#if 0
    //按类型操作端口数据
    for (u8 index = 0; index < uuzDEV_BRD_VALVE_MAX; index++) {
        if (xBoardCFG->valve[index].en == 1) {  //判断端口数据
            if (xBoardCFG->valve[index].t == type) {  //判断类型
                LOG_D("valve[%d][%d]", type, sta);
                rt_event_send(eventVALVE, valve_opt_single(index, sta));
                rt_event_send(eventDATA, UI_DATA_SYNC);  //发送界面刷新
            }
        }
    }
#endif
#if 0
    if (sta == uuzOPT_ON) {
        rt_event_send(eventVALVE, OPT_VLV_4_ON);  //灯光模式
    } else {
        rt_event_send(eventVALVE, OPT_VLV_4_OFF);  //灯光模式
    }
#endif
    valve_opt(0, 3, sta);  //开启|关闭
#endif
}

/**
 *
 * @brief 读取内部Broad板的实时数据
 * @param id:板的ID号
 */
void valve_broad_read(u8 index)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Device ID
    ucDataCommand[ucLenCommand++] = xDevSTA.xBrd[index].id;
    ucDataCommand[ucLenCommand++] = uuzMBR_READ_HOLDING_REGISTER;
    vU16ToU8(ucDataCommand + ucLenCommand, broad_opt_code[_MBR_R_VALUE].code, uuzMSB);
    ucLenCommand += 2U;
    //读取1组数据(16位)
    vU16ToU8(ucDataCommand + ucLenCommand, broad_opt_code[_MBR_R_VALUE].n, uuzMSB);
    ucLenCommand += 2U;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;
    //发送相关数据
    cmd_set(xDevSTA.xBrd[index].uart, (u8*) ucDataCommand, ucLenCommand);

    //N次读取无数据，将连接状态切断
    if (xDevSTA.xBrd[index].count < uuzDEV_CONNECT_ERR) {
        //连接计数
        xDevSTA.xBrd[index].count++;
    }
}

/**
 *
 * @brief 读取内部Broad板的实时数据
 * @param u8 index:需要设置的参数结构
 * @param state:需要操作的端口状态
 */
void valve_broad_set(u8 index, u16 state)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Device ID
    ucDataCommand[ucLenCommand++] = xDevSTA.xBrd[index].id;
    ucDataCommand[ucLenCommand++] = uuzMBR_WRITE_REGISTER;
    vU16ToU8(ucDataCommand + ucLenCommand, broad_opt_code[_MBR_R_VALUE].code, uuzMSB);
    ucLenCommand += 2U;
    //读取1组数据(16位)
    vU16ToU8(ucDataCommand + ucLenCommand, state, uuzMSB);
    ucLenCommand += 2U;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;

    cmd_set(xDevSTA.xBrd[index].uart, (u8*) ucDataCommand, ucLenCommand);

    //N次读取无数据，将连接状态切断
    if (xDevSTA.xBrd[index].count < uuzDEV_CONNECT_ERR) {
        //连接计数
        xDevSTA.xBrd[index].count++;
    }
}

/**
 * @brief 单独操作一个端口数据
 * @param index:电源板编号
 * @param id :Valve相应位置 0~8=1-9
 * @param sta :1-ON/0-OFF
 */
void valve_opt(u8 index, u8 id, u16 sta)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Device ID
    ucDataCommand[ucLenCommand++] = xDevSTA.xBrd[index].id;
    ucDataCommand[ucLenCommand++] = uuzMBR_WRITE_REGISTER;
    vU16ToU8(ucDataCommand + ucLenCommand, broad_opt_code[_MBR_R_VALUE + 1].code + id, uuzMSB);
    ucLenCommand += 2U;
    //写入开关状态(16位)
    vU16ToU8(ucDataCommand + ucLenCommand, sta, uuzMSB);
    ucLenCommand += 2U;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;

    cmd_set(xDevSTA.xBrd[index].uart, (u8*) ucDataCommand, ucLenCommand);

    //N次读取无数据，将连接状态切断
    if (xDevSTA.xBrd[index].count < uuzDEV_CONNECT_ERR) {
        //连接计数
        xDevSTA.xBrd[index].count++;
    }
}

#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
#include "uuzDevID.h"
#include "uuzConfigBBL.h"
#include "uuzEventSR.h"

#if 1
u16 ucACSState;
u16 ucACSValue;

u16 ucPlcPortState[10];

/**
 * @brief 接收注册信息数据
 * @param data
 */
void ac_valve_recv(u8 * data)
{
    //AC Station开关状态
    ucACSState = data[0];
    //AC Station开关量
    ucACSValue = data[1];
}

/**
 * @brief 初始化AC-Station ID为32
 */
void ac_valve_init(void)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;
    u8 ucTargetID[4];
    ucTargetID[0] = 0xC7U;
    ucTargetID[1] = 0xB5U;
    ucTargetID[2] = 0x5DU;
    ucTargetID[3] = 0x24U;

    // Device Type
    ucDataCommand[ucLenCommand++] = 32;
    ucDataCommand[ucLenCommand++] = 0xF7;
    // Own Device ID
    rt_memset(ucDataCommand + ucLenCommand, 0xF7U, 4);
    ucLenCommand += 4;

    uuz_vCommandSendToUSART(xDevSTA.xDos[0].uart, uuzBBL_BROADCAST_ID, uuzBBL_REPLY, ucTargetID,
            ucLenCommand, ucDataCommand);
}

/**
 * @brief 保持AC连接
 */
void ac_valve_read(void)
{
    u8 ucDataCommand[32];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Device ID
    ucDataCommand[ucLenCommand++] = 32;
    ucDataCommand[ucLenCommand++] = uuzMBR_READ_HOLDING_REGISTER;
    vU16ToU8(ucDataCommand + ucLenCommand, uuzADDR_RW_ACS_STA_DATA, uuzMSB);
    ucLenCommand += 2U;
    ucDataCommand[ucLenCommand++] = 0x00;
    ucDataCommand[ucLenCommand++] = 0x01;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;

    cmd_set(xDevSTA.xDos[0].uart, (u8*) ucDataCommand, ucLenCommand);   //连接到默认AC端口
}

/**
 * @brief 操作AC状态
 */
void ac_valve_opt(u8 state, u8 value)
{
    u8 ucDataCommand[32];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Device ID
    ucDataCommand[ucLenCommand++] = 32;  //固定ID
    ucDataCommand[ucLenCommand++] = uuzMBR_WRITE_REGISTER;
    vU16ToU8(ucDataCommand + ucLenCommand, uuzADDR_RW_ACS_STA_DATA, uuzMSB);
    ucLenCommand += 2U;
    ucDataCommand[ucLenCommand++] = state;
    ucDataCommand[ucLenCommand++] = value;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;

    cmd_set(xDevSTA.xDos[0].uart, (u8*) ucDataCommand, ucLenCommand);   //连接到默认AC端口

}
#else
u16 ucACSState;
u16 ucACSValue;

/**
 * @brief 接收注册信息数据
 * @param data
 */
void ac_valve_recv(u8 * data)
{
    //AC Station开关状态
    ucACSState = data[0];
    //AC Station开关量
    ucACSValue = data[1];
}

/**
 * @brief 初始化AC-Station ID为32
 */
void ac_valve_init(void)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;
    u8 ucTargetID[4];
    ucTargetID[0] = 0xC7U;
    ucTargetID[1] = 0xB5U;
    ucTargetID[2] = 0x5DU;
    ucTargetID[3] = 0x24U;

    // Device Type
    ucDataCommand[ucLenCommand++] = 32;
    ucDataCommand[ucLenCommand++] = 0xF7;
    // Own Device ID
    rt_memset(ucDataCommand + ucLenCommand, 0xF7U, 4);
    ucLenCommand += 4;

    uuz_vCommandSendToUSART(xDevSTA.xDos[0].uart, uuzBBL_BROADCAST_ID, uuzBBL_REPLY, ucTargetID,
            ucLenCommand, ucDataCommand);
}

/**
 * @brief 保持AC连接
 */
void ac_valve_read(void)
{
    u8 ucDataCommand[32];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Device ID
    ucDataCommand[ucLenCommand++] = 32;
    ucDataCommand[ucLenCommand++] = uuzMBR_READ_HOLDING_REGISTER;
    vU16ToU8(ucDataCommand + ucLenCommand, uuzADDR_RW_ACS_STA_DATA, uuzMSB);
    ucLenCommand += 2U;
    ucDataCommand[ucLenCommand++] = 0x00;
    ucDataCommand[ucLenCommand++] = 0x01;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;

    cmd_set(xDevSTA.xDos[0].uart, (u8*) ucDataCommand, ucLenCommand);   //连接到默认AC端口
}

/**
 * @brief 操作AC状态
 */
void ac_valve_opt(u8 state, u8 value)
{
    u8 ucDataCommand[32];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Device ID
    ucDataCommand[ucLenCommand++] = 32;  //固定ID
    ucDataCommand[ucLenCommand++] = uuzMBR_WRITE_REGISTER;
    vU16ToU8(ucDataCommand + ucLenCommand, uuzADDR_RW_ACS_STA_DATA, uuzMSB);
    ucLenCommand += 2U;
    ucDataCommand[ucLenCommand++] = state;
    ucDataCommand[ucLenCommand++] = value;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;

    cmd_set(xDevSTA.xDos[0].uart, (u8*) ucDataCommand, ucLenCommand);   //连接到默认AC端口

}
#endif
#endif
