#ifndef __UUZ_VALVE_EVENT_H
#define __UUZ_VALVE_EVENT_H

#include "typedefBASE.h"
#include "typedefMBR.h"
#include "typedefVALVE.h"
#include "uuzConfigVALVE.h"
#include <board.h>

extern MODBUS_RTU_CODE broad_opt_code[3];
extern Valve_Config_Typedef_t xValveConfig;
#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 接口初始参数
 * @param valve:需要设置的参数结构
 * @param en:接口状态
 * @param type:接口类型
 * @param id:执行的设备ID
 * @param addr:执行的设备命令
 */
void valve_init(Valve_Single_Typedef_t* valve, u16 en, u16 type);

/**
 * @brief 单独打开一个端口
 * @param index:端口编号
 * @param sta:执行状态
 * @return 返回端口操作值
 */
u16 valve_opt_single(u16 index, u16 sta);

/**
 * @brief 按类型开启和关闭端口设备
 * 
 * @param type 需要操作的类型
 * @param sta 操作开启和关闭:(0-OFF/1-ON)
 */
void valve_opt_group(u8 type, u16 sta);

/**
 * @brief 单独操作一个端口数据
 * @param index:电源板编号
 * @param id :Valve相应位置 0~8=1-9
 * @param sta :1-ON/0-OFF
 */
void valve_opt(u8 index, u8 id, u16 sta);
/**
 * @brief 获取内部Broad板的ID数据
 * @return u16 返回内部Broad板的唯一ID
 */
u16 valve_broad_id_get(void);

/**
 * @brief Board设备实时数据处理
 *
 * @param data 需要处理的设备实时数据
 */
void valve_board_resolve(u8* data);

/**
 * @brief Board板的操作回复数据处理
 * @param data
 */
void valve_board_opt_replay(u8* data);

/**
 * @brief 将设备单个数据端口输出
 * @param index
 * @return
 */
u16 valve_single_state_get(u16 index);

/**
 * @brief 将设备状态数据转换成单板数据
 * @param state: xSysSTA.state_brd[0]
 * @return
 */
u16 valve_board_trans(void);

/**
 *
 * @brief 读取内部Broad板的实时数据
 * @param id:板的ID号
 */
void valve_broad_read(u8 id);

/**
 *
 * @brief 读取内部Broad板的实时数据
 * @param u8 index:需要设置的参数结构
 * @param state:需要操作的端口状态
 */
void valve_broad_set(u8 index, u16 state);

#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
extern u16 ucACSState;
extern u16 ucACSValue;

extern u16 ucPlcPortState[10];
/**
 * @brief 接收注册信息数据
 * @param data
 */
void ac_valve_recv(u8 * data);

/**
 * @brief 初始化AC-Station ID为32
 */
void ac_valve_init(void);

/**
 * @brief 保持AC连接
 */
void ac_valve_read(void);

/**
 * @brief 操作AC状态
 */
void ac_valve_opt(u8 state, u8 value);
#endif

#ifdef __cplusplus
}
#endif

#endif // __UUZ_VALVE_EVENT_H
