/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
/*include*****************************************************************************/
#include <math.h>
#include <string.h>
/******************************************************************************/
#include "uuzEVENT.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzEEPROM.h"
#include "uuzRTC.h"
/******************************************************************************/
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
/******************************************************************************/
#include "typedefDEVID.h"
#include "uuzConfigEEPROM.h"
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
/******************************************************************************/
#include "typedefIRR.h"
#include "uuzEventIRR.h"
#include "uuzEventLGT.h"
#include "uuzEventWLS.h"
#include "uuzEventP260.h"
#include "uuzEventVALVE.h"
#include "uuzConfigPORT.h"
#include "uuzEventBRD.h"
/*UI---------------------------------------------*/
#include "uuzConfigHMI.h"
#include "uuzEventHMI.h"
/*log---------------------------------------------*/
#define DBG_TAG "e.irr"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/******************************************************************************/
Irr_Item_Typedef_t xIrrCache[_IRR_PRO_MAX];  //灌溉的缓存数据
Irr_Pro_Typedef_t * xIrrPro;    //灌溉程序相关数据地址
/******************************************************************************/
#if (uuzDEVICE_TYPE != _DEV_INNOVATION_ONLY)
/**
 * @brief 初始化灌溉的Project配置数据
 */
void irr_mode_config_init(void)
{
    u8 index = 0;

    for (index = 0; index < _IRR_PRO_MAX; index++) {   //内部端口设备参数
        xIrrPro->pro[index].en = RT_FALSE;
        xIrrPro->pro[index].md = _IRR_CUSTOMIZE;//默认为通用模式
        irrigation_config_single_default_init(&xIrrPro->pro[index].cfg, xIrrPro->pro[index].md);//更新相关内容数据
    }

    xIrrPro->ver = uuzDEVICE_TYPE;  //软件版本号
    xIrrPro->end = 0xBBBBU;  //结束符
}

/**
 * @brief 设置灌溉配置的初始相关数据
 *
 * @param config Irrigation的指针地址
 * @param mode
 */
void irrigation_config_single_default_init(Irrigation_Config_Typedef_t * config, u16 mode)
{
    int index = 0;

    if (config != RT_NULL) {
        //初始化Irrigation相关配置
        config->md = _M_MANUAL;//常闭模式
        config->sta = uuzOPT_OFF;//常闭模式
        //循环模式数据
        if (mode == _IRR_CUSTOMIZE) {
            config->t_cycle[0].on = 5 * 60;    //5min
            config->t_cycle[0].off = 20 * 60;//20min
            config->t_cycle[1].on = 8 * 60;//8min
            config->t_cycle[1].off = 60 * 60;//60min
        } else {
            config->t_cycle[0].on = 20;    //20sec
            config->t_cycle[0].off = 120;//120sec
            config->t_cycle[1].on = 60;//60sec
            config->t_cycle[1].off = 300;//300sec
        }
        //定时模式数据
        for (index = 0; index < 5; index++) {
            config->t_timer[index].en = RT_FALSE;    //关闭
            config->t_timer[index].on = 8 * 60 * 60;//8:00 (0:00~23:59)
            config->t_timer[index].off = (8 * 60 + 20) * 60;//8:20 (0:00~23:59)
        }
        //潮汐式模式数据
        config->flood[0] = 10 * 60;//10mins
        config->wait[0] = 60 * 60;//60mins
        config->flood[1] = 8 * 60;//8mins
        config->wait[1] = 120 * 60;//120mins

        //端口IO模式数据
        for (index = 0; index < _IO_PRO_MAX; index++) {
            config->io[index].en = RT_FALSE;    //关闭
            config->io[index].t = RT_FALSE;//无效类型
            config->io[index].id = RT_FALSE;//无效Modbus-ID编号
            config->io[index].io = RT_FALSE;//无效IO编号
        }
    }
}
#else
/**
 * @brief 初始化灌溉的Project配置数据
 */
void irr_mode_config_init(void)
{
    u8 index = 0;

    for (index = 0; index < _IRR_PRO_MAX; index++) {   //内部端口设备参数
        xIrrPro->pro[index].en = RT_TRUE;
        xIrrPro->pro[index].md = _IRR_TOPFEED;  //默认为通用模式
        irrigation_config_single_default_init(&xIrrPro->pro[index].cfg, xIrrPro->pro[index].md);    //更新相关内容数据
    }

    xIrrPro->ver = uuzDEVICE_TYPE;  //软件版本号
    xIrrPro->end = 0xBBBBU;  //结束符
}

/**
 * @brief 设置灌溉配置的初始相关数据
 * 
 * @param config Irrigation的指针地址
 * @param mode
 */
void irrigation_config_single_default_init(Irrigation_Config_Typedef_t * config, u16 mode)
{
    int index = 0;

    if (config != RT_NULL) {
        //初始化Irrigation相关配置
        config->md = _M_MANUAL;    //常闭模式
        config->sta = uuzOPT_OFF;    //常闭模式
        //循环模式数据
        config->t_cycle[0].on = 20;    //20sec
        config->t_cycle[0].off = 120;    //120sec
        config->t_cycle[1].on = 60;    //60sec
        config->t_cycle[1].off = 300;    //300sec

        //定时模式数据
        for (index = 0; index < 5; index++) {
            config->t_timer[index].en = RT_FALSE;    //关闭
            config->t_timer[index].on = 8 * 60 * 60;    //8:00 (0:00~23:59)
            config->t_timer[index].off = (8 * 60 + 20) * 60;    //8:20 (0:00~23:59)
        }
        //潮汐式模式数据
        config->flood[0] = 10 * 60;    //10mins
        config->wait[0] = 60 * 60;    //60mins
        config->flood[1] = 8 * 60;    //8mins
        config->wait[1] = 120 * 60;    //120mins

        //端口IO模式数据
        for (index = 0; index < _IO_PRO_MAX; index++) {
            config->io[index].en = RT_FALSE;    //关闭
            config->io[index].t = RT_FALSE;  //无效类型
            config->io[index].id = RT_FALSE;  //无效Modbus-ID编号
            config->io[index].io = RT_FALSE;  //无效IO编号
        }
    }
}
#endif

/**
 * @brief 灌溉缓存数据
 */
void irr_cache_init(void)
{
    //灯光循环参数处理
    for (u8 index = 0; index < _IRR_PRO_MAX; index++) {  //自动补水缓存数据更新
        rt_memset(&xIrrCache[index], 0x00U, sizeof(Irr_Item_Typedef_t));
    }

    for (u8 index = 0; index < _WLS_PRO_MAX; index++) {  //自动补水缓存数据更新
        rt_memset(&xWlsCache[index], 0x00U, sizeof(Wls_Item_Typedef_t));
    }
}

#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
/**
 * @brief 灌溉端口操作
 * @param pro:操作程序缓存地址
 * @param state:操作端口状态
 * @param type:操作端口类型
 */
void irr_opt_output(Irr_Single_Typedef_t * pro, u8 type, u16 state, u16 pool)
{
    u16 opt_state = 0;

    if (state == uuzOPT_OFF) {
        if (xSysSTA.need_dosing_fixed == 0) {
            ac_valve_opt(state, 0x00);  //运行AC Station模块
        }
    }

    if (pool == 0) {  //水池1
        if (type == uuzPORT_IRR_FLOOD) {    //执行灌溉数据
            if (state == uuzOPT_ON) {   //开启数据

            } else {

            }
        }
    }

    rt_thread_mdelay(3000);  //延时3秒执行动作
    if (state == uuzOPT_ON) {
        if (xSysSTA.need_dosing_fixed == 0) {
            ac_valve_opt(state, 0x64);
        }
    }
}

/**
 * @brief 灌溉数据列表重新生产
 * @param pro
 * @param type
 * @param state
 * @param pool
 */
void irr_list_cache_opt(void)
{
    //NOTE:读取水池1的灌溉数据
    //NOTE:读取水池2的灌溉数据
    //NOTE:检测水位高低变化来处理输出动作
    //NOTE:如果缺水，加入补液机制
}
#else
/**
 * @brief 灌溉端口操作
 * @param pro:操作程序缓存地址
 * @param state:操作端口状态
 * @param type:操作端口类型
 */
void irr_opt_output(Irr_Single_Typedef_t * pro, u8 type, u16 state)
{
    if (type == uuzPORT_IRR_FLOOD) {
#if 0
        if (state == uuzOPT_ON) {
            rt_event_send(eventVALVE, OPT_VLV_1_ON);  //灌溉模式
        } else {
            rt_event_send(eventVALVE, OPT_VLV_1_OFF);  //灌溉模式
        }
#endif
        valve_opt(0, 0, state);  //独立关闭
        rt_event_send(eventDATA, UI_DATA_SYNC);  //发送界面刷新
    } else if (type == uuzPORT_IRR_DRAIN) {
#if 0
        if (state == uuzOPT_ON) {
            rt_event_send(eventVALVE, OPT_VLV_2_ON);  //灌溉模式
        } else {
            rt_event_send(eventVALVE, OPT_VLV_2_OFF);  //灌溉模式
        }
#endif
        valve_opt(0, 1, state);  //独立关闭
        rt_event_send(eventDATA, UI_DATA_SYNC);  //发送界面刷新
    }
}
#endif

/**
 * @brief 配肥混合池操作
 * @param pro:操作程序缓存地址
 * @param state:操作端口状态
 * @param type:操作端口类型
 */
void irr_opt_mix(Irr_Single_Typedef_t * pro, u8 type, u16 state)
{
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
    if (state == uuzOPT_OFF) {
        ac_valve_opt(state, 0x00);
    }

    valve_opt(0, 0, state);  //操作端口 //混合端口
    valve_opt(0, 4, state);  //操作端口

    rt_thread_mdelay(3000);  //延时3秒执行动作
    if (state == uuzOPT_ON) {
        ac_valve_opt(state, 0x64);
    }
#endif
}

#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
void irr_pro_judge(Irr_Item_Typedef_t * cache, Irr_Single_Typedef_t * pro, u8 index)
{
    u8 day = xDayState.sta;  //白天黑夜模式
    u8 opt_state = 0;

    LOG_D("irr_md:%d-sta:%d", pro->md, pro->cfg.sta);
    u32 time = uuz_usRTC_GetMinutes() * 60;  //获取当前事件-分*60秒
    u32 dayON = 0;
    u32 dayOFF = 0;
    u8 isValid = 0;

    //NOTE:程序1-2-3-4对应灌溉池|程序5-6对应清水池
    if (index == 0 || index == 1 || index == 2 || index == 3) {   //培肥灌溉池
        if ((xP260Value[0].out == uuzSINP260_LOW)
                || (xWlsCache[0].opt == uuzRUN_ON)
                || (xSysSTA.need_dosing_fixed)
                ) {  //正在低水位或者正在补水或者正在配液
            opt_state = 0;
        } else {
            opt_state = 1;
        }
    } else if (index == 4 || index == 5) {    //补充水池灌溉池
        if ((xP260Value[1].out == uuzSINP260_LOW)
                || (xWlsCache[1].opt == uuzRUN_ON)
                ) {  //正在低水位或者正在补水
            opt_state = 0;
        } else {
            opt_state = 1;
        }
    }

    cache->sta_o = valve_single_state_get(0);   //读取相关数据
    for (u8 t_index = 0; t_index < 5; t_index++) {  //使用完整定时的阶段数据处理开启时间
        //定时数据有效
        if (pro->cfg.t_timer[t_index].en == RT_TRUE) {  //统一计算，获取最小开启时间和最大结束时间
            dayON = pro->cfg.t_timer[t_index].on;
            dayOFF = pro->cfg.t_timer[t_index].off;
            if ((time >= dayON) && (time <= dayOFF)) {  //为开启数据
                isValid = 1;
                break;
            }
        }
    }

    //有开启相关数据
    if (isValid) {
        if (opt_state) {    //非补水或低水位
            if (cache->sta_o == uuzOPT_OFF) {  //当前灌溉状态为关闭
                cache->sta_o = uuzOPT_ON;  //灌溉未开启,开启灌溉
                irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o, index);        //发送开启事件
                cache->opt_o = uuzRUN_ON;
            }
        }
    } else {
        if (cache->sta_o == uuzOPT_ON) {        //灌溉状态为开启
            cache->sta_o = uuzOPT_OFF;        //灌溉未开启,关闭灌溉
            irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o, index);        //发送关闭事件
            cache->opt_o = uuzRUN_OFF;
        }
    }
}
#else
/**
 * @brief 灌溉程序逻辑判断
 * @param cache:数据缓存地址
 * @param pro:编程数据地址
 * @param index:特定序列位
 */
void irr_pro_judge(Irr_Item_Typedef_t * cache, Irr_Single_Typedef_t * pro, u8 index)
{
    u8 day = xDayState.sta;  //白天黑夜模式

    LOG_D("irr_md:%d-sta:%d", pro->md, pro->cfg.sta);
    if (pro->md == _IRR_AERO) {                    //气雾培模式
        //循环模式
        //判断是否处于执行阶段
        if (cache->opt_o == uuzRUN_OFF) {            //如果不是开启状态，开启运行状态
            cache->time_o = 0;        //清除计时
            cache->sta_o = uuzOPT_ON;        //打开
            cache->opt_o = uuzRUN_ON;        //启动运行
            irr_opt_output(pro, uuzPORT_IRR_FLOOD, uuzOPT_ON);        //发送启动事件
        } else {        //如果是开启状态，时间计数
            if (cache->sta_o == uuzOPT_ON) {        //已经达到循环开启灯光状态
                if (cache->time_o >= pro->cfg.t_cycle[day].on) {        //开启运行状态-关闭灯光(second)
                    cache->time_o = 0;        //清除计时
                    cache->sta_o = uuzOPT_OFF;        //关闭
                    irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);        //发送关闭事件
                } else {
                    cache->time_o++;  //延时计数
                }
            } else {  //已经达到循环开启灌溉状态
                if (cache->time_o >= pro->cfg.t_cycle[day].off) {  //开启运行状态-开启操作
                    cache->time_o = 0;  //清除计时
                    cache->sta_o = uuzOPT_ON;  //打开
                    irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);        //发送开启事件
                } else {
                    cache->time_o++;  //延时计数
                }
            }
        }
    } else if (pro->md == _IRR_TOPFEED) {            //NOTE:滴灌模式没有回水状态
        u32 time = uuz_usRTC_GetMinutes() * 60;  //获取当前事件-分*60秒
        u32 dayON = 0;
        u32 dayOFF = 0;
        u8 isValid = 0;

        cache->sta_o = valve_single_state_get(0);   //读取相关数据
        for (u8 t_index = 0; t_index < 5; t_index++) {  //使用完整定时的阶段数据处理开启时间
            //定时数据有效
            if (pro->cfg.t_timer[t_index].en == RT_TRUE) {  //统一计算，获取最小开启时间和最大结束时间
                dayON = pro->cfg.t_timer[t_index].on;
                dayOFF = pro->cfg.t_timer[t_index].off;
                if ((time >= dayON) && (time <= dayOFF)) {  //为开启数据
                    isValid = 1;
                    break;
                }
            }
        }

        //有开启相关数据
        if (isValid) {
            if (cache->sta_o == uuzOPT_OFF) {  //当前灌溉状态为关闭
                cache->sta_o = uuzOPT_ON;//灌溉未开启,开启灌溉
                irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);//发送开启事件
                cache->opt_o = uuzRUN_ON;
            }
        } else {
            if (cache->sta_o == uuzOPT_ON) {        //灌溉状态为开启
                cache->sta_o = uuzOPT_OFF;//灌溉未开启,关闭灌溉
                irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);//发送关闭事件
                cache->opt_o = uuzRUN_OFF;
            }
        }
    } else if (pro->md == _IRR_FLOWEBB) {        //潮汐式
        //潮汐式灌溉标记
        u8 isValid = 0;//水位有效性判断
        u8 p260_index = 1;
        //默认判断有补水工作
        if (xDevSTA.xP260[p260_index].isconnect == uuzDEV_CONNECTED) {            //中间桶线路2数据判断
            sinp260_judge(
                    p260_index,
                    xWlsPro->cfg[p260_index].target,
                    xWlsPro->cfg[p260_index].high,
                    xWlsPro->cfg[p260_index].low);
            isValid = 1;//有专用水位信息
        }

        if (isValid) {            //有水位传感器数据,可以执行潮汐式灌溉
            LOG_D("irr:%d-sta_o:%d-time_o:%d-sta_b:%d-time_b:%d-flood[%d]-wait[%d]",
                    cache->opt_o, cache->sta_o, cache->time_o, cache->sta_b, cache->time_b,
                    pro->cfg.flood[day], pro->cfg.wait[day]);

            //LOG_D("opt[%d]--time[%d]--flood[%d]",cache->opt_o, cache->time_o, pro->cfg.flood[day]);
            if (cache->opt_o == uuzRUN_OFF) {            //判断是否处于执行阶段,还没有开启灌溉程序运行
                //开启运行状态
                cache->time_o = 0;//清除计时
                cache->time_b = 0;//清除计时
                cache->sta_o = uuzOPT_ON;//打开
                cache->sta_b = uuzOPT_OFF;//关闭

                //获取水位状态
                cache->out = xP260Value[p260_index].out;
                //当前不处于高水位，可以开启灌溉动作
                //有启动回水动作,关闭回水操作
                if (cache->out != uuzSINP260_HIGH) {
                    irr_opt_output(pro, uuzPORT_IRR_FLOOD, uuzOPT_ON);        //发送灌溉开启事件
                    irr_opt_output(pro, uuzPORT_IRR_DRAIN, uuzOPT_OFF);//发送回水关闭事件
                } else {
                    irr_opt_output(pro, uuzPORT_IRR_FLOOD, uuzOPT_OFF);        //发送灌溉开启事件
                    irr_opt_output(pro, uuzPORT_IRR_DRAIN, uuzOPT_OFF);//发送回水关闭事件
                }
                cache->opt_o = uuzRUN_ON;  //开启潮汐式程序运行
                //NOTE:开启进水动作
            } else {  //正在执行潮汐式灌溉，计算持续时间
                if (cache->time_o < pro->cfg.flood[day]) {  //时间处于涨潮模式(Flood)
                    cache->time_o++;//灌溉时间累积
                    cache->out = xP260Value[p260_index].out;//获取水位状态
                    if (cache->sta_o == uuzOPT_ON) {  //正在灌溉操作
                        if (cache->out == uuzSINP260_HIGH) {  //达到高水位,临时停止加水
                            cache->sta_o = uuzOPT_OFF;
                            irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);//涨潮状态，关闭灌溉发送灌溉关闭事件
                        }
                    } else {  //正在停止灌溉操作
                        if (cache->out != uuzSINP260_HIGH) {  //水桶未达到高水位
                            cache->sta_o = uuzOPT_ON;
                            irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);//涨潮状态，启动灌溉到高水位
                        }
                    }
                } else if (cache->time_o == pro->cfg.flood[day]) {  //达到涨潮结束时间,切换到落潮模式
                    cache->time_o++;//标记涨潮完成
                    cache->time_b = 0;//初始化落潮时间计数
                    cache->sta_o = uuzOPT_OFF;//打开
                    cache->sta_b = uuzOPT_ON;//关闭

                    cache->out = xP260Value[p260_index].out;//获取水位状态
                    //当前不处于低水位，可以开启回水动作
                    //有启动灌溉动作,关闭灌溉操作
                    if (cache->out != uuzSINP260_LOW) {
                        irr_opt_output(pro, uuzPORT_IRR_FLOOD, uuzOPT_OFF);        //开始落潮,发送灌溉开启事件
                        irr_opt_output(pro, uuzPORT_IRR_DRAIN, uuzOPT_ON);//开始落潮,发送回水关闭事件
                    } else {
                        irr_opt_output(pro, uuzPORT_IRR_FLOOD, uuzOPT_OFF);        //发送灌溉开启事件
                        irr_opt_output(pro, uuzPORT_IRR_DRAIN, uuzOPT_OFF);//发送回水关闭事件
                    }
                }

                //时间处于落潮模式(Wait)
                if ((cache->time_o > pro->cfg.flood[day]) && (cache->time_b < pro->cfg.wait[day])) {
                    cache->time_b++;  //落潮时间计算
                    cache->out = xP260Value[p260_index].out;//获取水位状态
                    if (cache->sta_b == uuzOPT_ON) {  //正在回水操作
                        if (cache->out == uuzSINP260_LOW) {  //达到低水位，停止回水
                            cache->sta_b = uuzOPT_OFF;
                            irr_opt_output(pro, uuzPORT_IRR_DRAIN, cache->sta_b);//落潮状态，关闭回水
                        }
                    } else {  //正在停止回水操作
                        if (cache->out != uuzSINP260_LOW) {  //水桶低于低水位
                            cache->sta_b = uuzOPT_ON;
                            irr_opt_output(pro, uuzPORT_IRR_DRAIN, cache->sta_b);//落潮状态，启动回水到低水位
                        }
                    }
                } else if (cache->time_b >= pro->cfg.wait[day]) {
                    //达到落潮结束时间,完成潮汐式灌溉程序,进入下一阶段程序
                    cache->opt_o = uuzRUN_OFF;
                }
            }
        } else {
            //关闭输出,关闭回水
            if (cache->sta_o == uuzOPT_ON) {
                cache->sta_o = uuzOPT_OFF;        //清除工作状态
                irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);//关闭灌溉
            }
            if (cache->sta_b == uuzOPT_ON) {
                cache->sta_b = uuzOPT_OFF;        //清除工作状态
                irr_opt_output(pro, uuzPORT_IRR_DRAIN, cache->sta_b);//关闭回水
            }

            //没有水位传感器，不启动潮汐式灌溉
            cache->opt_o = uuzRUN_OFF;
        }
    } else if (pro->md == _IRR_CUSTOMIZE) {        //处于灌溉自定义模式
        if (pro->cfg.md == _M_MANUAL) {        //手动模式
            cache->sta_o = valve_single_state_get(0);//读取相关数据
            if (cache->sta_o != pro->cfg.sta) {        //开启或关闭灌溉
                cache->sta_o = pro->cfg.sta;
                irr_opt_output(pro, uuzPORT_IRR_FLOOD, pro->cfg.sta);
            }
        } else if (pro->cfg.md == _M_CYCLE) {        //循环模式
            LOG_D("opt:%d-sta:%d-time:%d", cache->opt_o, cache->sta_o, cache->time_o);
            //判断是否处于执行阶段
            if (cache->opt_o == uuzRUN_OFF) {        //开启灌溉运行状态
                cache->time_o = 0;//清除计时
                cache->sta_o = uuzOPT_ON;//打开灌溉
                cache->opt_o = uuzRUN_ON;//启动运行
                irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);//发送启动运行事件
            } else {  //如果是开启状态，时间计数
                if (cache->sta_o == uuzOPT_ON) {  //已经达到循环关闭状态
                    if (cache->time_o >= pro->cfg.t_cycle[day].on) {  //开启灌溉运行状态-关闭
                        cache->time_o = 0;//清除计时
                        cache->sta_o = uuzOPT_OFF;//关闭灌溉
                        irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);//发送关闭事件
                    } else {
                        cache->time_o++;  //延时计数
                    }
                } else {  //已经达到循环开启状态
                    if (cache->time_o >= pro->cfg.t_cycle[day].off) {  //开启灌溉运行状态-开启
                        cache->time_o = 0;//清除计时
                        cache->sta_o = uuzOPT_ON;//打开灌溉
                        irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);//发送开启事件
                    } else {
                        cache->time_o++;  //延时计数
                    }
                }
            }
        } else if (pro->cfg.md == _M_TIMER) {
            u32 time = uuz_usRTC_GetMinutes() * 60;  //获取当前事件-分
            u32 dayON = 0;
            u32 dayOFF = 0;
            u8 isValid = 0;

            cache->sta_o = valve_single_state_get(0);//读取相关数据
            for (u8 t_index = 0; t_index < 5; t_index++) {  //使用完整定时的阶段数据处理开启时间
                //定时数据有效
                if (pro->cfg.t_timer[t_index].en == RT_TRUE) {  //统一计算，获取最小开启时间和最大结束时间
                    dayON = pro->cfg.t_timer[t_index].on;
                    dayOFF = pro->cfg.t_timer[t_index].off;
                    if ((time >= dayON) && (time <= dayOFF)) {  //为开启数据
                        isValid = 1;
                        break;
                    }
                }
            }

            if (isValid) {   //有开启相关数据
                if (cache->sta_o == uuzOPT_OFF) {  //当前灌溉状态为关闭
                    cache->sta_o = uuzOPT_ON;//灌溉未开启,开启灌溉
                    irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);//发送开启事件
                    //cache->opt_o = uuzRUN_ON;
                }
            } else {        //为关闭数据
                if (cache->sta_o == uuzOPT_ON) {        //灌溉状态为开启
                    cache->sta_o = uuzOPT_OFF;//灌溉未开启,关闭灌溉
                    irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);//发送关闭事件
                    //cache->opt_o = uuzRUN_OFF;
                }
            }
        }
    }
}

#if 0
{
    u8 day = xDayState.sta;  //白天黑夜模式
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
    u8 opt_state = 0;
#endif

    LOG_D("irr_md:%d-sta:%d", pro->md, pro->cfg.sta);
    if (pro->md == _IRR_AERO) {                    //气雾培模式
        //循环模式
        //判断是否处于执行阶段
        if (cache->opt_o == uuzRUN_OFF) {            //如果不是开启状态，开启运行状态
            cache->time_o = 0;//清除计时
            cache->sta_o = uuzOPT_ON;//打开
            cache->opt_o = uuzRUN_ON;//启动运行
            irr_opt_output(pro, uuzPORT_IRR_FLOOD, uuzOPT_ON);//发送启动事件
        } else {        //如果是开启状态，时间计数
            if (cache->sta_o == uuzOPT_ON) {        //已经达到循环开启灯光状态
                if (cache->time_o >= pro->cfg.t_cycle[day].on) {        //开启运行状态-关闭灯光(second)
                    cache->time_o = 0;//清除计时
                    cache->sta_o = uuzOPT_OFF;//关闭
                    irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);//发送关闭事件
                } else {
                    cache->time_o++;  //延时计数
                }
            } else {  //已经达到循环开启灌溉状态
                if (cache->time_o >= pro->cfg.t_cycle[day].off) {  //开启运行状态-开启操作
                    cache->time_o = 0;//清除计时
                    cache->sta_o = uuzOPT_ON;//打开
                    irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);//发送开启事件
                } else {
                    cache->time_o++;  //延时计数
                }
            }
        }

        //判断自动补水动作是否激活
        //补水线路1-营养池
        //sinp260_judge(0, xWlsPro->cfg[0].target, xWlsPro->cfg[0].high, xWlsPro->cfg[0].low);
        //补水操作事件1
        //sinp260_aero_event(0);
        //补水线路2-清水
        //sinp260_judge(1, xWlsPro->cfg[1].target, xWlsPro->cfg[1].high, xWlsPro->cfg[1].low);
        //补水操作事件2
        //sinp260_aero_event(1);
    } else if (pro->md == _IRR_TOPFEED) {            //NOTE:滴灌模式没有回水状态
        u32 time = uuz_usRTC_GetMinutes() * 60;//获取当前事件-分*60秒
        u32 dayON = 0;
        u32 dayOFF = 0;
        u8 isValid = 0;

#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
        //NOTE:程序1-2-3-4对应灌溉池|程序5-6对应清水池
        if (index == 0 || index == 1 || index == 2 || index == 3) {   //培肥灌溉池
            if ((xP260Value[0].out == uuzSINP260_LOW)
                    || (xWlsCache[0].opt == uuzRUN_ON)
                    || (xSysSTA.need_dosing_fixed)
            ) {  //正在低水位或者正在补水或者正在配液
                opt_state = 0;
            } else {
                opt_state = 1;
            }
        } else if (index == 4 || index == 5) {    //补充水池灌溉池
            if ((xP260Value[1].out == uuzSINP260_LOW)
                    || (xWlsCache[1].opt == uuzRUN_ON)
            ) {  //正在低水位或者正在补水
                opt_state = 0;
            } else {
                opt_state = 1;
            }
        }
#endif
        cache->sta_o = valve_single_state_get(0);   //读取相关数据
        for (u8 t_index = 0; t_index < 5; t_index++) {  //使用完整定时的阶段数据处理开启时间
            //定时数据有效
            if (pro->cfg.t_timer[t_index].en == RT_TRUE) {  //统一计算，获取最小开启时间和最大结束时间
                dayON = pro->cfg.t_timer[t_index].on;
                dayOFF = pro->cfg.t_timer[t_index].off;
                if ((time >= dayON) && (time <= dayOFF)) {  //为开启数据
                    isValid = 1;
                    break;
                }
            }
        }

        //有开启相关数据
        if (isValid) {
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
            if (opt_state) {    //非补水或低水位
#endif
                if (cache->sta_o == uuzOPT_OFF) {  //当前灌溉状态为关闭
                    cache->sta_o = uuzOPT_ON;  //灌溉未开启,开启灌溉
                    irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);        //发送开启事件
                    cache->opt_o = uuzRUN_ON;
                }
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
            }
#endif
        } else {
            if (cache->sta_o == uuzOPT_ON) {        //灌溉状态为开启
                cache->sta_o = uuzOPT_OFF;        //灌溉未开启,关闭灌溉
                irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);        //发送关闭事件
                cache->opt_o = uuzRUN_OFF;
            }
        }
    } else if (pro->md == _IRR_FLOWEBB) {        //潮汐式
        //潮汐式灌溉标记
        u8 isValid = 0;                //水位有效性判断
        u8 p260_index = 1;
        //默认判断有补水工作
        if (xDevSTA.xP260[p260_index].isconnect == uuzDEV_CONNECTED) {            //中间桶线路2数据判断
            sinp260_judge(
                    p260_index,
                    xWlsPro->cfg[p260_index].target,
                    xWlsPro->cfg[p260_index].high,
                    xWlsPro->cfg[p260_index].low);
            isValid = 1;    //有专用水位信息
        }

        if (isValid) {            //有水位传感器数据,可以执行潮汐式灌溉
            LOG_D("irr:%d-sta_o:%d-time_o:%d-sta_b:%d-time_b:%d-flood[%d]-wait[%d]",
                    cache->opt_o, cache->sta_o, cache->time_o, cache->sta_b, cache->time_b,
                    pro->cfg.flood[day], pro->cfg.wait[day]);

            //LOG_D("opt[%d]--time[%d]--flood[%d]",cache->opt_o, cache->time_o, pro->cfg.flood[day]);
            if (cache->opt_o == uuzRUN_OFF) {            //判断是否处于执行阶段,还没有开启灌溉程序运行
                //开启运行状态
                cache->time_o = 0;        //清除计时
                cache->time_b = 0;        //清除计时
                cache->sta_o = uuzOPT_ON;        //打开
                cache->sta_b = uuzOPT_OFF;        //关闭

                //获取水位状态
                cache->out = xP260Value[p260_index].out;
                //当前不处于高水位，可以开启灌溉动作
                //有启动回水动作,关闭回水操作
                if (cache->out != uuzSINP260_HIGH) {
                    irr_opt_output(pro, uuzPORT_IRR_FLOOD, uuzOPT_ON);        //发送灌溉开启事件
                    irr_opt_output(pro, uuzPORT_IRR_DRAIN, uuzOPT_OFF);        //发送回水关闭事件
                } else {
                    irr_opt_output(pro, uuzPORT_IRR_FLOOD, uuzOPT_OFF);        //发送灌溉开启事件
                    irr_opt_output(pro, uuzPORT_IRR_DRAIN, uuzOPT_OFF);        //发送回水关闭事件
                }
                cache->opt_o = uuzRUN_ON;  //开启潮汐式程序运行
                //NOTE:开启进水动作
            } else {  //正在执行潮汐式灌溉，计算持续时间
                if (cache->time_o < pro->cfg.flood[day]) {  //时间处于涨潮模式(Flood)
                    cache->time_o++;  //灌溉时间累积
                    cache->out = xP260Value[p260_index].out;  //获取水位状态
                    if (cache->sta_o == uuzOPT_ON) {  //正在灌溉操作
                        if (cache->out == uuzSINP260_HIGH) {  //达到高水位,临时停止加水
                            cache->sta_o = uuzOPT_OFF;
                            irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);        //涨潮状态，关闭灌溉发送灌溉关闭事件
                        }
                    } else {  //正在停止灌溉操作
                        if (cache->out != uuzSINP260_HIGH) {  //水桶未达到高水位
                            cache->sta_o = uuzOPT_ON;
                            irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);        //涨潮状态，启动灌溉到高水位
                        }
                    }
                } else if (cache->time_o == pro->cfg.flood[day]) {  //达到涨潮结束时间,切换到落潮模式
                    cache->time_o++;  //标记涨潮完成
                    cache->time_b = 0;  //初始化落潮时间计数
                    cache->sta_o = uuzOPT_OFF;  //打开
                    cache->sta_b = uuzOPT_ON;  //关闭

                    cache->out = xP260Value[p260_index].out;  //获取水位状态
                    //当前不处于低水位，可以开启回水动作
                    //有启动灌溉动作,关闭灌溉操作
                    if (cache->out != uuzSINP260_LOW) {
                        irr_opt_output(pro, uuzPORT_IRR_FLOOD, uuzOPT_OFF);        //开始落潮,发送灌溉开启事件
                        irr_opt_output(pro, uuzPORT_IRR_DRAIN, uuzOPT_ON);        //开始落潮,发送回水关闭事件
                    } else {
                        irr_opt_output(pro, uuzPORT_IRR_FLOOD, uuzOPT_OFF);        //发送灌溉开启事件
                        irr_opt_output(pro, uuzPORT_IRR_DRAIN, uuzOPT_OFF);        //发送回水关闭事件
                    }
                }

                //时间处于落潮模式(Wait)
                if ((cache->time_o > pro->cfg.flood[day]) && (cache->time_b < pro->cfg.wait[day])) {
                    cache->time_b++;  //落潮时间计算
                    cache->out = xP260Value[p260_index].out;  //获取水位状态
                    if (cache->sta_b == uuzOPT_ON) {  //正在回水操作
                        if (cache->out == uuzSINP260_LOW) {  //达到低水位，停止回水
                            cache->sta_b = uuzOPT_OFF;
                            irr_opt_output(pro, uuzPORT_IRR_DRAIN, cache->sta_b);        //落潮状态，关闭回水
                        }
                    } else {  //正在停止回水操作
                        if (cache->out != uuzSINP260_LOW) {  //水桶低于低水位
                            cache->sta_b = uuzOPT_ON;
                            irr_opt_output(pro, uuzPORT_IRR_DRAIN, cache->sta_b);        //落潮状态，启动回水到低水位
                        }
                    }
                } else if (cache->time_b >= pro->cfg.wait[day]) {
                    //达到落潮结束时间,完成潮汐式灌溉程序,进入下一阶段程序
                    cache->opt_o = uuzRUN_OFF;
                }
            }
        } else {
            //关闭输出,关闭回水
            if (cache->sta_o == uuzOPT_ON) {
                cache->sta_o = uuzOPT_OFF;        //清除工作状态
                irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);        //关闭灌溉
            }
            if (cache->sta_b == uuzOPT_ON) {
                cache->sta_b = uuzOPT_OFF;        //清除工作状态
                irr_opt_output(pro, uuzPORT_IRR_DRAIN, cache->sta_b);        //关闭回水
            }

            //没有水位传感器，不启动潮汐式灌溉
            cache->opt_o = uuzRUN_OFF;
        }
    } else if (pro->md == _IRR_CUSTOMIZE) {        //处于灌溉自定义模式
        if (pro->cfg.md == _M_MANUAL) {        //手动模式
            cache->sta_o = valve_single_state_get(0);   //读取相关数据
            if (cache->sta_o != pro->cfg.sta) {        //开启或关闭灌溉
                cache->sta_o = pro->cfg.sta;
                irr_opt_output(pro, uuzPORT_IRR_FLOOD, pro->cfg.sta);
            }
        } else if (pro->cfg.md == _M_CYCLE) {        //循环模式
            LOG_D("opt:%d-sta:%d-time:%d", cache->opt_o, cache->sta_o, cache->time_o);
            //判断是否处于执行阶段
            if (cache->opt_o == uuzRUN_OFF) {        //开启灌溉运行状态
                cache->time_o = 0;  //清除计时
                cache->sta_o = uuzOPT_ON;  //打开灌溉
                cache->opt_o = uuzRUN_ON;  //启动运行
                irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);  //发送启动运行事件
            } else {  //如果是开启状态，时间计数
                if (cache->sta_o == uuzOPT_ON) {  //已经达到循环关闭状态
                    if (cache->time_o >= pro->cfg.t_cycle[day].on) {  //开启灌溉运行状态-关闭
                        cache->time_o = 0;  //清除计时
                        cache->sta_o = uuzOPT_OFF;  //关闭灌溉
                        irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);  //发送关闭事件
                    } else {
                        cache->time_o++;  //延时计数
                    }
                } else {  //已经达到循环开启状态
                    if (cache->time_o >= pro->cfg.t_cycle[day].off) {  //开启灌溉运行状态-开启
                        cache->time_o = 0;  //清除计时
                        cache->sta_o = uuzOPT_ON;  //打开灌溉
                        irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);  //发送开启事件
                    } else {
                        cache->time_o++;  //延时计数
                    }
                }
            }
        } else if (pro->cfg.md == _M_TIMER) {
            u32 time = uuz_usRTC_GetMinutes() * 60;  //获取当前事件-分
            u32 dayON = 0;
            u32 dayOFF = 0;
            u8 isValid = 0;

            cache->sta_o = valve_single_state_get(0);   //读取相关数据
            for (u8 t_index = 0; t_index < 5; t_index++) {  //使用完整定时的阶段数据处理开启时间
                //定时数据有效
                if (pro->cfg.t_timer[t_index].en == RT_TRUE) {  //统一计算，获取最小开启时间和最大结束时间
                    dayON = pro->cfg.t_timer[t_index].on;
                    dayOFF = pro->cfg.t_timer[t_index].off;
                    if ((time >= dayON) && (time <= dayOFF)) {  //为开启数据
                        isValid = 1;
                        break;
                    }
                }
            }

            if (isValid) {   //有开启相关数据
                if (cache->sta_o == uuzOPT_OFF) {  //当前灌溉状态为关闭
                    cache->sta_o = uuzOPT_ON;  //灌溉未开启,开启灌溉
                    irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);        //发送开启事件
                    //cache->opt_o = uuzRUN_ON;
                }
            } else {        //为关闭数据
                if (cache->sta_o == uuzOPT_ON) {        //灌溉状态为开启
                    cache->sta_o = uuzOPT_OFF;        //灌溉未开启,关闭灌溉
                    irr_opt_output(pro, uuzPORT_IRR_FLOOD, cache->sta_o);        //发送关闭事件
                    //cache->opt_o = uuzRUN_OFF;
                }
            }
        }
    }
}
#endif
#endif
