/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_IRR_H
#define __TYPEDEF_IRR_H

// include ---------------------------------------------
#include "typedefBASE.h"
#include "typedefDEVID.h"
#include "uuzConfigDEV.h"
#include "uuzOpt.h"
// ------- ---------------------------------------------
#define IRR_HIGH_LEVEL_TIME_MAX (3U)   //超过高水位10秒
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
#define _IRR_PRO_MAX (2U)   //灌溉模式数据
#else
#define _IRR_PRO_MAX (1U)   //灌溉模式数据
#endif
#define _IO_PRO_MAX (6U)   //灌溉程序对应的IO
/**
 * @brief 对应的灌溉工作模式
 */
enum
{
    _IRR_MANUAL = 0,  //无工作状态
    _IRR_AERO,  //气雾培
    _IRR_TOPFEED,  //滴灌
    _IRR_FLOWEBB,  //潮汐式
    _IRR_CUSTOMIZE  //定制(手动/循环/定时)
};

typedef struct irrigation_config_t
{
    u8 md;  //工作模式
    //Manual
    u8 sta;  //手动状态：0-off/1-on
    //mode:aero
    //cycle-time
    Cycle_Typedef_t t_cycle[2];  //Day/Night:second

    //mode:top-feed
    //timer-time
    Timer_Typedef_t t_timer[5];  //5组滴灌定时器:mins

    //mode:Flow-Ebb
    u32 flood[2];  //Flow:涨潮时间
    u32 wait[2];  //Ebb:落潮时间

    IO_Typedef_t io[_IO_PRO_MAX];   //可以同时绑定N个IO(现在最多6个)

}__attribute__ ((__packed__)) Irrigation_Config_Typedef_t;
#define uuzIRRIGATION_CONFIG_LEN (sizeof(Irrigation_Config_Typedef_t))

/**
 * @brief 灌溉模式记录
 */
typedef struct irr_single_config_t
{
    u8 en;      //使能
    u8 md;    //灌溉工作模式
    Irrigation_Config_Typedef_t cfg;  //灌溉程序配置数据

}__attribute__ ((__packed__)) Irr_Single_Typedef_t;  //模式配置

/**
 * @brief 灌溉模式记录
 */
typedef struct irr_pro_t
{
    Irr_Single_Typedef_t pro[_IRR_PRO_MAX];  //灌溉程序配置数据

    u16 ver;
    u16 end;    //0xBBBBU

}__attribute__ ((__packed__)) Irr_Pro_Typedef_t;  //模式配置
#define uuzIRR_PRO_LEN (sizeof(Irr_Pro_Typedef_t))

#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
#define uuzPROG_LIST_MAX (10U)
//NOTE:集装箱运行缓存数据列表
typedef struct program_running_list_t
{
    u8 en[uuzPROG_LIST_MAX];    //按顺序操作使能
    u8 prog[uuzPROG_LIST_MAX];  //工作对象类型
    u8 opt[uuzPROG_LIST_MAX];   //操作对象类型

} Prog_Running_List_Typedef_t;
#define uuzPROG_RUNNING_LIST_LEN (sizeof(Prog_Running_List_Typedef_t))
#endif

/**
 * @brief 循环状态操作数
 */
typedef struct irr_item
{

    //灌溉状态记录
    u8 opt_o;  //执行状态
    u8 sta_o;  //上次状态
    u32 time_o;  //工作持续时间(sec)

    //回水状态记录
    u8 opt_b;  //执行状态
    u8 sta_b;  //上次状态
    u32 time_b;  //工作持续时间(sec)

    //补水状态记录
    u8 opt_i;  //执行状态
    u8 sta_i;  //上次状态
    u32 time_i;  //工作持续时间(sec)

    //水位状态
    u8 out;  //2路的水位状态

} Irr_Item_Typedef_t;

/**
 * @brief 自动补水相关
 */
typedef struct irr_level_t
{
    u8 mode;  //补水模式：0-Manual/1-Auto
    u32 limit;  //补水时常：30*60=1800sec
    u16 high;  //桶高水位
    u16 low;  //桶低水位

} Irr_Level_Typedef_t;

//灌溉相关设备的配置数据
typedef struct irrconfig_t
{
    u8 ucHead;
    //当前运行的模式
    u8 mode;  //0-None/1-Aeroponics/2-Top-Feed/3-Flow&Ebb/4-Customize

    //桶自动补水相关
    Irr_Level_Typedef_t level;

    u8 ucEnd;

} Irr_Config_Typedef_t;
#define uuzIRR_CONFIG_LEN (sizeof(Irr_Config_Typedef_t))

#endif //__TYPEDEF_IRR_H
