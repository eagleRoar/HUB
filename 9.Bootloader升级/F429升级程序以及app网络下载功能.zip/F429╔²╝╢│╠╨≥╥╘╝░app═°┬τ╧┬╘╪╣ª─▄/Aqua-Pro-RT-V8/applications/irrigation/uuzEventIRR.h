/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __UUZ_IRR_EVENT_H
#define __UUZ_IRR_EVENT_H

#include "typedefIRR.h"
#include "typedefMBR.h"

#ifdef __cplusplus
extern "C" {
#endif

extern Irr_Item_Typedef_t xIrrCache[_IRR_PRO_MAX];  //灌溉的缓存数据
extern Irr_Pro_Typedef_t * xIrrPro;    //灌溉程序相关数据地址

/**
 * @brief 设置灌溉配置的初始相关数据
 *
 * @param xIrrConfig Irrigation的指针地址
 * @param mode
 */
void irrigation_config_single_default_init(Irrigation_Config_Typedef_t * xIrrConfig, u16 mode);

/**
 * @brief 初始化灌溉数据配置数据
 */
void irr_mode_config_init(void);

/**
 * @brief 灌溉缓存数据
 * 
 */
void irr_cache_init(void);

/**
 * @brief 灌溉模式数据解析
 * 
 */
void irr_mode_judge(void);

#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
/**
 * @brief 灌溉端口操作
 * @param pro:操作程序缓存地址
 * @param state:操作端口状态
 * @param type:操作端口类型
 */
void irr_opt_output(Irr_Single_Typedef_t * pro, u8 type, u16 state, u16 pool);
#else
/**
 * @brief 灌溉端口操作
 * @param pro:操作程序缓存地址
 * @param state:操作端口状态
 * @param type:操作端口类型
 */
void irr_opt_output(Irr_Single_Typedef_t * pro, u8 type, u16 state);
#endif

/**
 * @brief 配肥混合池操作
 * @param pro:操作程序缓存地址
 * @param state:操作端口状态
 * @param type:操作端口类型
 */
void irr_opt_mix(Irr_Single_Typedef_t * pro, u8 type, u16 state);

/**
 * @brief 灌溉程序逻辑判断
 * @param cache:数据缓存地址
 * @param pro:编程数据地址
 * @param index:特定序列位
 */
void irr_pro_judge(Irr_Item_Typedef_t * cache, Irr_Single_Typedef_t * pro, u8 index);

/**
 * @brief 气雾培回水操作记录
 * 
 * @param id 水位编号
 */
void sinp260_aero_event(u8 id);

#ifdef __cplusplus
}
#endif

#endif // __UUZ_IRR_EVENT_H
