/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-27   ZhouXiaomin     first version
 * 2019-12-26   ZhouXiaomin     add recvice function
 */
/*include*******************************************************/
#include <rtthread.h>
/**************************************************************/
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzUART.h"
#include "uuzConfigDEV.h"
/**************************************************************/
#include "uuzDevID.h"
#include "uuzEventDevID.h"
/**************************************************************/
#include "uuzBBL.h"
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
#include "uuzMBR.h"
/**************************************************************/
#include "uuzUart8.h"
#include "uuzEventUART.h"
/**************************************************************/
#include "uuzEventVALVE.h"
/*log----------------------------------------------------------*/
#define DBG_TAG "uart.8"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/**************************************************************/
#if defined(BSP_USING_UART8)
/**
 * @brief  定义设备通讯通道
 */
typedef_Uart xUart8Rx;
/**
 * @brief 设备接口函数
 * 
 * @param dev 
 * @param size 
 * @return rt_err_t 
 */
rt_err_t uart8_input(rt_device_t dev, rt_size_t size)
{
    /* 串口接收到数据后产生中断，调用此回调函数，然后发送接收信号量 */
    //读取缓存数据
    rt_sem_release(&xUartE.uart[uuzUART_8].rx_sem);
    return RT_EOK;
}

/**
 * @brief  设备实际处理函数
 * 
 * @param ucRxCode 
 * @param ucTxCode 
 */
void uart8_receive_event(u8* ucRxCode, u8* ucTxCode)
{
    if (ucRxCode) {
        //读取设备的modbus和对应设备号
        u8 ucHead = ucRxCode[0];

#if 0
        if (ucHead != uuzBBL_HEAD) {
            u8 ucTxHead = ucTxCode[0];
            u16 usTxRegAddr = usU8ToU16(ucTxCode + 2, uuzMSB);

            //发送端和接收端相同
            if (ucHead == ucTxHead) {
                //读取发送参数
                u8 ucOpt = ucRxCode[1];
                u8 index = usValtoID(ucHead, uuzUART_8);
                //有设备数据
                if (index < uuzDEV_MAX) {
                    //设备数据为有效数据
                    if (xDevIDs.xDev[index].ucEnable == uuzDEV_REG_OK) {
                        //获取设备类型
                        u8 ucType = xDevIDs.xDev[index].ucSubType;
                        //设备的缓存位置
                        index = ucIDtoVal(ucHead, ucType, uuzUART_8);
                        //没有错误数据
                        switch (ucOpt)
                        {
                            case uuzMBR_READ_HOLDING_REGISTER:
                            case uuzMBR_READ_INPUT_REGISTER:
                            //判断设备类型
                            switch (ucType)
                            {
                                //AC Station
                                case uuzDEV_SL_ACO:
                                case uuzDEV_SL_AHT:
                                case uuzDEV_SL_ATA:
                                if (index < uuzDEV_ST_MAX) {
                                    //获取到相关数据
                                    if (usTxRegAddr == uuzADDR_RW_ACS_STA_DATA) {
                                        //获取实时数据
                                        uuz_vExACSDataGet((ucRxCode + 3), &xDevValue.xValue_ST[index]);
                                        //更新连接状态
                                        device_connect_reset(&xDevSTA.xST[index]);
                                        device_id_update(3);
                                    }
                                }
                                break;
                                case uuzDEV_SL_T003:
                                //T-003空调机
                                if (index < uuzDEV_T003_MAX) {
                                    //获取到相关数据
                                    if (usTxRegAddr == uuzADDR_R_T003_TA) {
                                        //获取实时数据
                                        uuz_vT003RealDataGet(ucRxCode, &xT003Cache[index]);
                                        //更新连接状态
                                        device_connect_reset(&xDevSTA.xT003[index]);
                                        device_id_update(9);
                                    }
                                }
                                break;
                                case uuzDEV_SL_YC10S:
                                //YC-10S 除湿机
                                if (index < uuzDEV_YC10S_MAX) {
                                    //获取到相关数据
                                    if (usTxRegAddr == uuzADDR_RW_YC10S_POWER) {
                                        //获取实时数据
                                        uuz_vYC10SRealDataGet(ucRxCode, &xYC10SCache[index]);
                                        //更新连接状态
                                        device_connect_reset(&xDevSTA.xYC10S[index]);
                                        device_id_update(8);
                                    }
                                }
                                break;
                                case uuzDEV_SL_DF34BMS:
                                //DF34B-MS空调机
                                if (index < uuzDEV_DF34B_MS_MAX) {
                                    //获取到相关数据
                                    if (usTxRegAddr == uuzADDR_RW_DF34B_MODE) {
                                        //获取实时数据
                                        uuz_vDF34B_GetState(ucRxCode, &xDF34BCache[index]);
                                        //更新连接状态
                                        device_connect_reset(&xDevSTA.xDF34BMS[index]);
                                        device_id_update(10);
                                    }
                                }
                                break;
                                default:
                                break;
                            }
                            break;
                            case uuzMBR_WRITE_REGISTER:
                            //判断设备类型
                            switch (ucType)
                            {
                                //AC Station
                                case uuzDEV_SL_ACO:
                                case uuzDEV_SL_AHT:
                                case uuzDEV_SL_ATA:
                                if (index < uuzDEV_ST_MAX) {
                                    if (usTxRegAddr == uuzADDR_RW_ACS_STA_DATA) {
                                        index = ucIDtoVal(ucHead, ucType, uuzUART_8);
                                        //获取实时数据
                                        uuz_vExACSDataGet((ucRxCode + 4), &xDevValue.xValue_ST[index]);
                                        //更新连接状态
                                        device_connect_reset(&xDevSTA.xST[index]);
                                        device_id_update(3);
                                    }
                                }
                                break;
                                case uuzDEV_SL_YC10S:
                                //YC-10S 除湿机
                                if (index < uuzDEV_YC10S_MAX) {
                                    //获取到相关数据
                                    if (usTxRegAddr == uuzADDR_RW_YC10S_POWER) {
                                        //获取实时数据
                                        uuz_vYC10SRealDataGet(ucRxCode, &xYC10SCache[index]);
                                        //更新连接状态
                                        device_connect_reset(&xDevSTA.xYC10S[index]);
                                        device_id_update(8);
                                    }
                                }
                                break;
                                case uuzDEV_SL_DF34BMS:
                                //DF34B-MS空调机
                                if (index < uuzDEV_DF34B_MS_MAX) {
                                    //获取到相关数据
                                    if (usTxRegAddr == uuzADDR_RW_DF34B_MODE) {
                                        //获取实时数据
                                        uuz_vDF34B_GetState(ucRxCode, &xDF34BCache[index]);
                                        //更新连接状态
                                        device_connect_reset(&xDevSTA.xDF34BMS[index]);
                                        device_id_update(10);
                                    }
                                }
                                break;
                                default:
                                break;
                            }
                            break;
                            case uuzMBR_READ_COILS:
                            case uuzMBR_WRITE_SINGLE_COIL:
                            //判断设备类型
                            switch (ucType)
                            {
                                case uuzDEV_SL_T003:
                                //T-003空调机
                                if (index < uuzDEV_T003_MAX) {
                                    //获取到相关数据
                                    if (usTxRegAddr == uuzADDR_RW_T003_ENABLE) {
                                        //获取实时数据
                                        uuz_vT003StateGet(ucRxCode, &xT003Cache[index]);
                                        //更新连接状态
                                        device_connect_reset(&xDevSTA.xT003[index]);
                                        device_id_update(9);
                                    }
                                }
                                break;
                                default:
                                break;
                            }
                            break;
                            default:
                            break;
                        }
                    }
                }
            }
        }
#else
        if (ucHead == 0x09U) {  //和PLC通讯ID
            if (ucRxCode[1] == 0x03U) {
                ac_valve_recv(ucRxCode);
            }
        }
#endif
    }
}
#endif /* BSP_USING_UART8 */
