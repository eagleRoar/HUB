/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-27   ZhouXiaomin     first version
 */
/*include*******************************************************/
#include <rtthread.h>
/**************************************************************/
#include "uuzOpt.h"
#include "uuzUART.h"
/**************************************************************/
#include "uuzBBL.h"
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
#include "uuzMBR.h"
/**************************************************************/
#include "uuzEventHMI.h"
#include "uuzEventUART.h"
#include "uuzHMI_UI.h"
#include "uuzHmiTFT.h"
/*log----------------------------------------------------------*/
#define DBG_TAG "u.hmi"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
//--------------------------------------------------------------
#if defined(BSP_USING_UART1)
/**
 * @brief hmi_uart_input
 * @param dev
 * @param size
 * @return
 */
rt_err_t hmitft_uart_input(rt_device_t dev, rt_size_t size)
{
    /* 串口接收到数据后产生中断，调用此回调函数，然后发送接收信号量 */
    typedef_Uart* uart = &xUartE.uart[uuzUART_1];
    //清空缓存区长度
    uart->len = (uart->len >= uuzUART_LEN) ? (0) : (uart->len);
    //读取缓存数据
    rt_sem_release(&uart->rx_sem);
    return RT_EOK;
}

/**
 * @brief hmitft_thread_entry
 * @param parameter
 */
void hmitft_thread_entry(void* parameter)
{
    typedef_Uart* uart = (typedef_Uart*) parameter;
    u8 ucIsToDo = 0;

    if (uart->readylen) {
        //如果是HMI官方协议
        if (uart->len >= 3) {
            //检测HMI官方协议头
            if (hmi_data_head_is_assert(uart->rxbuff[0]) == RT_TRUE) {
                //打印日志
                if (uart->log_rx == RT_TRUE) {
                    rt_kprintf("MHMI-R:");
                    for (u8 index = 0; index < uart->len; index++) {
                        if ((index != 0) && ((index % 24) == 0)) {
                            rt_kprintf("\r\n");
                        }
                        rt_kprintf("%02X ", uart->rxbuff[index]);
                    }
                    rt_kprintf("\r\n");
                }
                //检测HMI官方协议尾（0xFF 0xFF 0xFF ）
                if (hmi_data_end_is_assert(uart->rxbuff + (uart->len - 3)) == RT_TRUE) {
                    ucIsToDo = 1;
                }
            }

            //检测自定义协议头
            if (uart->rxbuff[0] == uuzBBL_HEAD) {
                //打印日志
                if (uart->log_rx == RT_TRUE) {
                    rt_kprintf("BHMI-R:");
                    for (u8 index = 0; index < uart->len; index++) {
                        if ((index != 0) && ((index % 24) == 0)) {
                            rt_kprintf("\r\n");
                        }
                        rt_kprintf("%02X ", uart->rxbuff[index]);
                    }
                    rt_kprintf("\r\n");
                }
                //如果是自定义协议,判断换行符
                if (crc_data_end_is_assert(uart->rxbuff + (uart->len - 2)) == RT_TRUE) {
                    ucIsToDo = 1;
                }
            }

            //有正确的数据
            if (ucIsToDo == 1) {
                hmi_receive_data(uart->rxbuff, uart->txbuff);
            }
            //清楚工作标记
            uart->len = 0;
            uart->readylen = 0;
        }
    }
}
#endif /* BSP_USING_UART1 */
