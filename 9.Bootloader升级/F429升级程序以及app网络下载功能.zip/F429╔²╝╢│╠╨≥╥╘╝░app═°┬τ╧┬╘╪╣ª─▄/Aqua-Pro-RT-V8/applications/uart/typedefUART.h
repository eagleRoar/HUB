/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-27   ZhouXiaomin     first version
 */

#ifndef _UUZ_UART_TYPEDEF_H_
#define _UUZ_UART_TYPEDEF_H_

#include "uuzConfigUART.h"
#include "uuzConfigDEV.h"
#include <board.h>
#include <rtthread.h>

typedef rt_err_t (*kitEvent)(rt_device_t, rt_size_t);
typedef void (*p_kitEvent)(void* parameter);
typedef void (*p_rxEvent)(u8 *rx, u8 *tx);

typedef struct uuz_uart
{
    //起始标记
    char name[RT_NAME_MAX];
    //Serial Name
    rt_device_t serial;
    u8 id;
    //Callback
    struct rt_semaphore rx_sem;
    //回调函数地址
    kitEvent* rx_cb;
    p_kitEvent* rx_entry;
    p_rxEvent do_entry;    //接收处理函数

    //串口类型
    //0:RS232;1:RS485;2:RS232(RTU);3-RS485(RTU)
    u8 serial_type;
    //接收区域
    u16 len;
    u16 readylen;
    u8 buff;
    u8 rxbuff[uuzUART_LEN];
    u8 txbuff[uuzUART_LEN];
    //接收标记
    u8 flag;    // 0/1
    u8 time_dy;    // 实时的延时时间
    u8 time_max;    //最大延时时间Max 0~255m
    //日志打印标记
    u8 log_rx;    // 0/1
    u8 log_tx;    // 0/1

} typedef_Uart;

typedef struct uart_group
{
    u8 max;     //有效的串口属性
    u8 en[uuzUART_MAX];      //0-无效/1-有效
    typedef_Uart uart[uuzUART_MAX];

} Uart_Group_Typedef_t;

#endif /* _UUZ_UART_TYPEDEF_H_ */
