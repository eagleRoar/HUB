/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-27   ZhouXiaomin     first version
 */
/*include*******************************************************/
#include <rtthread.h>
/**************************************************************/
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzUART.h"
#include "uuzConfigDEV.h"
/**************************************************************/
#include "uuzDevID.h"
#include "uuzDevCfg.h"
#include "uuzEventDevID.h"
/**************************************************************/
#include "uuzBBL.h"
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
#include "uuzMBR.h"
/**************************************************************/
#include "uuzUart7.h"
#include "typedefMBR.h"
#include "uuzEventPHEC.h"
#include "uuzEventP260.h"
#include "uuzEventHMI.h"
#include "uuzEventUART.h"
/*log----------------------------------------------------------*/
#define DBG_TAG "uart.7"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/**************************************************************/
#if defined(BSP_USING_UART7)
/** @brief	定义传感器通讯通道 */

/**
 * @brief 传感器接口处理函数
 * 
 * @param dev 
 * @param size 
 * @return rt_err_t 
 */
rt_err_t uart7_input(rt_device_t dev, rt_size_t size)
{
    /* 串口接收到数据后产生中断，调用此回调函数，然后发送接收信号量 */
    rt_sem_release(&xUartE.uart[uuzUART_7].rx_sem);
    return RT_EOK;
}

/**
 * @brief Sensor的串口接收处理函数
 * 
 * @param ucRxCode 
 * @param ucTxCode 
 */
void uart7_receive_event(u8* ucRxCode, u8* ucTxCode)
{
    // Init Temp Data
    if (ucRxCode) {
        //读取设备的modbus和对应设备号
        u8 ucHead = ucRxCode[0];
        if (ucHead != uuzBBL_HEAD) {
            // MODBUS-RTU RPOTOCOL
            u8 ucTxHead = ucTxCode[0];
            u16 usTxRegAddr = usU8ToU16(ucTxCode + 2, uuzMSB);

            //LOG_D("RX:%02X-TX:%02X", ucHead, ucTxHead);
            //发送端和接收端相同
            if (ucHead == ucTxHead) {
                //读取发送参数
                u8 ucOpt = ucRxCode[1];
                //读取总表里是否有设备ID
                u8 index = usValtoID(ucHead, uuzUART_7);

                //有设备数据
                if (index < uuzDEV_MAX) {
                    //设备数据为有效数据
                    if (xDevIDs[index].en == uuzDEV_REG_OK) {
                        //获取设备类型
                        u8 ucType = xDevIDs[index].type;
                        //查看加载区,设备是否存在
                        index = ucIDtoVal(ucHead, ucType, uuzUART_7);
                        //判断命令字
                        switch (ucOpt)
                        {
                            case uuzMBR_READ_HOLDING_REGISTER:
                                //判断设备类型
                                switch (ucType)
                                {
                                    case uuzDEV_SL_PHECB2:
                                        //设备的缓存位置
                                        if (index < uuzDEV_PHEC_B2_MAX) {
                                            if (usTxRegAddr == phec_opt_code[_MBR_R_VALUE].code) {
                                                //获取PHEC-B2的相关数据
                                                phec_value_resolve(index, ucRxCode);
                                                device_connect_reset(&xDevSTA.xB2[index]);
                                                device_id_update(uuzDEV_SL_PHECB2);
                                            }
                                        }
                                        break;
                                    case uuzDEV_SL_P260:
                                        //设备的缓存位置
                                        if (index < uuzDEV_SIN_P260_MAX) {
                                            if (usTxRegAddr == p260_opt_code[_MBR_R_VALUE].code) {    //获取SinP260的水位相关数据
                                                sinp260_value_resolve(index, ucRxCode);
                                                device_connect_reset(&xDevSTA.xP260[index]);
                                                device_id_update(uuzDEV_SL_P260);
                                                xSysSTA.state_find = 1;  //关闭查找状态
                                            } else if (usTxRegAddr == p260_opt_code[_MBR_GET_ID].code) {  //获取读取SinP260的水位相关数据
                                                sinp260_find_resolve(index, ucRxCode);
                                                device_connect_reset(&xDevSTA.xP260[index]);
                                                device_id_update(uuzDEV_SL_P260);
                                                xSysSTA.state_find = 1;  //关闭查找状态
                                            }
                                        }
                                        break;
                                    default:
                                        break;
                                }
                                break;
                            case uuzMBR_WRITE_REGISTER:
                                case uuzDEV_SL_P260:
                                //设备的缓存位置
                                if (index < uuzDEV_SIN_P260_MAX) {
                                    if (usTxRegAddr == p260_opt_code[_MBR_GET_ID].code) {  //获取读取SinP260的水位相关数据
                                        sinp260_find_resolve(index, ucRxCode);
                                        device_connect_reset(&xDevSTA.xP260[index]);
                                        device_id_update(uuzDEV_SL_P260);
                                        xSysSTA.state_find = 1;  //关闭查找状态
                                    }
                                }
                                break;
                                break;
                            default:
                                break;
                        }
                    } else {
                        LOG_E("The data header to be received is inconsistent with the sender");
                    }
                }
            }
        }
    }
}
#endif /* BSP_USING_UART7 */
