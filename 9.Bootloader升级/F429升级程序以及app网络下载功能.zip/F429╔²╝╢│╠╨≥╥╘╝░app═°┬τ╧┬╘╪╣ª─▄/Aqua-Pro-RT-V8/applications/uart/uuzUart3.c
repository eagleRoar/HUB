/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-27   ZhouXiaomin     first version
 */

/*include*******************************************************/
#include <rtthread.h>
/**************************************************************/
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzUART.h"
#include "uuzConfigDEV.h"
/**************************************************************/
#include "uuzDevID.h"
#include "uuzDevCfg.h"
#include "uuzEventDevID.h"
/**************************************************************/
#include "uuzBBL.h"
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
#include "uuzMBR.h"
/**************************************************************/
#include "uuzUart3.h"
#include "typedefMBR.h"
#include "uuzEventVALVE.h"
#include "uuzEventHMI.h"
#include "uuzEventUART.h"
#include "uuzEventTEST.h"
/*log----------------------------------------------------------*/
#define DBG_TAG "uart.3"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/**************************************************************/
#if defined(BSP_USING_UART3)
//定义LINE1通讯通道
typedef_Uart xUart3Rx;
/**
 *
 * @brief 串口接收回调
 * @param dev
 * @param size
 * @return
 */
rt_err_t uart3_input(rt_device_t dev, rt_size_t size)
{
    /* 串口接收到数据后产生中断，调用此回调函数，然后发送接收信号量 */
    //读取缓存数据
    rt_sem_release(&xUartE.uart[uuzUART_3].rx_sem);
    return RT_EOK;
}

/**
 * @brief uart3串口的接收处理
 * @param ucRxCode
 * @param ucTxCode
 */
void uart3_receive_event(u8* ucRxCode, u8* ucTxCode)
{
    // Init Temp Data
    if (ucRxCode) {
        //读取设备的modbus和对应设备号
        u8 ucHead = ucRxCode[0];
        if (ucHead != uuzBBL_HEAD) {
            // MODBUS-RTU RPOTOCOL
            u8 ucTxHead = ucTxCode[0];
            u16 usTxRegAddr = usU8ToU16(ucTxCode + 2, uuzMSB);

            //发送端和接收端相同
            if (ucHead == ucTxHead) {
                //读取发送参数
                u8 ucOpt = ucRxCode[1];
                //读取总表里是否有设备ID
                u8 index = usValtoID(ucHead, uuzUART_3);

                //有设备数据
                if (index < uuzDEV_MAX) {
                    //设备数据为有效数据
                    if (xDevIDs[index].en == uuzDEV_REG_OK) {
                        //获取设备类型
                        u8 ucType = xDevIDs[index].type;
                        //查看加载区,设备是否存在
                        index = ucIDtoVal(ucHead, ucType, uuzUART_3);
                        //LOG_D("Index[%d]-Type[%d]", index, ucType);
                        //判断命令字
                        switch (ucOpt)
                        {
                            case uuzMBR_READ_HOLDING_REGISTER:
                                //判断设备类型
                                switch (ucType)
                                {
                                    case uuzDEV_SL_BRD:
                                        //设备的缓存位置
                                        if (index < uuzDEV_BRD_MAX) {
                                            if (usTxRegAddr == broad_opt_code[_MBR_R_VALUE].code) {
                                                //获取Broad的状态相关数据
                                                valve_board_resolve(ucRxCode);
                                                device_connect_reset(&xDevSTA.xBrd[index]);
                                                device_id_update(uuzDEV_SL_BRD);
                                            }
                                        }
                                        break;
                                    default:
                                        break;
                                }
                                break;
                            case uuzMBR_WRITE_REGISTER:
                                //判断设备类型
                                switch (ucType)
                                {
                                    case uuzDEV_SL_BRD:
                                        //设备的缓存位置
                                        if (index < uuzDEV_BRD_MAX) {
                                            if (usTxRegAddr == broad_opt_code[_MBR_R_VALUE].code) {
                                                //获取Broad的状态相关数据
                                                valve_board_opt_replay(ucRxCode);
                                                device_connect_reset(&xDevSTA.xBrd[index]);
                                                device_id_update(uuzDEV_SL_BRD);
                                            }
                                        }
                                        break;
                                    default:
                                        break;
                                }
                                break;
                            default:
                                break;
                        }
                    } else {
                        LOG_E("The data header to be received is inconsistent with the sender");
                    }
                }
            } else {
                LOG_E("The data header[0x%02X] to be received is inconsistent with the sender[0x%02X]", ucHead,
                        ucTxHead);
            }
        }
    }
}
#endif /* BSP_USING_UART3 */
