/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-27   ZhouXiaomin     first version
 */

#ifndef _UUZ_UART_H_
#define _UUZ_UART_H_

/* rt-thread include-------------------------------------------*/
#include <board.h>
#include <rtthread.h>
/* user include------------------------------------------------*/
#include "uuzConfigUART.h"
#include "typedefBASE.h"
#include "typedefUART.h"

#ifdef __cplusplus
extern "C" {
#endif

//uart公共函数
/**
 * @brief 串口初始化函数
 *
 * @param name：串口名称
 * @param id：串口编号
 * @param baud_rate:波特率
 * @param xEvent:对应回调事件
 * @param thread_entry：回调线程
 * @param do_entry：串口执行函数
 * @param ulMem:使用空间大小
 * @param type:串口类型RS485/RS232
 * @param log_rx:接收日志-RT_TRUE/RT_FALSE
 * @param log_tx:发送日志-RT_TRUE/RT_FALSE
 * @return
 */
int uart_init(
        char* name, /* 串口名称*/
        u8 id,/*串口编号*/
        u32 baud_rate, /*串口波特率 */
        kitEvent xEvent, /*回调实现函数*/
        p_kitEvent thread_entry, /*线程实现函数*/
        p_rxEvent do_entry, /* 执行函数 */
        u32 ulMem, /* 线程的空间分配量 byte*/
        u8 type, /*串口类型*/
        u8 log_rx,/*串口发送日志*/
        u8 log_tx/*串口接收日志*/);
void rt_uart_send(typedef_Uart* pxUart, const u8* pucTxCode, u8 ucLen);
void rt_uart_thread_entry(void* parameter);
void uart_recv_entry(typedef_Uart *uart);
int dy_init(void);
int do_init(void);
/**
 * @brief 串口处理线程
 */
void uart_recv_event(void* parameter);

#ifdef __cplusplus
}
#endif

#endif /* _UUZ_UART_H_ */
