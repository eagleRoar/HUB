/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-27   ZhouXiaomin     first version
 */
/*include*******************************************************/
#include <rtthread.h>
/**************************************************************/
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzUART.h"
#include "uuzConfigDEV.h"
/**************************************************************/
#include "uuzBBL.h"
#include "uuzConfigBBL.h"
#include "typedefMBR.h"
#include "uuzConfigMBR.h"
#include "uuzMBR.h"
/**************************************************************/
#include "uuzDevID.h"
#include "uuzDevCfg.h"
#include "uuzEventDevID.h"
/**************************************************************/
#include "uuzUart2.h"
#include "uuzEventDOSING.h"
#include "uuzEventUART.h"
#include "uuzEventHMI.h"
/*log----------------------------------------------------------*/
#define DBG_TAG "uart.2"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/**************************************************************/
#if defined(BSP_USING_UART2)
//定义LINE2通讯通道
typedef_Uart xUart2Rx;
/**
 * @brief line2_uart_input
 * @param dev
 * @param size
 * @return
 */
rt_err_t uart2_input(rt_device_t dev, rt_size_t size)
{
    //该串口未被使用到LOG输出
    /* 串口接收到数据后产生中断，调用此回调函数，然后发送接收信号量 */
    //读取缓存数据
    rt_sem_release(&xUartE.uart[uuzUART_2].rx_sem);
    return RT_EOK;
}

/**
 * @brief uart2串口的接收处理
 * @param ucRxCode
 * @param ucTxCode
 * @param ucUart
 */
void uart2_receive_event(u8* ucRxCode, u8* ucTxCode)
{
    if (ucRxCode) {
        //读取设备的modbus和对应设备号
        u8 ucHead = ucRxCode[0];
        if (ucHead != uuzBBL_HEAD) {
            // MODBUS-RTU RPOTOCOL
            u8 ucTxHead = ucTxCode[0];
            u16 usTxRegAddr = usU8ToU16(ucTxCode + 2, uuzMSB);

            //发送端和接收端相同
            if (ucHead == ucTxHead) {
                //读取发送参数
                u8 ucOpt = ucRxCode[1];
                //读取总表里是否有设备ID
                u8 index = usValtoID(ucHead, uuzUART_2);

                //有设备数据
                if (index < uuzDEV_MAX) {
                    //设备数据为有效数据
                    if (xDevIDs[index].en == uuzDEV_REG_OK) {
                        //获取设备类型
                        u8 ucType = xDevIDs[index].type;
                        //查看加载区,设备是否存在
                        index = ucIDtoVal(ucHead, ucType, uuzUART_2);
                        //LOG_D("Index[0x%02X]-Type[%d]", index, ucType);
                        //判断命令字
                        switch (ucOpt)
                        {
                            case uuzMBR_READ_HOLDING_REGISTER:
                                //判断设备类型
                                switch (ucType)
                                {
                                    case uuzDEV_SL_DOS:
                                        //设备的缓存位置
                                        if (index < uuzDEV_DOS_MAX) {
                                            if (usTxRegAddr == dosing_opt_code[1].code) {           //获取Dosing蠕动泵的状态相关数据
                                                dosing_state_resolve(index, ucRxCode);
                                                device_connect_reset(&xDevSTA.xDos[index]);
                                                device_id_update(uuzDEV_SL_DOS);
                                            }
                                        }
                                        break;
                                    default:
                                        break;
                                }
                                break;
                            case uuzMBR_WRITE_REGISTER:
                                //判断设备类型
                                switch (ucType)
                                {
                                    case uuzDEV_SL_DOS:
                                        //设备的缓存位置
                                        if (index < uuzDEV_DOS_MAX) {
                                            if (usTxRegAddr == dosing_opt_code[2].code) {           //获取Dosing蠕动泵的状态相关数据
                                                dosing_state_replay(index, ucRxCode);
                                                device_connect_reset(&xDevSTA.xDos[index]);
                                                device_id_update(uuzDEV_SL_DOS);
                                            } else if (usTxRegAddr == dosing_opt_code[3].code) {               //修改蠕动泵速度
                                                dosing_ratio_replay(index, ucRxCode);
                                                device_connect_reset(&xDevSTA.xDos[index]);
                                                device_id_update(uuzDEV_SL_DOS);
                                            } else if (usTxRegAddr == dosing_opt_code[4].code) {               //清除蠕动泵计数
                                                device_connect_reset(&xDevSTA.xDos[index]);
                                                device_id_update(uuzDEV_SL_DOS);
                                            }
                                        }
                                        break;
                                    default:
                                        break;
                                }
                                break;
                            default:
                                break;
                        }
                    } else {
                        LOG_E("The data header to be received is inconsistent with the sender");
                    }
                }
            } else {
                LOG_E("The data header[0x%02X] to be received is inconsistent with the sender[0x%02X]", ucHead,
                        ucTxHead);
            }
        }
    }
}

#endif /* BSP_USING_UART2 */
