/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-27   ZhouXiaomin     first version
 */

#ifndef _UUZ_LINE2_H_
#define _UUZ_LINE2_H_

/* rt-thread include --------------------------------------- */
#include <board.h>
#include <rtthread.h>
/* uart include -------------------------------------------- */
#include "uuzConfigUART.h"
#include "typedefUART.h"

#ifdef __cplusplus
extern "C" {
#endif

#if defined(BSP_USING_UART2)
extern typedef_Uart xUart2Rx;
rt_err_t uart2_input(rt_device_t dev, rt_size_t size);
/* 接收回调函数 */
void uart2_thread_entry(void* parameter);

/**
 * @brief uart2串口的接收处理
 * @param ucRxCode
 * @param ucTxCode
 * @param ucUart
 */
void uart2_receive_event(u8* ucRxCode, u8* ucTxCode);
#endif /* BSP_USING_UART2 */

#ifdef __cplusplus
}
#endif

#endif /* _UUZ_LINE2_H_ */
