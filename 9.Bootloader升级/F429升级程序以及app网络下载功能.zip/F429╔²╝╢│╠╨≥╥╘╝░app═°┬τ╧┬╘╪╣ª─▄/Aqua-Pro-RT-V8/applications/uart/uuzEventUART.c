/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-27   ZhouXiaomin     first version
 */
/* rt-thread include ------------------------------------------*/
#include <rtthread.h>
#include <rtdevice.h>
/* user include -----------------------------------------------*/
#include "uuzConfigUART.h"
#include "uuzUART.h"
#include "uuzEventUART.h"
/* uart include -----------------------------------------------*/
#include "uuzHmiTFT.h"
#include "uuzUart3.h"
#include "uuzUart2.h"
#include "uuzUart7.h"
#include "uuzUart8.h"
/* uart define -----------------------------------------------*/
Uart_Group_Typedef_t xUartE;
/*log----------------------------------------------------------*/
#define DBG_TAG "e.uart"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
//--------------------------------------------------------------
/**
 * @brief 初始化设备串口参数，并打开相应的接收线程
 */
void uart_common_init(void)
{
    /* 开启设备的USART 1,2,3 UART7,8 */
    //UART-7
    uart_init(UART7_NAME, uuzUART_7, BAUD_RATE_9600, uart7_input,
            rt_uart_thread_entry, uart7_receive_event,
            1000, uuzUART_RTU_RS485, RT_FALSE, RT_FALSE);
    //UART-8
    uart_init(UART8_NAME, uuzUART_8, BAUD_RATE_9600, uart8_input,
            rt_uart_thread_entry, uart8_receive_event,
            1000, uuzUART_RTU_RS485, RT_FALSE, RT_FALSE);
    //UART-3
    uart_init(UART3_NAME, uuzUART_3, BAUD_RATE_9600, uart3_input,
            rt_uart_thread_entry, uart3_receive_event,
            1000, uuzUART_RTU_RS485, RT_FALSE, RT_FALSE);
    //UART-2
    uart_init(UART2_NAME, uuzUART_2, BAUD_RATE_9600, uart2_input,
            rt_uart_thread_entry, uart2_receive_event,
            //1000, uuzUART_RTU_RS485, RT_TRUE, RT_TRUE);
            1000,
            uuzUART_RTU_RS485,
            RT_FALSE,
            RT_FALSE);
    //HMI屏幕通讯
    uart_init(HMI_UART_NAME, uuzUART_1, BAUD_RATE_115200, hmitft_uart_input,
            rt_uart_thread_entry, hmi_receive_data,
            1000, uuzUART_COM_RS232, RT_TRUE, RT_FALSE);
    dy_init();  //延时数据判断
    do_init();  //执行数据判断

}
