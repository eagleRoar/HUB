/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-04   ZhouXiaomin     first version
 */
#ifndef _UUZ_DEVICE_H_
#define _UUZ_DEVICE_H_

/* rt-thread include --------------------------------------- */
#include <board.h>
#include <rtthread.h>
/* uart include -------------------------------------------- */
#include "uuzConfigUART.h"
#include "typedefUART.h"

#ifdef __cplusplus
extern "C" {
#endif

#if defined(BSP_USING_UART8)
extern typedef_Uart xUart8Rx;
rt_err_t uart8_input(rt_device_t dev, rt_size_t size);
/* 接收回调函数 */
void uart8_thread_entry(void* parameter);
void uart8_receive_event(u8* ucRxCode, u8* ucTxCode);
#endif /* BSP_USING_UART8 */

#ifdef __cplusplus
}
#endif

#endif /* _UUZ_DEVICE_H_ */
