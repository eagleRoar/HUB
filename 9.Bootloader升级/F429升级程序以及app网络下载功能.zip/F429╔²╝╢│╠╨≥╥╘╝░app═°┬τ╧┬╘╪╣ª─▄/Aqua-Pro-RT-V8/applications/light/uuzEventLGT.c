/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
/*include*****************************************************************************/
#include <math.h>
#include <string.h>
/******************************************************************************/
#include "uuzEEPROM.h"
#include "uuzEVENT.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzRTC.h"
/* modbus---------------------------------------------*/
#include "uuzConfigBBL.h"
#include "uuzConfigHMI.h"
#include "uuzConfigMBR.h"
/* device id---------------------------------------------*/
#include "typedefBASE.h"
#include "typedefDEVID.h"
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
/* event---------------------------------------------*/
#include "uuzEventLGT.h"
#include "uuzEventVALVE.h"
#include "uuzConfigPORT.h"
/* log---------------------------------------------*/
#define DBG_TAG "e.lgt"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/******************************************************************************/
Item_Typedef_t xDayState;  //白天黑夜缓存数据
Lgt_Pro_Typedef_t xLgtPro;  //灯光配置数据列表
/******************************************************************************/
/**
 * @brief 初始化灯光的Project配置数据
 */
void lgt_config_add(Lgt_Config_Typedef_t * xLgtCfg)
{
    u16 index = 0;

    if (xLgtCfg != RT_NULL) {

        xLgtCfg->en = uuzTRUE;  //数据有效
        xLgtCfg->md = _M_MANUAL;    //手动模式
        xLgtCfg->sta = uuzOPT_OFF;  //手动模式-关闭状态

        //Cycle模式
        xLgtCfg->t_cycle[0].on = 120;  //min:120min=2hour
        xLgtCfg->t_cycle[0].off = 60;  //min:60=1hour
        xLgtCfg->t_cycle[1].on = 30;  //min:30min=0.5hour
        xLgtCfg->t_cycle[1].off = 180;  //min:180=3hour

        //定时模式
        for (index = 0; index < 5; index++) {
            xLgtCfg->t_timer[index].en = 0;  //0-off/1-on
            xLgtCfg->t_timer[index].on = 8 * 60;  //8:00
            xLgtCfg->t_timer[index].off = 18 * 60;  //18:00
        }

        xLgtCfg->end = 0xBBBBU;  //结束符
        LOG_D("Init Light Config");
    }
}

/**
 * @brief 释放灯光的Project配置数据
 * @param xLgtCfg
 */
void lgt_config_init(Lgt_Config_Typedef_t * xLgtCfg)
{
    u16 index = 0;

    if (xLgtCfg != RT_NULL) {

        xLgtCfg->en = uuzFALSE;  //数据无效
        xLgtCfg->md = _M_NONE;
        xLgtCfg->sta = uuzOPT_OFF;

        //Cycle模式
        xLgtCfg->t_cycle[0].on = 120;  //min:120min=2hour
        xLgtCfg->t_cycle[0].off = 60;  //min:60=1hour
        xLgtCfg->t_cycle[1].on = 30;  //min:30min=0.5hour
        xLgtCfg->t_cycle[1].off = 180;  //min:180=3hour

        //定时模式
        for (index = 0; index < 5; index++) {
            xLgtCfg->t_timer[index].en = 0;  //0-off/1-on
            xLgtCfg->t_timer[index].on = 8 * 60;  //8:00
            xLgtCfg->t_timer[index].off = 18 * 60;  //18:00
        }

        xLgtCfg->end = 0xBBBBU;  //结束符

        LOG_D("Init Light Config");
    }
}

/**
 * @brief 灯光缓存数据
 */
void lgt_cache_init(void)
{
    //白天黑夜模式
    rt_memset(&xDayState, 0x00U, sizeof(Item_Typedef_t));    //清空缓存数据
    xDayState.max = 3;    //灯光判断次数
    lgt_state_reset();    //灯光循环参数处理
}

/**
 * @brief 读取设备的白天黑夜状态
 */
void lgt_daytime_judge(void)
{
    u32 time = uuz_usRTC_GetMinutes();    //当前时间分钟
    u16 sta_lgt = 0;

    if (xSysCFG.day_mode == 0) {    //手动设置模式,判断为白天/黑夜
        sta_lgt = ((time >= xSysCFG.day_on) && (time <= xSysCFG.day_off)) ? (uuzDAY) : (uuzNIGHT);
        item_analysis(&xDayState, sta_lgt);    //判断白天和黑夜是否有切换
        //LOG_D("CSta:%d,Opt:%d,Sta:%d,", sta_lgt, xDayState.opt, xDayState.sta);
        if (xDayState.opt == 1) {        //白天黑夜判断
            if (xDayState.sta != sta_lgt) {
                xDayState.sta = sta_lgt;        //记录当前状态
                xDayState.time = 0;        //清除延时计数
                //TODO:保存相关数据到log
            }
        }
    } else {
        for (u8 index = 0; index < _LGT_CFG_MAX; index++) {
            sta_lgt |= xLgtPro.sta[index].sta;  //获取灯光汇总数据
        }
        if (xDayState.sta != sta_lgt) {                //灯光自动模式
            xDayState.sta = (sta_lgt == uuzOPT_ON) ? (uuzDAY) : (uuzNIGHT);                //获取自动灯光信息
        }
    }
}

/**
 * @brief 灯光事件判断处理
 */
void lgt_opt_event(void)
{
    lgt_opt_judge(xLgtPro.cfg[0], &xLgtPro.sta[0]);
}

/**
 * @brief 单路灯光数据处理操作
 */
void lgt_opt_judge(Lgt_Config_Typedef_t * cfg, Cycle_Item_Typedef_t * sta)
{
    u8 day = uuzDAY;

    if (cfg->md == _M_MANUAL) {                //手动模式
        sta->sta = valve_single_state_get(3);   //读取相关数据
        if (sta->sta != cfg->sta) {                //更新手动数据
            valve_opt_group(uuzPORT_LIGHT, cfg->sta);   //执行动作
            sta->sta = cfg->sta;    //更新状态
        }
    } else if (cfg->md == _M_CYCLE) {  //循环模式
        LOG_D("lgt-opt:%d-sta:%d-time:%d", sta->opt, sta->sta, sta->time);
        if (xSysCFG.day_mode == 0) {  //判断是否手动模式,手动模式下才有白天黑夜数据不一致
            day = xDayState.sta;    //更新白天黑夜数据
        }

        if (sta->opt == uuzRUN_OFF) {    //判断是否处于执行阶段
            //开启灯光运行状态
            sta->time = 0;  //清除计时
            sta->sta = uuzOPT_ON;  //打开灯光
            sta->opt = uuzRUN_ON;  //启动运行
            valve_opt_group(uuzPORT_LIGHT, sta->sta);   //执行动作
        } else {  //如果是开启状态，时间计数
            if (sta->sta == uuzOPT_ON) {  //已经达到循环开启灯光状态
                if (sta->time >= cfg->t_cycle[day].on * 60) {  //开启灯光运行状态-关闭
                    sta->time = 0;  //清除计时
                    sta->sta = uuzOPT_OFF;  //打开灯光
                    valve_opt_group(uuzPORT_LIGHT, sta->sta);   //执行动作
                } else {
                    sta->time++;  //延时计数
                }
            } else {  //已经达到循环开启灯光状态
                if (sta->time >= cfg->t_cycle[day].off * 60) {  //开启灯光运行状态-开启
                    sta->time = 0;  //清除计时
                    sta->sta = uuzOPT_ON;  //打开灯光
                    valve_opt_group(uuzPORT_LIGHT, sta->sta);   //执行动作
                } else {
                    sta->time++;  //延时计数
                }
            }
        }
    } else if (cfg->md == _M_TIMER) {  //定时模式
        u32 time = uuz_usRTC_GetMinutes() * 60;  //获取当前事件-分
        u32 dayON = 0;
        u32 dayOFF = 0;
        u8 isValid = 0;

        sta->sta = valve_single_state_get(3);   //读取相关数据

        for (u8 index = 0; index < 5; index++) {  //使用完整定时的阶段数据处理开启时间
            if (cfg->t_timer[index].en == 1) {  //定时数据有效获取最小开启时间和最大结束时间
                dayON = cfg->t_timer[index].on * 60;
                dayOFF = cfg->t_timer[index].off * 60;
                if ((time >= dayON) && (time <= dayOFF)) {  //为开启数据
                    isValid = 1;
                    break;
                }
            }
        }

        if (isValid) {  //有开启相关数据
            if (sta->sta == uuzOPT_OFF) {  //灯光状态为关闭
                sta->sta = uuzOPT_ON;  //灯光未开启,开启灯光
                valve_opt_group(uuzPORT_LIGHT, sta->sta);   //执行动作
            }
        } else {  //为关闭数据
            if (sta->sta == uuzOPT_ON) {  //灯光状态为开启
                sta->sta = uuzOPT_OFF;  //灯光未开启,关闭灯光
                valve_opt_group(uuzPORT_LIGHT, sta->sta);   //执行动作
            }
        }
    }
}

/**
 * @brief 灯光工作状态清零
 */
void lgt_state_reset(void)
{
    //灯光循环参数处理
    for (u8 index = 0; index < _LGT_CFG_MAX; index++) {
        rt_memset(&xLgtPro.sta[index], 0x00U, sizeof(Cycle_Item_Typedef_t));
    }
}
