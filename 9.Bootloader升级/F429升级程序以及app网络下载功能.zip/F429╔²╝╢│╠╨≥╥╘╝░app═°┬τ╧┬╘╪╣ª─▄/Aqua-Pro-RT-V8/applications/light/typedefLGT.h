/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_LGT_H
#define __TYPEDEF_LGT_H

// include ---------------------------------------------
#include "typedefBASE.h"
#include "typedefDEVID.h"
#include "uuzConfigDEV.h"
#include "uuzOpt.h"
// ------- ---------------------------------------------
#define _LGT_CFG_MAX (1U)   //最多同时操作8组灯光数据
typedef struct light_config_t
{
    u8 en;  //配置有效性
    u8 md;  //Manual:工作模式
    u8 sta;  //手动状态：0-off/1-on
    //cycle-time
    Cycle_Typedef_t t_cycle[2];  //Day/Night:second
    //timer-time
    Timer_Typedef_t t_timer[5];  //5组定时器:mins

    u16 end;    //0xBBBBU

}__attribute__ ((__packed__)) Lgt_Config_Typedef_t;
#define uuzLGT_CFG_LEN (sizeof(Lgt_Config_Typedef_t))

typedef struct light_pro_t
{
    Lgt_Config_Typedef_t *cfg[_LGT_CFG_MAX];   //配置地址
    Cycle_Item_Typedef_t sta[_LGT_CFG_MAX];   //数据对应缓存

}__attribute__ ((__packed__)) Lgt_Pro_Typedef_t;

#endif // __TYPEDEF_LGT_H
