/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __UUZ_LGT_EVENT_H
#define __UUZ_LGT_EVENT_H

#include "typedefLGT.h"
#include "typedefMBR.h"

extern Item_Typedef_t xDayState;
extern Cycle_Item_Typedef_t xLgtCache;  //灯光的缓存数据
extern Lgt_Pro_Typedef_t xLgtPro;  //灯光配置数据列表

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 灯光缓存数据
 * 
 */
void lgt_cache_init(void);
/**
 * @brief 初始化灯光的Project配置数据
 */
void lgt_config_init(Lgt_Config_Typedef_t * xLgtCfg);
/**
 * @brief 初始化灯光的Project配置数据
 */
void lgt_config_add(Lgt_Config_Typedef_t * xLgtCfg);
/**
 * @brief 释放灯光的Project配置数据
 */
void lgt_config_free(Lgt_Config_Typedef_t * xLgtCfg);
#if 0
/**
 * @brief 处理类型数据的的相关状态
 * @param prev_p 需要处理的端口位置-旧
 * @param curr_p 需要处理的端口位置-新
 * @param state 需要处理的状态
 */
void lgt_config_sync(u16 prev_p, u16 curr_p, u8 state);
#endif
/**
 * @brief 读取设备的白天黑夜状态
 */
void lgt_daytime_judge(void);
#if 0
/**
 * @brief 灯光动作判断
 */
void lgt_mode_judge(void);
#endif

/**
 * @brief 灯光事件判断处理
 */
void lgt_opt_event(void);

/**
 * @brief 单路灯光数据处理操作
 */
void lgt_opt_judge(Lgt_Config_Typedef_t * cfg, Cycle_Item_Typedef_t * sta);

/**
 * @brief 灯光工作状态清零
 */
void lgt_state_reset(void);

#ifdef __cplusplus
}
#endif

#endif // __UUZ_LGT_EVENT_H
