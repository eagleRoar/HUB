/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-28   ZhouXiaomin     first version
 */
/* Includes ------------------------------------------------------------------*/
#include <string.h>
#include "uuzEEPROM.h"
#include "at24cxx.h"
#include "uuzINIT.h"
/* log---------------------------------------------*/
#define DBG_TAG "u.eeprom"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/* private---------------------------------------------*/
//AT24C256初始化
static at24cxx_device_t eeprom_dev;
/***************DEVICE CONFIG FUNCTIONS************************************/
/**
 * @brief 初始化EEPROM相关设备
 */
void device_eeprom_init(void)
{
    if (eeprom_dev != RT_NULL) {
        LOG_E("the i2c2 is already open!");
    } else {
        for (int i2c_reboot = 0; i2c_reboot < uuzREBOOT_COUNT; i2c_reboot++) {
            eeprom_dev = at24cxx_init(uuzEEPROM_I2C_BUS_NAME, 0);
            if (eeprom_dev == RT_NULL) {
                LOG_E("[%d]open at24cxx fail!", i2c_reboot);
            } else {
                LOG_D("[%d]open at24cxx success!", i2c_reboot);
                break;
            }
        }
    }
}

/**
 * @brief 从EEPROM读取数据
 * @param ReadAddr
 * @param pBuffer
 * @param NumToRead
 */
void eeprom_to_config(u16 ReadAddr, u8* pBuffer, u16 NumToRead)
{
    if (eeprom_dev != RT_NULL) {
        at24cxx_read(eeprom_dev, ReadAddr, pBuffer, NumToRead);
        LOG_D("eeprom read config[%04d] from addr[%04d]", NumToRead, ReadAddr);
    } else {
        LOG_E("eeprom i2c open fail--->read[%d]", ReadAddr);
    }
}

/**
 * @brief 写入数据到EEPROM
 * @param ReadAddr
 * @param pBuffer
 * @param NumToRead
 */
void config_to_eeprom(u16 WriteAddr, u8* pBuffer, u16 NumToRead)
{
    if (eeprom_dev != RT_NULL) {
        at24cxx_write(eeprom_dev, WriteAddr, pBuffer, NumToRead);
        LOG_D("eeprom write config[%04d] to addr[%04d]", NumToRead, WriteAddr);
    } else {
        LOG_E("eeprom i2c open fail--->write[%d]", WriteAddr);
    }
}
/**************************************************************************/
