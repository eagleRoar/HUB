/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __UUZ_CONFIG_SIN_P260_H
#define __UUZ_CONFIG_SIN_P260_H

#define uuzSINP260_MID 0x00 //正常水位
#define uuzSINP260_HIGH 0x01 //高水位
#define uuzSINP260_LOW 0x02 //低水位
#define uuzSINP260_TARGET 0x03 //目标水位
#define uuzSINP260_NULL 0xFFU //无效水位属性

#define uuzSINP260_STA_MAX (6U) //水位数据循环次数
#define uuzSINP260_CHK_MAX (10U) //水位检测循环次数

#endif // __UUZ_CONFIG_SIN_P260_H
