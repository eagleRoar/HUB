/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
/*include*****************************************************************************/
#include <math.h>
#include <string.h>
/******************************************************************************/
#include "uuzEVENT.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
/******************************************************************************/
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
/******************************************************************************/
#include "typedefDEVID.h"
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
/******************************************************************************/
#include "uuzEventHMI.h"
//#include "uuzConfigHMI.h"
/******************************************************************************/
#include "uuzEventP260.h"
#include "uuzEventSR.h"
/*log---------------------------------------------*/
#define DBG_TAG "e.p260"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/******************************************************************************/
//水位的缓存数据
SinP260_Value_Typedef_t xP260Value[uuzDEV_SIN_P260_MAX];
MODBUS_RTU_CODE p260_opt_code[5] =
            {
                        { _CODE_W, 0x000AU, 0x3879U },  //Set Password
                        { _CODE_R, 0x0004U, 0x0001U },  //Read Level Value
                        { _CODE_RW, 0x0000U, 0x0001U },  //Set Modbus-ID
                        { _CODE_W, 0x0005U, 0x0001U },  //Set Zero Point
                        { _CODE_RW, 0x0002U, 0x0000U }  //Set Unit "m"
            };
/******************************************************************************/

/**
 * @brief 水位传感器实时信息初始化
 * 
 */
void sinp260_value_init(void)
{
    //初始化连续N组数据为0
    for (u8 index = 0; index < uuzDEV_SIN_P260_MAX; index++) {
        rt_memset(&xP260Value[index], 0x00, sizeof(SinP260_Value_Typedef_t));
    }
}

/**
 * @brief 水位传感器实时信息读取
 * 
 * @param id 水位传感器编号
 */
void sinp260_value_read(u8 id)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Device ID
    ucDataCommand[ucLenCommand++] = xDevSTA.xP260[id].id;
    ucDataCommand[ucLenCommand++] = uuzMBR_READ_HOLDING_REGISTER;
    vU16ToU8(ucDataCommand + ucLenCommand, p260_opt_code[_MBR_R_VALUE].code, uuzMSB);
    ucLenCommand += 2U;
    //连续读取10组数据
    vU16ToU8(ucDataCommand + ucLenCommand, p260_opt_code[_MBR_R_VALUE].n, uuzMSB);
    ucLenCommand += 2U;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;

    cmd_set(xDevSTA.xP260[id].uart, (u8*) ucDataCommand, ucLenCommand);

    //N次读取无数据，将连接状态切断
    if (xDevSTA.xP260[id].count < uuzDEV_CONNECT_ERR) {
        //连接计数
        xDevSTA.xP260[id].count++;
    }
}

/**
 * @brief 设置水位的Modbus-ID
 *
 * @param id:需要设置的Modbus-ID
 */
void sinp260_set_id(u8 id)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;
    u8 ucOldModbusID = 0x01U;

    //Set Password, 解锁密码
    ucDataCommand[ucLenCommand++] = ucOldModbusID;  //新的水位传感器默认值
    ucDataCommand[ucLenCommand++] = uuzMBR_WRITE_REGISTER;
    //写入地址
    vU16ToU8(ucDataCommand + ucLenCommand, p260_opt_code[_MBR_GET_ID].code, uuzMSB);
    ucLenCommand += 2U;
    //需要设置的密码
    vU16ToU8(ucDataCommand + ucLenCommand, p260_opt_code[_MBR_GET_ID].n, uuzMSB);
    ucLenCommand += 2U;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;
    //向传感器串口发送数据
    cmd_set(uuzUART_7, (u8*) ucDataCommand, ucLenCommand);

    rt_thread_mdelay(500);

    //Set Modbus ID
    LOG_D("SET ID[%d]", id);
    ucLenCommand = 0;
    ucDataCommand[ucLenCommand++] = ucOldModbusID;  //新的水位传感器默认值
    ucDataCommand[ucLenCommand++] = uuzMBR_WRITE_REGISTER;
    //写入地址
    vU16ToU8(ucDataCommand + ucLenCommand, p260_opt_code[_MBR_SET_ID].code, uuzMSB);
    ucLenCommand += 2U;
    //输入密码
    vU16ToU8(ucDataCommand + ucLenCommand, id, uuzMSB);
    ucLenCommand += 2U;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;
    //向传感器串口发送数据
    cmd_set(uuzUART_7, (u8*) ucDataCommand, ucLenCommand);
}

/**
 * @brief 查找水位的Modbus-ID
 *
 * @param id:需要设置的Modbus-ID
 */
void sinp260_find_id(u8 id)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Set Password, 解锁密码
    ucDataCommand[ucLenCommand++] = id;  //新的水位传感器默认值
    ucDataCommand[ucLenCommand++] = uuzMBR_READ_HOLDING_REGISTER;
    //写入地址
    vU16ToU8(ucDataCommand + ucLenCommand, p260_opt_code[_MBR_R_VALUE].code, uuzMSB);
    ucLenCommand += 2U;
    //需要设置的密码
    vU16ToU8(ucDataCommand + ucLenCommand, 0x0001U, uuzMSB);
    ucLenCommand += 2U;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;
    //向传感器串口发送数据
    cmd_set(uuzUART_7, (u8*) ucDataCommand, ucLenCommand);
}

/**
 * @brief 水位传感器实时信息解读
 *
 * @param id 水位传感器编号
 * @param data 需要解读的水位传感器实时数据内容
 */
void sinp260_value_resolve(u8 id, u8* data)
{
    u16 ucLenCommand = 3;

    if (data != NULL) {  //实际水位高度
        xP260Value[id].high_p = xP260Value[id].high;
        xP260Value[id].high = usU8ToU16(data + ucLenCommand, uuzMSB);
        //LOG_D("[%d]c:%d--p:%d", id, xP260Value[id].high, xP260Value[id].high_p);
    }
}

/**
 * @brief 水位传感器实时信息解读
 *
 * @param id 水位传感器编号
 * @param data 需要解读的水位传感器实时数据内容
 */
void sinp260_find_resolve(u8 id, u8* data)
{
    if (data != NULL) {
        LOG_D("[%d]state:[%d]", id, data[0]);
    }
}

/**
 * @brief 水池数据水位判断
 * 
 * @param id 数据区编号
 * @param target 自动补水目标水位数据
 * @param high 高水位数据
 * @param low 低水位数据 
 */
void sinp260_judge(u8 id, u16 target, u16 high, u16 low)
{
    if (xDevSTA.xP260[id].isconnect == uuzDEV_CONNECTED) {  //有水位传感器的状态
        //检测实时水位状态
        if (xP260Value[id].high >= high) {
            xP260Value[id].sta = uuzSINP260_HIGH;  //NOTE:高水位
        } else if ((xP260Value[id].high >= target) && (xP260Value[id].high < high)) {
            xP260Value[id].sta = uuzSINP260_TARGET;  //NOTE:目标数据
        } else if ((xP260Value[id].high >= low) && (xP260Value[id].high < target)) {
            xP260Value[id].sta = uuzSINP260_MID;  //NOTE:正常水位
        } else {
            xP260Value[id].sta = uuzSINP260_LOW;  //NOTE:低水位
        }

        if (xP260Value[id].sta_p != xP260Value[id].sta) {  //如果当前状态和上一次检测状态不一致
            xP260Value[id].sta_c = 0;  //水位状态变化，清除状态延时计数
            xP260Value[id].sta_p = xP260Value[id].sta;  //更新上一次水位状态
        } else {
            if (xP260Value[id].sta_c < uuzSINP260_STA_MAX) {  //水位状态没有变化，状态延时计数增加
                xP260Value[id].sta_c++;
            }
        }
        //LOG_D("wls>%d:Count[%d]-Psta[%d]", id, xP260Value[id].sta_c, xP260Value[id].sta_p);
        //NOTE:Jump to 执行
        if (xP260Value[id].sta_c == uuzSINP260_STA_MAX) {  //状态计数延时等待10个检测循环
            xP260Value[id].out = xP260Value[id].sta;
            xP260Value[id].sta_c++;
            xP260Value[id].delay = 0;
            //xSysSTA.curr_wls = id;   //缓存数据标记
            rt_event_send(eventDATA, UI_DATA_SYNC);
        } else {
            if (xP260Value[id].high_p == xP260Value[id].high) {  //如果状态计数延时等待相同,水位高度延时计数
                xP260Value[id].delay++;
            } else {
                if (xP260Value[id].delay) {  //如果有数据不一致，清除一致判断
                    xP260Value[id].delay = 0;
                }
                //水位数据不一致，立刻刷新数据
                rt_event_send(eventDATA, UI_DATA_SYNC);
            }
        }
        //LOG_D("wls>%d:Sta[%d]-Out[%d]", id, xP260Value[id].sta, xP260Value[id].out);
    } else {
        xP260Value[id].sta = uuzSINP260_NULL;  //传感器属性无效
        if (xP260Value[id].sta_p != xP260Value[id].sta) {
            xP260Value[id].out = uuzSINP260_NULL;
            xP260Value[id].sta_c = 0;
            xP260Value[id].sta_p = uuzSINP260_NULL;
            xP260Value[id].delay = 0;
            //xSysSTA.curr_wls = id;   //缓存数据标记
            rt_event_send(eventDATA, UI_DATA_SYNC);
        }
    }
}
