/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __UUZ_SIN_P260_EVENT_H
#define __UUZ_SIN_P260_EVENT_H

#include "typedefMBR.h"
#include "typedefP260.h"
#include "uuzConfigDEV.h"
#include "uuzConfigP260.h"

//缓存数据
extern MODBUS_RTU_CODE p260_opt_code[5];
extern SinP260_Value_Typedef_t xP260Value[uuzDEV_SIN_P260_MAX];

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 水位传感器实时信息初始化
 * 
 */
void sinp260_value_init(void);

/**
 * @brief 水位传感器实时信息读取
 * 
 * @param id 水位传感器编号
 */
void sinp260_value_read(u8 id);

/**
 * @brief 水位传感器实时信息解读
 * 
 * @param id 水位传感器编号
 * @param data 需要解读的水位传感器实时数据内容
 */
void sinp260_value_resolve(u8 id, u8* data);

/**
 * @brief 水位传感器实时信息解读
 *
 * @param id 水位传感器编号
 * @param data 需要解读的水位传感器实时数据内容
 */
void sinp260_find_resolve(u8 id, u8* data);

/**
 * @brief 水池数据水位判断
 * 
 * @param id 数据区编号
 * @param target 自动补水目标水位数据
 * @param high 高水位数据
 * @param low 低水位数据 
 */
void sinp260_judge(u8 id, u16 target, u16 high, u16 low);

/**
 * @brief 设置水位的Modbus-ID
 *
 * @param id:需要设置的Modbus-ID
 */
void sinp260_set_id(u8 id);

/**
 * @brief 查找水位的Modbus-ID
 *
 * @param id:需要设置的Modbus-ID
 */
void sinp260_find_id(u8 id);

#ifdef __cplusplus
}
#endif

#endif // __UUZ_SIN_P260_EVENT_H
