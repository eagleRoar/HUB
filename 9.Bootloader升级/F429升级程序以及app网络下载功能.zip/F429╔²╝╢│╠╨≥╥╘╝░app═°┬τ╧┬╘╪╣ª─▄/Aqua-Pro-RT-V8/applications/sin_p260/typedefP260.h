/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_SIN_P260_H
#define __TYPEDEF_SIN_P260_H

#include "typedefDEVID.h"
#include "uuzConfigDEV.h"
#include "uuzOpt.h"

typedef struct sinp260value_t
{
    u32 high;  //实际实时数据
    u32 high_p;  //旧数据

    u8 sta;  //和数据的对比状态
    u8 sta_p;  //上一次-数据的对比状态记录
    u8 sta_c;   //状态延时计数

    u8 out;   //最终输出的水位状态
    u8 delay;   //输出目标的延时标记

} SinP260_Value_Typedef_t;

#endif // __TYPEDEF_SIN_P260_H
