/*
 * Copyright (c) 2006-2018, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author           Notes
 * 2020-02-10    ZhouXiaomin      first edition.
 */
/*
 * @brief 程序清单：SD使用例程
 *
 */

//rt-include-------------------------------------------------------
#include <dfs_posix.h>
#include <rtdevice.h>
#include <rtthread.h>
//user-include-------------------------------------------------------
#include "typedefBASE.h"
#include "uuzConfigSD.h"
#include "uuzGPIO.h"
#include "uuzINIT.h"
#include "uuzRTC.h"
#include "uuzSD.h"
#include "uuzLOG.h"
/*data---------------------------------------------*/
#include "uuzEventPHEC.h"
/*log---------------------------------------------*/
#define DBG_TAG "u.sd"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
//extern---------------------------------------------------------------
static rt_mutex_t sd_dfs_mutex = RT_NULL;
//---------------------------------------------------------------------
/**
 * @brief SD处理线程初始化
 * @return
 */
int sd_dfs_event_init(void)
{
    rt_err_t ret = RT_EOK;

    //SD卡结构初始化
    if (sd_card_is_vaild()) {
        sd_dfs_init();
        /* 创建 serial 线程 */
        rt_thread_t thread = rt_thread_create("et_dfs", sd_dfs_event_entry,
        RT_NULL, 4000, 25, 10);

        /* 创建成功则启动线程 */
        if (thread != RT_NULL) {
            rt_thread_startup(thread);
            LOG_I("start Thread [event dfs] sucess");
        } else {
            LOG_E("start Thread [event dfs] failed");
            ret = RT_ERROR;
        }

        /* 创建 log serial 线程 */
        thread = rt_thread_create("et_log", sd_log_event_entry,
        RT_NULL, 2000, 26, 10);

        /* 创建成功则启动线程 */
        if (thread != RT_NULL) {
            rt_thread_startup(thread);
            LOG_I("start Thread [event log] sucess");
        } else {
            LOG_E("start Thread [event log] failed");
            ret = RT_ERROR;
        }
    } else {
        LOG_E("sd card loading fail!");
    }

    return ret;
}

/**
 * @brief SD卡相关处理处理事件
 *
 * @param parameter
 */
void sd_dfs_event_entry(void* parameter)
{
    //读取系统日志
    read_data_by_sys(rTm.tm_year + 1900);
    //读取系统操作日志
    read_data_by_opt((rTm.tm_year + 1900), rTm.tm_mon);
    //读取报警操作日志
    read_data_by_alm((rTm.tm_year + 1900), rTm.tm_mon);
    //在SD部分添加保存日志
    save_data_by_sys(1);

    while (1) {
        //定时延时1000ms
        rt_thread_mdelay(1000);
    }
}

/**
 * @brief SD卡相关处理处理事件
 *
 * @param parameter
 */
void sd_log_event_entry(void* parameter)
{
    u32 ulCount = 0;
    //读取实时操作日志
    read_data_by_dev(0, (rTm.tm_year + 1900), rTm.tm_mon, rTm.tm_mday);

    while (1) {
        if (ulCount % 360 == 0) {
            //循环360s记录一次数据
            LOG_D("save device logs:0");
            save_data_by_dev(0, &xPhecB2Value[0]);
        }
        ulCount++;
        rt_thread_mdelay(1000);
    }
}

/**
 * @brief 检测SD是否存在
 * @return 返回SD卡读取的电平，高为卡有效，低为卡无效
 */
int sd_card_is_vaild(void)
{
    return (rt_pin_read(SD_CHK_PIN) == PIN_LOW) ? (1) : (0);
}

/**
 * @brief 初始化SD卡的DFS结构
 * @return
 */
int sd_dfs_init(void)
{
    rt_device_t dev;
    rt_err_t ret;

    u8 reCount = 0;

    /* 创建一个SD-DFS互斥量 */
    sd_dfs_mutex = rt_mutex_create("sd_dfs", RT_IPC_FLAG_FIFO);

    while (1) {
        dev = rt_device_find("sd0");
        if (dev != RT_NULL) {
            reCount++;
            if (dfs_mount("sd0", "/", "elm", 0, 0) == 0) {
                LOG_D("sd card mount to / success!");
                sd_file_init();
                ret = RT_EOK;
                break;
            } else {
                LOG_E("sd card mount to / failed!");
                ret = RT_ERROR;
            }
            //重复检查数据
            if (reCount > 3) {
                LOG_E("sd card mount to / failed again!");
                ret = RT_ERROR;
                break;
            }
        } else {
            LOG_E("sd card find failed!");
            ret = RT_ERROR;
            break;
        }
        rt_thread_delay(50);
    }

    return ret;
}

/**
 * @brief SD内文件和文件夹有效性
 */
void sd_file_init(void)
{
    //检测文件夹可读性
    rt_access_dir("/alarm");
    rt_access_dir("/logs");
    rt_access_dir("/data");
}

/**
 * @brief 检测文件是否存在,并获取文件长度
 * @param name:相关文件名称
 * @return 返回相关文件长度
 */
u32 length_file(char* name)
{
    int ret;
    struct stat buf;

    ret = stat(name, &buf);

    if (ret == 0) {
        LOG_D("%s file size = %d", name, buf.st_size);
        return buf.st_size;
    } else {
        LOG_E("%s file not fonud");
        return 0;
    }
}

/**
 * @brief 检测文件夹是否存在
 *
 * @param name:文件夹名称
 * @return 返回是否有效,成功为RT_EOK
 */
u8 rt_access_dir(char* name)
{
    int ret;

    ret = access(name, 0);
    if (ret < 0) {
        LOG_E("\"%s\" error, reset the dir", name);
        //创建文件夹
        ret = mkdir(name, 0x777);
        if (ret < 0) {
            LOG_E("mkdir \"%s\" error", name);
            return RT_ERROR;
        } else {
            return RT_EOK;
        }
    } else {
        return RT_ERROR;
    }
}

/**
 * @brief 创建数据文件
 *
 * @param name 写入的文件名称
 * @param text 写入数据的数量
 * @param l 写入默认数据长度
 * @return
 */
u8 create_log_data(char* name, u8* text, u32 l)
{
    int fd;

    if (text != NULL) {
        rt_mutex_take(sd_dfs_mutex, RT_WAITING_FOREVER);
        /*生成文件名称*/
        /* 以创建和读写模式打开 name 文件，如果该文件不存在则创建该文件*/
        fd = open(name, O_WRONLY | O_CREAT);
        if (fd >= 0) {
            write(fd, text, l);
            close(fd);
            rt_kprintf("Create done.\n");
            rt_mutex_release(sd_dfs_mutex);
            return RT_EOK;
        }
        rt_mutex_release(sd_dfs_mutex);
    }
    return RT_ERROR;
}

/**
 * @brief 将数据写入相应的LOG文件
 * 
 * @param name 写入的文件名称
 * @param text 需要写入的数据内容
 * @param l 写入长度
 * @return
 */
u8 write_log_data(char* name, u8* text, u32 l)
{
    int fd;

    if (text != NULL) {
        rt_mutex_take(sd_dfs_mutex, RT_WAITING_FOREVER);
        /*生成文件名称*/
        /* 以创建和读写模式打开 name 文件，如果该文件不存在则创建该文件*/
        fd = open(name, O_WRONLY | O_CREAT);
        if (fd >= 0) {
            write(fd, text, l);
            close(fd);
            //rt_kprintf("Write done.\n");
            rt_mutex_release(sd_dfs_mutex);
            return RT_EOK;
        }
        rt_mutex_release(sd_dfs_mutex);
    }
    return RT_ERROR;
}

/**
 * @brief 从文件中读取到固定位置的数据
 * 
 * @param name 需要读取的文件
 * @param text 返回的数据
 * @param l 文件读取的长度
 * @return u8 
 */
u8 read_log_data(char* name, u8* text, u32 l)
{
    int fd;
    int size;

    rt_mutex_take(sd_dfs_mutex, RT_WAITING_FOREVER);
    /*生成文件名称*/
    /* 以创建和读写模式打开 /text.txt 文件，如果该文件不存在则创建该文件*/
    fd = open(name, O_WRONLY | O_CREAT);
    if (fd >= 0) {
        size = read(fd, text, l);
        close(fd);
        if (size > 0) {
            LOG_D("read done[%d].", size);
            rt_mutex_release(sd_dfs_mutex);
            return RT_EOK;
        }
    }
    rt_mutex_release(sd_dfs_mutex);
    return RT_ERROR;
}

//---------------------------------------------------------------------
