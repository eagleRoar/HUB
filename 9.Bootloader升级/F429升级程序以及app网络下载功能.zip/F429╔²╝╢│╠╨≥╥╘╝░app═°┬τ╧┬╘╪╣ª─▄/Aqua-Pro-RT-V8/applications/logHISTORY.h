/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2021-03-08   ZhouXiaomin     first version
 */

#ifndef _UUZ_HISTORY_H_
#define _UUZ_HISTORY_H_

#define _DEV_BBL (0U)   //通用版本
#define _DEV_INNOVATION (1U)  //集装箱定制版本
#define _DEV_INNOVATION_ONLY (2U)  //INNI定制版本
#define _DEV_NULL (255U)  //空类型

//#define uuzDEVICE_TYPE (_DEV_BBL) //BBL版本类型
//#define uuzDEVICE_TYPE (_DEV_INNOVATION) //集装箱普通版本类型
#define uuzDEVICE_TYPE (_DEV_INNOVATION_ONLY) //集装箱定制版本类型

//修改记录：
//#define uuzSOFTWAVE_VERSION_UPDATE (1000)
//2021-11-09：(V1.000)在集装箱版本上调整最终版本
//#define uuzSOFTWAVE_VERSION_UPDATE (1001)
//2021-11-09：(V1.001)增加高度单位设置inch/cm
//#define uuzSOFTWAVE_VERSION_UPDATE (1002)
//2021-11-10：(V1.002)修改实时数据、水位配置数据单位显示和保存处理
//#define uuzSOFTWAVE_VERSION_UPDATE (1003)
//2021-11-11：(V1.003)修改蠕动泵最大数量的设置和调试界面的相关调整
//#define uuzSOFTWAVE_VERSION_UPDATE (1004)
//2021-11-14：(V1.004)添加密码输入界面相关逻辑
//#define uuzSOFTWAVE_VERSION_UPDATE (1005)
//2021-11-15：(V1.005)添加密码修改界面相关逻辑
//#define uuzSOFTWAVE_VERSION_UPDATE (1006)
//2021-12-08：(V1.006)去掉灌溉项目选择界面
//            (V1.006)去掉回水的项目选择界面
//#define uuzSOFTWAVE_VERSION_UPDATE (1007)
//2021-12-13：(V1.007)修改设置蠕动泵数量BUG
//            (V1.007)跟新灯光|定时器的相关逻辑优化BUG
//            (V1.007)修改系统设置界面的数据保存
//            (V1.007)修改回水数据保存
//            (V1.007)修改背光问题
//            (V1.007)修改自动熄屏问题
//#define uuzSOFTWAVE_VERSION_UPDATE (1008)
//2021-12-14：(V1.008)修改设置蠕动泵自动运行的问题
//#define uuzSOFTWAVE_VERSION_UPDATE (1009)
//2021-12-15：(V1.009)主界面的暂停按键更新-1
//            (V1.009)修改灯光和定时界面下数据读取-2
//#define uuzSOFTWAVE_VERSION_UPDATE (1010)
//2021-12-16：(V1.010)配肥相关的切换及对应动作
//            (V1.010)增加了EC过高，pH过高/过低，温度过高的相关报警提示
//#define uuzSOFTWAVE_VERSION_UPDATE (1011)
//2021-12-16：(V1.011)修改报警机制、修改端口执行机制
//            (V1.011)修改蠕动泵的执行逻辑
//            (V1.011)修改周期表的添加删除处理
//#define uuzSOFTWAVE_VERSION_UPDATE (1012)
//2021-12-17：(V1.012)端口执行接收处执行标记错误
//            (V1.012)修改端口执行处符号判断错误
//            (V1.012)修改定时出执行符号错误
//            (V1.012)修改报警线程的状态处理
//#define uuzSOFTWAVE_VERSION_UPDATE (1013)
//2021-12-21：(V1.013)修改周期表保存逻辑
//            (V1.013)修改专用版本的代码宏过滤
//#define uuzSOFTWAVE_VERSION_UPDATE (1014)
//2021-12-22：(V1.014)调整根据定制软件版本界面
//            (V1.014)增加水位得目标设置
//#define uuzSOFTWAVE_VERSION_UPDATE (1015)
//2021-12-23：(V1.015)修改水位得通用逻辑
//#define uuzSOFTWAVE_VERSION_UPDATE (1016)
//2021-12-27：(V1.016)修改读取相关逻辑
//#define uuzSOFTWAVE_VERSION_UPDATE (1017)
//2021-12-28：(V1.017)修改华氏度数据判断相关内容
//#define uuzSOFTWAVE_VERSION_UPDATE (1018)
//2021-12-29：(V1.018)修改AUX界面的操作
//            (V1.018)修改回水模式切换内容
#define uuzSOFTWAVE_VERSION_UPDATE (1019)
//2021-12-30：(V1.019)修改回水执行端口内容
//            (V1.019)修改端口执行动作

#define uuzSOFTWAVE_VERSION (uuzSOFTWAVE_VERSION_UPDATE)

#endif /* _UUZ_HISTORY_H_ */
