/*
 * @Copyright (c) 2006-2018 RT-Thread Development Team:  
 * @SPDX-License-Identifier: Apache-2.0:  
 * @Date: 2020-01-01 09:23:03
 * @LastEditors  : Zhou Xiaomin
 * @LastEditTime : 2020-01-17 01:39:48
 * @Note:  
 */
/*include***********************************************************************/
#include <rtthread.h>
#include <string.h>
/******************************************************************************/
#include "uuzOpt.h"
#include "uuzEVENT.h"
#include "uuzINIT.h"
/******************************************************************************/
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
/******************************************************************************/
#include "uuzConfigDEV.h"
#include "uuzDevID.h"
#include "uuzEventDevID.h"
/******************************************************************************/
#include "uuzEventSR.h"
#include "uuzEventPHEC.h"
#include "uuzEventP260.h"
#include "uuzEventDOSING.h"
#include "uuzEventVALVE.h"
/*log----------------------------------------------------------*/
#define DBG_TAG "e.sensor"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/******************************************************************************/
/**
 * @brief:  初始化传感器数据读取函数，每500ms一个循环
 * @returns:  int
 */
int sensor_read_init(void)
{
    rt_err_t ret = RT_EOK;
    /* 创建 serial 线程 */
    rt_thread_t thread = rt_thread_create("tsr_rd", sensor_rd_thread_entry,
    RT_NULL, 2048, (RT_THREAD_PRIORITY_MAX * 2 / 3 - 2), 20);

    /* 创建成功则启动线程 */
    if (thread != RT_NULL) {
        rt_thread_startup(thread);
        LOG_I("start Thread [sensor read]");
    } else {
        LOG_E("start Thread [sensor read] failed");
        ret = RT_ERROR;
    }

    return ret;
}

/**
 * @brief 设备读取传感器数据和设备状态函数
 * 
 * @param parameter 
 */
void sensor_rd_thread_entry(void* parameter)
{
    static u32 countSync = 0;
    //初始化设备状态
    device_id_update(0);

    while (1) {
        //UI初始化状态
        if (xSysSTA.hmi_init >= 5) {
            if (xSysSTA.is_init_data == 0) {

                //传感器数据
                if (countSync % 5 == 0) {
                    //检查设备的相关状态,间隔500秒检查一个数据
                    if (xDevSTA.usCountU7 == 0) {
                        //获取传感器命令数量
                        //计数器清零,重置命令
                        sensor_cmd_set();
                    } else {
                        //Read Sensor Data --> Sensor
                        cmd_read(uuzUART_7);
                    }
                }

                //电源板数据
                if (countSync % 3 == 0) {
                    //检查设备的相关状态,间隔500秒检查一个数据
                    if (xDevSTA.usCountU3 == 0) {
                        //获取传感器命令数量
                        //计数器清零,重置命令
                        board_cmd_set();
                    } else {
                        //Read Board Data --> Board
                        cmd_read(uuzUART_3);
                    }
                }

                //蠕动泵数据数据
                //检查设备的相关状态,间隔300秒检查一个数据
                if (xDevSTA.usCountU2 == 0) {
                    //获取传感器命令数量
                    //计数器清零,重置命令
                    if (countSync % 40 == 0) {  //每4.0秒添加一个数据
                        dosing_cmd_set();
                    }
                } else {
                    //Read Dosing Data --> Dosing
                    if (countSync % 2 == 0) {
                        cmd_read(uuzUART_2);
                    }
                }

                //判断设备的连接状态，是否需要重新发送连接数据
                device_state_isconnected();
                countSync++;
            }
        }
        //每个循环100ms
        rt_thread_delay(100);
    }
}

/**
 * @brief 设备状态读取函数
 * 
 */
void device_state_isconnected(void)
{
    u8 index = 0;
    //NOTE:如果计数第一次到达连接错误 uuzDEV_CONNECT_ERR
    //NOTE:如果设备已经 uuzDEV_CONNECT_ERR * uuzDEV_REG_ERR没有收到回复，重新注册数据

    if (xDevSTA.usCountB2) {
        //PHEC-B2模块连接状态
        for (index = 0; index < uuzDEV_PHEC_B2_MAX; index++) {
            if (xDevSTA.xB2[index].en == uuzDEV_REG_OK) {
                if (device_isconnected(&xDevSTA.xB2[index]) == RT_TRUE) {
                    rt_event_send(eventDATA, UI_DATA_SYNC);
                    //LOG_D("B2-ISCONNECTed");
                }
            }
        }
    }

    if (xDevSTA.usCountP260) {
        //SIN-P260模块连接状态
        for (index = 0; index < uuzDEV_SIN_P260_MAX; index++) {
            if (xDevSTA.xP260[index].en == uuzDEV_REG_OK) {
                if (device_isconnected(&xDevSTA.xP260[index]) == RT_TRUE) {
                    rt_event_send(eventDATA, UI_DATA_SYNC);
                    //LOG_D("P260-ISCONNECTed");
                }
            }
        }
    }

    if (xDevSTA.usCountBrd) {
        //Power Broad模块连接状态
        for (index = 0; index < uuzDEV_BRD_MAX; index++) {
            if (xDevSTA.xBrd[index].en == uuzDEV_REG_OK) {
                if (device_isconnected(&xDevSTA.xBrd[index]) == RT_TRUE) {
                    rt_event_send(eventDATA, UI_DATA_SYNC);
                    //LOG_D("BRD-ISCONNECTed");
                }
            }
        }
    }

    if (xDevSTA.usCountDos) {
        //蠕动泵(Dosing)模块连接状态
        for (index = 0; index < xSysCFG.dosing_num; index++) {  //使用设置蠕动泵数量
            if (xDevSTA.xDos[index].en == uuzDEV_REG_OK) {
                if (device_isconnected(&xDevSTA.xDos[index]) == RT_TRUE) {
                    rt_event_send(eventDATA, UI_DATA_SYNC);
                    //LOG_D("DOS-ISCONNECTed");
                }
            }
        }
    }
}

/**
 * @brief 单个设备连接状态
 * 
 * @param xDev 
 * @return 回复需要切换的状态位RT_TRUE/无需要使用RT_FALSE
 */
u8 device_isconnected(DevID_Typedef_t * xDev)
{
    u8 retVal = RT_FALSE;
    //NOTE:如果计数第一次到达连接错误 uuzDEV_CONNECT_ERR，向HMI发送状态转换
    //NOTE:如果设备已经 uuzDEV_CONNECT_ERR * uuzDEV_REG_ERR没有收到回复，重新注册数据
    if (xDev != NULL) {
        if (xDev->en == uuzDEV_REG_OK) {
            if (xDev->count == uuzDEV_CONNECT_ERR) {
                if (xDev->isconnect == uuzDEV_CONNECTED) {    //切换设备状态
                    xDev->isconnect = uuzDEV_NOCONNECT;
                    retVal = RT_TRUE;
                }
            } else if (xDev->count == uuzDEV_CONNECT_OK) {
                if (xDev->isconnect == uuzDEV_NOCONNECT) {    //切换设备状态
                    xDev->isconnect = uuzDEV_CONNECTED;
                    xDev->reg_en = uuzDEV_CONNECT_OK;
                    retVal = RT_TRUE;
                }
            }
        }
    }

    if (retVal) {   //输出日志
        if (xDev->reg_en == uuzDEV_NOCONNECT) {
            LOG_E("Device[%d] is noconnected", xDev->map);
        }
    }

    return retVal;
}

/**
 * @brief 加载CMD数据到待发送区
 * 
 * @param ucUart 
 * @param ucData 
 * @param ucLen 
 */
void cmd_set(u8 ucUart, u8* ucData, u8 ucLen)
{
    int index;
    DevCmd_Typedef_t * xDevCmd = NULL;

#if 0
    //判断数据表
    if (ucUart == uuzUART_7) {
        xDevCmd = &xDevSTA.xDevCmd_U7[0];
    } else if (ucUart == uuzUART_8) {
        xDevCmd = &xDevSTA.xDevCmd_U8[0];
    } else if (ucUart == uuzUART_2) {
        xDevCmd = &xDevSTA.xDevCmd_U2[0];
    } else if (ucUart == uuzUART_3) {
        xDevCmd = &xDevSTA.xDevCmd_U3[0];
    }

    for (index = 0; index < uuzDEVICE_CMD_MAX; index++) {
        if (xDevCmd->ucEnable == uuzDEV_UNREG) {
            xDevCmd->ucUart = ucUart;
            rt_memcpy(xDevCmd->ucData, ucData, ucLen);
            xDevCmd->ucLen = ucLen;
            xDevCmd->ucEnable = uuzDEV_REG_OK;
            break;
        }
        xDevCmd++;
    }
#else
    //判断数据表
    if (ucUart == uuzUART_7) {
        xDevCmd = &xDevSTA.xDevCmd_U7[0];
    } else if (ucUart == uuzUART_8) {
        xDevCmd = &xDevSTA.xDevCmd_U8[0];
    } else if (ucUart == uuzUART_2) {
        xDevCmd = &xDevSTA.xDevCmd_U2[0];
    } else if (ucUart == uuzUART_3) {
        xDevCmd = &xDevSTA.xDevCmd_U3[0];
    }

    u8 devCount = 0;
    u8 prevIndex = 0;

    //获取最后的数据
    for (index = 0; index < uuzDEVICE_CMD_MAX; index++) {
        if (xDevCmd->ucEnable == uuzDEV_REG_OK) {
            prevIndex = index + 1;
            devCount++;
        }
        xDevCmd++;
    }

    //判断数据表
    if (ucUart == uuzUART_7) {
        xDevCmd = &xDevSTA.xDevCmd_U7[0];
    } else if (ucUart == uuzUART_8) {
        xDevCmd = &xDevSTA.xDevCmd_U8[0];
    } else if (ucUart == uuzUART_2) {
        xDevCmd = &xDevSTA.xDevCmd_U2[0];
    } else if (ucUart == uuzUART_3) {
        xDevCmd = &xDevSTA.xDevCmd_U3[0];
    }

    if (devCount) {   //如果待发送数据
        for (index = 0; index < uuzDEVICE_CMD_MAX; index++) {
            if (index == prevIndex) {
                if (xDevCmd->ucEnable == uuzDEV_UNREG) {
                    xDevCmd->ucUart = ucUart;
                    rt_memcpy(xDevCmd->ucData, ucData, ucLen);
                    xDevCmd->ucLen = ucLen;
                    xDevCmd->ucEnable = uuzDEV_REG_OK;
                    break;
                }
            }
            xDevCmd++;
        }
    } else {
        if (xDevCmd->ucEnable == uuzDEV_UNREG) {
            xDevCmd->ucUart = ucUart;
            rt_memcpy(xDevCmd->ucData, ucData, ucLen);
            xDevCmd->ucLen = ucLen;
            xDevCmd->ucEnable = uuzDEV_REG_OK;
        }
    }
#endif
}

/**
 * @brief 读取数据，并是生成命令表
 */
void sensor_cmd_set(void)
{
    int index = 0;
    u8 ucCountCMD = 0;

    //如果有设备数据
    //如果有PHEC-B2模块
    if (xDevSTA.usCountB2) {
        for (index = 0; index < uuzDEV_PHEC_B2_MAX; index++) {
            //如果是已经注册的设备
            if (xDevSTA.xB2[index].en == uuzDEV_REG_OK) {
                //关于PHEC-B2数据的相关处理
                phec_value_read(index);
            }
        }
    }

    //如果有SIN-P260模块
    if (xDevSTA.usCountP260) {
        for (index = 0; index < uuzDEV_SIN_P260_MAX; index++) {
            //如果是已经注册的设备
            if (xDevSTA.xP260[index].en == uuzDEV_REG_OK) {
                //读取传感器相关信息，计算连接状态
                sinp260_value_read(index);
            }
        }
    }

    //设备命令统计
    for (index = 0; index < uuzDEVICE_CMD_MAX; index++) {
        if (xDevSTA.xDevCmd_U7[index].ucEnable == uuzDEV_REG_OK) {
            ucCountCMD++;
        }
    }

    xDevSTA.usCountU7 = ucCountCMD;
}

/**
 * @brief 读取设备数据，并是生成命令表
 */
void board_cmd_set(void)
{
    int index = 0;
    u8 ucCountCMD = 0;

    //如果有Power Broad模块
    if (xDevSTA.usCountBrd) {
        for (index = 0; index < uuzDEV_BRD_MAX; index++) {
            //如果是已经注册的设备
            if (xDevSTA.xBrd[index].en == uuzDEV_REG_OK) {
                //LOG_D("Read Valve[%d] Info!", index);
                //读取电源板相关信息，计算连接状态
                valve_broad_read(index);
            }
        }
    }

    //设备命令统计
    for (index = 0; index < uuzDEVICE_CMD_MAX; index++) {
        if (xDevSTA.xDevCmd_U3[index].ucEnable == uuzDEV_REG_OK) {
            ucCountCMD++;
        }
    }

    xDevSTA.usCountU3 = ucCountCMD;
}

/**
 * @brief 读取蠕动泵数据，并是生成命令表
 */
void dosing_cmd_set(void)
{
    int index = 0;
    u8 ucCountCMD = 0;

    //如果有Dosing模块
    LOG_D("Count Dos[%d]", xDevSTA.usCountDos);
    if (xDevSTA.usCountDos) {
        for (index = 0; index < xSysCFG.dosing_num; index++) {  //使用当前蠕动泵数量
            LOG_D("[%d]Count EN[%d]", index, xDevSTA.xDos[index].en);
            if (xDevSTA.xDos[index].en == uuzDEV_REG_OK) {  //如果是已经注册的设备
                //读取电源板相关信息，计算连接状态
                dosing_state_read(index);
            }
        }
    }
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
    ac_valve_read();
#endif

    //设备命令统计
    for (index = 0; index < uuzDEVICE_CMD_MAX; index++) {
        if (xDevSTA.xDevCmd_U2[index].ucEnable == uuzDEV_REG_OK) {
            ucCountCMD++;
        }
    }

    xDevSTA.usCountU2 = ucCountCMD;
}

/**
 * @brief	Determine whether the sensor state is not connected based on the data.
 * @note 检测当前存在的传感器/设备数据
 * 
 */
void cmd_read(u8 uart)
{
    int index = 0;
    u8 ucCountCMD = 0;
    DevCmd_Typedef_t * xDevCmd = NULL;
    u16 usCountMAX = 0;

    //根据串口取数据
    if (uart == uuzUART_7) {
        xDevCmd = &xDevSTA.xDevCmd_U7[0];
        usCountMAX = xDevSTA.usCountU7;
    } else if (uart == uuzUART_8) {
        xDevCmd = &xDevSTA.xDevCmd_U8[0];
        usCountMAX = xDevSTA.usCountU8;
    } else if (uart == uuzUART_2) {
        xDevCmd = &xDevSTA.xDevCmd_U2[0];
        usCountMAX = xDevSTA.usCountU2;
    } else if (uart == uuzUART_3) {
        xDevCmd = &xDevSTA.xDevCmd_U3[0];
        usCountMAX = xDevSTA.usCountU3;
    }

    //如果有待设置命令,添加数据到发送区
    if (usCountMAX) {
        for (index = 0; index < uuzDEVICE_CMD_MAX; index++) {
            //如果是已经注册的设备
            if (xDevCmd->ucEnable == uuzDEV_REG_OK) {
                uuz_vDevCommandSend(xDevCmd->ucUart, xDevCmd->ucData, xDevCmd->ucLen);
                xDevCmd->ucEnable = uuzDEV_UNREG;
                LOG_D("CMD:I-%02d:U-%02X:D-%02X:L-%d", index, xDevCmd->ucUart,
                        xDevCmd->ucData[0],
                        xDevCmd->ucLen);
                break;
            }
            xDevCmd++;
        }
    }

    //设备命令统计
    for (index = 0; index < uuzDEVICE_CMD_MAX; index++) {
        if (xDevCmd->ucEnable == uuzDEV_REG_OK) {
            ucCountCMD++;
        }
        xDevCmd++;
    }

    //计算命令数量并赋值
    if (uart == uuzUART_7) {
        xDevSTA.usCountU7 = ucCountCMD;
    } else if (uart == uuzUART_8) {
        xDevSTA.usCountU8 = ucCountCMD;
    } else if (uart == uuzUART_2) {
        xDevSTA.usCountU2 = ucCountCMD;
    } else if (uart == uuzUART_3) {
        xDevSTA.usCountU3 = ucCountCMD;
    }
}
