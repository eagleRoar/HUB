/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-01   ZhouXiaomin     first version
 */
/* Includes ------------------------------------------------------------------*/
#include <board.h>
/* ----------------------------------------------------------------*/
#include "uuzCalendar.h"
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
#include "uuzConfigPORT.h"
/* ----------------------------------------------------------------*/
#include "uuzEventHMI.h"
#include "uuzEventPHEC.h"
#include "uuzEventBRD.h"
#include "uuzEventSCH.h"
#include "uuzEventLGT.h"
#include "uuzEventWLS.h"
#include "uuzEventCFG.h"
#include "uuzEventVALVE.h"
#include "uuzEventDOSING.h"
#include "uuzHMI_UI.h"
#include "uuzEventTIM.h"
#include "typedefWLS.h"
/* ----------------------------------------------------------------*/
#include "uuzTEMP.h"
#include "uuzEVENT.h"
#include "uuzEEPROM.h"
#include "uuzOpt.h"
#include "uuzRTC.h"
/*log---------------------------------------------*/
#define DBG_TAG "hmi.cfg"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/* ----------------------------------------------------------------*/
/**
 * @brief 程序设置界面相关信息同步
 */
void hmi_prog_config_sync(void)
{
    hmi_sys_send("d102", xSysCFG.running_mode);  //如果是静态配肥模式，选择程序编号
    hmi_sys_send("d100", xSysCFG.fixed_id);   //配肥程序选择（程序模式）
    hmi_sys_send("d103", xSysCFG.single_mode);   //如果是独立模式，选择配肥类型
    hmi_sys_send("d104", xSysCFG.running_mode);   //如果是静态配肥模式，选择程序编号
    hmi_sys_send("d105", xSysCFG.dynamic_id);   //如果是动态配肥模式，选择程序编号
}

/**
 * @brief 对单个程序定量同步配置信息
 */
void hmi_fixed_single_config_sync(Fixed_Single_Typedef_t * fixed)
{
    char cmd[10];

    //向屏幕发送当前Fixed的配置数据
    hmi_sys_send("d194", fixed->volume);  //桶大小
    hmi_sys_send("d195", fixed->uint);  //桶单位
    //蠕动泵相关配置
    for (u8 index = 0; index < uuzDEV_DOS_MAX; index++) {
        rt_sprintf(cmd, "d%03d", (131 + index * 3));
        hmi_sys_send(cmd, fixed->en[index]);    //蠕动泵有效性
        rt_sprintf(cmd, "d%03d", (132 + index * 3));
        hmi_sys_send(cmd, fixed->dos[index]);   //蠕动泵参数
        if ((fixed->dos[index] > 0) && (fixed->volume > 0)) {
            if (fixed->uint == 0) {  //如果是数据L单位
                fixed->t[index] = (fixed->volume * fixed->dos[index]) / xDosCFG->speed;   //计算工作时间
            } else {    //如果是加仑单位
                fixed->t[index] = (fixed->volume * fixed->dos[index]) / xDosCFG->speed;   //计算工作时间
            }
        } else {
            fixed->t[index] = 0;   //无效时间
        }
        rt_sprintf(cmd, "d%03d", (133 + index * 3));
        hmi_sys_send(cmd, fixed->t[index]);  //工作时间
    }
}

/**
 * @brief 对单个程序动态同步配置信息
 */
void hmi_prog_single_config_sync(Dynamic_Single_Typedef_t* dynamic)
{
    char cmd[16];
    //向屏幕发送当前PROG的配置数据
    if (dynamic != RT_NULL) {
        //EC配置
        hmi_sys_send("d110", dynamic->cfg.ec_t);
        hmi_sys_send("d111", dynamic->cfg.ec_d);
        hmi_sys_send("d112", dynamic->cfg.ec_h);
        hmi_sys_send("d113", dynamic->cfg.ec_l);
        hmi_sys_send("d114", dynamic->cfg.ec_en);
        //pH配置
        hmi_sys_send("d120", dynamic->cfg.pH_t);
        hmi_sys_send("d121", dynamic->cfg.pH_d);
        hmi_sys_send("d122", dynamic->cfg.pH_h);
        hmi_sys_send("d123", dynamic->cfg.pH_l);
        hmi_sys_send("d124", dynamic->cfg.pH_en);
        //水温配置
        u16 ta_h = dynamic->cfg.ta_h;
        if (xSysCFG.unit_ta == uuzTA_F) {   //如果是华氏度，需要转换后处理
            ta_h = uuz_usTemp2Int_ConvCplt(uuz_usTempC2F_ConvCplt(ta_h));
        }
        hmi_sys_send("d115", ta_h);
        hmi_sys_send("d116", dynamic->cfg.ta_en);

        //蠕动泵相关配置
        for (u8 index = 0; index < xSysCFG.dosing_num; index++) {
            rt_sprintf(cmd, "d%03d", (131 + index * 3));
            hmi_sys_send(cmd, dynamic->dos[index].en);
            rt_sprintf(cmd, "d%03d", (132 + index * 3));
            hmi_sys_send(cmd, dynamic->dos[index].ratio);
            rt_sprintf(cmd, "d%03d", (133 + index * 3));
            hmi_sys_send(cmd, dynamic->dos[index].type);
        }
    }
}

/**
 * @brief 程序设置界面相关信息同步
 */
void hmi_dosing_config_sync(void)
{
    //蠕动泵统一配置
    hmi_sys_send("d190", xDosCFG->running);  //运行时间
    hmi_sys_send("d191", xDosCFG->waiting);  //停止时间
    hmi_sys_send("d192", xDosCFG->speed);   //速度
    hmi_sys_send("d193", xDosCFG->mode);    //模式

    hmi_reset_dosing_time();    //上一次的蠕动泵重置事件同步时间
}

#if 0
/**
 * @brief 对单个程序同步配置信息
 */
void hmi_prog_current_config_sync(PROG_Single_Typedef_t* prog)
{
    char cmd[10];

    //向屏幕发送当前PROG的配置数据
    //EC配置
    hmi_sys_send("d110", prog->xPhec.ec_t);
    hmi_sys_send("d111", prog->xPhec.ec_d);
    hmi_sys_send("d112", prog->xPhec.ec_h);
    hmi_sys_send("d113", prog->xPhec.ec_l);
    hmi_sys_send("d114", prog->xPhec.ec_en);
    //pH配置
    hmi_sys_send("d120", prog->xPhec.pH_t);
    hmi_sys_send("d121", prog->xPhec.pH_d);
    hmi_sys_send("d122", prog->xPhec.pH_h);
    hmi_sys_send("d123", prog->xPhec.pH_l);
    hmi_sys_send("d124", prog->xPhec.pH_en);
    //温度配置
    hmi_sys_send("d115", prog->xPhec.ta_h);
    hmi_sys_send("d116", prog->xPhec.ta_en);

    //蠕动泵相关配置
    for (u8 index = 0; index < _DOSING_NUM; index++) {
        rt_sprintf(cmd, "d%03d", (131 + index * 3));
        hmi_sys_send(cmd, prog->xDosing[index].en);
        rt_sprintf(cmd, "d%03d", (132 + index * 3));
        hmi_sys_send(cmd, prog->xDosing[index].ratio);
        rt_sprintf(cmd, "d%03d", (133 + index * 3));
        hmi_sys_send(cmd, prog->xDosing[index].type);
    }

    //蠕动泵统一配置
    hmi_sys_send("d190", prog->xDosingConfig.running);
    hmi_sys_send("d191", prog->xDosingConfig.waiting);
    hmi_sys_send("d192", prog->xDosingConfig.speed);
    hmi_sys_send("d193", prog->xDosingConfig.mode);
}
#endif

/**
 * @brief 加载设备配置列表数据
 */
void hmi_device_list_sync(void)
{
    char cmd[24];

    LOG_D("LGT[%d]--TIM1[%d]--TIM2[%d]",
            xLgtPro.cfg[0]->en,
            xTimPro.cfg[0]->en,
            xTimPro.cfg[1]->en);
    //Light
    if (xLgtPro.cfg[0]->en == 1) {
        rt_sprintf(cmd, "c%02d", 20);
        hmi_sys_send(cmd, xLgtPro.cfg[0]->en);   //数据使能(0-Disable|1-Enable)
        rt_sprintf(cmd, "c%02d", 21);
        hmi_sys_send(cmd, uuzPORT_LIGHT);   //配置类型
        rt_sprintf(cmd, "c%02d", 22);
        hmi_sys_send(cmd, 4);   //端口位置
        rt_sprintf(cmd, "c%02d", 24);
        hmi_sys_send(cmd, xLgtPro.cfg[0]->md);  //端口内数据模式类型
        rt_sprintf(cmd, "c%02d", 25);
        hmi_sys_send(cmd, valve_single_state_get(3));   //端口状态(0-OFF|1-ON)
    }
    //Timer-1
    if (xTimPro.cfg[0]->en == 1) {
        rt_sprintf(cmd, "c%02d", 30);
        hmi_sys_send(cmd, xTimPro.cfg[0]->en);   //数据使能(0-Disable|1-Enable)
        rt_sprintf(cmd, "c%02d", 31);
        hmi_sys_send(cmd, uuzPORT_TIMER);   //配置类型
        rt_sprintf(cmd, "c%02d", 32);
        hmi_sys_send(cmd, 5);   //端口位置
        rt_sprintf(cmd, "c%02d", 34);
        hmi_sys_send(cmd, xTimPro.cfg[0]->md);  //端口内数据模式类型
        rt_sprintf(cmd, "c%02d", 35);
        hmi_sys_send(cmd, valve_single_state_get(4));   //端口状态(0-OFF|1-ON)
    }
    //Timer-2
    if (xTimPro.cfg[0]->en == 1) {
        rt_sprintf(cmd, "c%02d", 40);
        hmi_sys_send(cmd, xTimPro.cfg[1]->en);   //数据使能(0-Disable|1-Enable)
        rt_sprintf(cmd, "c%02d", 41);
        hmi_sys_send(cmd, uuzPORT_TIMER);   //配置类型
        rt_sprintf(cmd, "c%02d", 42);
        hmi_sys_send(cmd, 6);   //端口位置
        rt_sprintf(cmd, "c%02d", 44);
        hmi_sys_send(cmd, xTimPro.cfg[1]->md);  //端口内数据模式类型
        rt_sprintf(cmd, "c%02d", 45);
        hmi_sys_send(cmd, valve_single_state_get(5));   //端口状态(0-OFF|1-ON)
    }
}

#if 0
/**
 * @brief 加载灯光列表数据
 */
void hmi_light_list_sync(u16 page)
{
    char cmd[24];
    u8 index = 0;
    u8 count = 0;
    u8 currentPage = 0;

#if 0
    u8 min = 0;
    u8 max = 0;
    currentPage = ucPageGet(6, xDevSTA.usCountLGT);   //查看读取的页码数据是否OK
    min = page * 6;
    max = (page + 1) * 6;
#else
    currentPage = 1;
#endif

    hmi_sys_send("k00", xDevSTA.usCountLGT);   //发送端口数量和页码数量
    hmi_sys_send("k01", currentPage);

    for (index = 0, count = 0; index < _IO_PRO_MAX; index++) {
        if (xLgtPro.cfg[index]->en == 1) {  //如果有相关数据
            rt_sprintf(cmd, "c%02d", (count * 10 + 20));
            hmi_sys_send(cmd, xLgtPro.cfg[index]->en);   //数据使能(0-Disable|1-Enable)
            rt_sprintf(cmd, "c%02d", (count * 10 + 21));
            hmi_sys_send(cmd, xDevSTA.xLGT[count].t);   //设备类型(Board|AC Station|IO Station)
            rt_sprintf(cmd, "c%02d", (count * 10 + 22));
            hmi_sys_send(cmd, xDevSTA.xLGT[count].io + 1);   //端口位置(0-5)
            rt_sprintf(cmd, "c%02d", (count * 10 + 23));
            hmi_sys_send(cmd, xDevSTA.xLGT[count].id);   //端口ID(defualt:2)
            rt_sprintf(cmd, "c%02d", (count * 10 + 24));
            hmi_sys_send(cmd, xLgtPro.cfg[index]->md);  //端口内数据模式类型
            rt_sprintf(cmd, "c%02d", (count * 10 + 25));
            hmi_sys_send(cmd, 0);   //端口状态(0-OFF|1-ON)
            count++;
        }
    }

    for (index = count; index < 6; index++) {
        rt_sprintf(cmd, "c%02d", (index * 10 + 20));            //是一个无效数据
        hmi_sys_send(cmd, 0);
    }
}
#endif

/**
 * @brief 加载灯光配置
 * @param port:端口数据
 */
void hmi_light_config_sync(u16 port)
{
    char cmd[20];

    if (xLgtPro.cfg[port] != RT_NULL) {
        //Light Mode
        hmi_sys_send("d501", xLgtPro.cfg[port]->md);
        //Manual Mode
        hmi_sys_send("d502", xLgtPro.cfg[port]->sta);
        //Cycle Mode
        hmi_sys_send("d503", xLgtPro.cfg[port]->t_cycle[0].on);
        hmi_sys_send("d504", xLgtPro.cfg[port]->t_cycle[0].off);
        hmi_sys_send("d505", xLgtPro.cfg[port]->t_cycle[1].on);
        hmi_sys_send("d506", xLgtPro.cfg[port]->t_cycle[1].off);
        //Timer Mode
        for (int index = 0; index < 5; index++) {
            rt_sprintf(cmd, "d%03d", (index * 3 + 507));
            hmi_sys_send(cmd, xLgtPro.cfg[port]->t_timer[index].en);
            rt_sprintf(cmd, "d%03d", (index * 3 + 508));
            hmi_sys_send(cmd, xLgtPro.cfg[port]->t_timer[index].on);
            rt_sprintf(cmd, "d%03d", (index * 3 + 509));
            hmi_sys_send(cmd, xLgtPro.cfg[port]->t_timer[index].off);
        }

    }
}

/**
 * @brief 加载灯光配置
 * @param port:端口数据
 */
void hmi_timer_config_sync(u16 port)
{
    char cmd[20];

    if (xTimPro.cfg[port] != RT_NULL) {
        //Timer Mode
        hmi_sys_send("d501", xTimPro.cfg[port]->md);
        //Manual Mode
        hmi_sys_send("d502", xTimPro.cfg[port]->sta);
        //Cycle Mode
        hmi_sys_send("d503", xTimPro.cfg[port]->t_cycle.on);
        hmi_sys_send("d504", xTimPro.cfg[port]->t_cycle.off);
        //Timer Mode
        for (int index = 0; index < 5; index++) {
            rt_sprintf(cmd, "d%03d", (index * 3 + 507));
            hmi_sys_send(cmd, xTimPro.cfg[port]->t_timer[index].en);
            rt_sprintf(cmd, "d%03d", (index * 3 + 508));
            hmi_sys_send(cmd, xTimPro.cfg[port]->t_timer[index].on);
            rt_sprintf(cmd, "d%03d", (index * 3 + 509));
            hmi_sys_send(cmd, xTimPro.cfg[port]->t_timer[index].off);
        }
    }
}

/**
 * @brief 显示单个设备数据的列表信息
 * @param index：需要显示的设备编号
 */
void hmi_aux_list_sync(u8 index)
{
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
    hmi_aux_ui_sync(index);   //处理页面左右箭头标记
    hmi_board_state_sync(index, 0);
#else
    hmi_aux_ui_sync(index);   //处理页面左右箭头标记
    if (index == 0) {   //0显示第一个设备信息
        hmi_board_state_sync(index, 0);
    } else {    //显示主板之外的数据

    }
#endif
}

/**
 * @brief AUX界面当前设备数据
 * @param targetIndex:当前要显示的目标设备
 */
void hmi_aux_ui_sync(u8 targetIndex)
{
    char page[10];

    if (xDevSTA.usCountAUX) {   //如果有Board+AUX数据
        hmi_page_is_assert(page, uuzHMI_UI_AUX1);   //获取对应的页面数据
        if (targetIndex == 0) {  //隐藏左箭头,显示右箭头
            hmi_txt_send(page, "left", "");  //隐藏<<
        } else {
            hmi_txt_send(page, "left", "<<");  //<<
        }
        if (targetIndex == (xDevSTA.usCountAUX - 1)) {
            hmi_txt_send(page, "right", "");  //隐藏>>
        } else {
            hmi_txt_send(page, "right", ">>");  //显示>>
        }
    }
}

/**
 * @brief 加载电源板的端口列表相关数据
 * @param targetIndex:当前要显示的目标设备
 * @param targetPage:当前要显示的目标设备编号（0 - N）
 */
void hmi_board_state_sync(u8 targetIndex, u8 targetPage)
{
    char cmd[16];
    char page[10];

#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
    hmi_page_is_assert(page, uuzHMI_UI_AUX1);   //获取对应的页面数据
    rt_sprintf(cmd, "BOARD");    //设备类型BOARD ID
    hmi_txt_send(page, "devinfo", cmd);    //发送设备名字
    valve_info_sync(0, uuzDEV_BRD_VALVE_MAX, &xBoardCFG->valve[0]);  //刷新VALVE信息数据
    //显示AC-Station的模块状态
#else

    u8 valveIndex = 0;
    u8 maxPage = 0;
    u8 maxDev = 0;
    u8 data_state = 0;

    xSysSTA.dev = device_id_list_check(0, targetIndex);  //获取当前的设备数据地址

    if (xSysSTA.dev != RT_NULL) {   //有相关数据队列
        if (xSysSTA.dev->en == uuzDEV_REG_OK) {    //相应的硬件设备
            if (xSysSTA.dev->type == uuzDEV_SL_BRD) {   //如果是输出电源板,显示相关数据
                LOG_D("ID:%d--TYPE:%d", xSysSTA.dev->id, xSysSTA.dev->type);
                //------------------------------------>
                hmi_sys_send("auxID", xSysSTA.dev->id);   //页面编码属性
                hmi_sys_send("auxType", xSysSTA.dev->type);   //页面类型属性
                maxDev = uuzDEV_BRD_VALVE_MAX;   //电源板类型的端口最大数量
                maxPage = ucPageGet(6, maxDev);    //查看读取端口的页面数据是否OK
                hmi_sys_send("g02", maxPage);   //页面编码属性
                hmi_page_is_assert(page, uuzHMI_UI_AUX1);   //获取对应的页面数据
                //rt_sprintf(cmd, "Board [ID:%d]", xSysSTA.dev->id);    //设备类型BOARD ID
                rt_sprintf(cmd, "BOARD");    //设备类型BOARD ID
                hmi_txt_send(page, "devinfo", cmd);    //发送设备名字
                if (targetPage <= maxPage) {
                    xSysSTA.currPage = targetPage;
                    valve_info_sync(targetPage, maxDev, &xBoardCFG->valve[0]);  //刷新VALVE信息数据
                }
            }
            data_state = 1;
        }

        if (!data_state) {  //没有有效数据
            hmi_txt_send(page, "devinfo", "");  //发送空设备名字
            for (valveIndex = 0; valveIndex < 6; valveIndex++) {
                rt_sprintf(cmd, "g%02d", ((valveIndex % 6) * 10 + 20));  //发送一个无效数据
                hmi_sys_send(cmd, 0);
            }
        }
    }
#endif
}

/**
 * @brief 水位补水配置相关数据
 */
void hmi_wls_list_sync(void)
{
    char cmd[24];
    u8 index = 0;

    if (xWlsPro != RT_NULL) {   //有相关数据
        hmi_sys_send("k00", 2);   //发送传感器数量和页码数量
        hmi_sys_send("k01", 1);   //当前页码数量

        for (index = 0; index < _WLS_PRO_MAX; index++) {
            rt_sprintf(cmd, "c%02d", (index * 10 + 20));
            hmi_sys_send(cmd, xWlsPro->cfg[index].en);    //配置使能
            rt_sprintf(cmd, "c%02d", (index * 10 + 21));
            hmi_sys_send(cmd, xWlsPro->cfg[index].md);     //模式
            rt_sprintf(cmd, "c%02d", (index * 10 + 22));
            hmi_sys_send(cmd, (index + 1));   //端口位置
        }
    }
}

/**
 * @brief 水位补水配置数据相关显示
 */
void hmi_wls_data_sync(u16 index)
{
    u32 high_inch = 0;
    u32 low_inch = 0;
    u32 target_inch = 0;

    if (xWlsPro != RT_NULL) {   //有相关数据
        xSysSTA.curr_wls = index;    //缓存回水类型界面
        high_inch = xWlsPro->cfg[index].high;  //高水位高度
        low_inch = xWlsPro->cfg[index].low;  //低水位高度
        target_inch = xWlsPro->cfg[index].target;  //目标高度
        if (xSysCFG.unit_lv == uuzLV_INCH) {
            high_inch = mm_and_inch_to(0, high_inch);
            low_inch = mm_and_inch_to(0, low_inch);
            target_inch = mm_and_inch_to(0, target_inch);
        }
        hmi_sys_send("d450", high_inch);    //对应高水位
        hmi_sys_send("d451", low_inch);  //对应低水位
        hmi_sys_send("d457", target_inch);   //对应水位目标值
        hmi_sys_send("d452", xWlsPro->cfg[index].md);
        hmi_sys_send("d454", xWlsPro->cfg[index].limit / 60);   //换算成分钟
        hmi_sys_send("d455", xWlsPro->cfg[index].io);   //对应IO位置
        hmi_sys_send("d456", xWlsPro->cfg[index].bid);   //对应Board-ID数据
        hmi_level_value_sync(index);  //NOTE:水位数据实时数据
    }
}

/**
 * @brief 端口信息同步
 * @param currPage  当前页码
 * @param maxDev    类型最大数量
 * @param valve     端口配置地址
 */
void valve_info_sync(u16 currPage, u16 maxDev, Valve_Single_Typedef_t * valve)
{
    int index;
    int count = 0;
    char cmd[30];
    char page[10];
    char type[20];
    int min = 0;
    int max = 0;

    min = currPage * uuzHMI_PAGE_MAX;
    max = (currPage + 1) * uuzHMI_PAGE_MAX;  //页面设备最大最小数据

    hmi_page_is_assert(page, uuzHMI_UI_AUX1);   //获取对应的页面数据
    for (index = 0, count = 0; index < maxDev; index++) {
        if (count >= min && count < max) {  //发送对应页面的端口数据
            rt_sprintf(cmd, "g%02d", index * 10 + 20);  //发送设备端口当前状态
            hmi_sys_send(cmd, valve->en);
            rt_sprintf(cmd, "name%d", index);  //发送设备端类型名称
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
            hmi_box_port_type_is_assert(type, index);  //获取类型名称
#else
            hmi_port_type_is_assert(type, valve->t);  //获取类型名称
#endif
            hmi_txt_send(page, cmd, type);  //发送设备名字
            rt_sprintf(cmd, "g%02d", index * 10 + 21);  //发送设备端口当前类型
            hmi_sys_send(cmd, valve->t);
#if 0
            rt_sprintf(cmd, "g%02d", index * 10 + 22);  //发生设备实时状态
            if ((valve->en == 1) && (xDevSTA.xBrd[0].isconnect == uuzDEV_CONNECTED)) {
                hmi_sys_send(cmd, xSysSTA.state_brd[index]);
            } else {
                hmi_sys_send(cmd, 0);  //无数据,发生空数据包
            }
#endif
            rt_sprintf(cmd, "g%02d", index * 10 + 23);  //发送设备端口对应的编号
            hmi_sys_send(cmd, (index + 1));
        }
        valve++;
        count++;
    }

    if (count < max) {  //清空空位置
        for (index = count; index < max; index++) {
            rt_sprintf(cmd, "g%02d", ((index % 6) * 10 + 20));  //发送一个无效数据
            hmi_sys_send(cmd, 0);
        }
    }
}

/**
 * @brief 加载周期表的列表相关数据
 */
void hmi_sch_config_sync(void)
{
    u8 index = 0;
    char cmd[10];
    u8 schCount = 0;
    u32 mday = 0;
    u32 tday = 0;
    u32 cday = 0;

    //start time
    hmi_sys_send("d204", xSchCFG->start[0]);
    hmi_sys_send("d205", xSchCFG->start[1]);
    hmi_sys_send("d206", xSchCFG->start[2]);

    for (index = 0; index < uuzSCH_DATA_MAX; index++) {
        if (xSchCFG->en[index] == 1) {
            rt_sprintf(cmd, "d%03d", (schCount * 10 + 211));
            hmi_sys_send(cmd, xSchCFG->en[index]);
            rt_sprintf(cmd, "d%03d", (schCount * 10 + 212));
            hmi_sys_send(cmd, xSchCFG->day[index]);
            rt_sprintf(cmd, "d%03d", (schCount * 10 + 213));
            hmi_sys_send(cmd, xSchCFG->prog[index]);
            rt_sprintf(cmd, "d%03d", (schCount + 280));
            hmi_sys_send(cmd, index);
            //计算总时间
            mday += xSchCFG->day[index];
            //添加一个数据
            schCount++;
        }
    }

    if (mday > 0) {
        //获取临时时间
        tday = allDays2Year(xSchCFG->start[0]);  //计算年时间
        cday = allDays(xSchCFG->start[0], xSchCFG->start[1], xSchCFG->start[2]);  //计算当年之内的时间
        tday += cday;
        tday += mday;  //获取结束时间
        all_days_to_time(tday, &xSchCFG->end[0]);
    } else {
        xSchCFG->end[0] = xSchCFG->start[0];
        xSchCFG->end[1] = xSchCFG->start[1];
        xSchCFG->end[2] = xSchCFG->start[2];
    }

    hmi_sys_send("d207", xSchCFG->end[0]);
    hmi_sys_send("d208", xSchCFG->end[1]);
    hmi_sys_send("d209", xSchCFG->end[2]);

    //清空空数据位
    for (index = schCount; index < uuzSCH_DATA_MAX; index++) {
        rt_sprintf(cmd, "d%03d", (index * 10 + 211));
        hmi_sys_send(cmd, 0);
        rt_sprintf(cmd, "d%03d", (index + 280));
        hmi_sys_send(cmd, 255);
    }

    //发送周期表总数据
    hmi_sys_send("d200", schCount);
}
