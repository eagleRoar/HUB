/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-01   ZhouXiaomin     first version
 */
/* Includes ------------------------------------------------------------------*/
#include <rtdevice.h>
#include <string.h>
/* ------------------------------------------------------------------*/
#include "uuzEVENT.h"
#include "uuzOpt.h"
#include "uuzRTC.h"
#include "uuzPIN.h"
#include "uuzUART.h"
#include "uuzTEMP.h"
/* ------------------------------------------------------------------*/
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
#include "uuzEventDevID.h"
#include "uuzConfigPORT.h"
/* ------------------------------------------------------------------*/
#include "typedefHMI.h"
#include "uuzEventHMI.h"
#include "uuzHMI_UI.h"
/* ------------------------------------------------------------------*/
#include "uuzEventDOSING.h"
#include "uuzEventIRR.h"
#include "uuzEventP260.h"
#include "uuzEventPHEC.h"
#include "uuzEventPROG.h"
#include "uuzEventVALVE.h"
#include "uuzEventBRD.h"
#include "uuzEventCFG.h"
#include "uuzEventLGT.h"
#include "uuzEventTIM.h"
#include "uuzEventWLS.h"
#include "uuzEventSCH.h"
#include "uuzEventDOSING.h"
/*log----------------------------------------------------------*/
#define DBG_TAG "hmi.ui"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/* ----------------------------------------------------------------*/
/**
 * @brief hmi_ui_init
 */
void hmi_ui_init(void)
{
    //初始化界面状态数据
    rt_memset(&xCurrUI, 0xFF, sizeof(HMI_Typedef_t));
    rt_memset(&xPrevUI, 0xFF, sizeof(HMI_Typedef_t));
}
/**
 * @brief 初始化参数界面
 * @param ucKeyID
 * @param ucEvent
 */
void hmi_ui_init_task(u8 ucKeyID, u8* ucEvent)
{
    u32 value = 210;

    switch (ucKeyID) {
        case 0x01U:   //初始化系统设置
            if (xSysSTA.is_init_data == 0) {
                xSysSTA.is_init_data = 1;   //进入数据重置阶段
                LOG_D("Init system config!");
                system_config_init(1);
                rt_hw_cpu_reset();  //重启设备
            }
            break;
        case 0x02U:   //初始化设备ID设置
            if (xSysSTA.is_init_data == 0) {
                xSysSTA.is_init_data = 1;   //进入数据重置阶段
                LOG_D("Init device config!");
                config_addr_init(1);
                rt_hw_cpu_reset();   //重启设备
            }
            break;
        case 0x03U:   //重置Device Map的ID
            LOG_D("Reset Device Map ID!");
            device_map_init(1);
            rt_hw_cpu_reset();            //重启设备
            break;
        case 0x04U:   //重置PHEC-B2的ID
            LOG_D("Reset PHEC-B2 ID!");
            phec_id_reset();
            break;
        case 0x05U:   //读取P260的动作
            LOG_D("Read SIN-P260 ID!");
            xSysSTA.state_find = 0;
            for (u16 index = 1; index < 247; index++) {
                if (xSysSTA.state_find == 0) {
                    sinp260_find_id(index);
                    rt_thread_mdelay(500);
                }
            }
            break;
        case 0x06U:   //重置SIN-P260的ID
            LOG_D("Reset SIN-P260 [%d] ID!", ucEvent[0]);
            sinp260_set_id(ucEvent[0]);
            break;
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
        case 0x10U:   //重置AC Station的ID
            LOG_D("Reset AC Station!");
            ac_valve_init();
            break;
        case 0x07U:   //开启AC-Station
            ac_valve_opt(ucEvent[0], 0x64);
            break;
#endif
        case 0x08U:   //测试水位转换
            value = mm_and_inch_to(0, value);
            value = mm_and_inch_to(1, value);
            value = mm_and_inch_to(0, value);
            value = mm_and_inch_to(1, value);
            value = mm_and_inch_to(0, value);
            value = mm_and_inch_to(1, value);
            break;
        default:
            break;
    }
}

/**
 * @brief 提示框界面
 * @param ucKeyID
 * @param ucEvent
 * @param ucLength
 */
void hmi_ui_tip_task(u8 ucKeyID, u8* ucEvent, u8 ucLength)
{
    u8 ucLenCommand = 0;
    u8 index = 0;
    u16 proType;    //程序相关类型
    u16 proIndex;   //程序相关编号
#if 0
    u8 id = 0;
    u8 ret = RT_ERROR;
    u16 proCount;   //程序数据编号
    u16 proIO;   //程序IO端口位置
    u16 proID;   //程序端口板ID号
    u16 proDevType;   //程序端口板类型
    u16 proEnable;   //程序数据使能
    u16 state = 0;
#endif
    u16 mode;   //缓存模式
    u16 enable = 0;  //有效性

    u16 save_flag = 0;  //保存标记
    u16 data[16];  //临时保存数据

    switch (ucKeyID) {
        case 0x01U:  //Delete Schedule
#if 0
            LOG_D("Delete Schedule Data [%d]!", ucEvent[0]);
            if ((ucEvent[0] >= 0) && (ucEvent[0] < uuzSCH_DATA_MAX)) {
                Sch_Config_Typedef_t xSch;
                rt_memcpy(&xSch, xSchCFG, uuzSCH_CONFIG_LEN);    //备份数据

                u8 sch_id = ucEvent[0];
                u8 count = 0;
                //NOTE:准备删除一个SCH数据
                for (index = 0; index < uuzSCH_DATA_MAX; index++) {
                    if (sch_id != index) {
                        xSch.en[count] = xSchCFG->en[index];
                        xSch.day[count] = xSchCFG->day[index];
                        xSch.prog[count] = xSchCFG->prog[index];
                        count++;
                    }
                }

                for (index = count; index < uuzSCH_DATA_MAX; index++) {
                    xSch.en[index] = 0;    //清空数据栏位
                }

                rt_memcpy(xSchCFG, &xSch, uuzSCH_CONFIG_LEN);    //将数据还原,重新计算
                config_data_save(_S_CFG_SCH, 0xFFFF);  //保存相关数据
                rt_thread_mdelay(1500);  //延时1000ms
                hmi_sch_config_sync();  //更新数据
                prog_cache_init();  //清除缓存数据
                dosing_all_close();  //关闭当前数据
            }
            hmi_reset_loading_stage();  //完成加载标记
            hmi_resync_ui_stage(1);  //刷新界面
#endif
            break;
        case 0x02U:  //Reset System Config Data
            //state = usU8ToU16(ucEvent, uuzLSB);  //获取状态
            if (xSysSTA.is_init_data == 0) {
                xSysSTA.is_init_data = 1;
                LOG_D("Init system config!");
                system_config_init(1);  //初始化系统设置
                LOG_D("Reset Device Map ID!");
                device_map_init(1);  //初始化数据ID列表
                LOG_D("Reset PHEC-B2 ID!");
                phec_id_reset();  //重置PHEC-B2的ID
                LOG_D("Init device config!");
                config_addr_init(1);  //初始化设备配置数据
                hmi_reset_loading_stage();  //完成加载标记
                rt_thread_mdelay(2000);
                rt_hw_cpu_reset();  //重启设备
            }
            break;
        case 0x03U:
            //Save Program Data
            ucLenCommand = 0;
            mode = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);    //配肥类型
            ucLenCommand += 2;
            proIndex = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);    //程序编号
            ucLenCommand += 2;
            LOG_D("Save Dynamic Dosing Data[%d]", proIndex);
            if (proIndex < uuzPROG_MAX) {  //有对应数据区域
                //Data-EC
                xProgCFG.xDynamic[proIndex]->cfg.ec_t = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                xProgCFG.xDynamic[proIndex]->cfg.ec_d = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                xProgCFG.xDynamic[proIndex]->cfg.ec_h = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                xProgCFG.xDynamic[proIndex]->cfg.ec_l = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                xProgCFG.xDynamic[proIndex]->cfg.ec_en = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                //Data-pH
                xProgCFG.xDynamic[proIndex]->cfg.pH_t = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                xProgCFG.xDynamic[proIndex]->cfg.pH_d = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                xProgCFG.xDynamic[proIndex]->cfg.pH_h = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                xProgCFG.xDynamic[proIndex]->cfg.pH_l = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                xProgCFG.xDynamic[proIndex]->cfg.pH_en = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                //Data-TA
#if (uuzDEVICE_TYPE==_DEV_INNOVATION_ONLY)
                xProgCFG.xDynamic[proIndex]->cfg.ta_h = uuz_usTemp2Int_ConvCplt(uuz_usTempF2C_ConvCplt(
                        usU8ToU16(ucEvent + ucLenCommand, uuzLSB)));
#else
                xProgCFG.xDynamic[proIndex]->cfg.ta_h = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
#endif
                ucLenCommand += 2;
                xProgCFG.xDynamic[proIndex]->cfg.ta_en = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                //Data-Dosing
                for (u8 index = 0; index < uuzDEV_DOS_MAX; index++) {
                    xProgCFG.xDynamic[proIndex]->dos[index].en = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                    ucLenCommand += 2;
                    xProgCFG.xDynamic[proIndex]->dos[index].ratio = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                    ucLenCommand += 2;
                    xProgCFG.xDynamic[proIndex]->dos[index].type = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                    ucLenCommand += 2;
                }
                config_data_save(_S_CFG_NUT, proIndex);  //保存相关数据
                rt_thread_mdelay(500);
            }
            prog_cache_init();  //清除缓存数据
            dosing_all_close();  //关闭当前数据
            hmi_reset_loading_stage();  //完成加载标记
            break;
        case 0x04U:
            //完成加载标记
            hmi_reset_loading_stage();
            break;
        case 0x05U:
            //AERO相关配置数据
            ucLenCommand = 0;
            proIndex = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);   //当前相关程序编号
            ucLenCommand += 2;
            proType = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);   //当前相关程序类型
            ucLenCommand += 2;
            LOG_D("Save Project <<%d>> for [%d] Data", proIndex, proType);
            //proIndex--;  //处理序号
            if ((proIndex < _IRR_PRO_MAX) && (proType == _IRR_AERO)) {
                for (index = 0; index < 2; index++) {
                    xIrrPro->pro[proIndex].cfg.t_cycle[index].on = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                    ucLenCommand += 2;
                    xIrrPro->pro[proIndex].cfg.t_cycle[index].off = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                    ucLenCommand += 2;
                }

#if 0
                proCount = 0;
                //IO数据初始化
                for (index = 0; index < 16; index += 2) {
                    proEnable = ucEvent[ucLenCommand + index];    //使能(ON/OFF
                    proIO = ucEvent[ucLenCommand + 1 + index];   //设备端口编号(1,2,3...
                    proIO--;
                    proDevType = ucEvent[ucLenCommand + 16 + index];   //设备类型
                    proID = ucEvent[ucLenCommand + 17 + index];   //设备ID号
                    if (proEnable == 1) {
                        xIrrPro->pro[proIndex].cfg.io[proCount].en = RT_TRUE;
                        xIrrPro->pro[proIndex].cfg.io[proCount].id = proID;
                        xIrrPro->pro[proIndex].cfg.io[proCount].io = proIO;
                        xIrrPro->pro[proIndex].cfg.io[proCount].t = proDevType;
                        proCount++;
                    }
                }
                //清空其他数据
                for (index = proCount; index < _IO_PRO_MAX; index++) {
                    xIrrPro->pro[proIndex].cfg.io[index].en = RT_FALSE;
                }
#endif
                config_data_save(_S_CFG_IRR, 0xFFFF);  //保存相关数据
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
        case 0x06U:
            //Top-Feed相关配置数据
            ucLenCommand = 0;
            proIndex = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);   //当前相关程序编号
            ucLenCommand += 2;
            proType = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);   //当前相关程序类型
            ucLenCommand += 2;
            LOG_D("Save Project <<%d>> for [%d] Data", proIndex, proType);
            //NOTE:数据处理
            if ((proIndex < _IRR_PRO_MAX) && (proType == _IRR_TOPFEED)) {
                for (index = 0; index < 5; index++) {
                    xIrrPro->pro[proIndex].cfg.t_timer[index].en = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                    ucLenCommand += 2;
                    xIrrPro->pro[proIndex].cfg.t_timer[index].on = (usU8ToU16(ucEvent + ucLenCommand, uuzLSB) * 60);
                    ucLenCommand += 2;
                    xIrrPro->pro[proIndex].cfg.t_timer[index].off =
                            (usU8ToU16(ucEvent + ucLenCommand, uuzLSB) * 60);
                    ucLenCommand += 2;
                }

#if 0
                proCount = 0;
                //IO数据初始化
                for (index = 0; index < 16; index += 2) {
                    proEnable = ucEvent[ucLenCommand + index];    //使能(ON/OFF
                    proIO = ucEvent[ucLenCommand + 1 + index];   //设备端口编号(1,2,3...
                    proIO--;
                    proDevType = ucEvent[ucLenCommand + 16 + index];   //设备类型
                    proID = ucEvent[ucLenCommand + 17 + index];   //设备ID号
                    if (proEnable == 1) {
                        xIrrPro->pro[proIndex].cfg.io[proCount].en = RT_TRUE;
                        xIrrPro->pro[proIndex].cfg.io[proCount].id = proID;
                        xIrrPro->pro[proIndex].cfg.io[proCount].io = proIO;
                        xIrrPro->pro[proIndex].cfg.io[proCount].t = proDevType;
                        proCount++;
                    }
                }
                //清空其他数据
                for (index = proCount; index < _IO_PRO_MAX; index++) {
                    xIrrPro->pro[proIndex].cfg.io[index].en = RT_FALSE;
                }
#endif
                config_data_save(_S_CFG_IRR, 0xFFFF);  //保存相关数据
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
        case 0x07U:
            //flow-ebb相关配置数据
            ucLenCommand = 0;
            proIndex = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);   //当前灌溉数据编号
            ucLenCommand += 2;
            proType = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);   //当前水位传感器编号
            ucLenCommand += 2;
            LOG_D("Save Project <<%d>> for [%d] Data", proIndex, proType);
            if ((proIndex == 0) && (proType == 1)) {
                for (index = 0; index < 2; index++) {
                    xIrrPro->pro[proIndex].cfg.flood[index] = (usU8ToU16(ucEvent + ucLenCommand, uuzLSB) * 60);
                    ucLenCommand += 2;
                    xIrrPro->pro[proIndex].cfg.wait[index] = (usU8ToU16(ucEvent + ucLenCommand, uuzLSB) * 60);
                    ucLenCommand += 2;
                }
                config_data_save(_S_CFG_IRR, 0xFFFFU);  //保存相关数据

                //添加相关水位数据
                xWlsPro->cfg[proType].high = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                xWlsPro->cfg[proType].target = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);   //将目标数据同步
                ucLenCommand += 2;
                xWlsPro->cfg[proType].low = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);

                config_data_save(_S_CFG_WLS, 0xFFFFU);  //保存相关数据
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
        case 0x08U:  //灌溉程序数据更新
            ucLenCommand = 0;
            proIndex = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);   //当前相关程序编号
            ucLenCommand += 2;
            proType = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);   //当前相关程序类型
            ucLenCommand += 2;
            LOG_D("Save Project <<%d>> for [%d] Data", proIndex, proType);
            //proIndex--;   //处理序号
            if ((proIndex < _IRR_PRO_MAX) && (proType == _IRR_CUSTOMIZE)) {
                xIrrPro->pro[proIndex].cfg.md = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                xIrrPro->pro[proIndex].cfg.sta = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                for (index = 0; index < 2; index++) {
                    xIrrPro->pro[proIndex].cfg.t_cycle[index].on = (usU8ToU16(ucEvent + ucLenCommand, uuzLSB) * 60);
                    ucLenCommand += 2;
                    xIrrPro->pro[proIndex].cfg.t_cycle[index].off =
                            (usU8ToU16(ucEvent + ucLenCommand, uuzLSB) * 60);
                    ucLenCommand += 2;
                }
                for (index = 0; index < 5; index++) {
                    xIrrPro->pro[proIndex].cfg.t_timer[index].en = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                    ucLenCommand += 2;
                    xIrrPro->pro[proIndex].cfg.t_timer[index].on = (usU8ToU16(ucEvent + ucLenCommand, uuzLSB) * 60);
                    ucLenCommand += 2;
                    xIrrPro->pro[proIndex].cfg.t_timer[index].off =
                            (usU8ToU16(ucEvent + ucLenCommand, uuzLSB) * 60);
                    ucLenCommand += 2;
                }
#if 0
                proCount = 0;
                //IO数据初始化
                for (index = 0; index < 16; index += 2) {
                    proEnable = ucEvent[ucLenCommand + index];    //使能(ON/OFF
                    proIO = ucEvent[ucLenCommand + 1 + index];   //设备端口编号(1,2,3...
                    proIO--;
                    proDevType = ucEvent[ucLenCommand + 16 + index];   //设备类型
                    proID = ucEvent[ucLenCommand + 17 + index];   //设备ID号
                    if (proEnable == 1) {
                        xIrrPro->pro[proIndex].cfg.io[proCount].en = RT_TRUE;
                        xIrrPro->pro[proIndex].cfg.io[proCount].id = proID;
                        xIrrPro->pro[proIndex].cfg.io[proCount].io = proIO;
                        xIrrPro->pro[proIndex].cfg.io[proCount].t = proDevType;
                        proCount++;
                    }
                }
                //清空其他数据
                for (index = proCount; index < _IO_PRO_MAX; index++) {
                    xIrrPro->pro[proIndex].cfg.io[index].en = RT_FALSE;
                }
#endif
                config_data_save(_S_CFG_IRR, 0xFFFF);  //保存相关数据
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
        case 0x09U:
            LOG_I("Save Custom-Drain Data");
#if 0
            ucLenCommand = 0;
            xIrrCustom.d_mode = ucEvent[ucLenCommand];
            ucLenCommand++;
            //Manual
            xIrrCustom.d_en = ucEvent[ucLenCommand];
            ucLenCommand++;
            //Timer
            for (index = 0; index < 10; index++) {
                xIrrCustom.d_timer[index].en = ucEvent[ucLenCommand];
                ucLenCommand++;
                xIrrCustom.d_timer[index].on = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                xIrrCustom.d_timer[index].off = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
            }
            //保存相关数据
            //irr_custom_save();
            //完成加载标记
#endif
            hmi_reset_loading_stage();
            break;
        case 0x0AU:  //回水数据相关保存
            ucLenCommand = 0;
            LOG_D("[%d]Save Water Supply Data", xSysSTA.curr_wls);
            proIndex = xSysSTA.curr_wls;
            if (proIndex < _WLS_PRO_MAX) {
                u16 inch = 0;
                inch = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);   //High Level
                if (xSysCFG.unit_lv == uuzLV_INCH) {
                    inch = mm_and_inch_to(1, inch);
                }
                xWlsPro->cfg[proIndex].high = inch;   //High Level
                ucLenCommand += 2;
                inch = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);   //Low Level
                if (xSysCFG.unit_lv == uuzLV_INCH) {
                    inch = mm_and_inch_to(1, inch);
                }
                xWlsPro->cfg[proIndex].low = inch;   //Low Level
                ucLenCommand += 2;
                inch = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);   //Target Level
                if (xSysCFG.unit_lv == uuzLV_INCH) {
                    inch = mm_and_inch_to(1, inch);
                }
                xWlsPro->cfg[proIndex].target = inch;   //Target Level
                ucLenCommand += 2;
                xWlsPro->cfg[proIndex].md = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);   //Manual/Auto
                ucLenCommand += 2;
                xWlsPro->cfg[proIndex].limit = (usU8ToU16(ucEvent + ucLenCommand, uuzLSB) * 60);   //最大持续补水时间,换算成秒
                ucLenCommand += 2;
#if 0
                //IO数据初始化
                proEnable = ucEvent[ucLenCommand];//使能(ON/OFF
                xWlsPro->cfg[proIndex].io = ucEvent[ucLenCommand + 1] - 1;//设备端口编号(1,2,3...
                xWlsPro->cfg[proIndex].t = ucEvent[ucLenCommand + 2];//设备类型
                xWlsPro->cfg[proIndex].bid = ucEvent[ucLenCommand + 3];//设备ID号
#endif
                config_data_save(_S_CFG_WLS, 0xFFFF);  //保存相关数据
            }
            hmi_reset_loading_stage();            //完成加载标记
            break;
        case 0x0BU:  //保存灯光相关数据
            LOG_D("Save Light Data");
            ucLenCommand = 0;
            proIndex = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);   //当前灯光编号
            proIndex--;  //序号切换到下标需要数字-1
            ucLenCommand += 2;
            LOG_D("Light Index[%d]", proIndex);
            if (proIndex < _LGT_CFG_MAX) {
                xLgtPro.cfg[proIndex]->md = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                //Manual Mode
                xLgtPro.cfg[proIndex]->sta = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                //Cycle Mode
                xLgtPro.cfg[proIndex]->t_cycle[0].on = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                xLgtPro.cfg[proIndex]->t_cycle[0].off = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                xLgtPro.cfg[proIndex]->t_cycle[1].on = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                xLgtPro.cfg[proIndex]->t_cycle[1].off = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                //Timer Mode
                for (index = 0; index < 5; index++) {
                    xLgtPro.cfg[proIndex]->t_timer[index].en = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                    ucLenCommand += 2;
                    xLgtPro.cfg[proIndex]->t_timer[index].on = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                    ucLenCommand += 2;
                    xLgtPro.cfg[proIndex]->t_timer[index].off = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                    ucLenCommand += 2;
                }
                config_data_save(_S_CFG_LGT, 0xFFFF);  //保存相关数据
                rt_memset(&xLgtPro.sta[proIndex], 0x00U, sizeof(Cycle_Item_Typedef_t));
            }
            hmi_reset_loading_stage();   //完成加载标记
            break;
        case 0x0CU:  //保存定时相关数据
            LOG_D("Save Timer Data");
            ucLenCommand = 0;
            proIndex = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);   //当前定时编号
            proIndex -= 2;  //序号切换到下标需要数字-2
            ucLenCommand += 2;
            LOG_D("Timer Index[%d]", proIndex);
            if (proIndex < _TIM_CFG_MAX) {
                xTimPro.cfg[proIndex]->md = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                //Manual Mode
                xTimPro.cfg[proIndex]->sta = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                //Cycle Mode
                xTimPro.cfg[proIndex]->t_cycle.on = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 2;
                xTimPro.cfg[proIndex]->t_cycle.off = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                ucLenCommand += 6;  //跳过2个无效数据
                //Timer Mode
                for (index = 0; index < 5; index++) {
                    xTimPro.cfg[proIndex]->t_timer[index].en = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                    ucLenCommand += 2;
                    xTimPro.cfg[proIndex]->t_timer[index].on = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                    ucLenCommand += 2;
                    xTimPro.cfg[proIndex]->t_timer[index].off = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
                    ucLenCommand += 2;
                }
                config_data_save(_S_CFG_TIM, proIndex);  //保存相关数据
                rt_memset(&xTimSta[proIndex], 0x00U, sizeof(Cycle_Item_Typedef_t));
            }
            hmi_device_list_sync();  //更新列表界面数据
            hmi_reset_loading_stage();   //完成加载标记
            hmi_resync_ui_stage(2);   //局部刷新数据
            break;
        case 0x0D:
            LOG_D("Save System Setup Data");
            ucLenCommand = 0;
            //更新数据
            xSysCFG.unit_ec = ucEvent[ucLenCommand];
            ucLenCommand++;
            xSysCFG.unit_ta = ucEvent[ucLenCommand];
            ucLenCommand++;
            xSysCFG.unit_lv = ucEvent[ucLenCommand];
            ucLenCommand++;
            xSysCFG.unit_date = ucEvent[ucLenCommand];
            ucLenCommand++;
            xSysCFG.unit_time = ucEvent[ucLenCommand];
            ucLenCommand++;
            xSysCFG.bk_mode = ucEvent[ucLenCommand];
            ucLenCommand++;
            xSysCFG.bk_time = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
            ucLenCommand += 2;
            xSysCFG.bk_level = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
            ucLenCommand += 2;
            xSysCFG.day_mode = ucEvent[ucLenCommand];
            ucLenCommand++;
            xSysCFG.day_on = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
            ucLenCommand += 2;
            xSysCFG.day_off = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
            ucLenCommand += 2;
            //时间临时数据
            u16 tRtc[6];  //year-month-day-hour-min-sec
            tRtc[0] = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
            ucLenCommand += 2;
            tRtc[1] = ucEvent[ucLenCommand];
            ucLenCommand++;
            tRtc[2] = ucEvent[ucLenCommand];
            ucLenCommand++;
            tRtc[3] = ucEvent[ucLenCommand];
            ucLenCommand++;
            tRtc[4] = ucEvent[ucLenCommand];
            ucLenCommand++;
            tRtc[5] = ucEvent[ucLenCommand];
            ucLenCommand++;
            //设置系统实时时间,并更新实时数据
            rt_rtc_set(tRtc[0], tRtc[1], tRtc[2], tRtc[3], tRtc[4], tRtc[5]);
            //保存配置数据
            system_config_save();
            //完成加载标记
            hmi_reset_loading_stage();
            break;
        case 0x0E:
            LOG_D("Save Schedule Setup Data");
            ucLenCommand = 0;
            //更新数据
            //开启时间
            xSchCFG->start[0] = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
            ucLenCommand += 2;
            xSchCFG->start[1] = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
            ucLenCommand += 2;
            xSchCFG->start[2] = usU8ToU16(ucEvent + ucLenCommand, uuzLSB);
            ucLenCommand += 2;
            //周期表属性
            for (index = 0; index < uuzSCH_DATA_MAX; index++) {
                xSchCFG->en[index] = ucEvent[ucLenCommand];
                ucLenCommand++;
                xSchCFG->day[index] = ucEvent[ucLenCommand];
                ucLenCommand++;
                xSchCFG->prog[index] = ucEvent[ucLenCommand];
                ucLenCommand++;
            }
            //保存配置数据
            config_data_save(_S_CFG_SCH, 0xFFFF);  //保存相关数据
            rt_thread_mdelay(1500);
            //更新数据，完成加载标记
            hmi_sch_config_sync();  //更新数据
            prog_cache_init();  //清除缓存数据
            dosing_all_close();  //关闭当前数据
            rt_thread_mdelay(1000);
            hmi_reset_loading_stage();  //完成加载标记
            hmi_resync_ui_stage(1);  //刷新界面
            break;
        case 0x0F:
            //切换运行工作模式
            mode = usU8ToU16(ucEvent, uuzLSB);  //切换运行模式
            xSysCFG.running_mode = ((mode < 3) ? (mode) : (0));  //防止输入错误数据
            //mode = usU8ToU16(ucEvent + 2, uuzLSB);  //切换运行模式
            //xSysCFG.single_mode = (mode < 2) ? (mode) : (0);  //防止输入错误数据
#if (uuzDEVICE_TYPE==_DEV_INNOVATION_ONLY)
            xSysCFG.single_mode = 0;    //定量模式
#else
                    xSysCFG.single_mode = 1;    //动态模式
#endif
            LOG_D("CFG[%d-%d]", xSysCFG.running_mode, xSysCFG.single_mode);
            prog_cache_init();  //清除缓存数据
            dosing_all_close();  //关闭当前数据
            system_config_save();  //保存配置数据
            hmi_reset_loading_stage();  //完成加载标记
            rt_event_send(eventDATA, UI_STA_SYNC);                //添加发送界面刷新计数
            break;
        case 0x10:
            //切换灌溉模式，重置相关数据
            LOG_D("Reset Irrigation Config Data");
            mode = usU8ToU16(ucEvent, uuzLSB);    //设备类型
            if (mode < 5) {  //赋值错误，提供基本信息
                if (xIrrPro->pro[0].md != mode) {
                    xIrrPro->pro[0].md = mode;   //模式不同，需要将数据重置
                    irrigation_config_single_default_init(&xIrrPro->pro[0].cfg, mode);  //数据重置
#if (uuzDEVICE_TYPE!=_DEV_INNOVATION_ONLY)
                    //rt_event_send(eventVALVE, OPT_VLV_2_OFF);  //灌溉模式
                    valve_opt(0, 1, uuzOPT_OFF);  //切换灌溉模式,关闭回水
#endif
                    save_flag = 1;  //保存标记
                }
                if (save_flag) {
                    config_data_save(_S_CFG_IRR, 0xFFFF);  //保存相关数据
                }
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
        case 0x11:
            //修改回水模式相关数据
            LOG_D("Save Water Supply List Data");
            data[0] = usU8ToU16(ucEvent, uuzLSB);    //程序数据1
            data[1] = usU8ToU16(ucEvent + 2, uuzLSB);    //程序数据2
            if (data[0] < 2) {  //输入的数据正确
                if (xWlsPro->cfg[0].en != data[0]) {    //如果数据有改变
                    xWlsPro->cfg[0].en = data[0];   //更新数据
                    save_flag = 1;  //保存标记
                }
            }
            if (data[1] < 2) {  //输入的数据正确
                if (xWlsPro->cfg[1].en != data[1]) {  //如果数据有改变
                    xWlsPro->cfg[1].en = data[1];   //更新数据
                    save_flag = 1;  //保存标记
                }
            }
            if (save_flag) {
                config_data_save(_S_CFG_WLS, 0xFFFF);  //保存相关数据
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
        case 0x12:
            //修改定量配肥的相关数据
            mode = usU8ToU16(ucEvent, uuzLSB);    //配肥类型
            proIndex = usU8ToU16(ucEvent + 2, uuzLSB);    //程序编号
            LOG_D("Save Fixed Dosing Data[%d]", proIndex);
            u16 volume = usU8ToU16(ucEvent + 4, uuzLSB);    //水池容量
            u16 uint = usU8ToU16(ucEvent + 6, uuzLSB);    //水池单位
            u16 dosing = 0;  //蠕动泵速度
            u16 t_dosing = 0;   //蠕动泵时间
            if (xProgCFG.xFixed[proIndex]->volume != volume) {
                xProgCFG.xFixed[proIndex]->volume = volume;
                save_flag = 1;  //保存标记
            }

            if (xProgCFG.xFixed[proIndex]->uint != uint) {
                xProgCFG.xFixed[proIndex]->uint = uint;
                save_flag = 1;  //保存标记
            }
            u16 max = (xSysCFG.dosing_num < uuzDEV_DOS_MAX) ? (xSysCFG.dosing_num) : (uuzDEV_DOS_MAX);  //计算最大蠕动泵数量
            if (proIndex < uuzPROG_MAX) {  //有对应数据区域
                for (index = 0; index < max; index++) {
                    enable = usU8ToU16(ucEvent + 8 + (index * 2 * 2), uuzLSB);  //蠕动泵状态
                    dosing = usU8ToU16(ucEvent + 10 + (index * 2 * 2), uuzLSB);    //蠕动泵参数
                    t_dosing = (volume * 1000) / dosing;    //计算需要时间(秒)
                    LOG_D("TIP-Save Project INFO:[%d]-[%d]-[%d]", enable, dosing, t_dosing);
                    if (xProgCFG.xFixed[proIndex]->en[index] != enable) {
                        xProgCFG.xFixed[proIndex]->en[index] = enable;
                        save_flag = 1;  //保存标记
                    }
                    if (xProgCFG.xFixed[proIndex]->dos[index] != dosing) {
                        xProgCFG.xFixed[proIndex]->dos[index] = dosing;
                        save_flag = 1;  //保存标记
                    }
                    if (xProgCFG.xFixed[proIndex]->t[index] != t_dosing) {
                        xProgCFG.xFixed[proIndex]->t[index] = t_dosing;
                        save_flag = 1;  //保存标记
                    }
                }
            }
            if (save_flag) {
                hmi_fixed_single_config_sync(xProgCFG.xFixed[proIndex]);
                config_data_save(_S_CFG_FIX, proIndex);  //保存相关数据
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
        case 0x13:  //保存蠕动泵相关数据
            data[0] = usU8ToU16(ucEvent, uuzLSB);  //蠕动泵工作时间
            if (xDosCFG->running != data[0]) {
                xDosCFG->running = data[0];
                save_flag = 1;
            }

            data[1] = usU8ToU16(ucEvent + 2, uuzLSB);  //蠕动泵等待时间
            if (xDosCFG->waiting != data[1]) {
                xDosCFG->waiting = data[1];
                save_flag = 1;
            }

            data[2] = usU8ToU16(ucEvent + 4, uuzLSB);  //蠕动泵等待时间
            if (xDosCFG->speed != data[2]) {
                xDosCFG->speed = data[2];
                save_flag = 1;
            }

            data[3] = usU8ToU16(ucEvent + 6, uuzLSB);  //蠕动泵等待时间
            if (xDosCFG->mode != data[3]) {
                xDosCFG->mode = data[3];
                save_flag = 1;
            }

            if (save_flag) {
                config_data_save(_S_CFG_DOS, 0xFFFFU);  //保存相关数据
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
        default:
            break;
    }
    //TODO:保存日志
}

/**
 * @brief 启动全局处理界面
 * @param ucKeyID
 * @param ucEvent
 */
void hmi_ui_global_task(u8 ucKeyID, u8* ucEvent)
{
    u16 data;

    //全局操作函数
    switch (ucKeyID) {
        case 0xFFU:
            data = usU8ToU16(ucEvent, uuzLSB);
            if (data == uuzHMI_CMD_RBT_HW) {  //当屏幕重启后，同步重启主板恢复通讯
                LOG_D("Need Reboot CPU!");
                rt_hw_cpu_reset();
            }
            break;
        case 0x66U:  //初始化界面ID
            data = usU8ToU16(ucEvent, uuzLSB);
            LOG_D("First into UI[%d], Sync UI.", xCurrUI.ucPageID);
            if (data == uuzHMI_UI_MAIN) {   //在界面ID编号范围内
                xCurrUI.ucPageID = data;
                //第一次进入主界面，准备进入倒计数
                if (xSysSTA.waiting_state == 0) {
                    xSysSTA.waiting_time = 0;   //重置标记
                    xSysSTA.waiting_state = 1;
                }
                //立即刷新界面程序
                rt_event_send(eventDATA, UI_DATA_SYNC);
                hmi_reset_loading_stage();  //回复加载完成标记
            }
            break;
        default:
            break;
    }
}

/**
 * @brief 选择灌溉端口配置选择界面
 * @param ucKeyID
 * @param ucEvent
 */
void hmi_ui_irr_port_set_task(u8 ucKeyID, u8* ucEvent)
{
    //int index = 0;
    //u16 enable = 0;
    u16 mode = 0;
    u16 port = 0;
    //int save_flag = 0;   //保存数据标记

    switch (ucKeyID) {
#if 0
        case 0x01U:  //灌溉端口数据
            xSysSTA.currPage = usU8ToU16(ucEvent + 2, uuzLSB);  //获取当前页码
            LOG_D("Loading Data[%d]!", xSysSTA.currPage);
            hmi_irrigation_mode_loading(xSysSTA.currPage);  //加载灌溉模式相关数据
            hmi_reset_loading_stage();  //完成加载标记
            break;
#endif
        case 0x01U:  //单个端口配置数据
            port = usU8ToU16(ucEvent, uuzLSB) - 1;    //设备序号
            mode = usU8ToU16(ucEvent + 2, uuzLSB);    //设备类型
            LOG_D("Loading Project INFO:[%d]-[%d]", port, mode);
            if (port < _IRR_PRO_MAX) {  //有对应数据
                hmi_irrigation_mode_info_sync(mode, port);
                if (mode == _IRR_FLOWEBB) {  //NOTE:如果是潮汐式模式,额外显示水位相关数据
                    hmi_wls_data_sync(1);   //NOTE:显示水位和自动补水相关数据
                }
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
#if 0
        case 0x03U:  //保存修改的端口类型和端口数据
            for (index = 0; index < 6; index++) {
                enable = usU8ToU16(ucEvent + (index * 3 * 2), uuzLSB);  //设备配置执行状态
                mode = usU8ToU16(ucEvent + 2 + (index * 3 * 2), uuzLSB);    //设备类型
                port = usU8ToU16(ucEvent + 4 + (index * 3 * 2), uuzLSB) - 1;    //设备序号
                LOG_D("Save Project INFO:[%d]-[%d]-[%d]", enable, mode, port);
                if (port < _IRR_PRO_MAX) {  //有对应数据
                    if ((xIrrPro->pro[port].en != enable) || (xIrrPro->pro[port].md != mode)) {
                        xIrrPro->pro[port].en = enable;
                        xIrrPro->pro[port].md = mode;
                        save_flag = 1;  //保存标记
                    }
                }
            }
            if (save_flag) {
                config_data_save(_S_CFG_IRR, 0xFFFF);  //保存相关数据
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
#endif
        default:
            break;
    }
}

#if 0
/**
 * @brief 选择灌溉端口配置选择界面
 * @param ucKeyID
 * @param ucEvent
 */
void hmi_ui_irr_flow_ebb_task(u8 ucKeyID, u8* ucEvent)
{
    u16 mode = 0;
    u16 port = 0;

    switch (ucKeyID) {
        case 0x01U:  //单个端口配置数据
            port = usU8ToU16(ucEvent, uuzLSB) - 1;    //回水数据序号
            LOG_D("Loading Project INFO:[%d]-[%d]", port);
            if (port < _WLS_PRO_MAX) {  //有对应数据
                hmi_wls_data_sync(port);   //NOTE:显示水位和自动补水相关数据
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
        default:
            break;
    }
}
#endif

/**
 * @brief 灯光端口配置选择界面
 * @param ucKeyID
 * @param ucEvent
 */
void hmi_ui_light_port_set_task(u8 ucKeyID, u8* ucEvent)
{
    u16 index = 0;
    u16 state = uuzOPT_OFF;

    switch (ucKeyID) {
        case 0x02U:  //单个端口配置数据
            index = usU8ToU16(ucEvent, uuzLSB) - 1;    //设备序号
            LOG_D("Loading Project INFO:[%d]", index);
            if (index == 0) {    //灯光配置数据
                hmi_light_config_sync(index);    //刷新灯光数据
            } else if (index == 1 || index == 2) {    //刷新定时配置数据
                hmi_timer_config_sync(index - 1);
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
        case 0x03U:  //单个端口状态设置
            index = usU8ToU16(ucEvent, uuzLSB) - 1;    //设备序号
            state = usU8ToU16(ucEvent + 2, uuzLSB);
            if (state == uuzOPT_ON || state == uuzOPT_OFF) {
                //rt_event_send(eventVALVE, valve_opt_single((index + 3), state));  //执行动作
                valve_opt(0, index, state);  //开关端口
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
        default:
            break;
    }
}

/**
 * @brief 自动补水设置界面
 * @param ucKeyID
 * @param ucEvent
 */
void hmi_ui_water_supply_set_task(u8 ucKeyID, u8* ucEvent)
{
    u16 index = 0;
    u16 state = 0;

    switch (ucKeyID) {
        case 0x01U:
            index = usU8ToU16(ucEvent, uuzLSB);
            state = usU8ToU16(ucEvent + 2, uuzLSB);
            LOG_D("Water Supply [%d] Opt Status [%d]!", index, state);
            if (index < 2) {  //当前工作状态未开启，把补水关闭
                xSysSTA.curr_wls = index;    //缓存操作区数
                if (state == uuzOPT_OFF) {
                    xWlsCache[index].sta = uuzOPT_OFF;  //退出补水状态
                    wls_auto_fill_output(index, uuzOPT_OFF);  //自动关闭补水事件
                    xWlsCache[index].time = 0;  //清除计时状态
                    xWlsCache[index].opt = uuzRUN_OFF;  //关闭补水程序动作
                } else if (state == uuzOPT_ON) {
                    xWlsCache[index].sta = uuzOPT_ON;  //进入补水状态
                    wls_auto_fill_output(index, uuzOPT_ON);  //手动开启补水事件
                    xWlsCache[index].time = 0;  //清除计时状态
                    xWlsCache[index].opt = uuzRUN_ON;  //开启补水程序动作
                }
            }
            break;
        default:
            break;
    }
}

/**
 * @brief 外设菜单界面当个AUX数据
 * @param ucKeyID
 * @param ucEvent
 */
void hmi_ui_aux_menu_task(u8 ucKeyID, u8* ucEvent)
{
    u16 index = 0;
    u16 opt = uuzOPT_OFF;
    //u16 state = 0;

    switch (ucKeyID) {
        case 0x03U:
            index = usU8ToU16(ucEvent, uuzLSB);  //操作位置
            opt = usU8ToU16(ucEvent + 2, uuzLSB);   //操作数据
            LOG_D("Loading Aux Device[%d]--Opt[%d]!", index, opt);
            if ((index < uuzDEV_BRD_VALVE_MAX)
                    && ((opt == uuzOPT_OFF) || (opt == uuzOPT_ON))) {  //相关数据判断
                //rt_event_send(eventVALVE, valve_opt_single(index, opt));
                valve_opt(0, index, opt);  //开关端口
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
        default:
            break;

    }
}

#if 0
/**
 * @brief 选择设置加载外设设备数据
 * @param ucKeyID
 * @param ucEvent
 */
void hmi_ui_aux_port_set_task(u8 ucKeyID, u8* ucEvent)
{
    u16 id = 0;
    u16 type = 0;
    u16 port = 0;
    u16 prevtype = 0;
    u16 currtype = 0;
    u16 index = 0;
    u16 f_need_save_data = 0;
    u16 sta_tool_data = 0;
    u16 f_need_save_light_pro_data = 0;

#if 1
    switch (ucKeyID) {
        case 0x01U:
            f_need_save_data = 0;
            f_need_save_light_pro_data = 0;
            id = usU8ToU16(ucEvent, uuzLSB);    //主设备ID
            type = usU8ToU16(ucEvent + 2, uuzLSB);  //主设备类型
            port = usU8ToU16(ucEvent + 4, uuzLSB) - 1;  //设置的端口数据
            currtype = usU8ToU16(ucEvent + 6, uuzLSB);  //设置的端口类型
            LOG_D("Get Data:ID[%d]-Type[%d]-Port[%d]-currType[%d]", id, type, port, currtype);

            if (xSysSTA.dev != RT_NULL) {  //加载相关参数
                if ((xSysSTA.dev->id == id) && (xSysSTA.dev->type == type)) {   //如果数据符合要求
                    if (type == uuzDEV_SL_BRD) {    //如果是电源板数据
                        index = device_index_exist(&xDevSTA.xBrd[0], uuzDEV_BRD_MAX, xSysSTA.dev->id);
                        if (port < uuzDEV_BRD_VALVE_MAX) {    //判断端口数量
                            if (xBoardCFG->valve[port].t != currtype) {  //如果端口数据有更新
                                prevtype = xBoardCFG->valve[port].t;    //缓存类型数据
                                //NOTE:判断是否要更新灯光相关的数据
                                if (prevtype != uuzPORT_LIGHT) {   //如果原来不灯光模块切换到灯光模块
                                    if (currtype == uuzPORT_LIGHT) {    //如果原来不是灯光串口，初始化灯光数据
                                        lgt_config_add(xLgtPro.cfg[port]);    //如果由其他类型变成灯光类型，需要增加数据
                                        f_need_save_light_pro_data = 1;  //处理灯光数据
                                    }
                                } else {    //灯光模块类型切换到其他类型模块
                                    lgt_config_init(xLgtPro.cfg[port]);  //情况相关数据
                                    f_need_save_light_pro_data = 1;  //处理灯光数据
                                }
                                xBoardCFG->valve[port].t = currtype;  //更新端口类型数据
                                f_need_save_data = 1;   //有需要保存的数据
                                value_cache_init();  //主板数据更新
                            }
                        }

                        u32 s_save_mode = 0;
                        if (f_need_save_data == 1) {    //有需要保存的数据标记
                            valve_info_sync(xSysSTA.currPage, uuzDEV_BRD_VALVE_MAX,
                                    &xBoardCFG->valve[0]);  //更新修改后的数据
                            s_save_mode |= _S_CFG_BRD;  //保存Board数据IO数据
                            if (f_need_save_light_pro_data == 1) {
                                s_save_mode |= _S_CFG_LGT;  //保存灯光相关数据
                            }
                            config_data_save(s_save_mode, port);
                        }
                    }
                }
            }
        hmi_reset_loading_stage();  //完成加载标记
        break;
        default:
        break;
    }
#else
    switch (ucKeyID) {
        case 0x01U:
            f_need_save_data = 0;
            f_need_save_light_pro_data = 0;
            id = usU8ToU16(ucEvent, uuzLSB);    //主设备ID
            type = usU8ToU16(ucEvent + 2, uuzLSB);  //主设备类型
            port = usU8ToU16(ucEvent + 4, uuzLSB) - 1;  //设置的端口数据
            currtype = usU8ToU16(ucEvent + 6, uuzLSB);  //设置的端口类型
            LOG_D("Get Data:ID[%d]-Type[%d]-Port[%d]-currType[%d]", id, type, port, currtype);

            if (type == uuzDEV_SL_BRD) {    //如果是电源板数据
                //index = device_index_exist(&xDevSTA.xBrd[0], uuzDEV_BRD_MAX, xSysSTA.dev->id);
                if (port < uuzDEV_BRD_VALVE_MAX) {    //判断端口数量
                    if (xBoardCFG->valve[port].t != currtype) {  //如果端口数据有更新
                        prevtype = xBoardCFG->valve[port].t;    //缓存类型数据
#if 0
                        //NOTE:判断是否要更新灯光相关的数据
                        if (prevtype != uuzPORT_LIGHT) {   //如果原来不灯光模块切换到灯光模块
                            if (currtype == uuzPORT_LIGHT) {    //如果原来不是灯光串口，初始化灯光数据
                                lgt_config_add(xLgtPro.cfg[port]);    //如果由其他类型变成灯光类型，需要增加数据
                                f_need_save_light_pro_data = 1;  //处理灯光数据
                            }
                        } else {    //灯光模块类型切换到其他类型模块
                            lgt_config_init(xLgtPro.cfg[port]);  //情况相关数据
                            f_need_save_light_pro_data = 1;  //处理灯光数据
                        }
#endif
                        xBoardCFG->valve[port].t = currtype;  //更新端口类型数据
                        f_need_save_data = 1;   //有需要保存的数据
                        //value_cache_init();  //主板数据更新
                    }
                }

                u32 s_save_mode = 0;
                if (f_need_save_data == 1) {    //有需要保存的数据标记
                    valve_info_sync(xSysSTA.currPage, uuzDEV_BRD_VALVE_MAX,
                            &xBoardCFG->valve[0]);  //向UI更新修改后的数据
                    s_save_mode |= _S_CFG_BRD;  //保存Board数据IO数据
#if 0
                    if (f_need_save_light_pro_data == 1) {
                        s_save_mode |= _S_CFG_LGT;  //保存灯光相关数据
                    }
#endif
                    config_data_save(s_save_mode, port);
                }
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
        default:
            break;
    }
#endif
}
#endif

/**
 * @brief 加载传感器/执行设备/外设设备数据
 * @param ucKeyID
 * @param ucEvent
 */
void hmi_state_type_state_task(u8 ucKeyID, u8* ucEvent)
{
    switch (ucKeyID) {
        case 0x03U:
            xSysSTA.state_type = usU8ToU16(ucEvent, uuzLSB);  //当前显示的设备状态
            xSysSTA.currPage = usU8ToU16(ucEvent + 2, uuzLSB);
            LOG_D("Loading Device State![%d]", xSysSTA.state_type);
            if (xSysSTA.state_type == 0x01) {
                hmi_sensor_state_loading(xSysSTA.currPage);  //加载传感器列表参数
            } else if (xSysSTA.state_type == 0x02) {
                hmi_device_state_loading(xSysSTA.currPage);  //加载执行设备列表参数
            } else if (xSysSTA.state_type == 0x03) {
                hmi_external_state_loading(xSysSTA.currPage);  //加载外接设备列表参数
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
        default:
            break;
    }
}

/**
 *
 * @brief 调试电源板状态数据
 * @param ucKeyID
 * @param ucEvent
 */
void hmi_ui_debug_board_task(u8 ucKeyID, u8* ucEvent)
{
    u32 opt = 0;

    switch (ucKeyID) {
        case 0x00U:    //Manual-Single-OFF
            LOG_D("Manual-Single-OFF[%d]", ucEvent[0]);
            //rt_event_send(eventVALVE, (OPT_VLV_1_OFF << (ucEvent[0] * 2)));
            valve_opt(0, ucEvent[0], uuzOPT_OFF);  //独立关闭
            break;
        case 0x01U:    //Manual-Single-ON
            LOG_D("Manual-Single-ON[%d]", ucEvent[0]);
            //rt_event_send(eventVALVE, (OPT_VLV_1_ON << (ucEvent[0] * 2)));
            valve_opt(0, ucEvent[0], uuzOPT_ON);  //独立关闭
            break;
        case 0x02U:    //Manual-ALL-ON
            valve_broad_set(0, 0xFFFFU);
            break;
        case 0x03U:    //Manual-ALL-OFF
            valve_broad_set(0, 0x0000U);
            break;
        case 0x04U:    //Manual-Multi-ON/OFF
            opt = usU8ToU16(ucEvent, uuzLSB);
            //rt_event_send(eventVALVE, opt);
            break;
        default:
            break;
    }
}

/**
 *
 * @brief 调试蠕动泵状态数据
 * @param ucKeyID
 * @param ucEvent
 */
void hmi_ui_debug_dosing_task(u8 ucKeyID, u8* ucEvent)
{
    switch (ucKeyID) {
        case 0x00U:    //Manual-Single-OFF
            dosing_opt(ucEvent[0], uuzOPT_OFF);
            break;
        case 0x01U:    //Manual-Single-ON
            dosing_opt(ucEvent[0], uuzOPT_ON);
            break;
        case 0x02U:    //Manual-All-ON
            for (u8 index = 0; index < uuzDEV_DOS_MAX; index++) {
                dosing_opt(index, uuzOPT_ON);
                rt_thread_mdelay(50);
            }
            break;
        case 0x03U:    //Manual-All-OFF
            for (u8 index = 0; index < uuzDEV_DOS_MAX; index++) {
                dosing_opt(index, uuzOPT_OFF);
                rt_thread_mdelay(50);
            }
            break;
        default:
            break;
    }
}

/**
 * @brief 开锁密码输入界面
 * @param ucKeyID
 * @param ucEvent
 */
void hmi_ui_key_password_task(u8 ucKeyID, u8* ucEvent)
{
    u16 newpassword = uuzPIN_KEY_CNT;   //默认密码

    if (ucKeyID == 0x01U) {    //表示开锁状态更新成功
        xSysSTA.is_lock = ucEvent[0];    //更新锁定状态
        xSysSTA.tim_lock = 0;    //清除自动锁定延时标记
    } else if (ucKeyID == 0xFFU) {  //表示修改密码界面
        newpassword = usU8ToU16(ucEvent, uuzLSB);
        if (newpassword >= 0 && newpassword <= 9999) {
            if (newpassword != xSysCFG.lock_pin) {
                unlock_pin_set(newpassword);  //保存相关数据
                xSysSTA.is_lock = 1;  //自动锁定修改状态
                xSysSTA.tim_lock = 0;    //清除锁定状态
                hmi_auto_lock_sync();   //上报相关数据
            }
        }
    }
}

