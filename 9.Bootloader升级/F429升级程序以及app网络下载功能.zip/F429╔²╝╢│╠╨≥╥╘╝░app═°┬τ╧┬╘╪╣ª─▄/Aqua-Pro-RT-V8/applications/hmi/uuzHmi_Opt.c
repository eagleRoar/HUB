/* * @Copyright (c) 2006-2018 RT-Thread Development Team:
 * @SPDX-License-Identifier: Apache-2.0:  
 * @Date: 2020-01-01 09:23:03
 * @LastEditors  : Zhou Xiaomin
 * @LastEditTime : 2020-01-11 11:00:46
 * @Description:  
 */
/* Includes ------------------------------------------------------------------*/
#include <board.h>
#include <rtdevice.h>
/**************************************************************/
#include "uuzDevCfg.h"
#include "uuzEVENT.h"
#include "uuzGPIO.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzUART.h"
#include "uuzDevID.h"
/**************************************************************/
#include "uuzConfigBBL.h"
#include "uuzConfigDEV.h"
#include "uuzConfigHMI.h"
#include "uuzConfigPORT.h"
/**************************************************************/
#include "uuzEventHMI.h"
#include "uuzHMI_UI.h"
#include "uuzHmiTFT.h"
/**************************************************************/
#include "uuzEventUART.h"
#include "uuzEventDOSING.h"
#include "uuzEventLGT.h"
#include "uuzEventP260.h"
#include "uuzEventPROG.h"
#include "uuzEventSR.h"
#include "uuzEventVALVE.h"
#include "uuzEventWLS.h"
#include "uuzEventPROG.h"
/*Log---------------------------------------------*/
#define DBG_TAG "e.hopt"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/* ----------------------------------------------------------------*/
/**
 * @brief UI数据同步线程
 * 
 * @param parameter 
 */
void ui_sync_thread_entry(void* parameter)
{
    u32 recved = 0;
    u32 delay = 100;  //100ms
    hmi_ui_init();  //初始化HMI的UI数据

    //数据当前有效值
    while (1) {
        //是否加载HMI屏幕完成
        if (xSysSTA.hmi_init >= 5) {
            if (xSysSTA.is_init_data == 0) {
                if (recved == 0) {
                    //界面刷新数据
                    rt_event_recv(eventDATA,
                    UI_DATA_SYNC,
                            (RT_EVENT_FLAG_AND | RT_EVENT_FLAG_CLEAR),
                            delay,
                            &recved);
                }

                if (recved == 0) {
                    //界面刷新数据
                    rt_event_recv(eventDATA,
                    UI_STA_SYNC,
                            (RT_EVENT_FLAG_AND | RT_EVENT_FLAG_CLEAR),
                            delay,
                            &recved);
                }

                //有报警数据的情况下,执行相关动作
                if (recved == UI_DATA_SYNC) {
                    //LOG_D("ui sync:%d", recved);
                    //处理相关刷新信息信息
                    switch (xCurrUI.ucPageID) {
                        case uuzHMI_UI_MAIN:
                            hmi_value_sync();  //当前是主界面刷新实时数据
                            hmi_irr_sta_sync();  //当前设备工作状态刷新
                            break;
                        case uuzHMI_UI_WLS:
                        case uuzHMI_UI_IRR3:
                            hmi_level_value_sync(xSysSTA.curr_wls);  //水位数据实时数据
                            break;
                        case uuzHMI_UI_AUX1:                        //内部设备实时状态数据
                        case uuzHMI_UI_LGTB:                        //设备实时状态数据
                            hmi_board_value_sync();
                            hmi_resync_ui_stage(1);
                            break;
                        case uuzHMI_UI_CSS:
                            if (xSysSTA.state_type == 0x01U) {
                                hmi_sensor_state_loading(xSysSTA.currPage);                        //传感器界面状态
                            } else if (xSysSTA.state_type == 0x02U) {
                                hmi_device_state_loading(xSysSTA.currPage);                        //设备数据界面状态
                            } else if (xSysSTA.state_type == 0x03U) {
                                hmi_external_state_loading(xSysSTA.currPage);                        //设备数据界面状态
                            }
                            hmi_reset_loading_stage();                        //完成加载标记
                            break;
#if 0
                        case uuzHMI_UI_CSD:
                            hmi_device_state_loading(xSysSTA.currPage);                        //设备界面状态
                            hmi_reset_loading_stage();//完成加载标记
                            break;
                        case uuzHMI_UI_CSE:
                            hmi_external_state_loading(xSysSTA.currPage);//加载外接设备列表参数
                            hmi_reset_loading_stage();//完成加载标记
                            break;
#endif
                        case uuzHMI_UI_DBRD:
                            hmi_board_value_sync();                        //电源板调试界面数据显示
                            hmi_resync_ui_stage(1);                        //刷新界面数据
                            break;
                        case uuzHMI_UI_DDOS:
                            //蠕动泵调试界面数据显示
                            hmi_dosing_value_sync();
                            //刷新界面数据
                            hmi_resync_ui_stage(1);
                            break;
                        default:
                            break;
                    }
                } else if (recved == UI_STA_SYNC) {
                    LOG_D("state sync:%d", recved);
                    //处理相关刷新信息信息
                    //当前是主界面或设置界面都刷新实时状态
                    hmi_state_sync();
                    //发送运行阶段
                    hmi_schedule_state_sync();
                    //立即刷新界面数据
                    if ((xCurrUI.ucPageID == uuzHMI_UI_NUT00)
                            || (xCurrUI.ucPageID == uuzHMI_UI_NUT01)) {
                        hmi_resync_ui_stage(1);
                    }
                }
                //清空报警标记
                recved = 0;
            }
        } else {
            //延时计数
            //每500ms一次
            rt_thread_mdelay(500);
        }
    }
}

/**
 * @brief 启动UI的同步线程
 * 
 * @return int 
 */
int ui_sync_init(void)
{
    rt_err_t ret = RT_EOK;
    /* 创建界面刷新事件事件内容 */
    eventDATA = rt_event_create("et data", RT_IPC_FLAG_FIFO);

    /* 创建 serial 线程 */
    rt_thread_t thread = rt_thread_create("ui sync", ui_sync_thread_entry,
    RT_NULL, 2048, 15, 20);

    /* 创建成功则启动线程 */
    if (thread != RT_NULL) {
        rt_thread_startup(thread);
        LOG_D("start Thread [ui sync]");
    } else {
        LOG_E("start Thread [ui sync] failed");
        ret = RT_ERROR;
    }

    return ret;
}

/**
 * @brief 实时数据同步处理函数
 * 
 * @param parameter 
 */
void data_sync_thread_entry(void* parameter)
{
    static u32 delayCount = 1;
    u8 count = 0;
    //数据当前有效值
    //延时计数
    while (delayCount++) {
        if (xSysSTA.hmi_init >= 5) {    //等待初始化屏幕完成
            //等待相关数据发送
            if (delayCount % uuzTM_CURR_VALUE == 0) {            //1秒发送一次延时数据
                if (xSysSTA.is_init_data == 0) {  //配置状态重置阶段
                    lgt_daytime_judge();            //白天黑夜状态判断
                    for (count = 0; count < xDevSTA.usCountP260; count++) {            //营养池的水位相关数据判断
                        sinp260_judge(count,
                                xWlsPro->cfg[count].target,
                                xWlsPro->cfg[count].high,
                                xWlsPro->cfg[count].low);
                    }
                    if (xSysSTA.waiting_state == 3) {                //完成等待状态
                        //LOG_D("Startup-Preiod:%d-Time:%d", xSysSTA.waiting_state, xSysSTA.waiting_time);
                        uuz_vValue_DataProcessing();                //1秒进行一次检测，相关数据处理
                    }
                }
            }

            if (delayCount % uuzTM_SYNC_VALUE == 0) {                //500ms读取一次数据
                if ((xSysSTA.waiting_state == 1)
                        || (xSysSTA.waiting_state == 2)) {                //初始化界面读取
                    hmi_startup_waiting_preiod();
                    //Complete Event is 3
                }
            }
        }
        //每20ms一次
        rt_thread_mdelay(20);
    }
}

/**
 * @brief 启动实时数据线程
 *
 * @return int
 */
int data_sync_init(void)
{
    rt_err_t ret = RT_EOK;
    /* 创建 serial 线程 */
    rt_thread_t thread = rt_thread_create("data sync", data_sync_thread_entry,
    RT_NULL, 1024, 14, 20);

    /* 创建成功则启动线程 */
    if (thread != RT_NULL) {
        rt_thread_startup(thread);
        LOG_I("start Thread [data sync]");
    } else {
        LOG_E("start Thread [data sync] failed");
        ret = RT_ERROR;
    }

    return ret;
}

/**
 * @brief 操作蠕动泵同步处理函数
 *
 * @param parameter
 */
void opt_event_thread_entry(void* parameter)
{
    u32 recved = 0;
    u32 delay = 100;  //100ms
    //数据当前有效值
    //延时计数
    while (1) {
        //是否加载HMI屏幕完成
        if (xSysSTA.hmi_init >= 5) {    //等待初始化屏幕完成
            if (xSysSTA.is_init_data == 0) {
                if (recved == 0) {
                    //EC操作数据
                    rt_event_recv(eventOPT,
                    OPT_EC_ON,
                            (RT_EVENT_FLAG_AND | RT_EVENT_FLAG_CLEAR),
                            delay,
                            &recved);
                }
                if (recved == 0) {
                    //EC操作数据
                    rt_event_recv(eventOPT,
                    OPT_EC_OFF,
                            (RT_EVENT_FLAG_AND | RT_EVENT_FLAG_CLEAR),
                            delay,
                            &recved);
                }

                if (recved == 0) {
                    //pH+操作数据
                    rt_event_recv(eventOPT,
                    OPT_PHA_ON,
                            (RT_EVENT_FLAG_AND | RT_EVENT_FLAG_CLEAR),
                            delay,
                            &recved);
                }

                if (recved == 0) {
                    //pH-操作数据
                    rt_event_recv(eventOPT,
                    OPT_PHD_ON,
                            (RT_EVENT_FLAG_AND | RT_EVENT_FLAG_CLEAR),
                            delay,
                            &recved);
                }

                if (recved == 0) {
                    //pH关闭操作数据
                    rt_event_recv(eventOPT,
                    OPT_PH_OFF,
                            (RT_EVENT_FLAG_AND | RT_EVENT_FLAG_CLEAR),
                            delay,
                            &recved);
                }

                //有数据的情况下,执行相关动作
                if (recved) {
                    LOG_D("opt event:%d", recved);
                    //处理相关刷新信息信息
                    switch (recved) {
                        case OPT_EC_ON:  //开启EC蠕动泵
                            dosing_opt_group(
                                    (Dynamic_Single_Typedef_t *) progCache.prog.addr,
                                    _DOS_T_EC,
                                    uuzOPT_ON);
                            break;
                        case OPT_EC_OFF:  //关闭EC蠕动泵
                            dosing_opt_group(
                                    (Dynamic_Single_Typedef_t *) progCache.prog.addr,
                                    _DOS_T_EC,
                                    uuzOPT_OFF);
                            break;
                        case OPT_PHA_ON:  //开启pH+蠕动泵
                            dosing_opt_group(
                                    (Dynamic_Single_Typedef_t *) progCache.prog.addr,
                                    _DOS_T_PHA,
                                    uuzOPT_ON);
                            break;
                        case OPT_PHD_ON:  //开启pH-蠕动泵
                            dosing_opt_group(
                                    (Dynamic_Single_Typedef_t *) progCache.prog.addr,
                                    _DOS_T_PHD,
                                    uuzOPT_ON);
                            break;
                        case OPT_PH_OFF:  //关闭pH蠕动泵
                            if (progCache.pH.sta == 1) {
                                dosing_opt_group(
                                        (Dynamic_Single_Typedef_t *) progCache.prog.addr,
                                        _DOS_T_PHA,
                                        uuzOPT_OFF);
                            } else if (progCache.pH.sta == 2) {
                                dosing_opt_group(
                                        (Dynamic_Single_Typedef_t *) progCache.prog.addr,
                                        _DOS_T_PHD,
                                        uuzOPT_OFF);
                            }
                            break;
                        default:
                            break;
                    }
                    //清空操作标记
                    recved = 0;
                }
            }
        } else {
            //延时计数
            //每500ms一次
            rt_thread_mdelay(500);
        }
    }
}

/**
 * @brief 启动蠕动泵操作事件线程
 *
 * @return int
 */
int opt_event_init(void)
{
    rt_err_t ret = RT_EOK;
    /* 创建界面刷新事件事件内容 */
    eventOPT = rt_event_create("opt ent", RT_IPC_FLAG_FIFO);

    /* 创建 serial 线程 */
    rt_thread_t thread = rt_thread_create("opt event", opt_event_thread_entry,
    RT_NULL, 2048, 19, 20);

    /* 创建成功则启动线程 */
    if (thread != RT_NULL) {
        rt_thread_startup(thread);
        LOG_I("start Thread [opt_event]");
    } else {
        LOG_E("start Thread [opt_event] failed");
        ret = RT_ERROR;
    }

    return ret;
}

#if (uuzDEVICE_TYPE==_DEV_INNOVATION_ONLY||uuzDEVICE_TYPE==_DEV_INNOVATION)
/**
 * @brief 端口操作同步处理函数
 *
 * @param parameter
 */
void valve_event_thread_entry(void* parameter)
{
    rt_uint32_t recved = 0;
    u32 delay = 1000;  //100ms
    u32 single_opt = 0;
    u32 single_sta = 0;
    u32 single_flag = 0;
    //数据当前有效值
    //延时计数
    while (1) {
        //是否加载HMI屏幕完成
        if (xSysSTA.hmi_init >= 5) {
            if (xSysSTA.is_init_data == 0) {
                if (recved == 0) {
                    //端口操作数据
                    rt_event_recv(eventVALVE,
                            (OPT_VLV_1_ON | OPT_VLV_1_OFF    //开启或关闭端口1
                                    | OPT_VLV_2_ON | OPT_VLV_2_OFF    //开启或关闭端口2
                                    | OPT_VLV_3_ON | OPT_VLV_3_OFF    //开启或关闭端口3
                                    | OPT_VLV_4_ON | OPT_VLV_4_OFF    //开启或关闭端口4
                                    | OPT_VLV_5_ON | OPT_VLV_5_OFF    //开启或关闭端口5
                                    | OPT_VLV_6_ON | OPT_VLV_6_OFF    //开启或关闭端口6
                                    | OPT_VLV_7_ON | OPT_VLV_7_OFF    //开启或关闭端口AC
                            ),
                            (RT_EVENT_FLAG_OR | RT_EVENT_FLAG_CLEAR),
                            delay,
                            &recved);
                }

                if (recved) {
                    //处理相关刷新信息信息
                    if (recved & OPT_VLV_1_ON) {    //有端口1开启动作
                        //opt |= (0x0001U);
                        single_opt = 0;
                        single_sta = uuzOPT_ON;
                        single_flag = 1;
                        //LOG_D("Open Valve 1");
                        //valve_opt(xSysCFG.board_id, single_opt, uuzOPT_ON);  //独立打开
                    }
                    if (recved & OPT_VLV_1_OFF) {    //有端口1关闭动作
                        //opt = opt & (~0x0001U);
                        //LOG_D("Close Valve 1");
                        single_opt = 0;
                        single_sta = uuzOPT_OFF;
                        single_flag = 1;
                        //valve_opt(xSysCFG.board_id, single_opt, uuzOPT_OFF);  //独立关闭
                    }
                    if (recved & OPT_VLV_2_ON) {    //有端口2开启动作
                        //opt |= (0x0001U << 1);
                        //LOG_D("Open Valve 2");
                        single_opt = 1;
                        single_sta = uuzOPT_ON;
                        single_flag = 1;
                        //valve_opt(xSysCFG.board_id, single_opt, uuzOPT_ON);  //独立打开
                    }
                    if (recved & OPT_VLV_2_OFF) {    //有端口2关闭动作
                        //opt = opt & (~(0x0001U << 1));
                        //LOG_D("Close Valve 2");
                        single_opt = 1;
                        single_sta = uuzOPT_OFF;
                        single_flag = 1;
                        //valve_opt(xSysCFG.board_id, single_opt, uuzOPT_OFF);  //独立关闭
                    }
                    if (recved & OPT_VLV_3_ON) {    //有端口3开启动作
                        //opt |= (0x0001U << 2);
                        //LOG_D("Open Valve 3");
                        single_opt = 2;
                        single_sta = uuzOPT_ON;
                        single_flag = 1;
                        //valve_opt(xSysCFG.board_id, single_opt, uuzOPT_ON);  //独立打开
                    }
                    if (recved & OPT_VLV_3_OFF) {    //有端口3关闭动作
                        //opt = opt & (~(0x0001U << 2));
                        //LOG_D("Close Valve 3");
                        single_opt = 2;
                        single_sta = uuzOPT_OFF;
                        single_flag = 1;
                        //valve_opt(xSysCFG.board_id, single_opt, uuzOPT_OFF);  //独立关闭
                    }
                    if (recved & OPT_VLV_4_ON) {    //有端口4开启动作
                        //opt |= (0x0001U << 3);
                        single_opt = 3;
                        single_sta = uuzOPT_ON;
                        single_flag = 1;
                        //LOG_D("Open Valve 4");
                        //valve_opt(xSysCFG.board_id, single_opt, uuzOPT_ON);  //独立打开
                    }
                    if (recved & OPT_VLV_4_OFF) {    //有端口4关闭动作
                        //opt = opt & (~(0x0001U << 3));
                        //LOG_D("Close Valve 4");
                        single_opt = 3;
                        single_sta = uuzOPT_OFF;
                        single_flag = 1;
                        //valve_opt(xSysCFG.board_id, single_opt, uuzOPT_OFF);  //独立关闭
                    }
                    if (recved & OPT_VLV_5_ON) {    //有端口5开启动作
                        //opt |= (0x0001U << 4);
                        single_opt = 4;
                        single_sta = uuzOPT_ON;
                        single_flag = 1;
                        //LOG_D("Open Valve 5");
                        //valve_opt(xSysCFG.board_id, single_opt, uuzOPT_ON);  //独立打开
                    }
                    if (recved & OPT_VLV_5_OFF) {    //有端口5关闭动作
                        //opt = opt & (~(0x0001U << 4));
                        //LOG_D("Close Valve 5");
                        single_opt = 4;
                        single_sta = uuzOPT_OFF;
                        single_flag = 1;
                        //valve_opt(xSysCFG.board_id, single_opt, uuzOPT_OFF);  //独立关闭
                    }
                    if (recved & OPT_VLV_6_ON) {    //有端口6开启动作
                        //opt |= (0x0001U << 5);
                        single_opt = 5;
                        single_sta = uuzOPT_ON;
                        single_flag = 1;
                        //LOG_D("Open Valve 6");
                        //valve_opt(xSysCFG.board_id, single_opt, uuzOPT_ON);  //独立打开
                    }
                    if (recved & OPT_VLV_6_OFF) {    //有端口6关闭动作
                        //opt = opt & (~(0x0001U << 5));
                        //LOG_D("Close Valve 6");
                        single_opt = 5;
                        single_sta = uuzOPT_OFF;
                        single_flag = 1;
                        //valve_opt(xSysCFG.board_id, single_opt, uuzOPT_OFF);  //独立关闭
                    }

#if 0
                    if ((recved != OPT_VLV_7_ON) && (recved != OPT_VLV_7_OFF)) {
                        LOG_D("opt[%d]", opt);
                        if ((opt == (0x0001U << 1))
                                || (opt == (0x0001U << 2))
                                || (opt == (0x0001U << 3))
                                || (opt == (0x0001U << 4))
                                || (opt == (0x0001U << 5))) {
                            valve_opt(xSysCFG.board_id, single_opt, uuzOPT_ON);  //独立打开
                        } else {
                            valve_broad_set(0, opt);    //执行OPT动作
                        }
                    }
#endif

#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
                    if (recved & OPT_VLV_7_ON) {    //有端口AC开启动作
                        ac_valve_opt(uuzOPT_ON, 0x64);
                        LOG_D("Open Valve 7");
                    }
                    if (recved & OPT_VLV_7_OFF) {    //有端口AC关闭动作
                        ac_valve_opt(uuzOPT_OFF, 0x00);
                        LOG_D("Close Valve 7");
                    }
#else
                    LOG_D("event[%d] -- opt[%d]", recved, single_opt);
                    if ((recved != OPT_VLV_7_ON) && (recved != OPT_VLV_7_OFF)) {
                        if (single_flag) {
                            valve_opt(0, single_opt, single_sta);  //独立关闭
                            single_flag = 0;
                            single_sta = 0;
                        }
                    }
#endif
                    //刷新界面数据
                    rt_event_send(eventDATA, UI_DATA_SYNC);
                    //TODO:更新LOGO
                    //清空操作标记
                    recved = 0;
                }
            }
        } else {
            //延时计数
            //每500ms一次
            rt_thread_mdelay(500);
        }
    }
}

/**
 * @brief 启动端口操作事件线程
 *
 * @return int
 */
int valve_event_init(void)
{
    rt_err_t ret = RT_EOK;
    /* 创建界面刷新事件事件内容 */
    eventVALVE = rt_event_create("valve ent", RT_IPC_FLAG_FIFO);

    /* 创建 serial 线程 */
    rt_thread_t thread = rt_thread_create("valve event", valve_event_thread_entry,
    RT_NULL, 3000, 23, 20);

    /* 创建成功则启动线程 */
    if (thread != RT_NULL) {
        rt_thread_startup(thread);
        LOG_I("start Thread [valve_event]");
    } else {
        LOG_E("start Thread [valve_event] failed");
        ret = RT_ERROR;
    }

    return ret;
}
#endif

/**
 * @brief 报警数据界面触发函数
 *
 * @param parameter
 */
void alarm_sync_thread_entry(void* parameter)
{
    rt_uint32_t recved = 0;
    u32 delay = 100;  //100ms

    //数据当前有效值
    //延时计数
    while (1) {
        if (xSysSTA.is_init_data == 0) {
            if (recved == 0) {
                rt_event_recv(eventALM,
                        (
                        LV_NULL_EVENT    //水位无报警数据
                        | TA_NULL_EVENT    //Ta.无报警数据
                                | PH_NULL_EVENT    //pH无报警数据
                                | EC_NULL_EVENT    //EC无报警数据
                                | LV_L_EVENT    //水位低报警数据
                                | LV_H_EVENT  //水位高报警数据
                                | TA_H_EVENT  //温度高报警数据
                                | PH_L_EVENT  //pH低报警数据
                                | PH_H_EVENT  //pH高报警数据
                                | EC_H_EVENT  //EC报警数据
                        ),
                        (RT_EVENT_FLAG_OR | RT_EVENT_FLAG_CLEAR),
                        delay,
                        &recved);
            }

            //有报警数据的情况下,执行相关动作
            if (recved) {
                LOG_D("alarm data:%d", recved);
                //处理相关报警信息
                hmi_alarm_event_resolve(recved);
                //清空报警标记
                recved = 0;
            }
        }

        rt_thread_mdelay(20);
    }
}

/**
 * @brief 触发报警的事件
 * @return
 */
int alarm_sync_init(void)
{
    rt_err_t ret = RT_EOK;
    /* 创建事件内容 */
    eventALM = rt_event_create("et alarm", RT_IPC_FLAG_FIFO);

    /* 创建 serial 线程 */
    rt_thread_t thread = rt_thread_create("alarm sync", alarm_sync_thread_entry,
    RT_NULL, 2048, 23, 20);

    /* 创建成功则启动线程 */
    if (thread != RT_NULL) {
        rt_thread_startup(thread);
        LOG_I("start Thread [alarm sync]");
    } else {
        LOG_E("start Thread [alarm sync] failed");
        ret = RT_ERROR;
    }

    return ret;
}

/**
 *
 * @brief  发送复位指令到HMI屏幕使其重置
 * 			@note   IO: GPIO-B,12
 *
 */
void hmi_hw_reset(void)
{
    rt_pin_write(HMI_RST_PIN, PIN_LOW);
    rt_thread_delay(300);
    rt_pin_write(HMI_RST_PIN, PIN_HIGH);
    LOG_I("Reboot HMI");
}
/**
 * @brief:   关于启动延时的判断
 * @returns:   NULL
 */
void hmi_startup_waiting_preiod(void)
{
    //在主页上显示相关弹出信息
    //完成初始化后，再等待倒计时15秒稳定数据
    if (xSysSTA.waiting_state == 1) {
        xSysSTA.waiting_time++;
        if ((xSysSTA.waiting_time % 2) == 0) {
            hmi_self_check_time(xSysSTA.waiting_state,
                    ((uuzDEV_SELF_CHECK_TIME - xSysSTA.waiting_time) / 2));
        }

        //延时15秒,完成初始化指令
        if (xSysSTA.waiting_time == uuzDEV_SELF_CHECK_TIME) {
            xSysSTA.waiting_time = 0;
            xSysSTA.waiting_state++;
            hmi_self_check_time(xSysSTA.waiting_state, 0);
            LOG_I("Device startup completed");
        }
    } else if (xSysSTA.waiting_state == 2) {
        //清空数据
        xSysSTA.waiting_time = 0;
        //清空日志显示框
        xSysSTA.waiting_state++;  //最后值=3
        hmi_self_check_time(xSysSTA.waiting_state, 0);
    }
}

/**
 * @brief HMI串口发送函数
 *
 * @param pcCommand 需要发送的数据内容
 */
void hmi_command(char* pcCommand)
{
    if (pcCommand != NULL) {
        //LOG_I(pcCommand);
        u8 ucTmpCommand[uuzUART_LEN];
        u8 ucLenCommand = 0;
        u8 ucEnd[3] =
                    { 0xFF, 0xFF, 0xFF };
        ucLenCommand = rt_strlen(pcCommand);
        rt_memcpy(ucTmpCommand, (u8*) pcCommand, ucLenCommand);
        rt_memcpy((ucTmpCommand + ucLenCommand), ucEnd, 3);  //末尾补3个0xFF
        ucLenCommand += 3;
        rt_uart_send(&xUartE.uart[uuzUART_1], ucTmpCommand, ucLenCommand);
    }
}

/**
 * @brief HMI全局变量赋值动作
 *
 * @param pcSYS 需要赋值的全局变量名称
 * @param ulVal 需要赋值的全局变量内容
 */
void hmi_sys_send(char* pcSYS, u32 ulVal)
{
    char cTmpData[uuzUART_LEN / 2];
    rt_sprintf(cTmpData, "%s=%d", pcSYS, ulVal);
    hmi_command(cTmpData);
    //LOG_D(cTmpData);
    rt_thread_mdelay(2);
}

/**********************************************************************************************//**
 *
 * @brief	发送文本给HMI屏幕
 *
 * @author	Zhou Xiaomin
 * @date	2019/12/30
 *
 * @param [in,out]	pcUI	 	.
 * @param [in,out]	pcID	 	.
 * @param [in,out]	pcContent	.
 **************************************************************************************************/

void hmi_txt_send(char* pcUI, char* pcID, char* pcContent)
{
    char cTmpData[uuzUART_LEN];
    rt_sprintf(cTmpData, "%s.%s.txt=\"%s\"", pcUI, pcID, pcContent);
    hmi_command(cTmpData);
    rt_thread_delay(4);
}

/**********************************************************************************************//**
 *
 * @brief	将数值转换成文本发送给HMI屏幕
 *
 * @author	Zhou Xiaomin
 * @date	2019/12/30
 *
 * @param [in,out]	pcUI 	.
 * @param [in,out]	pcID 	.
 * @param 		  	ulVal	.
 **************************************************************************************************/
void hmi_val2txt_send(char* pcUI, char* pcID, u32 ulVal)
{
    char cTmpData[uuzUART_LEN];
    rt_sprintf(cTmpData, "%s.%s.txt=\"%d\"", pcUI, pcID, ulVal);
    hmi_command(cTmpData);
    rt_thread_delay(4);
}

/**********************************************************************************************//**
 *
 * @brief	发送数值给HMI屏幕
 *
 * @author	Zhou Xiaomin
 * @date	2019/12/30
 *
 * @param [in,out]	pcUI 	.
 * @param [in,out]	pcID 	.
 * @param 		  	ulVal	.
 **************************************************************************************************/
void hmi_val_send(char* pcUI, char* pcID, u32 ulVal)
{
    char cTmpData[uuzUART_LEN];
    rt_sprintf(cTmpData, "%s.%s.val=%d", pcUI, pcID, ulVal);
    hmi_command(cTmpData);
    rt_thread_delay(2);
}

/**********************************************************************************************//**
 *
 * @brief	在HMI上更新某条表数据
 *
 * @author	Zhou Xiaomin
 * @date	2019/12/30
 *
 * @param [in,out]	pcUI	 	.
 * @param [in,out]	pcBox	 	.
 * @param [in,out]	pcContent	.
 * @param 		  	ulIndex  	.
 **************************************************************************************************/

void hmi_box_up(char* pcUI, char* pcBox, char* pcContent, u32 ulIndex)
{
    char cTmpData[uuzUART_LEN];
    rt_sprintf(cTmpData, "%s.%s.up(\"%s\",%d)", pcUI, pcBox, pcContent, ulIndex);
    hmi_command(cTmpData);
    rt_thread_delay(2);
}

/**********************************************************************************************//**
 *
 * @brief	给表插入一个新数据
 *
 * @author	Zhou Xiaomin
 * @date	2019/12/30
 *
 * @param [in,out]	pcUI	 	.
 * @param [in,out]	pcBox	 	.
 * @param [in,out]	pcContent	.
 **************************************************************************************************/

void hmi_box_insert(char* pcUI, char* pcBox, char* pcContent)
{
    char cTmpData[uuzUART_LEN * 2];
    rt_sprintf(cTmpData, "%s.%s.insert(\"%s\")", pcUI, pcBox, pcContent);
    hmi_command(cTmpData);
    rt_thread_delay(2);
}

/**
 * @brief 触发事件
 * @param event:事件名称
 * @param state:事件状态0/1
 */
void hmi_event_send(char* event, u8 state)
{
    char cTmpData[uuzUART_LEN];
    rt_sprintf(cTmpData, "click %s,%d", event, state);
    hmi_command(cTmpData);
    rt_thread_delay(4);
}

/**
 * @brief hmi_data_head_is_assert
 * @param ucCode
 * @return
 */
u8 hmi_data_head_is_assert(u8 ucCode)
{
    if (  // HMI EVENT_CODE
    (ucCode == uuzHMI_TOUCH)  //触摸标记事件
    || (ucCode == uuzHMI_PAGE_ID)  //页面编号
            || (ucCode == uuzHMI_TOUCH_XY)  //触摸XY坐标
            || (ucCode == uuzHMI_SLEEP_XY)  //睡眠触发事件
            || (ucCode == uuzHMI_GET_TXT)  //字符串变量数据返回
            || (ucCode == uuzHMI_GET_VAL)  //数值变量数据返回
            || (ucCode == uuzHMI_AUTO_SLEEP)  //设备自动进入睡眠模式
            || (ucCode == uuzHMI_AUTO_AWAKEN)  //设备自动唤醒
            || (ucCode == uuzHMI_POWER_ON)  //系统启动成功
            || (ucCode == uuzHMI_SD_UPDATE)  //开始SD卡升级
            || (ucCode == uuzHMI_TRANSMIT_SUC)  //透传数据完成
            || (ucCode == uuzHMI_TRANSMIT_RDY)  //数据透传就绪
            ) {
        return (RT_TRUE);
    } else {
        return (RT_FALSE);
    }
}

/**
 * @brief 检测末尾的换行符是否HMI命令的0xFF/0xFF/0xFF
 * @param data
 * @return
 */
rt_err_t hmi_data_end_is_assert(u8 * data)
{
    //判断协议是否完成
    return ((data[0] == 0xFFU) && (data[1] == 0xFFU) && (data[2] == 0xFFU))
           ? (RT_TRUE) : (RT_FALSE);
}
/**
 * @brief 根据页面ID读取相应的页面名称
 * @param page:读取到的页面名称
 * @param id:页面ID
 * @return 读取成功：RT_TRUE/读取失败：RT_FALSE
 */
u8 hmi_page_is_assert(char * page, u32 id)
{
    u8 result = RT_TRUE;

    switch (id)
    {
        case uuzHMI_UI_TIP:
            strcpy(page, "tip");
            break;
        case uuzHMI_UI_KEY:
            strcpy(page, "key");
            break;
        case uuzHMI_UI_DST:
            strcpy(page, "dst");
            break;
        case uuzHMI_UI_TST:
            strcpy(page, "tst");
            break;
        case uuzHMI_UI_TIM:
            strcpy(page, "tim");
            break;
        case uuzHMI_UI_BG:
            strcpy(page, "bg");
            break;
        case uuzHMI_UI_MAIN:
            strcpy(page, "main");
            break;
        case uuzHMI_UI_NUT00:
            strcpy(page, "nut00");
            break;
        case uuzHMI_UI_NUT01:
            strcpy(page, "nut01");
            break;
        case uuzHMI_UI_NUT1:
            strcpy(page, "nut1");
            break;
        case uuzHMI_UI_NUT2:
            strcpy(page, "nut2");
            break;
        case uuzHMI_UI_NUT3:
            strcpy(page, "nut3");
            break;
        case uuzHMI_UI_NUT4:
            strcpy(page, "nut4");
            break;
        case uuzHMI_UI_PPS:
            strcpy(page, "pps");
            break;
        case uuzHMI_UI_SCH:
            strcpy(page, "sch");
            break;
        case uuzHMI_UI_GTIP:
            strcpy(page, "gtip");
            break;
        case uuzHMI_UI_IRRB:
            strcpy(page, "irrb");
            break;
        case uuzHMI_UI_IRRA:
            strcpy(page, "irrA");
            break;
        case uuzHMI_UI_IRR1:
            strcpy(page, "irr1");
            break;
        case uuzHMI_UI_DRN1:
            strcpy(page, "drn1");
            break;
        case uuzHMI_UI_IRR2:
            strcpy(page, "irr2");
            break;
        case uuzHMI_UI_DRN2:
            strcpy(page, "drn2");
            break;
        case uuzHMI_UI_IRR3:
            strcpy(page, "irr3");
            break;
        case uuzHMI_UI_DRN3:
            strcpy(page, "drn3");
            break;
        case uuzHMI_UI_IRR4M:
            strcpy(page, "irr3m");
            break;
        case uuzHMI_UI_IRR4C:
            strcpy(page, "irr3c");
            break;
        case uuzHMI_UI_IRR4T:
            strcpy(page, "irr3t");
            break;
        case uuzHMI_UI_DRN4M:
            strcpy(page, "drn3m");
            break;
        case uuzHMI_UI_DRN4C:
            strcpy(page, "drn3c");
            break;
        case uuzHMI_UI_DRN4T:
            strcpy(page, "drn3t");
            break;
        case uuzHMI_UI_WLSB:
            strcpy(page, "wlsB");
            break;
        case uuzHMI_UI_WLS:
            strcpy(page, "wls");
            break;
        case uuzHMI_UI_WLSP:
            strcpy(page, "wlsP");
            break;
        case uuzHMI_UI_LGTB:
            strcpy(page, "lgtB");
            break;
        case uuzHMI_UI_LGT1:
            strcpy(page, "lgt1");
            break;
        case uuzHMI_UI_LGT2:
            strcpy(page, "lgt2");
            break;
        case uuzHMI_UI_LGT3:
            strcpy(page, "lgt3");
            break;
        case uuzHMI_UI_AUX1:
            strcpy(page, "aux1");
            break;
        case uuzHMI_UI_AUXA:
            strcpy(page, "auxa");
            break;
        case uuzHMI_UI_DEV1:
            strcpy(page, "dev1");
            break;
        case uuzHMI_UI_DEV2:
            strcpy(page, "dev2");
            break;
        case uuzHMI_UI_DEV3:
            strcpy(page, "dev3");
            break;
        case uuzHMI_UI_CSS:
            strcpy(page, "css");
            break;
#if 0
            case uuzHMI_UI_CSD:
            strcpy(page, "csd");
            break;
            case uuzHMI_UI_CSE:
            strcpy(page, "cse");
            break;
#endif
        case uuzHMI_UI_LOGM:
            strcpy(page, "logm");
            break;
        case uuzHMI_UI_LOG1:
            strcpy(page, "log1");
            break;
        case uuzHMI_UI_TAB1:
            strcpy(page, "tab1");
            break;
        case uuzHMI_UI_TAB2:
            strcpy(page, "tab2");
            break;
        case uuzHMI_UI_TAB3:
            strcpy(page, "tab3");
            break;
        case uuzHMI_UI_TAB4:
            strcpy(page, "tab4");
            break;
        case uuzHMI_UI_SYSD:
            strcpy(page, "sysd");
            break;
        case uuzHMI_UI_SYST:
            strcpy(page, "syst");
            break;
        case uuzHMI_UI_CEC:
            strcpy(page, "cec");
            break;
        case uuzHMI_UI_CPH:
            strcpy(page, "cph");
            break;
        case uuzHMI_UI_INIT:
            strcpy(page, "init");
            break;
        case uuzHMI_UI_DBRD:
            strcpy(page, "dbrd");
            break;
        case uuzHMI_UI_DDOS:
            strcpy(page, "ddos");
            break;
        case uuzHMI_UI_GLOBAL:
            strcpy(page, "global");
            break;
        default:
            result = RT_FALSE;  //没有找到对应页面数据
            break;
    }

    //LOG_D("P[%d]:%s", id, page);

    return result;
}

/**
 * @brief 根据设备类型读取相应的类型名称
 * @param cmd:读取到的类型名称
 * @param type:类型ID
 * @return 读取成功：RT_TRUE/读取失败：RT_FALSE
 */
u8 hmi_type_is_assert(char * cmd, u32 type)
{
    u8 result = RT_TRUE;

    switch (type)
    {
        case uuzDEV_SL_SCD30:
            case uuzDEV_SL_S8:  //CO2传感器类型
            strcpy(cmd, "CO2-SR");
            break;
        case uuzDEV_SL_SHT30:   //湿度传感器类型
            strcpy(cmd, "H&T-SR");
            break;
        case uuzDEV_SL_LDA1:    //灯光模块类型
            strcpy(cmd, "LDA-1");
            break;
        case uuzDEV_SL_DOS:  //蠕动泵类型
            strcpy(cmd, "DOSING");
            break;
        case uuzDEV_SL_BRD:  //电源IO板类型
            strcpy(cmd, "BOARD");
            break;
        case uuzDEV_SL_ACO:  //默认的AC-Station的CO2模块
            strcpy(cmd, "AC-CO2");
            break;
        case uuzDEV_SL_ATA:  //AC-Station的加热温度模块
            strcpy(cmd, "AC-HOT");
            break;
        case uuzDEV_SL_AHT:  //AC-Station的增湿模块
            strcpy(cmd, "AC-HT");
            break;
        case uuzDEV_SL_ADH:  //AC-Station的除湿模块
            strcpy(cmd, "AC-DEHT");
            break;
        case uuzDEV_SL_ACT:  //AC-Station的温度模块
            strcpy(cmd, "AC-COOL");
            break;
        case uuzDEV_SL_TRAY:    //红外温度控制模块
            strcpy(cmd, "RAY-TA");
            break;
        case uuzDEV_SL_HRAY:    //红外湿度控制模块
            strcpy(cmd, "RAY-H&T");
            break;
        case uuzDEV_SL_PHECB2:  //PHEC-B2模块
            strcpy(cmd, "PHEC-B2");
            break;
        case uuzDEV_SL_P260:  //联测水位模块模块
            strcpy(cmd, "LEVEL-SR");
            break;
        case uuzDEV_SL_CFKT:   //除湿机1(RS485)
            strcpy(cmd, "CF-KT");
            break;
        case uuzDEV_SL_YC10S:   //除湿机2(RS485)
            strcpy(cmd, "YC-10S");
            break;
        case uuzDEV_SL_T003:   //空调机1(RS485)
            strcpy(cmd, "T-003");
            break;
        case uuzDEV_SL_DF34B:   //空调机2(RS485)
            strcpy(cmd, "DF-34BMS");
            break;
        case uuzDEV_SL_FLAR:   //空调面板(RS485)
            strcpy(cmd, "FL-AR");
            break;
        case uuzDEV_SL_SL1600F:   //SL-1600F(RS485)
            strcpy(cmd, "SL-1600F");
            break;
        case uuzDEV_SL_HVAC:   //HVAC(RS485)
            strcpy(cmd, "HVAC");
            break;
        default:
            strcpy(cmd, "UNKNOWN");
            result = RT_FALSE;  //没有找到对应类型数据
            break;
    }

    return result;
}

/**
 * @brief 根据端口类型读取相应的类型名称
 * @param cmd:读取到的名称
 * @param type:类型
 * @return 读取成功：RT_TRUE/读取失败：RT_FALSE
 */
u8 hmi_port_type_is_assert(char * cmd, u32 type)
{
    u8 result = RT_TRUE;

    switch (type)
    {
        case uuzPORT_CO2:  //CO2端口
            strcpy(cmd, "CO2");
            break;
        case uuzPORT_HEAT:  //加热端口
            strcpy(cmd, "HEAT");
            break;
        case uuzPORT_COOL:  //制冷端口
            strcpy(cmd, "COOL");
            break;
        case uuzPORT_HUMI:  //增湿端口
            strcpy(cmd, "HUMIDIFY");
            break;
        case uuzPORT_DEHUMI:  //除湿端口
            strcpy(cmd, "DEHUMIDIFY");
            break;
        case uuzPORT_LIGHT:  //线路1端口
            strcpy(cmd, "LIGHT");
            break;
        case uuzPORT_ALARM:  //报警端口
            strcpy(cmd, "ALARM");
            break;
        case uuzPORT_FAN_L:  //风机端口(Low)
            strcpy(cmd, "FAN LOW");
            break;
        case uuzPORT_FAN_M:  //风机端口(Middle)
            strcpy(cmd, "FAN MID");
            break;
        case uuzPORT_FAN_H:  //风机端口(High)
            strcpy(cmd, "FAN HIGH");
            break;
        case uuzPORT_IRR_FLOOD:  //灌溉端口
            strcpy(cmd, "IRR FLOOD");
            break;
        case uuzPORT_IRR_DRAIN:  //回水端口
            strcpy(cmd, "IRR DRAIN");
            break;
        case uuzPORT_IRR_IN:  //补水端口
            strcpy(cmd, "IRR IN");
            break;
        case uuzPORT_IRR_QUALITY:  //检测端口
            strcpy(cmd, "IRR QUAL");
            break;
        case uuzPORT_IRR_MIX:  //混合端口
            strcpy(cmd, "IRR MAX");
            break;
        case uuzPORT_TIMER:  //定时器
            strcpy(cmd, "TIMER");
            break;
        case uuzPORT_CYCLE:  //定时器
            strcpy(cmd, "CYCLE");
            break;
        case uuzPORT_FAN:  //风扇
            strcpy(cmd, "FAN");
            break;
        default:
            strcpy(cmd, "UNKNOWN");
            result = RT_FALSE;  //没有找到对应类型数据
            break;
    }

    return result;
}

/**
 * @brief 根据端口类型读取相应的类型名称
 * @param cmd:读取到的名称
 * @param type:类型
 * @return 读取成功：RT_TRUE/读取失败：RT_FALSE
 */
u8 hmi_box_port_type_is_assert(char * cmd, u8 index)
{
    u8 result = RT_TRUE;

    switch (index)
    {
        case 0:
            strcpy(cmd, "IRR MIX");
            break;
        case 1:
            strcpy(cmd, "IRR OUT");
            break;
        case 2:
            strcpy(cmd, "IRR IN 1");
            break;
        case 3:
            strcpy(cmd, "IRR IN 2");
            break;
        case 4:
            strcpy(cmd, "IRR POOL 2");
            break;
        case 5:
            strcpy(cmd, "IRR POOL 1");
            break;
        default:
            break;
    }

    return result;
}

/**********************************************************************************************//**
 *
 * @brief	HMI串口信息处理函数
 *
 * @author	Zhou Xiaomin
 * @date	2019/12/30
 *
 * @param 	ucRxCode 从HMI接收到的数据
 **************************************************************************************************/
void hmi_receive_data(u8* ucRxCode, u8 * ucTxCode)
{
    u8 ucHeadCode = 0;
    u8 ucLenCommand = 0x00U;
    char page[16];

    if (ucRxCode) {
        ucHeadCode = ucRxCode[0];
        switch (ucHeadCode) {
            case uuzBBL_HEAD:
                //自定义协议头
                //初始化数据
                ucLenCommand = ucRxCode[1];  //读取长度
                xCurrUI.ucPageID = ucRxCode[2];  //页面参数
                xCurrUI.ucKeyID = ucRxCode[3];  //读取操作焦点
                hmi_page_is_assert(page, ucRxCode[2]);
                LOG_D("LEN[%d]-PID[%d][%s]-CMD[%d]", ucRxCode[1], ucRxCode[2], page, ucRxCode[3]);
                if ((ucLenCommand - 2) > 0) {
                    rt_memcpy(xCurrUI.ucEvent, (ucRxCode + 4), (ucLenCommand - 2));  //需要操作的ID
                } else {
                    xCurrUI.ucEvent[0] = '0';
                }
                //保存界面编号
                if (rt_memcmp(&xCurrUI, &xPrevUI, sizeof(HMI_Typedef_t)) != 0) {
                    //存储原来的编号ID
                    rt_memcpy(&xPrevUI, &xCurrUI, sizeof(HMI_Typedef_t));
                }
                //根据界面处理事件
                switch (xCurrUI.ucPageID) {
                    case uuzHMI_UI_MAIN:  //主菜单界面-
                        hmi_ui_main_task(xCurrUI.ucKeyID, xCurrUI.ucEvent);
                        break;
                    case uuzHMI_UI_NUT00:  //周期表设置前置界面
                        hmi_ui_nut_schedule_task(xCurrUI.ucKeyID, xCurrUI.ucEvent);
                        break;
                    case uuzHMI_UI_NUT01:  //程序设置前置界面
                        hmi_ui_nut_program_task(xCurrUI.ucKeyID, xCurrUI.ucEvent);
                        break;
                    case uuzHMI_UI_NUT4:
                        hmi_ui_nut_fixed_task(xCurrUI.ucKeyID, xCurrUI.ucEvent);
                        break;
                    case uuzHMI_UI_TIP:  //提示界面
                        hmi_ui_tip_task(xCurrUI.ucKeyID, xCurrUI.ucEvent, (ucLenCommand - 2));
                        break;
                    case uuzHMI_UI_PPS:  //Dosing统一参数设置界面
                        hmi_ui_nut_pps_set_task(xCurrUI.ucKeyID, xCurrUI.ucEvent);
                        break;
                    case uuzHMI_UI_IRRB:  //灌溉端口配置选择界面

                        hmi_ui_irr_port_set_task(xCurrUI.ucKeyID, xCurrUI.ucEvent);
                        break;
                    case uuzHMI_UI_LGTB:  //设备配置选择界面
                        hmi_ui_light_port_set_task(xCurrUI.ucKeyID, xCurrUI.ucEvent);
                        break;
                    case uuzHMI_UI_AUX1:  //外设设备信息菜单界面
                        hmi_ui_aux_menu_task(xCurrUI.ucKeyID, xCurrUI.ucEvent);
                        break;
                    case uuzHMI_UI_AUXA:  //外设统一生成界面
                        //hmi_ui_aux_port_set_task(xCurrUI.ucKeyID, xCurrUI.ucEvent);
                        break;
                    case uuzHMI_UI_WLS:
                        hmi_ui_water_supply_set_task(xCurrUI.ucKeyID, xCurrUI.ucEvent);
                        break;
                    case uuzHMI_UI_CSS:  //传感器/执行机构/外设状态界面
                        hmi_state_type_state_task(xCurrUI.ucKeyID, xCurrUI.ucEvent);
                        break;
                    case uuzHMI_UI_INIT:  //初始界面
                        hmi_ui_init_task(xCurrUI.ucKeyID, xCurrUI.ucEvent);
                        break;
                    case uuzHMI_UI_DBRD:
                        hmi_ui_debug_board_task(xCurrUI.ucKeyID, xCurrUI.ucEvent);
                        break;
                    case uuzHMI_UI_DDOS:
                        hmi_ui_debug_dosing_task(xCurrUI.ucKeyID, xCurrUI.ucEvent);
                        break;
                    case uuzHMI_UI_KEYPW:
                        hmi_ui_key_password_task(xCurrUI.ucKeyID, xCurrUI.ucEvent);
                        break;
                    case uuzHMI_UI_GLOBAL:
                        hmi_ui_global_task(xCurrUI.ucKeyID, xCurrUI.ucEvent);  //全局操作函数
                        break;
                    default:
                        break;
                }
                break;
            case uuzHMI_TOUCH:
                //触摸事件
                break;
            case uuzHMI_PAGE_ID:
                //更新UI信息
                xCurrUI.ucPageID = ucRxCode[1];  //页面参数
                if (rt_memcmp(&xCurrUI, &xPrevUI, sizeof(HMI_Typedef_t)) != 0) {
                    //存储原来的编号ID
                    rt_memcpy(&xPrevUI, &xCurrUI, sizeof(HMI_Typedef_t));
                }
                //切换界面时，立即刷新数据处理
                switch (xCurrUI.ucPageID) {
                    case uuzHMI_UI_BG:  //加载界面-
                    case uuzHMI_UI_MAIN:  //主菜单界面-
                        //第一次进入主界面，准备进入倒计数
                        if (xSysSTA.waiting_state == 0) {
                            xSysSTA.waiting_time = 0;
                            xSysSTA.waiting_state = 1;
                        }
                        LOG_D("Change UI[%d], Sync UI.", xCurrUI.ucPageID);
                        //立即刷新界面程序
                        rt_event_send(eventDATA, UI_DATA_SYNC);
                        break;
                    case uuzHMI_UI_DRN1:    //回水界面-气雾培
                    case uuzHMI_UI_DRN3:    //回水界面-潮汐式
                    case uuzHMI_UI_VAL:    //缓存数据界面
                    case uuzHMI_UI_NUT00:   //配肥界面
                    case uuzHMI_UI_NUT01:   //配肥界面
                        rt_event_send(eventDATA, UI_DATA_SYNC);
                        break;
                    case uuzHMI_UI_DBRD:
                        //电源板调试界面数据显示
                        hmi_board_value_sync();
                        break;
                    case uuzHMI_UI_DDOS:
                        //蠕动泵调试界面
                        hmi_dosing_value_sync();
                        break;
                    default:
                        break;
                }
                break;
            case uuzHMI_GET_TXT:
                //接收HMI数据
                if (ucRxCode[1] == uuzHMI_UI_BG) {
                    LOG_I("Need Reboot CPU!");
                    //当屏幕重启后，同步重启主板恢复通讯
                    if (xSysSTA.hmi_init >= 5) {
                        rt_hw_cpu_reset();
                    }
                }
                break;
            default:
                break;
        }
    }
}

/*-----------------------------------------------------------------*/
