/**
 * @file uuzHMI_Value.c
 * @author your name (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2020-04-13
 * 
 * @copyright Copyright (c) 2020
 * 
 */
/* Includes -------------------------------------------------------*/
#include <rtthread.h>
/* ----------------------------------------------------------------*/
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
/* ----------------------------------------------------------------*/
#include "uuzEventHMI.h"
#include "uuzHMI_UI.h"
/* ----------------------------------------------------------------*/
#include "uuzEventDOSING.h"
#include "uuzEventIRR.h"
#include "uuzEventLGT.h"
#include "uuzEventP260.h"
#include "uuzEventPHEC.h"
#include "uuzEventPROG.h"
#include "uuzEventWLS.h"
#include "uuzEventTIM.h"
/* ----------------------------------------------------------------*/
#include "uuzEEPROM.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzRTC.h"
/*log--------------------------------------------------------------*/
#define DBG_TAG "hmi.val"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/* ----------------------------------------------------------------*/
/**
 * @brief 检查Value的相关数据,获取设备最终状态
 * 
 */
void uuz_vValue_DataProcessing(void)
{
    prog_running_event();  //读取程序运行线程
    lgt_opt_event();    //灯光参数判断
    wls_auto_fill_judge(0);    //营养池自动补水参数判断
    irr_pro_judge(&xIrrCache[0], &xIrrPro->pro[0], 0);  //更新灌溉数据
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
    wls_auto_fill_judge(1);    //营养池自动补水参数判断
    irr_pro_judge(&xIrrCache[1], &xIrrPro->pro[1], 0);  //更新清水池数据
#endif
    tim_opt_judge(xTimPro.cfg[0], &xTimSta[0], 0);
    tim_opt_judge(xTimPro.cfg[1], &xTimSta[1], 1);
}

/**
 * @brief 发送全部数据到HMI界面上
 * 
 */
void hmi_value_sync(void)
{
    char cmd[24];
    u8 index = 0;
    u8 connect_state = uuzDEV_NOCONNECT;

    //向HMI屏幕发送实时数据
    if (xDevSTA.usCountB2) {  //有PHEC-B2的相关设备
        index = device_index_exist(&xDevSTA.xB2[0], uuzDEV_PHEC_B2_MAX, xSysCFG.pehc_id);  //判断设备数据在缓存中的位置
        if (index < uuzDEV_PHEC_B2_MAX) {   //如果是有效的数据
            if (xDevSTA.xB2[index].isconnect == uuzDEV_CONNECTED) {
                hmi_curr_value_sync(
                        xPhecB2Value[index].usVal_ec,
                        xPhecB2Value[index].usVal_pH,
                        xPhecB2Value[index].usVal_Tp);
                connect_state = uuzDEV_CONNECTED;   //标记连接状态
            }
        }
    }
    //没有连接状态
    if (connect_state == uuzDEV_NOCONNECT) {
        //在HMI屏幕上显示“----”
        hmi_txt_send("main", "ecV", "----");
        hmi_txt_send("main", "phV", "----");
        hmi_txt_send("main", "tpV", "----");
    }

    connect_state = uuzDEV_NOCONNECT;
    if (xDevSTA.usCountP260) {
        index = device_index_exist(&xDevSTA.xP260[0], uuzDEV_SIN_P260_MAX, xSysCFG.pool_id[0]);  //判断设备数据在缓存中的位置
        if (index < uuzDEV_SIN_P260_MAX) {   //如果是有效的数据
            if (xDevSTA.xP260[index].isconnect == uuzDEV_CONNECTED) {
                u32 inch = xP260Value[index].high;  //当前读取到的数据
                if (xSysCFG.unit_lv == uuzLV_INCH) {
                    inch = mm_and_inch_to(0, inch);
                    rt_sprintf(cmd, "%d.%d in", inch / 10, inch % 10);
                } else {
                    rt_sprintf(cmd, "%d.%02d m", inch / 1000, ((inch % 1000) / 10));
                }
                hmi_txt_send("main", "lvV", cmd);
                connect_state = uuzDEV_CONNECTED;   //标记连接状态
            }
        }
    }
    //没有连接状态
    if (connect_state == uuzDEV_NOCONNECT) {
        //在HMI屏幕上显示“----”
        hmi_txt_send("main", "lvV", "----");
    }
    //显示实际的水位状态
    hmi_sys_send("s_level", xP260Value[index].out);
    //发送白天黑夜界面信息
    hmi_sys_send("a001", xDayState.sta);
    //发送灯光状态信息
    if ((xSysSTA.state_brd[0] >> 3) & (0x0001U)) {
        hmi_txt_send("main", "ltV", "ON");
    } else {
        hmi_txt_send("main", "ltV", "OFF");
    }
}

/**
 * @brief 在主界面上显示状态运行数据
 * 
 */
void hmi_state_sync(void)
{
    char cmd[32];

    //15秒等待执行标记
    if (xSysSTA.waiting_state == 3) {
        //只执行EC/pH控制
        if (progCache.ec.sta == 1 && progCache.pH.sta == 0) {
            rt_sprintf(cmd, "Dosing EC %03d sec", progCache.ec.time);
        } else if (progCache.ec.sta == 0 && (progCache.pH.sta == 1 || progCache.pH.sta == 2)) {
            rt_sprintf(cmd, "Dosing pH %03d sec", progCache.pH.time);
        } else if (progCache.ec.sta == 1 && (progCache.pH.sta == 1 || progCache.pH.sta == 2)) {
            rt_sprintf(cmd, "Dosing EC %03d | pH %03d sec", progCache.ec.time, progCache.pH.time);
        } else if (progCache.ec.sta == 1 && progCache.pH.sta == 0) {
            rt_sprintf(cmd, " ");
        }
        hmi_txt_send("main", "t_log", cmd);
    }
}

/**
 * @brief 在周期表设置界面上显示不同的阶段
 * 
 */
void hmi_schedule_state_sync(void)
{
    char cmd[30] = "No Program Running.";

    //判断PHEC检测是否连接正常
    if (xDevSTA.xB2[0].isconnect == uuzDEV_NOCONNECT) {
        rt_sprintf(cmd, "No PHEC Device.");
    } else {
        if ((xSysSTA.currProgram >= 1) && (xSysSTA.currProgram <= uuzPROG_MAX)) {
            rt_sprintf(cmd, "Program %02d Running.", xSysSTA.currProgram);
        } else {
            rt_sprintf(cmd, "No Program Running.");
        }
    }
    if (xCurrUI.ucPageID == uuzHMI_UI_NUT00) {
        hmi_txt_send("nut00", "t_info", cmd);
    } else if (xCurrUI.ucPageID == uuzHMI_UI_NUT01) {
        hmi_txt_send("nut01", "t_info", cmd);
    }
}

/**
 * @brief 显示水位的状态
 */
void hmi_level_value_sync(u8 wls)
{
    char page[10];
    char cmd[24];

    if (xDevSTA.usCountP260) {
        hmi_page_is_assert(page, uuzHMI_UI_WLS);
        if ((wls < _WLS_PRO_MAX) && (xDevSTA.xP260[wls].isconnect == uuzDEV_CONNECTED)) {
            u32 inch = xP260Value[wls].high;  //当前读取到的数据
            if (xSysCFG.unit_lv == uuzLV_INCH) {
                inch = mm_and_inch_to(0, inch);
                rt_sprintf(cmd, "%d.%d in", inch / 10, inch % 10);  //精度10.5 in
            } else {
                rt_sprintf(cmd, "%d.%02d m", inch / 1000, ((inch % 1000) / 10));    //精度 1.05 m
            }
            hmi_txt_send(page, "t_lvV", cmd);
            //显示当前的水位状态
            if (xP260Value[wls].out == uuzSINP260_MID) {
                hmi_txt_send(page, "t_lvS", "Normal");
            } else if (xP260Value[wls].out == uuzSINP260_HIGH) {
                hmi_txt_send(page, "t_lvS", "High");
            } else if (xP260Value[wls].out == uuzSINP260_LOW) {
                hmi_txt_send(page, "t_lvS", "Low");
            } else if (xP260Value[wls].out == uuzSINP260_TARGET) {
                hmi_txt_send(page, "t_lvS", "Target");
            } else {
                hmi_txt_send(page, "t_lvS", "----");
            }
        } else {  //NOTE:没有正确数据，在HMI屏幕上显示“----”
            hmi_txt_send(page, "t_lvV", "----");
            hmi_txt_send(page, "t_lvS", "----");
        }
    } else {
        //没有正确数据，在HMI屏幕上显示“----”
        hmi_txt_send("wls", "t_lvV", "----");
        hmi_txt_send("wls", "t_lvS", "----");
    }
    hmi_sys_send("s_level", xP260Value[wls].out);  //显示首页的实际的水位状态

}

/**
 * @brief 显示内部端口的状态
 */
void hmi_board_value_sync(void)
{
    char cmd[24];
    int index = 0;

    if (xDevSTA.usCountBrd) {  //Board Valve的相关属性配置
        for (index = 0; index < uuzDEV_BRD_VALVE_MAX; index++) {
            rt_sprintf(cmd, "auxs%02d", index + 1);
            hmi_sys_send(cmd, ((xSysSTA.state_brd[0] >> index) & 0x01U));
        }
    }
}

/**
 * @brief 显示蠕动泵端口的状态
 */
void hmi_dosing_value_sync(void)
{
    char cmd[24];
    int index = 0;

    if (xDevSTA.usCountDos) {
        //Dosing Valve的相关属性配置
        for (index = 0; index < uuzDEV_DOS_MAX; index++) {
            rt_sprintf(cmd, "auxs%02d", index + 1);
            hmi_sys_send(cmd, xDosingState[index].state);
        }
    }
}
