/*
 * @Copyright (c) 2006-2018 RT-Thread Development Team:  
 * @SPDX-License-Identifier: Apache-2.0:  
 * @Change Logs: 
 * @Date: 2020-01-01 09:23:03
 * @LastEditors: Zhou Xiaomin
 * @LastEditTime: 2020-01-11 11:02:14
 * @Description:  
 */
#ifndef UUZ_HMI_UI_H
#define UUZ_HMI_UI_H

#include "typedefHMI.h"
#include "typedefBASE.h"
#include "uuzConfigHMI.h"

#ifdef __cplusplus
extern "C" {
#endif

void hmi_ui_init(void);
void hmi_hw_reset(void);

void hmi_command(char* pcCommand);
void hmi_sys_send(char* pcSYS, u32 ulVal);
void hmi_txt_send(char* pcUI, char* pcID, char* pcContent);
void hmi_val2txt_send(char* pcUI, char* pcID, u32 ulVal);
void hmi_val_send(char* pcUI, char* pcID, u32 ulVal);
void hmi_box_up(char* pcUI, char* pcBox, char* pcContent, u32 ulIndex);
void hmi_box_inset_send(char* pcUI, char* pcBox, char* pcContent);
/**
 * @brief 显示数据缓存界面
 */
void hmi_test_cache_sync(void);
/**
 * @brief 检测末尾的换行符是否HMI命令的0xFF/0xFF/0xFF
 * @param data
 * @return
 */
rt_err_t hmi_data_end_is_assert(u8 * data);
/**
 * @brief 触发事件
 * @param event:事件名称
 * @param state:事件状态0/1
 */
void hmi_event_send(char* event, u8 state);

/**
 * @brief 根据页面ID读取相应的页面名称
 * @param page:读取到的页面名称
 * @param id:页面ID
 * @return 读取成功：RT_TRUE/读取失败：RT_FALSE
 */
u8 hmi_page_is_assert(char * page, u32 id);
/**
 * @brief 根据设备类型读取相应的类型名称
 * @param cmd:读取到的类型名称
 * @param type:类型ID
 * @return 读取成功：RT_TRUE/读取失败：RT_FALSE
 */
u8 hmi_type_is_assert(char * cmd, u32 type);
/**
 * @brief 根据端口类型读取相应的类型名称
 * @param cmd:读取到的名称
 * @param type:类型
 * @return 读取成功：RT_TRUE/读取失败：RT_FALSE
 */
u8 hmi_port_type_is_assert(char * cmd, u32 type);
/**
 * @brief 根据端口类型读取相应的类型名称
 * @param cmd:读取到的名称
 * @param type:类型
 * @return 读取成功：RT_TRUE/读取失败：RT_FALSE
 */
u8 hmi_box_port_type_is_assert(char * cmd, u8 index);

//接收HMI数据相关函数
u8 hmi_data_head_is_assert(u8 ucCode);
//单独UI界面处理函数-启动全局处理界面
void hmi_ui_global_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-参数初始界面，隐藏不显示
void hmi_ui_init_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-背景加载图片
void hmi_ui_background_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-主界面
void hmi_ui_main_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-周期表选择相关界面
void hmi_ui_nut_schedule_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-项目选择相关界面
void hmi_ui_nut_program_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-定量配肥项目选择相关界面
void hmi_ui_nut_fixed_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-项目参数保存相关界面
void hmi_ui_nut_set_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-蠕动泵参数保存相关界面
void hmi_ui_nut_pps_set_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-提示框界面
void hmi_ui_tip_task(u8 ucKeyID, u8* ucEvent, u8 ucLength);
//单独UI界面处理函数-灌溉端口选择界面
void hmi_ui_irr_port_set_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-灯光端口选择界面
void hmi_ui_light_port_set_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-自动补水设置界面
void hmi_ui_water_supply_set_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-外设设备菜单界面
void hmi_ui_aux_menu_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-外设设备数据设置界面
//void hmi_ui_aux_port_set_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-加载传感器/执行设备/外设设备数据
void hmi_state_type_state_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-调试电源板界面
void hmi_ui_debug_board_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-调试蠕动泵界面
void hmi_ui_debug_dosing_task(u8 ucKeyID, u8* ucEvent);
//单独UI界面处理函数-开锁按键界面
void hmi_ui_key_password_task(u8 ucKeyID, u8* ucEvent);

#ifdef __cplusplus
}
#endif

#endif // UUZ_HMI_UI_H
