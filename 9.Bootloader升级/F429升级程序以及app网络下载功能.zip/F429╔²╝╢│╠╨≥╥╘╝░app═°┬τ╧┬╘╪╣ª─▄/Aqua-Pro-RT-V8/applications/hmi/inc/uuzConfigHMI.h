﻿/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-29   ZhouXiaomin     first version
 */
#ifndef __UUZ_CONFIG_HMI_H
#define __UUZ_CONFIG_HMI_H

//uuzMBR_CODE
/* ----------------------- Defines ------------------------------------------*/
#define uuzHMI_VERSION (1011U) //Ver1.00.0
#define uuzHMI_END (0xFFU)

//Page Mode
#define uuzHMI_PAGE_MAX (0x06U) //最大每页6个

//单延时20ms,不同设备的定时相关数据
#define uuzTM_WAIT_REG (25U) //发送待注册设备数据延时
#define uuzTM_CURR_VALUE (50U) //实时数据获取延时
#define uuzTM_SYNC_VALUE (25U) //实时数据刷新延时

//ERROR CODE
#define uuzHMI_INVALID (0x00U)
#define uuzHMI_SUCCESS (0x01U)
#define uuzHMI_ID_INVALID (0x02U)
#define uuzHMI_PG_INVALID (0x03U)
#define uuzHMI_PIC_INVALID (0x04U)
#define uuzHMI_FONT_INVALID (0x05U)
#define uuzHMI_FILE_INVALID (0x06U)
#define uuzHMI_CRC_INVALID (0x09U)
#define uuzHMI_BAUD_INVALID (0x11U)
#define uuzHMI_CURVE_INVALID (0x12U)
#define uuzHMI_NAME_INVALID (0x1AU)
#define uuzHMI_VAL_ERR (0x1BU)
#define uuzHMI_SVAL_ERR (0x1CU)
#define uuzHMI_EEPROM_ERR (0x1DU)
#define uuzHMI_PARAM_INVALID (0x1EU)
#define uuzHMI_IO_INVALID (0x1FU)
#define uuzHMI_CHAR_INVALID (0x20U)
#define uuzHMI_LVAL_EER (0x23U)
#define uuzHMI_BAUD_LONG (0x24U)

//EVENT CODE
#define uuzHMI_TOUCH (0x65U)
#define uuzHMI_PAGE_ID (0x66U)
#define uuzHMI_TOUCH_XY (0x67U)
#define uuzHMI_SLEEP_XY (0x68U)
#define uuzHMI_GET_TXT (0x70U)
#define uuzHMI_GET_VAL (0x71U)
#define uuzHMI_AUTO_SLEEP (0x86U)
#define uuzHMI_AUTO_AWAKEN (0x87U)
#define uuzHMI_POWER_ON (0x88U)
#define uuzHMI_SD_UPDATE (0x89U)
#define uuzHMI_TRANSMIT_SUC (0xFDU)
#define uuzHMI_TRANSMIT_RDY (0xFEU)

#define uuzHMI_CMD_RBT_HW (0x00BBU) //重启的指令

//UI PAGE CODE
enum
{
    uuzHMI_UI_TIP = (0U),  //提示框
    uuzHMI_UI_KEY,  //数字输入框
    uuzHMI_UI_DST,  //日期输入界面
    uuzHMI_UI_TST,  //时间输入界面
    uuzHMI_UI_TIM,  //时间设置输入界面
    uuzHMI_UI_BG = (5U),  //背景页面
    uuzHMI_UI_MAIN,  //首页面
    uuzHMI_UI_NUT00,  //灌溉设置界面（周期表)
    uuzHMI_UI_NUT01,  //灌溉光照的设置界面
    uuzHMI_UI_NUT1,  //EC&Ta.设置界面
    uuzHMI_UI_NUT2 = (10U),  //10-pH设置界面
    uuzHMI_UI_NUT3,  //Dosing设置界面
    uuzHMI_UI_NUT4,  //定量Dosing设置界面
    uuzHMI_UI_PPS,  //Dosing参数设置界面
    uuzHMI_UI_SCH,  //周期表参数设置界面
    uuzHMI_UI_GTIP,  //15-周期表界面设置弹出界面
    uuzHMI_UI_IRRB,  //灌溉设备菜单界面
    uuzHMI_UI_IRRA,  //灌溉类型选择菜单界面
    uuzHMI_UI_IRRI,  //灌溉IO选择菜单界面
    uuzHMI_UI_IRR1,  //气雾培设置界面
    uuzHMI_UI_IRR2,  //20-滴灌设置界面
    uuzHMI_UI_IRR3,  //潮汐式设置界面
    uuzHMI_UI_IRR4M,  //通用灌溉设置界面-手动
    uuzHMI_UI_IRR4C,  //通用灌溉设置界面-循环
    uuzHMI_UI_IRR4T,  //通用灌溉设置界面-定时
    uuzHMI_UI_DRN1,  //25-气雾培回水设置界面
    uuzHMI_UI_DRN2,  //滴灌设置界面
    uuzHMI_UI_DRN3,  //潮汐式设置界面
    uuzHMI_UI_DRN4M,  //通用回水设置界面-手动
    uuzHMI_UI_DRN4C,  //通用回水设置界面-循环
    uuzHMI_UI_DRN4T,  //30-通用回水设置界面-定时
    uuzHMI_UI_WLSB,  //水位状态界面
    uuzHMI_UI_WLS,  //水位状态界面
    uuzHMI_UI_WLSP,  //水位端口状态界面
    uuzHMI_UI_LGTB,  //灯光设设备菜单界面
    uuzHMI_UI_LGT1,  //35-通用灯光设置界面-手动
    uuzHMI_UI_LGT2,  //通用灯光设置界面-循环
    uuzHMI_UI_LGT3,  //通用灯光设置界面-定时
    uuzHMI_UI_AUX1,  //内部设备设置界面
    uuzHMI_UI_AUXA,  //设备设置界面
    uuzHMI_UI_DEV1,  //40-通用设备设置界面-手动
    uuzHMI_UI_DEV2,  //通用设备设置界面-循环
    uuzHMI_UI_DEV3,  //通用设备设置界面-定时
    uuzHMI_UI_CSS,  //传感器-设备-外设状态界面
    uuzHMI_UI_LOGM,  //日志菜单界面
    uuzHMI_UI_LOG1,  //45-日志显示界面-历史日志
    uuzHMI_UI_TAB1,  //图表显示界面-历史日志
    uuzHMI_UI_TAB2,  //图表显示界面-
    uuzHMI_UI_TAB3,  //图表显示界面
    uuzHMI_UI_TAB4,  //图表显示界面
    uuzHMI_UI_SYSD,  //50-系统设置界面-配置
    uuzHMI_UI_SYST,  //系统设置界面-时间
    uuzHMI_UI_CEC,  //EC校正界面
    uuzHMI_UI_CPH,  //pH校正界面
    uuzHMI_UI_INIT,  //系统初始化设置界面
    uuzHMI_UI_DBRD,  //55-设备端口测试界面
    uuzHMI_UI_DDOS,  //蠕动泵端口测试界面
    uuzHMI_UI_KEYPW,  //密码输入测试界面
    uuzHMI_UI_VAL,  //测试数据界面
    uuzHMI_UI_GLOBAL = (0xEFU),  //全局界面编号
    uuzHMI_UI_MAX  //最后一个界面编号
};

//错误提示框
#define uuzHMI_LINE_ERR (0x03U)
#define uuzHMI_HOST_REPEAT (0x04U)

#endif // __UUZ_CONFIG_HMI_H
