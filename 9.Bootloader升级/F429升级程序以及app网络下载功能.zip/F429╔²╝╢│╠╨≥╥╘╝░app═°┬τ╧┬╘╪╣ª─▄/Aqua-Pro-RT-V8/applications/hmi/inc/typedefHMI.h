/*
 * @Copyright (c) 2006-2018 RT-Thread Development Team:  
 * @SPDX-License-Identifier: Apache-2.0:  
 * @Date: 2020-01-01 09:23:03
 * @LastEditors  : Zhou Xiaomin
 * @LastEditTime : 2020-01-11 10:36:15
 * @Description:  
 */
#ifndef _TYPEDEF_HMI_H
#define _TYPEDEF_HMI_H

#include "board.h"
#include "uuzConfigUART.h"

//设备的相关信息
typedef struct hmi_config
{

    u16 version;    //版本号
    u16 language;  //初始化状态

    //---------单位相关
    u16 unit_ec;  //EC单位:EC/CF-TDS(x500)-PPM(x700)
    u16 unit_ta;  //温度单位：C-F
    u16 unit_date;  //MM/DD/YY-DD/MM/YY-YY/MM/DD
    u16 unit_time;  //24/12时制
    //---------亮度设置
    u16 bk_mode;  //背光开关状态1-Manual/0-Auto
    u16 bk_level;  //背光亮度0~100%
    u16 bk_time;  //自动熄屏时间（15--180s）

    u16 crc;    //末尾校正数据，0x3545U 如果不是，则重置前面的数据

} HMI_Config_Typedef_t;

#define _UUZ_HMI_CONFIG_LEN (sizeof(HMI_Config_Typedef_t))

enum
{
    _HMI_VER = 0U,  //版本号
    _HMI_LANG,  //语言
    //---------单位相关
    _HMI_EC,  //EC单位:EC/CF-TDS(x500)-PPM(x700)
    _HMI_TA,  //温度单位：C-F
    _HMI_DATE,  //MM/DD/YY-DD/MM/YY-YY/MM/DD
    _HMI_TIME,  //24/12时制
    //---------亮度设置
    _HMI_BK_EN,  //背光开关状态1-Manual/0-Auto
    _HMI_BK_L,  //背光亮度0~100%
    _HMI_BK_T,  //自动熄屏时间（15--180s）

    //数量
    _HMI_MAX
};

typedef struct hmi_t
{
    u8 ucPageID;
    u16 ucKeyID;
    u8 ucEvent[uuzUART_LEN];

} HMI_Typedef_t;

typedef struct hmi_cache_t
{
    u8 ucShowMask;
    u8 ucLocationMask;
    u8 ucLocationTimeOut;

} HMI_CACHE_Typedef_t;

#endif // _TYPEDEF_HMI_H
