/*
 * @Copyright (c) 2006-2018 RT-Thread Development Team:  
 * @SPDX-License-Identifier: Apache-2.0:  
 * @Change Logs: 
 * @Date: 2020-01-01 09:23:03
 * @LastEditors  : Zhou Xiaomin
 * @LastEditTime : 2020-01-15 12:31:19
 * @Description:  
 */
#ifndef UUZ_HMI_EVENT_H
#define UUZ_HMI_EVENT_H

#include "typedefHMI.h"
#include "typedefPHEC.h"
#include "typedefPROG.h"
#include "typedefVALVE.h"
#include "typedefSCH.h"
#include "uuzINIT.h"
#include <board.h>
#include <rtthread.h>

extern HMI_Typedef_t xCurrUI;
extern HMI_Typedef_t xPrevUI;

#ifdef __cplusplus
extern "C" {
#endif

//UI处理线程的开启
/**
 * @brief 启动UI的同步线程
 *
 * @return int
 */
int ui_sync_init(void);

/**
 * @brief 启动实时数据线程
 *
 * @return int
 */
int data_sync_init(void);

/**
 * @brief 操作事件线程
 * 
 * @return int 
 */
int opt_event_init(void);
/**
 * @brief 启动端口操作事件线程
 *
 * @return int
 */
int valve_event_init(void);
/**
 * @brief 触发报警的事件
 * @return int
 */
int alarm_sync_init(void);
/* 初始化相关同步信息 */
void hmi_sync_start(void);
void hmi_init_stage(u8 stage);
void hmi_time_sync(void);
void hmi_self_check_time(u8 ucFlag, u16 usTimeOut);
void hmi_startup_waiting_preiod(void);
void hmi_config_param_sync(void);
void hmi_auto_lock_sync(void);
/**
 * @brief 发送完成标记加载标记
 */
void hmi_reset_loading_stage(void);
void hmi_alarm_event_resolve(u32 event);
void uuz_vDayModeToHmi(u8 ucType);
/**
 * @brief 重新刷新该界面
 */
void hmi_resync_ui_stage(u8 flag);
/**
 * @brief 刷新设备主界面的实时值
 * @param ec:实时EC
 * @param pH:实时pH
 * @param ta:实时温度
 */
void hmi_curr_value_sync(u16 ec, u16 ph, u16 ta);
/**
 * @brief 回水数据显示
 * @param time:持续秒数
 * @param stage:运行阶段:0-停止阶段/1-持续阶段/2-加液超时
 */
void hmi_water_supply_ui_stage(u32 time, u8 stage);
/**
 * @brief 选择加载灌溉相关数据
 * @param type:选择加载的类型1-Aero/2-Topfeed/3-Flow&Ebb/4-Customize
 */
void hmi_irr_menu_loading(u8 type);
//发送设备相关信息
void uuz_vDevStateToHmi(u8 ucSta, u8 index);
void uuz_vDevPopTipToHmi(u8 ucTip);
//回复操作相关状态
void uuz_vUIID_ReplyToHmi(u8 ucReply);
//About Device ID
void uuz_vRegID_WaitSend(void);
void uuz_vRegWaitIDToHmi(u8 index);
//---------------------------------------------------------------------//
/**
 * @brief 对单个程序定量同步配置信息
 */
void hmi_fixed_single_config_sync(Fixed_Single_Typedef_t * fixed);
/**
 * @brief 对单个程序同步配置信息
 */
void hmi_prog_single_config_sync(Dynamic_Single_Typedef_t* dynamic);
//---------------------------------------------------------------------//
/**
 * @brief 加载周期表的列表相关数据
 */
void hmi_sch_config_sync(void);
/**
 * @brief 程序设置界面相关信息同步
 */
void hmi_prog_config_sync(void);
/**
 * @brief 对单个程序同步配置信息
 */
void hmi_prog_current_config_sync(PROG_Single_Typedef_t* prog);
/**
 * @brief 发送重置蠕动泵时间数据
 */
void hmi_reset_dosing_time(void);
/**
 * @brief 水位配置相关信息
 */
void hmi_level_config_sync(void);
/**
 * @brief 水位状态相关信息
 */
void hmi_level_value_sync(u8 wls);
/**
 * @brief 刷新灌溉回水的水位的数据
 */
void hmi_level_float_value_sync(void);
/**
 * @brief 显示内部端口的状态
 */
void hmi_board_value_sync(void);
/**
 * @brief 显示蠕动泵端口的状态
 */
void hmi_dosing_value_sync(void);
/**
 * @brief 加载灯光相关数据
 */
void hmi_light_list_sync(u16 page);
/**
 * @brief 数据处理线程
 * 
 */
void uuz_vValue_DataProcessing(void);
/**
 * @brief 实时数据主界面刷新相关
 * 
 */
void hmi_value_sync(void);
/**
 * @brief 在主界面上显示状态运行数据
 * 
 */
void hmi_state_sync(void);
/**
 * @brief 在周期表设置界面上显示不同的阶段
 * 
 */
void hmi_schedule_state_sync(void);
/**
 * @brief 主页面灌溉状态相关
 * 
 */
void hmi_irr_sta_sync(void);
/**
 * @brief 加载电源板的端口列表相关数据
 * @param targetIndex:当前要显示的目标设备
 * @param targetPage:当前要显示的目标设备编号
 */
void hmi_board_state_sync(u8 targetIndex, u8 targetPage);
/**
 * @brief 显示端口相关信息
 */
void hmi_board_value_state(void);
/**
 * @brief 端口信息同步
 * @param currPage  当前页码
 * @param maxDev    类型最大数量
 * @param valve     端口配置地址
 */
void valve_info_sync(u16 currPage, u16 maxDev, Valve_Single_Typedef_t * valve);
/**
 * @brief 加载外设的列表相关数据
 */
void hmi_aux_config_sync(void);
/**
 * @brief 单独加载具体外设的实际数据
 * @param valve
 */
//void hmi_aux_single_sync(Aux_Valve_Typedef_t* valve);
/**
 * @brief 传感器状态列表
 * @param page:当前要显示的页码编号(0-N)
 */
void hmi_sensor_state_loading(u8 page);
/**
 * @brief 执行设备状态列表
 * @param page:当前显示的页面页面（0-N）
 */
void hmi_device_state_loading(u8 page);
/**
 * @brief 外设设备状态列表
 * @param page:当前显示的页面页面（0-N）
 */
void hmi_external_state_loading(u8 page);
/**
 * @brief 灌溉端口分开状态列表
 * @param page:当前显示的页面: 0-灌溉|1-回水|2-进水
 */
void hmi_irrigation_state_loading(u8 page);
/**
 * @brief 灌溉模式状态列表
 * @param page:当前显示的页面: 潮汐|起雾|滴灌|通用
 */
void hmi_irrigation_mode_loading(u8 page);
/**
 * @brief 灌溉模式相关信息显示
 * @param mode
 * @param port
 */
void hmi_irrigation_mode_info_sync(u16 mode, u16 port);
#if 0
/**
 * @brief 灌溉模式IO相关信息显示
 * @param port
 * @param page
 */
void hmi_irrigation_io_info_sync(u16 port, u16 page);
/**
 * @brief 补水模式IO相关信息显示
 * @param port
 * @param page
 */
void hmi_wls_io_info_sync(u16 port, u16 page);
#endif
/**
 * @brief AUX界面当前设备数据
 * @param targetIndex:当前要显示的目标设备
 */
void hmi_aux_ui_sync(u8 targetIndex);

/**
 * @brief 显示单个设备数据的列表信息
 * @param index：需要显示的设备编号
 */
void hmi_aux_list_sync(u8 index);

/**
 * @brief 加载设备配置列表数据
 */
void hmi_device_list_sync(void);

/**
 * @brief 加载灯光配置
 * @param port:端口数据
 */
void hmi_light_config_sync(u16 port);
/**
 * @brief 加载灯光配置
 * @param port:端口数据
 */
void hmi_timer_config_sync(u16 port);
/**
 * @brief 水位补水配置相关数据
 */
void hmi_wls_list_sync(void);
/**
 * @brief 水位补水配置数据相关显示
 */
void hmi_wls_data_sync(u16 index);
/**
 * @brief 程序设置界面相关信息同步
 */
void hmi_dosing_config_sync(void);

#ifdef __cplusplus
}
#endif

#endif // UUZ_HMI_EVENT_H
