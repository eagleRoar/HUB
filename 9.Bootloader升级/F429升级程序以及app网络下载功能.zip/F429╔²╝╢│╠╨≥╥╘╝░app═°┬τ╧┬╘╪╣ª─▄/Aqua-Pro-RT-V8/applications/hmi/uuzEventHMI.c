/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-01   ZhouXiaomin     first version
 */
/* Includes ------------------------------------------------------------------*/
#include <board.h>
#include <rtthread.h>
/* ----------------------------------------------------------------*/
#include "uuzConfigDEV.h"
#include "uuzConfigPORT.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
#include "logHISTORY.h"
/* ----------------------------------------------------------------*/
#include "uuzConfigHMI.h"
#include "uuzEventHMI.h"
#include "uuzHMI_UI.h"
/* ----------------------------------------------------------------*/
#include "uuzEEPROM.h"
#include "uuzEVENT.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzRTC.h"
/*event---------------------------------------------*/
#include "uuzEventIRR.h"
#include "uuzEventBRD.h"
#include "uuzEventWLS.h"
#include "uuzEventDOSING.h"
/*log---------------------------------------------*/
#define DBG_TAG "e.hmi"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/* ----------------------------------------------------------------*/
HMI_Typedef_t xCurrUI;
HMI_Typedef_t xPrevUI;
/* ----------------------------------------------------------------*/
/**
 * @brief	启动HMI屏幕数据同步动作
 *
 */
void hmi_sync_start(void)
{
    xSysSTA.hmi_init = 0;  //系统初始化标记
    LOG_D("System Initialization...");
    //------------------------------->
    xSysSTA.hmi_init++;  //配置发送标记
    hmi_config_param_sync();  //发送HMI配置
    hmi_time_sync();  //发送RTC校正
    LOG_D("Loading Module Informationn...");
    //------------------------------->
    xSysSTA.hmi_init++;  //模块信息初始化
    //hmi_irr_sta_sync();//显示水位相关数据
    LOG_D("Loading Module Configurations...");
    //------------------------------->
    xSysSTA.hmi_init++;  //模块配置读取初始化
    hmi_prog_config_sync();  //Program基本数据
    hmi_dosing_config_sync();   //同步蠕动相关数据
    //hmi_level_config_sync();//肥桶水位相关信息
    LOG_D("Acquisition Device Data...");
    //------------------------------->
    xSysSTA.hmi_init++;
    LOG_D("Initialize Device UI...");
    hmi_value_sync();  //当前是主界面刷新实时数据
    //------------------------------->
    xSysSTA.hmi_init++;
    //第一次进入主界面，准备进入倒计数
    if (xSysSTA.waiting_state == 0) {
        xSysSTA.waiting_time = 0;  //重置标记
        xSysSTA.waiting_state = 1;
    }
    xCurrUI.ucPageID = uuzHMI_UI_MAIN;  //更新界面当前ID
    hmi_sys_send("devtype", uuzDEVICE_TYPE);  //发送类型版本 0-babala 1-Inni 2-InniOnly
    hmi_sys_send("version", uuzSOFTWAVE_VERSION);  //发送系统版本号
    hmi_sys_send("startup", 1);  //发送启动标记
    LOG_D("[%d]Device Startup Completed.", xSysSTA.hmi_init);  //设备启动完成
}

/**
 * @brief 清除加载中标记
 */
void hmi_reset_loading_stage(void)
{
    hmi_sys_send("a005", 2);  //发送完成加载标记加载标记
}

/**
 * @brief 重新刷新该界面
 */
void hmi_resync_ui_stage(u8 flag)
{
    hmi_sys_send("a008", flag);  //重新刷新界面
}

/**
 * @brief 重新上锁状态
 */
void hmi_auto_lock_sync(void)
{
    hmi_sys_send("islock", 1);  //重新加上上锁状态
}

/**
 * @brief 向屏幕发送RTC时间
 */
void hmi_time_sync(void)
{
    //Synchronize RTC time
    hmi_sys_send("rtc0", (rTm.tm_year + 1900));
    hmi_sys_send("rtc1", (rTm.tm_mon + 1));
    hmi_sys_send("rtc2", rTm.tm_mday);
    hmi_sys_send("rtc3", rTm.tm_hour);
    hmi_sys_send("rtc4", rTm.tm_min);
    hmi_sys_send("rtc5", rTm.tm_sec);
    //保存相关数据
    hmi_sys_send("r001", (rTm.tm_year + 1900));
    hmi_sys_send("r002", (rTm.tm_mon + 1));
    hmi_sys_send("r003", rTm.tm_mday);
    hmi_sys_send("r004", rTm.tm_hour);
    hmi_sys_send("r005", rTm.tm_min);
    hmi_sys_send("r006", rTm.tm_sec);
}

/**
 * @brief 向屏幕发送的相关参数
 */
void hmi_config_param_sync(void)
{
    //固定存储HMI系统数据
    hmi_sys_send("s1000", xSysCFG.unit_ec);  //EC单位
    hmi_sys_send("s1001", xSysCFG.unit_ta);  //温度单位
    hmi_sys_send("s1002", xSysCFG.unit_date);  //年-时制显示
    hmi_sys_send("s1003", xSysCFG.unit_time);  //时-时制显示
    hmi_sys_send("s1004", xSysCFG.bk_mode);  //自动熄屏设置
    hmi_sys_send("s1005", xSysCFG.bk_time);  //屏幕自动熄屏时间
    hmi_sys_send("s1006", xSysCFG.bk_level);  //屏幕亮度
    hmi_sys_send("s1007", xSysCFG.day_mode);  //白天黑夜设置模式
    hmi_sys_send("s1008", xSysCFG.day_on);  //白天开启时间
    hmi_sys_send("s1009", xSysCFG.day_off);  //白天关闭时间
    hmi_sys_send("s1010", xSysCFG.unit_lv);  //水位单位
    hmi_sys_send("d130", xSysCFG.dosing_num);  //蠕动泵数量
    hmi_sys_send("pinlock", xSysCFG.lock_pin);  //锁定密码
}

/**
 * @brief 报警事件
 * @param event 报警事件标记
 * @return 如果有动作，则返回处理成功RT_EOK，没有动作返回 RT_ERROR
 */
void hmi_alarm_event_resolve(u32 event)
{
    u8 need_sync_ui = 0;
    if (event & EC_H_EVENT) {
        hmi_sys_send("alm_ec", 1);  //EC高报警数据
        need_sync_ui = 1;
    }
    if (event & PH_H_EVENT) {
        hmi_sys_send("alm_ph", 2);  //pH高报警数据
        need_sync_ui = 1;
    }
    if (event & PH_L_EVENT) {
        hmi_sys_send("alm_ph", 1);  //pH低报警数据
        need_sync_ui = 1;
    }
    if (event & TA_H_EVENT) {
        hmi_sys_send("alm_ta", 1);  //温度高报警数据
        need_sync_ui = 1;
    }
    if (event & LV_H_EVENT) {
        hmi_sys_send("alm_lv", 1);  //水位高报警数据
        need_sync_ui = 1;
    }
    if (event & LV_L_EVENT) {
        hmi_sys_send("alm_lv", 2);  //水位低报警数据
        need_sync_ui = 1;
    }
    if (event & EC_NULL_EVENT) {
        hmi_sys_send("alm_ec", 0);  //清除报警数据
        need_sync_ui = 1;
    }
    if (event & PH_NULL_EVENT) {
        hmi_sys_send("alm_ph", 0);  //清除报警数据
        need_sync_ui = 1;
    }
    if (event & TA_NULL_EVENT) {
        hmi_sys_send("alm_ta", 0);  //清除报警数据
        need_sync_ui = 1;
    }
    if (event & LV_NULL_EVENT) {
        hmi_sys_send("alm_lv", 0);  //清除报警数据
        need_sync_ui = 1;
    }
    if (need_sync_ui == 1) {
        rt_event_send(eventDATA, UI_DATA_SYNC);  //刷新界面
    }
}

/**
 * @brief 发送重置蠕动泵时间数据
 */
void hmi_reset_dosing_time(void)
{
    char cmd[30];

#if 0
    rt_sprintf(cmd, "%04d-%02d-%02d %02d:%02d:%02d", xProgConfig.resetCyclesRTC[0], xProgConfig.resetCyclesRTC[1],
            xProgConfig.resetCyclesRTC[2], xProgConfig.resetCyclesRTC[3], xProgConfig.resetCyclesRTC[4],
            xProgConfig.resetCyclesRTC[5]);
#else
    rt_sprintf(cmd, "%04d-%02d-%02d %02d:%02d:%02d",
            xDosCFG->rtc[0],
            xDosCFG->rtc[1],
            xDosCFG->rtc[2],
            xDosCFG->rtc[3],
            xDosCFG->rtc[4],
            xDosCFG->rtc[5]);
#endif
    hmi_txt_send("pps", "t_date", cmd);
}

/**
 * @brief 回水数据显示
 * @param time:持续秒数
 * @param stage:运行阶段:0-停止阶段/1-持续阶段/2-加液超时
 */
void hmi_water_supply_ui_stage(u32 time, u8 stage)
{
    char cmd[32];
    if (stage == 0) {
        hmi_txt_send("wls", "t_runT", "As Free.");
    } else if (stage == 1) {
        if (time > 300) {  //如果数据大于5分钟,转换成分钟显示
            rt_sprintf(cmd, "Run: %dm%02ds", (time / 60), (time % 60));
        } else {
            rt_sprintf(cmd, "Run: %d s", time);
        }
        hmi_txt_send("wls", "t_runT", cmd);
    } else if (stage == 2) {
        rt_sprintf(cmd, "Time Out.");
        hmi_txt_send("wls", "t_runT", cmd);
    } else {
        rt_sprintf(cmd, "No Sensor.");
        hmi_txt_send("wls", "t_runT", cmd);
    }
}

/**
 * @brief 灌溉模式相关信息显示
 * @param mode
 * @param port
 */
void hmi_irrigation_mode_info_sync(u16 mode, u16 port)
{
    char cmd[10];
    u8 index = 0;

    hmi_sys_send("d300", xIrrPro->pro[port].md);  //灌溉模式
    switch (mode) {
        case _IRR_AERO:
            hmi_sys_send("d301", xIrrPro->pro[port].cfg.t_cycle[0].on);  //白天数据
            hmi_sys_send("d302", xIrrPro->pro[port].cfg.t_cycle[0].off);
            hmi_sys_send("d303", xIrrPro->pro[port].cfg.t_cycle[1].on);  //晚上数据
            hmi_sys_send("d304", xIrrPro->pro[port].cfg.t_cycle[1].off);
            break;
        case _IRR_TOPFEED:
            for (index = 0; index < 5; index++) {  //滴灌定时参数
                rt_sprintf(cmd, "d%03d", (index * 3 + 320));
                hmi_sys_send(cmd, xIrrPro->pro[port].cfg.t_timer[index].en);
                rt_sprintf(cmd, "d%03d", (index * 3 + 321));
                hmi_sys_send(cmd, xIrrPro->pro[port].cfg.t_timer[index].on / 60);
                rt_sprintf(cmd, "d%03d", (index * 3 + 322));
                hmi_sys_send(cmd, xIrrPro->pro[port].cfg.t_timer[index].off / 60);
            }
            break;
        case _IRR_FLOWEBB:
            hmi_sys_send("d340", xIrrPro->pro[port].cfg.flood[0] / 60);  //白天数据
            hmi_sys_send("d341", xIrrPro->pro[port].cfg.wait[0] / 60);
            hmi_sys_send("d342", xIrrPro->pro[port].cfg.flood[1] / 60);  //晚上数据
            hmi_sys_send("d343", xIrrPro->pro[port].cfg.wait[1] / 60);
            break;
        case _IRR_CUSTOMIZE:
            //Manual Mode
            hmi_sys_send("d348", xIrrPro->pro[port].cfg.md);  //当前模式
            hmi_sys_send("d349", xIrrPro->pro[port].cfg.sta);  //工作状态
            //Cycle Mode
            hmi_sys_send("d350", xIrrPro->pro[port].cfg.t_cycle[0].on / 60);
            hmi_sys_send("d351", xIrrPro->pro[port].cfg.t_cycle[0].off / 60);
            hmi_sys_send("d352", xIrrPro->pro[port].cfg.t_cycle[1].on / 60);
            hmi_sys_send("d353", xIrrPro->pro[port].cfg.t_cycle[1].off / 60);
            //Timer Mode
            for (index = 0; index < 5; index++) {
                rt_sprintf(cmd, "d%03d", (index * 3 + 354));
                hmi_sys_send(cmd, xIrrPro->pro[port].cfg.t_timer[index].en);
                rt_sprintf(cmd, "d%03d", (index * 3 + 355));
                hmi_sys_send(cmd, xIrrPro->pro[port].cfg.t_timer[index].on / 60);
                rt_sprintf(cmd, "d%03d", (index * 3 + 356));
                hmi_sys_send(cmd, xIrrPro->pro[port].cfg.t_timer[index].off / 60);
            }
            break;
        default:
            break;
    }
}

#if 0
/**
 * @brief 灌溉模式IO相关信息显示
 * @param port
 * @param page
 */
void hmi_irrigation_io_info_sync(u16 port, u16 page)
{
    u16 index = 0;
    u16 currentPage = 0;
    u16 min, max;
    u16 count = 0;
    char cmd[24];
    currentPage = ucPageGet(count, 8);   //查看读取的页码数据是否OK
    hmi_sys_send("k00", 8);   //发送数量和页码数量
    hmi_sys_send("k01", currentPage);
    min = page * 8;
    max = (page + 1) * 8;
    u16 i;
    u8 sta = 0;
    count = xDevSTA.usCountIRROUT + xDevSTA.usCountIRRDRAIN;
    //有灌溉输出端口相关数据
    for (index = min; index < max; index++) {
        if (index < xDevSTA.usCountIRROUT) {
            rt_sprintf(cmd, "k%003d", index % 8);
            hmi_sys_send(cmd, xDevSTA.xIrrOUT[index].en);    //使能
            rt_sprintf(cmd, "k%003d", index % 8 + 10);
            hmi_sys_send(cmd, xDevSTA.xIrrOUT[index].t);    //设备模板类型:比如uuzDEV_SL_BRD
            rt_sprintf(cmd, "k%003d", index % 8 + 20);
            hmi_sys_send(cmd, (xDevSTA.xIrrOUT[index].io + 1));    //端口位置
            //解读端口有效性数据
            sta = 0;
            for (i = 0; i < _IO_PRO_MAX; i++) {  //判断是否有有效数据
                if (xDevSTA.xIrrOUT[index].id == xIrrPro->pro[port].cfg.io[i].id) {   //对应的ID相同
                    if (xDevSTA.xIrrOUT[index].io == xIrrPro->pro[port].cfg.io[i].io) {   //IO的位置相同
                        sta = 1;
                        break;
                    }
                }
            }
            rt_sprintf(cmd, "k%003d", index % 8 + 30);
            hmi_sys_send(cmd, sta);    //端口打勾属性
            rt_sprintf(cmd, "k%003d", index % 8 + 40);
            hmi_sys_send(cmd, uuzPORT_IRR_FLOOD);    //端口类型
            rt_sprintf(cmd, "k%003d", index % 8 + 50);
            hmi_sys_send(cmd, xDevSTA.xIrrOUT[index].id);    //设备类型ID
        } else if (index < count) {  //计算回水的端口
            rt_sprintf(cmd, "k%003d", index % 8);
            hmi_sys_send(cmd, xDevSTA.xIrrDRAIN[index - xDevSTA.usCountIRROUT].en);    //使能
            rt_sprintf(cmd, "k%003d", index % 8 + 10);
            hmi_sys_send(cmd, xDevSTA.xIrrDRAIN[index - xDevSTA.usCountIRROUT].t);    //设备模板类型:比如uuzDEV_SL_BRD
            rt_sprintf(cmd, "k%003d", index % 8 + 20);
            hmi_sys_send(cmd, (xDevSTA.xIrrDRAIN[index - xDevSTA.usCountIRROUT].io + 1));    //端口位置
            //解读端口有效性数据
            sta = 0;
            for (i = 0; i < _IO_PRO_MAX; i++) {  //判断是否有有效数据
                if (xDevSTA.xIrrDRAIN[index - xDevSTA.usCountIRROUT].id == xIrrPro->pro[port].cfg.io[i].id) {  //对应的ID相同
                    if (xDevSTA.xIrrDRAIN[index - xDevSTA.usCountIRROUT].io == xIrrPro->pro[port].cfg.io[i].io) {  //IO的位置相同
                        sta = 1;
                        break;
                    }
                }
            }
            rt_sprintf(cmd, "k%003d", index % 8 + 30);
            hmi_sys_send(cmd, sta);    //端口打勾属性
            rt_sprintf(cmd, "k%003d", index % 8 + 40);
            hmi_sys_send(cmd, uuzPORT_IRR_DRAIN);    //端口类型
            rt_sprintf(cmd, "k%003d", index % 8 + 50);
            hmi_sys_send(cmd, xDevSTA.xIrrDRAIN[index - xDevSTA.usCountIRROUT].id);    //设备类型ID
        } else {
            rt_sprintf(cmd, "k%003d", index % 8);
            hmi_sys_send(cmd, 0);    //使能
        }
    }
}

/**
 * @brief 补水模式IO相关信息显示
 * @param port
 * @param page
 */
void hmi_wls_io_info_sync(u16 port, u16 page)
{
    u16 index = 0;
    u16 currentPage = 0;
    u16 min, max;
    u16 count = 0;
    char cmd[24];

    currentPage = ucPageGet(count, 8);   //查看读取的页码数据是否OK
    hmi_sys_send("k00", 8);   //发送数量和页码数量
    hmi_sys_send("k01", currentPage);
    min = page * 8;
    max = (page + 1) * 8;
    u8 sta = 0;
    count = xDevSTA.usCountIRRIN;

    //有补水输出端口相关数据
    for (index = min; index < max; index++) {
        if (index < xDevSTA.usCountIRRIN) {
            rt_sprintf(cmd, "k%003d", index % 8);
            hmi_sys_send(cmd, xDevSTA.xIrrIN[index].en);    //使能
            rt_sprintf(cmd, "k%003d", index % 8 + 10);
            hmi_sys_send(cmd, xDevSTA.xIrrIN[index].t);    //设备模板类型:比如uuzDEV_SL_BRD
            rt_sprintf(cmd, "k%003d", index % 8 + 20);
            hmi_sys_send(cmd, (xDevSTA.xIrrIN[index].io + 1));    //端口位置
            //解读端口有效性数据
            sta = 0;
            if (xDevSTA.xIrrIN[index].id == xWlsPro->cfg[port].bid) {   //对应的ID相同
                if (xDevSTA.xIrrIN[index].io == xWlsPro->cfg[port].io) {   //IO的位置相同
                    sta = 1;
                }
            }
            rt_sprintf(cmd, "k%003d", index % 8 + 30);
            hmi_sys_send(cmd, sta);    //端口打勾属性
            rt_sprintf(cmd, "k%003d", index % 8 + 40);
            hmi_sys_send(cmd, uuzPORT_IRR_IN);    //端口类型
            rt_sprintf(cmd, "k%003d", index % 8 + 50);
            hmi_sys_send(cmd, xDevSTA.xIrrIN[index].id);    //设备类型ID
        } else {
            rt_sprintf(cmd, "k%003d", index % 8);
            hmi_sys_send(cmd, 0);    //使能
        }
    }
}
#endif

/**
 * @brief 灌溉模式状态列表
 * @param page:当前显示的页面: 潮汐|起雾|滴灌|通用
 */
void hmi_irrigation_mode_loading(u8 page)
{
    char cmd[24];
    u8 index = 0;
    u8 count = 0;
    u8 currentPage = 0;
    u8 min = 0;
    u8 max = 0;

    currentPage = ucPageGet(uuzHMI_PAGE_MAX, _IRR_PRO_MAX);   //查看读取的页码数据是否OK

    hmi_sys_send("k00", _IRR_PRO_MAX);   //发送传感器数量和页码数量
    hmi_sys_send("k01", currentPage);   //当前页码数量

    min = page * uuzHMI_PAGE_MAX;
    max = (page + 1) * uuzHMI_PAGE_MAX;

    for (index = 0; index < _IRR_PRO_MAX; index++) {
        if (count >= min && count < max) {   //有一个有效数据
            rt_sprintf(cmd, "c%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 20));
            hmi_sys_send(cmd, xIrrPro->pro[index].en);    //使能
            rt_sprintf(cmd, "c%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 21));
            hmi_sys_send(cmd, xIrrPro->pro[index].md);     //模式
            rt_sprintf(cmd, "c%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 22));
            hmi_sys_send(cmd, (index + 1));   //端口位置
            //rt_sprintf(cmd, "c%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 23));
            //hmi_sys_send(cmd, xDevSTA.xBrd[x].id);
        }
        count++;
    }

    if (count < max) {            //清空空位置
        for (index = count; index < max; index++) {
            rt_sprintf(cmd, "c%02d", ((index % uuzHMI_PAGE_MAX) * 10 + 20));  //是一个无效数据
            hmi_sys_send(cmd, 0);
        }
    }
}

/**
 * @brief 灌溉端口分开状态列表
 * @param page:当前显示的页面: 0-灌溉|1-回水|2-进水
 */
void hmi_irrigation_state_loading(u8 page)
{
    char cmd[24];
    u8 index = 0;
    u8 count = 0;
    u8 currentPage = 0;
    u8 min = 0;
    u8 max = 0;
    u16 usCountIRR = 0;

    if (xDevSTA.usCountAUX) {   //外设数据相关
        if (xDevSTA.usCountBrd) {   //端口板相关数据
            for (index = 0; index < uuzDEV_BRD_VALVE_MAX; index++) {
                if (xBoardCFG->valve[index].en == 1) {
                    if ((xBoardCFG->valve[index].t == uuzPORT_IRR_FLOOD)
                            || (xBoardCFG->valve[index].t == uuzPORT_IRR_DRAIN)
                            || (xBoardCFG->valve[index].t == uuzPORT_IRR_IN)
                            || (xBoardCFG->valve[index].t == uuzPORT_IRR_QUALITY)
                            || (xBoardCFG->valve[index].t == uuzPORT_IRR_MIX)) {
                        usCountIRR++;   //计算灌溉相关的端口总数据
                    }
                }
            }
        }
    }

    if (usCountIRR) {   //端口数据总计
        currentPage = ucPageGet(6, usCountIRR);   //查看读取的页码数据是否OK
        LOG_D("curr:%d-total:%d", currentPage, usCountIRR);

        //发送传感器数量和页码数量
        hmi_sys_send("k00", usCountIRR);
        hmi_sys_send("k01", currentPage);

        min = page * 6;
        max = (page + 1) * 6;

        if (xDevSTA.usCountBrd) {   //端口板相关数据
            for (index = 0; index < uuzDEV_BRD_VALVE_MAX; index++) {
                if (xBoardCFG->valve[index].en == 1) {
                    if ((xBoardCFG->valve[index].t == uuzPORT_IRR_FLOOD)
                            || (xBoardCFG->valve[index].t == uuzPORT_IRR_DRAIN)
                            || (xBoardCFG->valve[index].t == uuzPORT_IRR_IN)
                            || (xBoardCFG->valve[index].t == uuzPORT_IRR_QUALITY)
                            || (xBoardCFG->valve[index].t == uuzPORT_IRR_MIX)) {
                        if (count >= min && count < max) {   //有一个有效数据
                            rt_sprintf(cmd, "g%02d", ((count % 6) * 10 + 20));
                            hmi_sys_send(cmd, xBoardCFG->valve[index].en);    //使能
                            rt_sprintf(cmd, "g%02d", ((count % 6) * 10 + 21));
                            hmi_sys_send(cmd, xBoardCFG->valve[index].t);     //类型
                            rt_sprintf(cmd, "g%02d", ((count % 6) * 10 + 22));
                            hmi_sys_send(cmd, index);   //端口位置
                            rt_sprintf(cmd, "g%02d", ((count % 6) * 10 + 23));
                            hmi_sys_send(cmd, xDevSTA.xBrd[0].id);
                        }
                        count++;
                    }
                }
            }
        }
        //清空空位置
        if (count < max) {
            for (index = count; index < max; index++) {
                //是一个无效数据
                rt_sprintf(cmd, "g%02d", ((index % 6) * 10 + 20));
                hmi_sys_send(cmd, 0);
            }
        }
    }
}

/**
 * @brief 传感器状态列表
 * @param page:当前显示的页面页面（0-N）
 */
void hmi_sensor_state_loading(u8 page)
{
    char cmd[16];
    u8 index = 0;
    u8 count = 0;
    u8 tPage = 0;
    u8 min = 0;
    u8 max = 0;

    tPage = ucPageGet(uuzHMI_PAGE_MAX, xDevSTA.usCountSR);

    if (tPage > page) {   //查看读取的页码数据是否OK
        //发送传感器数量和页码数量
        hmi_sys_send("k00", xDevSTA.usCountSR);
        hmi_sys_send("k01", tPage);

        min = page * uuzHMI_PAGE_MAX;
        max = (page + 1) * uuzHMI_PAGE_MAX;

        if (xDevSTA.usCountB2) {
            //加载PHEC-HUB的相关数据
            for (index = 0; index < uuzDEV_PHEC_B2_MAX; index++) {
                if (xDevSTA.xB2[index].en == uuzDEV_REG_OK) {
                    if (count >= min && count < max) {        //有一个有效数据
                        rt_sprintf(cmd, "g%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 20));
                        hmi_sys_send(cmd, xDevSTA.xB2[index].en);
                        rt_sprintf(cmd, "g%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 21));
                        hmi_sys_send(cmd, xDevSTA.xB2[index].type);
                        rt_sprintf(cmd, "g%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 22));
                        hmi_sys_send(cmd, xDevSTA.xB2[index].isconnect);
                        rt_sprintf(cmd, "g%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 23));
                        hmi_sys_send(cmd, xDevSTA.xB2[index].id);
                    }
                    count++;
                }
            }
        }

        if (xDevSTA.usCountP260) {
            //加载PHEC-HUB的相关数据
            for (index = 0; index < uuzDEV_SIN_P260_MAX; index++) {
                if (xDevSTA.xP260[index].en == uuzDEV_REG_OK) {
                    if (count >= min && count < max) {
                        //有一个有效数据
                        rt_sprintf(cmd, "g%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 20));
                        hmi_sys_send(cmd, xDevSTA.xP260[index].en);
                        rt_sprintf(cmd, "g%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 21));
                        hmi_sys_send(cmd, xDevSTA.xP260[index].type);
                        rt_sprintf(cmd, "g%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 22));
                        hmi_sys_send(cmd, xDevSTA.xP260[index].isconnect);
                        rt_sprintf(cmd, "g%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 23));
                        hmi_sys_send(cmd, xDevSTA.xP260[index].id);
                    }
                    count++;
                }
            }
        }

        if (count < max) {        //清空空位置
            for (index = count; index < max; index++) {
                rt_sprintf(cmd, "g%02d", ((index % uuzHMI_PAGE_MAX) * 10 + 20));        //是一个无效数据
                hmi_sys_send(cmd, 0);
            }
        }
    }
}

/**
 * @brief 执行设备状态列表
 * @param page:当前显示的页面页面（0-N）
 */
void hmi_device_state_loading(u8 page)
{
    char cmd[16];
    u8 index = 0;
    u8 count = 0;
    u8 currentPage = 0;
    u8 min = 0;
    u8 max = 0;

    currentPage = ucPageGet(uuzHMI_PAGE_MAX, xDevSTA.usCountDEV);

    if (currentPage > page) {        //查看读取的页码数据是否OK
        hmi_sys_send("k00", xDevSTA.usCountDEV);
        hmi_sys_send("k01", currentPage);

        min = page * uuzHMI_PAGE_MAX;
        max = (page + 1) * uuzHMI_PAGE_MAX;

        if (xDevSTA.usCountBrd) {        //加载Power Broad的相关数据
            for (index = 0; index < uuzDEV_BRD_MAX; index++) {
                if (xDevSTA.xBrd[index].en == uuzDEV_REG_OK) {
                    if (count >= min && count < max) {
                        //有一个有效数据
                        rt_sprintf(cmd, "g%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 20));
                        hmi_sys_send(cmd, xDevSTA.xBrd[index].en);
                        rt_sprintf(cmd, "g%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 21));
                        hmi_sys_send(cmd, xDevSTA.xBrd[index].type);
                        rt_sprintf(cmd, "g%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 22));
                        hmi_sys_send(cmd, xDevSTA.xBrd[index].isconnect);
                        rt_sprintf(cmd, "g%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 23));
                        hmi_sys_send(cmd, xDevSTA.xBrd[index].id);
                    }
                    count++;
                }
            }
        }

        if (xDevSTA.usCountDos) {
            //加载蠕动泵的相关数据
            for (index = 0; index < uuzDEV_DOS_MAX; index++) {
                if (xDevSTA.xDos[index].en == uuzDEV_REG_OK) {
                    if (count >= min && count < max) {        //有一个有效数据
                        rt_sprintf(cmd, "g%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 20));
                        hmi_sys_send(cmd, xDevSTA.xDos[index].en);
                        rt_sprintf(cmd, "g%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 21));
                        hmi_sys_send(cmd, xDevSTA.xDos[index].type);
                        rt_sprintf(cmd, "g%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 22));
                        hmi_sys_send(cmd, xDevSTA.xDos[index].isconnect);
                        rt_sprintf(cmd, "g%02d", ((count % uuzHMI_PAGE_MAX) * 10 + 23));
                        hmi_sys_send(cmd, xDevSTA.xDos[index].id);
                    }
                    count++;
                }
            }
        }

        if (count < max) {        //清空空位置
            for (index = count; index < max; index++) {        //是一个无效数据
                rt_sprintf(cmd, "g%02d", ((index % uuzHMI_PAGE_MAX) * 10 + 20));
                hmi_sys_send(cmd, 0);
            }
        }
    }
}

/**
 * @brief 外设设备状态列表
 * @param page:当前显示的页面页面（0-N）
 */
void hmi_external_state_loading(u8 page)
{
    char cmd[16];
    u8 index = 0;
    u8 count = 0;
    u8 currentPage = 0;
    u8 max = 0;

    currentPage = ucPageGet(6, xDevSTA.usCountAUX);

    if (currentPage > page) {        //查看读取的页码数据是否OK

        hmi_sys_send("k00", xDevSTA.usCountAUX);
        hmi_sys_send("k01", currentPage);

        max = (page + 1) * 6;

        if (count < max) {        //清空空位置
            for (index = count; index < max; index++) {
                //是一个无效数据
                rt_sprintf(cmd, "g%02d", ((index % 6) * 10 + 20));
                hmi_sys_send(cmd, 0);
            }
        }
    }
}

/* ----------------------------------------------------------------*/
