/**
 * @file uuzHMI_Dev.c
 * @author Zhou Xiaomin (zxm123465@gmail.com)
 * @brief 
 * @version 0.3
 * @date 2020-04-12
 * 
 * @copyright Copyright (c) 2020
 * 
 */
/* Includes ------------------------------------------------------------------*/
#include <rtthread.h>
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
/* ----------------------------------------------------------------*/
#include "uuzEventHMI.h"
#include "uuzHMI_UI.h"
/* ----------------------------------------------------------------*/
#include "uuzEEPROM.h"
#include "uuzOpt.h"
#include "uuzRTC.h"
/* ----------------------------------------------------------------*/
#include "uuzDevID.h"
/*log----------------------------------------------------------*/
#define DBG_TAG "hmi.dev"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/* ----------------------------------------------------------------*/
/**
 * @brief 发送等待ID数据
 * 
 * @return u8 
 */
void uuz_vRegID_WaitSend(void)
{
#if 0
    u8 index = 0;
    u8 ucIsNeedSend = 1;

    //有等待发送数据
    if (xDevSTA.usWaitRegCount) {
        //默认数据
        ucIsNeedSend = 1;
        //检测是否有已发送未回复数据
        for (index = 0; index < uuzDEV_WAIT_REG_MAX; index++) {
            if (xDevSTA.xWaitRegID[index].en == uuzDEV_REG_WAIT) {
                //有待回复数据，先不发送新数据
                ucIsNeedSend = 0;
                //延时判断
                xDevSTA.xWaitRegID[index].delay++;
            }

            if (xDevSTA.xWaitRegID[index].delay > 2) {
                xDevSTA.xWaitRegID[index].en = uuzDEV_REG_NOT;
                xDevSTA.xWaitRegID[index].delay = 0;
            }
        }

        //准备发送新信息数据
        if (ucIsNeedSend == 1) {
            for (index = 0; index < uuzDEV_WAIT_REG_MAX; index++) {
                //如果是注册没有发送，则将数据发送,
                //只有在完成等待后，才能继续发送相关数据
                if (xDevSTA.xWaitRegID[index].en == uuzDEV_REG_NOT) {
                    //TODO:uuz_vRegWaitIDToHmi(index);
                    //修改数据为待发送状态
                    xDevSTA.xWaitRegID[index].en = uuzDEV_REG_WAIT;
                    xDevSTA.xWaitRegID[index].delay = 0;
                    break;
                }
            }
        }
    }
#endif
}

#if 0
/**
 * @brief 发送弹出的相关数据给HMI屏幕显示
 * 
 * @param index 
 */
void uuz_vRegWaitIDToHmi(u8 index)
{
    char cTmpData[24];

    //发送设备的待注册设备信息
    if ((xDevSTA.xWaitRegID[index].ucSubType == uuzDEV_SL_SCD30)
            || (xDevSTA.xWaitRegID[index].ucSubType == uuzDEV_SL_S8)) {
        hmi_txt_send("tip", "txt_e", "CO2 Sensor");
    } else if (xDevSTA.xWaitRegID[index].ucSubType == uuzDEV_SL_SHT30) {
        hmi_txt_send("tip", "txt_e", "H&T Sensor");
    } else if (xDevSTA.xWaitRegID[index].ucSubType == uuzDEV_SL_ACO) {
        hmi_txt_send("tip", "txt_e", "AC Station (CO2)");
    } else if (xDevSTA.xWaitRegID[index].ucSubType == uuzDEV_SL_AHT) {
        hmi_txt_send("tip", "txt_e", "AC Station (H&T)");
    } else if (xDevSTA.xWaitRegID[index].ucSubType == uuzDEV_SL_ATA) {
        hmi_txt_send("tip", "txt_e", "AC Station (Temperature)");
    } else if (xDevSTA.xWaitRegID[index].ucSubType == uuzDEV_SL_LDA1) {
        hmi_txt_send("tip", "txt_e", "LDA-1");
    }

    //发送设备的待注册ID
    rt_sprintf(cTmpData, "ID: %02X%02X%02X%02X", xDevSTA.xWaitRegID[index].ucID[0],
            xDevSTA.xWaitRegID[index].ucID[1], xDevSTA.xWaitRegID[index].ucID[2],
            xDevSTA.xWaitRegID[index].ucID[3]);
    hmi_txt_send("tip", "id_e", cTmpData);

    //记录弹出的数据位
    hmi_sys_send("popN", (index));
    //标记弹出界面属性
    hmi_sys_send("popW", (0x01U));
}

/**
 * @brief 根据页面和标签显示对应的内容
 * 
 * @param ucPage 当前页面
 * @param ucTab  当前标签
 */
void uuz_vDevice_InfoShow(u8 ucPage, u8 ucTab)
{
    u8 ucMin = ucPage * uuzDEV_INFO_LIST_MAX;
    u8 ucMax = 0;
    u8 ucDevMax = 0;
    u8 ucListMax = 0;
    u8 ucMaxPage = ucPage + 1;
    u8 index = 0;
    u8 ucShowIndex = 0;

    if (xCurrUI.ucPageID == uuzHMI_UI_DVL) {
        ucListMax = uuzDEV_INFO_LIST_MAX;
    } else if ((xCurrUI.ucPageID == uuzHMI_UI_SSL) || (xCurrUI.ucPageID == uuzHMI_UI_SDL)) {
        ucListMax = uuzDEV_SR_LIST_MAX;
    } else {
        ucListMax = uuzDEV_INFO_LIST_MAX;
    }

    ucShowIndex = 0;
    switch (ucTab)
    {
        case 0x01U:
        //Sensor List
        //有设备数据
        if (xDevSTA.usCountSR) {
            //计算需要显示的设备总数
            ucDevMax = xDevSTA.usCountSR;
            //判断当前页需要显示的范围
            ucMax = ucMin + ucListMax;
            //解析最大编号
            ucMax = (ucDevMax >= ucMax) ? (ucMax) : (ucDevMax);
            //读取最大页数
            ucMaxPage = ((ucDevMax % ucListMax) == 0) ? (ucDevMax / ucListMax) : ((ucDevMax / ucListMax) + 1);
            //发送最大页数数据
            uuz_vMaxPage_SendToHmi(ucPage, (ucMaxPage - 1));
            LOG_I("Tab[%d]:Min[%d]--Max[%d]", ucTab, ucMin, ucMax);

            if (xDevSTA.usCountHT) {
                for (index = 0; index < uuzDEV_HT_SR_MAX; index++) {
                    if (xDevSTA.xHT[index].ucEnable == uuzDEV_REG_OK) {
                        if ((ucShowIndex >= ucMin) && (ucShowIndex < ucMax)) {
                            uuz_vSingleDevice_SendToHmi((ucShowIndex % ucListMax), &xDevSTA.xHT[index]);
                        }
                        ucShowIndex++;
                    }
                }
            }

            if (xDevSTA.usCountCO2) {
                for (index = 0; index < uuzDEV_CO2_SR_MAX; index++) {
                    if (xDevSTA.xCO2[index].ucEnable == uuzDEV_REG_OK) {
                        if ((ucShowIndex >= ucMin) && (ucShowIndex < ucMax)) {
                            uuz_vSingleDevice_SendToHmi((ucShowIndex % ucListMax), &xDevSTA.xCO2[index]);
                        }
                        ucShowIndex++;
                    }
                }
            }

            if (xDevSTA.usCountB2) {
                for (index = 0; index < uuzDEV_PHEC_B2_MAX; index++) {
                    if (xDevSTA.xB2[index].ucEnable == uuzDEV_REG_OK) {
                        if ((ucShowIndex >= ucMin) && (ucShowIndex < ucMax)) {
                            uuz_vSingleDevice_SendToHmi((ucShowIndex % ucListMax), &xDevSTA.xB2[index]);
                        }
                        ucShowIndex++;
                    }
                }
            }

            if (xDevSTA.usCountP260) {
                for (index = 0; index < uuzDEV_SIN_P260_MAX; index++) {
                    if (xDevSTA.xP260[index].ucEnable == uuzDEV_REG_OK) {
                        if ((ucShowIndex >= ucMin) && (ucShowIndex < ucMax)) {
                            uuz_vSingleDevice_SendToHmi((ucShowIndex % ucListMax), &xDevSTA.xP260[index]);
                        }
                        ucShowIndex++;
                    }
                }
            }
            //如果出余大于0，表示还有数据空格
            //隐藏其他数据
            if (ucShowIndex != ucListMax) {
                for (index = (ucShowIndex % ucListMax); index < ucListMax; index++) {
                    uuz_vSingleDevice_SendToHmi(index, NULL);
                }
            }
        } else {
            for (index = 0; index < ucListMax; index++) {
                uuz_vSingleDevice_SendToHmi(index, NULL);
            }
        }
        break;
        case 0x02U:
        //Device List
        if (xDevSTA.usCountDEV) {
            //计算需要显示的设备总数
            ucDevMax = xDevSTA.usCountDEV;
            //判断当前页需要显示的范围
            ucMax = ucMin + ucListMax;
            //解析最大编号
            ucMax = (ucDevMax >= ucMax) ? (ucMax) : (ucDevMax);
            //读取最大页数
            ucMaxPage = ((ucDevMax % ucListMax) == 0) ? (ucDevMax / ucListMax) : ((ucDevMax / ucListMax) + 1);
            //发送最大页数数据
            uuz_vMaxPage_SendToHmi(ucPage, (ucMaxPage - 1));
            LOG_I("Tab[%d]:Min[%d]--Max[%d]", ucTab, ucMin, ucMax);

            if (xDevSTA.usCountST) {
                for (index = 0; index < uuzDEV_ST_MAX; index++) {
                    if (xDevSTA.xST[index].ucEnable == uuzDEV_REG_OK) {
                        if ((ucShowIndex >= ucMin) && (ucShowIndex < ucMax)) {
                            uuz_vSingleDevice_SendToHmi((ucShowIndex % ucListMax), &xDevSTA.xST[index]);
                        }
                        ucShowIndex++;
                    }
                }
            }
            //隐藏其他数据
            if (ucShowIndex != ucListMax) {
                for (index = (ucShowIndex % ucListMax); index < ucListMax; index++) {
                    uuz_vSingleDevice_SendToHmi(index, NULL);
                }
            }
        } else {
            for (index = 0; index < ucListMax; index++) {
                uuz_vSingleDevice_SendToHmi(index, NULL);
            }
        }
        break;
        case 0x04U:
        //LDA-1 CH1
        if (xDevSTA.usCountCH1) {
            //计算需要显示的设备总数
            ucDevMax = xDevSTA.usCountCH1;
            //判断当前页需要显示的范围
            ucMax = ucMin + ucListMax;
            //解析最大编号
            ucMax = (ucDevMax >= ucMax) ? (ucMax) : (ucDevMax);
            //读取最大页数
            ucMaxPage = ((ucDevMax % ucListMax) == 0) ? (ucDevMax / ucListMax) : ((ucDevMax / ucListMax) + 1);
            //发送最大页数数据
            uuz_vMaxPage_SendToHmi(ucPage, (ucMaxPage - 1));
            LOG_I("Tab[%d]:Min[%d]--Max[%d]", ucTab, ucMin, ucMax);

            if (xDevSTA.usCountLT1) {
                for (index = 0; index < uuzDEV_LT1_MAX; index++) {
                    if (xDevSTA.xLT1[index].ucEnable == uuzDEV_REG_OK) {
                        if ((ucShowIndex >= ucMin) && (ucShowIndex < ucMax)) {
                            uuz_vSingleDevice_SendToHmi((ucShowIndex % ucListMax), &xDevSTA.xLT1[index]);
                        }
                        ucShowIndex++;
                    }
                }
            }
            //隐藏其他数据
            if (ucShowIndex != ucListMax) {
                for (index = (ucShowIndex % ucListMax); index < ucListMax; index++) {
                    uuz_vSingleDevice_SendToHmi(index, NULL);
                }
            }
        } else {
            for (index = 0; index < ucListMax; index++) {
                uuz_vSingleDevice_SendToHmi(index, NULL);
            }
        }
        break;
        case 0x08U:
        //LDA-1 CH2
        if (xDevSTA.usCountCH2) {
            //计算需要显示的设备总数
            ucDevMax = xDevSTA.usCountCH2;
            //判断当前页需要显示的范围
            ucMax = ucMin + ucListMax;
            //解析最大编号
            ucMax = (ucDevMax >= ucMax) ? (ucMax) : (ucDevMax);
            //读取最大页数
            ucMaxPage = ((ucDevMax % ucListMax) == 0) ? (ucDevMax / ucListMax) : ((ucDevMax / ucListMax) + 1);
            //发送最大页数数据
            uuz_vMaxPage_SendToHmi(ucPage, (ucMaxPage - 1));
            LOG_I("Tab[%d]:Min[%d]--Max[%d]", ucTab, ucMin, ucMax);

            if (xDevSTA.usCountLT2) {
                for (index = 0; index < uuzDEV_LT2_MAX; index++) {
                    if (xDevSTA.xLT2[index].ucEnable == uuzDEV_REG_OK) {
                        if ((ucShowIndex >= ucMin) && (ucShowIndex < ucMax)) {
                            uuz_vSingleDevice_SendToHmi((ucShowIndex % ucListMax), &xDevSTA.xLT2[index]);
                        }
                        ucShowIndex++;
                    }
                }
            }
            //隐藏其他数据
            if (ucShowIndex != ucListMax) {
                for (index = (ucShowIndex % ucListMax); index < ucListMax; index++) {
                    uuz_vSingleDevice_SendToHmi(index, NULL);
                }
            }
        } else {
            for (index = 0; index < ucListMax; index++) {
                uuz_vSingleDevice_SendToHmi(index, NULL);
            }
        }
        break;
        case 0x10U:
        //计算需要显示的设备总数
        if (xDevSTA.usCountPT) {
            ucDevMax = xDevSTA.usCountPT;
            //判断当前页需要显示的范围
            ucMax = ucMin + ucListMax;
            //解析最大编号
            ucMax = (ucDevMax >= ucMax) ? (ucMax) : (ucDevMax);
            //读取最大页数
            ucMaxPage = ((ucDevMax % ucListMax) == 0) ? (ucDevMax / ucListMax) : ((ucDevMax / ucListMax) + 1);
            //发送最大页数数据
            uuz_vMaxPage_SendToHmi(ucPage, (ucMaxPage - 1));
            //Port Info
            for (index = 0; index < uuzPORT_MAX; index++) {
                if (xDevConfig.xPortConfig[index].ucEnable == uuzDEV_REG_OK) {
                    if ((ucShowIndex >= ucMin) && (ucShowIndex < ucMax)) {
                        uuz_vSinglePort_SendToHmi((ucShowIndex % ucListMax), &xDevConfig.xPortConfig[index]);
                    }
                    ucShowIndex++;
                }
            }
        }
        break;
        case 64U:
        //计算需要显示的设备总数
        ucDevMax = xDevSTA.usCountDEV + xDevSTA.usCountCH1 + xDevSTA.usCountCH2;
        if (ucDevMax) {
            //判断当前页需要显示的范围
            ucMax = ucMin + ucListMax;
            //解析最大编号
            ucMax = (ucDevMax >= ucMax) ? (ucMax) : (ucDevMax);
            //读取最大页数
            ucMaxPage = ((ucDevMax % ucListMax) == 0) ? (ucDevMax / ucListMax) : ((ucDevMax / ucListMax) + 1);
            //发送最大页数数据
            uuz_vMaxPage_SendToHmi(ucPage, (ucMaxPage - 1));
            LOG_I("Tab[%d]:Min[%d]--Max[%d]", ucTab, ucMin, ucMax);

            if (xDevSTA.usCountST) {
                for (index = 0; index < uuzDEV_ST_MAX; index++) {
                    if (xDevSTA.xST[index].ucEnable == uuzDEV_REG_OK) {
                        if ((ucShowIndex >= ucMin) && (ucShowIndex < ucMax)) {
                            uuz_vSingleDevice_SendToHmi((ucShowIndex % ucListMax), &xDevSTA.xST[index]);
                        }
                        ucShowIndex++;
                    }
                }
            }
            //LDA-1 CH1
            if (xDevSTA.usCountCH1) {
                for (index = 0; index < uuzDEV_LT1_MAX; index++) {
                    if (xDevSTA.xLT1[index].ucEnable == uuzDEV_REG_OK) {
                        if ((ucShowIndex >= ucMin) && (ucShowIndex < ucMax)) {
                            uuz_vSingleDevice_SendToHmi((ucShowIndex % ucListMax), &xDevSTA.xLT1[index]);
                        }
                        ucShowIndex++;
                    }
                }
            }
            //LDA-1 CH2
            if (xDevSTA.usCountCH2) {
                for (index = 0; index < uuzDEV_LT2_MAX; index++) {
                    if (xDevSTA.xLT2[index].ucEnable == uuzDEV_REG_OK) {
                        if ((ucShowIndex >= ucMin) && (ucShowIndex < ucMax)) {
                            uuz_vSingleDevice_SendToHmi((ucShowIndex % ucListMax), &xDevSTA.xLT2[index]);
                        }
                        ucShowIndex++;
                    }
                }
            }
            //隐藏其他数据
            if (ucShowIndex != ucListMax) {
                for (index = (ucShowIndex % ucListMax); index < ucListMax; index++) {
                    uuz_vSingleDevice_SendToHmi(index, NULL);
                }
            }
        } else {
            for (index = 0; index < ucListMax; index++) {
                uuz_vSingleDevice_SendToHmi(index, NULL);
            }
        }
        break;
        default:
        break;
    }
}

/**
 * @brief 发送总页面数据
 * 
 * @param ucPage 
 * @param ucMaxPage 
 */
void uuz_vMaxPage_SendToHmi(u8 ucPage, u8 ucMaxPage)
{
    char cmd[20];

    hmi_sys_send("pg_t", (ucMaxPage - 1));
    rt_sprintf(cmd, "%d/%d", (ucPage + 1), (ucMaxPage + 1));
    hmi_txt_send("dvl", "t27", cmd);
}

/*
 * @brief 发送单个数据信息给HMI
 * 
 * @param ucNum 
 * @param xDev 
 */
void uuz_vSingleDevice_SendToHmi(u8 ucNum, Device_Typedef_t* xDev)
{
    char cmd[32];
    if (xDev != NULL) {
        //Enable
        rt_sprintf(cmd, "ben%d", (ucNum + 1));
        hmi_sys_send(cmd, 0x01);
        //IsConnect
        rt_sprintf(cmd, "bic%d", (ucNum + 1));
        hmi_sys_send(cmd, xDev->ucIsConnect);
        //Type
        rt_sprintf(cmd, "bty%d", (ucNum + 1));
        hmi_sys_send(cmd, xDev->ucSubType);
        //ID
        rt_sprintf(cmd, "bid%d", (ucNum + 1));
        hmi_sys_send(cmd, xDev->ucModbusID);
        //Work State
        rt_sprintf(cmd, "bws%d", (ucNum + 1));
        hmi_sys_send(cmd, xDev->ucData[0]);
    } else {
        rt_sprintf(cmd, "ben%d", (ucNum + 1));
        hmi_sys_send(cmd, 0x00);
    }
}

/**
 * @brief 发送端口的工作状态
 * 
 * @param ucNum 
 * @param xPort 
 */
void uuz_vSinglePort_SendToHmi(u8 ucNum, Port_Typedef_t* xPort)
{
    char cmd[20];
    //Enable
    rt_sprintf(cmd, "ben%d", (ucNum + 1));
    hmi_sys_send(cmd, 0x01);
    //IsConnect
    rt_sprintf(cmd, "bic%d", (ucNum + 1));
    hmi_sys_send(cmd, xPort->ucEnable);
    //Type
    rt_sprintf(cmd, "bty%d", (ucNum + 1));
    hmi_sys_send(cmd, xPort->ucType);
    //ID
    rt_sprintf(cmd, "bid%d", (ucNum + 1));
    hmi_sys_send(cmd, 255);//表示是Port端口
    //Work State
    rt_sprintf(cmd, "bws%d", (ucNum + 1));
    hmi_sys_send(cmd, valve_read(ucNum));
}

/**
 * @brief 显示外部设备数据
 */
void uuz_vExternalDevice_SendToHmi(u8 ucNum, Device_Typedef_t* xDev)
{
    char cmd[32];
    if (xDev != NULL) {
        //Enable
        rt_sprintf(cmd, "cen%d", (ucNum + 1));
        hmi_sys_send(cmd, xDev->ucEnable);
        //IsConnect
        rt_sprintf(cmd, "cic%d", (ucNum + 1));
        hmi_sys_send(cmd, xDev->ucIsConnect);
        //Type
        rt_sprintf(cmd, "cty%d", (ucNum + 1));
        hmi_sys_send(cmd, xDev->ucSubType);
        //ID
        rt_sprintf(cmd, "cid%d", (ucNum + 1));
        hmi_sys_send(cmd, xDev->ucModbusID);
        //Work State
        rt_sprintf(cmd, "cws%d", (ucNum + 1));
        hmi_sys_send(cmd, xDev->ucData[0]);
    } else {
        rt_sprintf(cmd, "cen%d", (ucNum + 1));
        hmi_sys_send(cmd, 0x00);
    }
}
#endif
/* ----------------------------------------------------------------*/
