/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-01   ZhouXiaomin     first version
 */
/* Includes ------------------------------------------------------------------*/
#include <rtdevice.h>
#include <string.h>
/* ------------------------------------------------------------------*/
#include "uuzEVENT.h"
#include "uuzOpt.h"
#include "uuzRTC.h"
#include "uuzUART.h"
/* ------------------------------------------------------------------*/
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
#include "uuzEventDevID.h"
/* ------------------------------------------------------------------*/
#include "typedefHMI.h"
#include "typedefWLS.h"
#include "uuzEventHMI.h"
#include "uuzHMI_UI.h"
#include "uuzEventIRR.h"
#include "uuzEventVALVE.h"
#include "uuzEventWLS.h"
/*log----------------------------------------------------------*/
#define DBG_TAG "ui.main"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/* ----------------------------------------------------------------*/
/**
 * @brief 启动加载界面
 * @param ucKeyID
 * @param ucEvent
 */
void hmi_ui_background_task(u8 ucKeyID, u8* ucEvent)
{
    //TODO:空数据区
}

/**
 * @brief	发送HMI屏幕阶段标记
 *
 * @param  stage 当前的执行的阶段
 */
void hmi_init_stage(u8 stage)
{
    hmi_sys_send("stage", stage);  //后台初始化阶段
    LOG_D("Now Stage is %d", stage);
    rt_thread_mdelay(30);
    hmi_sys_send("stageflag", 0);  //修改发送状态,为等待状态
}

/**
 * @brief 主菜单
 * @param ucKeyID:输入按键
 * @param ucEvent:相关事件
 */
void hmi_ui_main_task(u8 ucKeyID, u8* ucEvent)
{
    u16 data;

    switch (ucKeyID) {
        case 0x00U:  //手动暂停动作
            break;
        case 0x01U:  //灌溉端口相关参数配置
            data = usU8ToU16(ucEvent, uuzLSB);  //AUX的个数
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
            u16 port = usU8ToU16(ucEvent + 2, uuzLSB);  //端口编号
            if (data == 0x02U) {    //直接进入滴灌状态（程序1）
                hmi_irrigation_mode_info_sync(_IRR_TOPFEED, port);  //定制版本，默认为滴灌程序1
            }
#else
            if (data == 0x01U) {    //进入灌溉类型列表界面
                hmi_irrigation_mode_info_sync(xIrrPro->pro[0].md, 0);
                if (xIrrPro->pro[0].md == _IRR_FLOWEBB) {  //NOTE:如果是潮汐式模式,额外显示水位相关数据
                    hmi_wls_data_sync(1);//NOTE:显示水位和自动补水相关数据
                }
            }
#endif
            hmi_reset_loading_stage();  //完成加载标记
            break;
        case 0x02U:  //灯光端口相关参数配置
            //xSysSTA.currPage = usU8ToU16(ucEvent + 2, uuzLSB);  //获取页面编码
            hmi_device_list_sync();  //加载设备标题界面
            hmi_reset_loading_stage();  //完成加载标记
            break;
        case 0x03U:  //传感器和设备相关信息配置
            xSysSTA.state_type = usU8ToU16(ucEvent, uuzLSB);  //当前显示的设备状态
            xSysSTA.currPage = usU8ToU16(ucEvent + 2, uuzLSB);  //获取页面编码
            if (xSysSTA.state_type == 0x01U) {
                hmi_sensor_state_loading(xSysSTA.currPage);  //加载传感器状态
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
        case 0x04U:  //外设相关信息
            data = usU8ToU16(ucEvent, uuzLSB);  //AUX的个数
            hmi_aux_list_sync(data);   //显示设备数据(Board+AUX)
            hmi_reset_loading_stage();  //完成加载标记
            break;
        case 0x05U:  //自动回水相关设置信息
            data = usU8ToU16(ucEvent + 2, uuzLSB);  //读取区域设置编号
            LOG_D("Water Level[%d]", data);
            if (data < _WLS_PRO_MAX) {
                hmi_wls_data_sync(data);   //NOTE:显示水位和自动补水相关数据
            }
            hmi_reset_loading_stage();  //完成加载标记
            break;
        case 0x06U:  //手动锁定密码状态信息
            xSysSTA.is_lock = 1;   //锁定状态
            xSysSTA.tim_lock = 0;    //清除计时
            break;
        case 0x10U:
            rt_event_send(eventDATA, UI_DATA_SYNC);  //刷新传感器数据
            break;
        default:
            break;
    }
}

/**
 * @brief 刷新设备主界面的实时值
 * @param ec:实时EC
 * @param pH:实时pH
 * @param ta:实时温度
 */
void hmi_curr_value_sync(u16 ec, u16 ph, u16 ta)
{
    char cmd[24];
    //Main-EC实时值
    rt_sprintf(cmd, "%d.%02d", ec / 100, ec % 100);
    hmi_txt_send("main", "ecV", cmd);
    //Main-pH实时值
    rt_sprintf(cmd, "%d.%02d", ph / 100, ph % 100);
    hmi_txt_send("main", "phV", cmd);
    //Main-Ta.实时值
    rt_sprintf(cmd, "%d.%d", ta / 10, ta % 10);
    hmi_txt_send("main", "tpV", cmd);
}

/**
 * @brief 延时自检标记
 *
 * @param ucFlag
 * @param usTimeOut
 */
void hmi_self_check_time(u8 ucFlag, u16 usTimeOut)
{
    char cmd[64];
    //如果ucFlag=1表示还在延时状态下
    //如果ucFlag=2表示完成状态
    //如果ucFlag=3表示完成清除状态
    if (ucFlag == 1) {
        rt_sprintf(cmd, "Device Self-Check %ds.", usTimeOut);
        hmi_txt_send("main", "t_log", cmd);
    } else if (ucFlag == 2) {
        hmi_txt_send("main", "t_log", "Device Startup Completed.");
    } else if (ucFlag == 3) {
        hmi_txt_send("main", "t_log", " ");
    }
}

/**
 * @brief 主页发送灌溉相关西信息
 */
void hmi_irr_sta_sync(void)
{
    hmi_sys_send("s_output", ((xSysSTA.state_brd[0]) & 0x01U));    //灌溉输出
    hmi_sys_send("s_back", ((xSysSTA.state_brd[0] >> 1) & 0x01U));    //灌溉回水
    hmi_sys_send("s_in", ((xSysSTA.state_brd[0] >> 2) & 0x01U));    //灌溉输入
    //hmi_sys_send("s_run", xState[_S_IRR_EN]);//灌溉状态
    //hmi_sys_send("d300", xIrrConfig.mode);//当前灌溉模式
}
