/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-01   ZhouXiaomin     first version
 */
/* Includes ------------------------------------------------------------------*/
#include <rtdevice.h>
#include <string.h>
/* ------------------------------------------------------------------*/
#include "uuzEVENT.h"
#include "uuzOpt.h"
#include "uuzRTC.h"
#include "uuzUART.h"
/* ------------------------------------------------------------------*/
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
#include "uuzEventDevID.h"
/* ------------------------------------------------------------------*/
#include "typedefHMI.h"
#include "uuzEventHMI.h"
#include "uuzHMI_UI.h"
/* ------------------------------------------------------------------*/
#include "uuzEventPROG.h"
#include "uuzEventCFG.h"
#include "uuzEventSCH.h"
#include "uuzEventDOSING.h"
/*log----------------------------------------------------------*/
#define DBG_TAG "ui.nut"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/* ----------------------------------------------------------------*/

/**
 * @brief 周期表参数运行程序选择
 * @param ucKeyID:输入按键
 * @param ucEvent:相关事件
 */
void hmi_ui_nut_schedule_task(u8 ucKeyID, u8* ucEvent)
{
    //u16 mode = 0;   //当前模式
    u16 program = 0;    //当前程序

    switch (ucKeyID) {
        case 0x01U:
            LOG_D("Loading Schedule Data!");
            //读取周期表数据
            hmi_sch_config_sync();
            rt_thread_mdelay(1000);
            //刷新界面
            hmi_resync_ui_stage(1);
            //完成同步后，发送完成标记
            hmi_reset_loading_stage();
            break;
        case 0x02U:
            //mode = usU8ToU16(ucEvent, uuzLSB);  //定量、动态模式
            program = usU8ToU16(ucEvent + 2, uuzLSB);   //程序编号
            if (program >= 0 && program < 9) {  //判断编号符合
#if 0
                LOG_D("Loading Program Data:%d", (program + 1));
                if (xSysCFG.single_mode == 0) {  //定量配肥模式
                    hmi_fixed_single_config_sync(xProgCFG.xFixed[program]);
                } else if (xSysCFG.single_mode == 1) {  //动态配肥模式
                    hmi_prog_single_config_sync(xProgCFG.xDynamic[program]);
                }
#else
                hmi_prog_single_config_sync(xProgCFG.xDynamic[program]);
#endif
            }
            hmi_reset_loading_stage();  //完成同步后，发送完成标记
            break;
        default:
            break;
    }
}

/**
 * @brief 默认参数运行程序选择
 * @param ucKeyID:输入按键
 * @param ucEvent:相关事件
 */
void hmi_ui_nut_program_task(u8 ucKeyID, u8* ucEvent)
{
    u16 mode = 0;   //当前模式
    u16 program = 0;    //当前程序
    u16 save_flag = 0;  //保存标记

    switch (ucKeyID) {
        case 0x01U:
            mode = usU8ToU16(ucEvent, uuzLSB);  //定量、动态
            program = usU8ToU16(ucEvent + 2, uuzLSB);
#if 0
            if (mode == 1) {    //动态工作模式
                if (xSysCFG.dynamic_id != program) {
                    xSysCFG.dynamic_id = program;
                    save_flag = 1;
                }
            } else if (mode == 0) {    //定量工作模式
                if (xSysCFG.fixed_id != program) {
                    xSysCFG.fixed_id = program;
                    save_flag = 1;
                }
            }
#else
            if (xSysCFG.dynamic_id != program) {
                xSysCFG.dynamic_id = program;
                save_flag = 1;
            }
#endif
            if (save_flag) {    //TODO:切换运行模式
                system_config_save();    //保存相关数据
            }
            //更新软件缓存
            prog_cache_init();  //清除缓存数据
            dosing_all_close();
            hmi_reset_loading_stage();    //完成同步后，发送完成标记
            rt_event_send(eventDATA, UI_STA_SYNC);                //添加发送界面刷新计数
            break;
        case 0x02U:    //加载程序的基本配置
            mode = usU8ToU16(ucEvent, uuzLSB);  //定量、动态模式
            program = usU8ToU16(ucEvent + 2, uuzLSB);   //程序编号
            LOG_D("program[%d]", program);
            if (program >= 0 && program < 9) {  //判断编号符合
                hmi_prog_single_config_sync(xProgCFG.xDynamic[program]);
            }
            hmi_reset_loading_stage();  //完成同步后，发送完成标记
            break;
        default:
            break;
    }
}

/**
 * @brief 默认参数运行程序选择
 * @param ucKeyID:输入按键
 * @param ucEvent:相关事件
 */
void hmi_ui_nut_fixed_task(u8 ucKeyID, u8* ucEvent)
{
    //u16 program = 0;   //当前模式
    u16 state = 0;    //当前程序

    switch (ucKeyID) {
        case 0x01U:  //手动开启配肥动作
            //program = usU8ToU16(ucEvent, uuzLSB);  //编号
            state = usU8ToU16(ucEvent + 2, uuzLSB);  //状态
            if (state == 0) {
                xSysSTA.need_dosing_fixed = 0;
            } else {
                xSysSTA.need_dosing_fixed = 1;
            }
            break;
        default:
            break;
    }
}

/**
 * @brief Program(Dosing Config)参数设置界面
 * @param ucKeyID:输入按键
 * @param ucEvent:相关事件
 */
void hmi_ui_nut_pps_set_task(u8 ucKeyID, u8* ucEvent)
{
    u8 f_save = 0;
    u8 dosing_num = 0;

    switch (ucKeyID) {
        case 0x01U:
            xDosCFG->rtc[0] = usU8ToU16(ucEvent, uuzLSB);  //year
            xDosCFG->rtc[1] = ucEvent[2];  //month
            xDosCFG->rtc[2] = ucEvent[3];  //day
            xDosCFG->rtc[3] = ucEvent[4];  //hour
            xDosCFG->rtc[4] = ucEvent[5];  //min
            xDosCFG->rtc[5] = ucEvent[6];  //sec
            //向蠕动发送重置数据
            dosing_cycle_group_reset();
            LOG_D("Update Reset Cycles Time");
            //保存相关数据
            config_data_save(_S_CFG_DOS, 0xFFFFU);  //保存相关数据
            //TODO:保存日志
            break;
        case 0x02U:
            dosing_num = ucEvent[0];
            LOG_D("Dosing Num[%d]", dosing_num);
            if (dosing_num <= uuzDEV_DOS_MAX) {   //数据符合范围
                if (xSysCFG.dosing_num != dosing_num) {
                    xSysCFG.dosing_num = dosing_num;    //更新相关数据
                    f_save = 1;
                }
            }
            if (f_save) {   //保存数据
                system_config_save();   //保存相关数据
                hmi_sys_send("d130", xSysCFG.dosing_num);  //蠕动泵数量
            }
            for (u8 index = 0; index < xSysCFG.dosing_num; index++) {  //初次同步蠕动泵数据
                dosing_config_set(index, 100, xDosCFG);  //发送相关数据
            }
            break;
        default:
            break;
    }
}
