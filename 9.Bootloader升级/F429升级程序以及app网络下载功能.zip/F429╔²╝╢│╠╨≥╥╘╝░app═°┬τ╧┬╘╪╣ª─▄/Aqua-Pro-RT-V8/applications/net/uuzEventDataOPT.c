/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-08-28   ZhouXiaomin     first version
 */
/*include*****************************************************************************/
#include "uuzOpt.h"
#include <finsh.h>
#include <netdb.h>
#include <rtthread.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h> /* 使用BSD socket，需要包含socket.h头文件 */
/******************************************************************************/
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
#include "uuzConfigUART.h"
#include "uuzConfigEEPROM.h"
/******************************************************************************/
#include "uuzRTC.h"
#include "uuzEEPROM.h"
#include "typedefNET.h"
#include "uuzDevCFG.h"
#include "uuzEventDataOPT.h"
#include "uuzEventHMI.h"
#include "uuzHMI_UI.h"
#include "uuzOPT.h"
#include "uuzEventTCP.h"
/******************************************************************************/
#define DBG_ENABLE
#define DBG_SECTION_NAME "NET "
#define DBG_LEVEL DBG_LOG
#define DBG_COLOR
#include <rtdbg.h>
/******************************************************************************/
NetCache_Typedef_t xNetCache;    //网络配置数据缓存
NetConfig_Typedef_t xNetConfig;    //网络配置数据
//u16 map[uuzNET_MAP_MAX];    //网络缓存数据
//u8 net_init_flag = 0;  //网络状态初始化标记
/******************************************************************************/
#define uuzNET_RBT_MAX (300U)
#define uuzNET_RBT_LIMIT (1000U)
/******************************************************************************/
/**
 * @brief 保存设备的网络配置信息
 */
void net_config_save(void)
{
    LOG_D("Save Net Data");
    //uuz_vConfigToEEPROMWrite(
    //uuzEEPROM_ADDR_NET, (u8*) (&xNetConfig), sizeof(xNetConfig));
    rt_thread_mdelay(50);
}

/**
 * @brief 读取设备的配置信息
 * @param flag
 */
void net_config_init(u8 flag)
{
    u8 ip[4] =
                { 192, 168, 0, 63 };
    u8 gw[4] =
                { 192, 168, 0, 1 };
    u8 mask[4] =
                { 255, 255, 0, 0 };
    u8 serverip[4] =
            //{ 212, 13, 9, 198 };    //阿里云云端1
                { 120, 78, 138, 133 };    //阿里云云端2
    //{ 50, 18, 69, 89 };   //亚马逊云端
    //相关端口
    u32 serverport = 6800;    //默认发送端口
    u32 lport = 6800;    //默认监听端口

    if (!flag) {
        //从EERPOM读取Net Config相关数据
        //uuz_vConfigFromEEPROMRead(
        //uuzEEPROM_ADDR_NET, (u8*) (&xNetConfig), sizeof(xNetConfig));
        rt_thread_delay(20);
    }

    //更新模块设备Net Config
    if ((xNetConfig.end != 0xBBBBU) || (flag)) {
        rt_memset(&xNetConfig, 0x00, sizeof(NetConfig_Typedef_t));
        xNetConfig.mode = 1;    //0-Manual|1-Auto DNS
        //设置默认IP参数
        rt_memcpy(xNetConfig.ip, ip, 4);    //192.168.0.63
        rt_memcpy(xNetConfig.gw, gw, 4);    //192.168.0.1
        rt_memcpy(xNetConfig.mask, mask, 4);    //255.255.0.0
        xNetConfig.cloud = 2;   //0-Amazon|1-Aliyun|2-Default IP
        ip_string_to_hex(serverip, uuzNET_CLOUD_DEFAULT);   //转换数据到数字IP
        rt_memcpy(xNetConfig.serverip, serverip, 4);    //212.13.9.198
        //1-Aliyun:212.13.9.198
        xNetConfig.serverport = serverport;   //6800
        xNetConfig.lport = lport;   //6800
        //初始化默认配置
        xNetConfig.end = 0xBBBBU;
        //保存网络数据
        net_config_save();
        LOG_W("Reset Net Config");
    } else {
        LOG_I("Read Net Config Success,Cloud[%d]", xNetConfig.cloud);
    }
}

/**
 * @brief 网络相关数据汇总
 * @return
 */
int net_data_init(void)
{
    rt_err_t ret = RT_EOK;
    rt_thread_t thread;
    //准备互斥锁
    net_mux = rt_mutex_create("net_lock", RT_IPC_FLAG_PRIO);
    if (ret == RT_EOK) {
        /* 创建 serial 线程 */
        thread = rt_thread_create("tcp_data", net_data_thread_entry,
        RT_NULL, 1024, 15, 20);

        /* 创建成功则启动线程 */
        if (thread != RT_NULL) {
            rt_thread_startup(thread);
            LOG_I("start Thread [net data] success.");
        } else {
            LOG_E("start Thread [net data] failed.");
            ret = RT_ERROR;
        }
    }

    return ret;
}

/**
 * @brief 网络数据处理
 * @param parameter
 */
void net_data_thread_entry(void* parameter)
{
    static u32 net_count = 0;   //初始化网络计数标记

    while (1) {
        net_count++;
        rt_thread_mdelay(100);
    }
}



