/*
 * @Copyright (c) 2006-2018 RT-Thread Development Team:  
 * @SPDX-License-Identifier: Apache-2.0:  
 * @Date: 2020-01-01 09:23:03
 * @LastEditors  : Zhou Xiaomin
 * @LastEditTime : 2020-01-08 15:39:20
 * @Description:  
 */
#ifndef __UUZ_EVENT_TCP_H
#define __UUZ_EVENT_TCP_H

#include "typedefNET.h"
#include "uuzConfigNET.h"

extern u16 map[uuzNET_MAP_MAX];
extern NetConfig_Typedef_t xNetConfig;    //网络配置数据
extern NetCache_Typedef_t xNetCache;    //网络配置数据缓存
extern rt_mutex_t net_mux;   //网络数据缓存标记
extern int send_sock;

#ifdef __cplusplus
extern "C" {
#endif

int net_opt_init(void);
void net_opt_thread_entry(void* parameter);
/**
 * @brief 将IP数据转换成HEX模式
 *
 * @param hex_ip 数据模式的IP
 * @param string_ip 字符串模式的IP
 */
void ip_string_to_hex(u8* hex_ip, char* ip);
u8 netdev_list_get(void);   //获取IP数据和网络状态
#if 0
rt_err_t start_tcp(u32 port, char * url);
void net_data_connect(u16 alarm);
rt_err_t get_data_to_modbus_rtu(u8 * data, u16 * cmd, u8 len);
rt_err_t send_data_to_tcp(u8 connected, const u8 * data, u8 len);

/**
 * @brief 判断设备地址是否有效
 * @return
 */
rt_err_t modbus_rtu_addr_is_assert(u16 addr);
/**
 * @brief 判断读取数据长度是否有效
 * @param len
 * @return 返回数据长度是否OK
 */
rt_err_t modbus_rtu_len_is_assert(u16 addr, u16 len);
/**
 * @brief 回复相关Modbus-RTU相关数据
 * @param code  命令
 * @param data  数据
 * @param len   长度
 */
u8 reply_data_to_tcp(u8 connected, u8 code, u8 * data, u8 len);

/**
 * @param 发送服务器同步数据协议
 */
void sync_data_to_server(void);

/**
 * @brief 网络缓存数据保存数据配置
 *
 * @param state:需要保存的状态
 */
void net_data_save(u16 state);

/**
 * @brief 重新打开TCP端口
 * @param port:需要监听的端口
 * @param url:需要处理 的解析地址
 * @return
 */
rt_err_t reboot_tcp(u32 port, char * url);
#endif
#ifdef __cplusplus
}
#endif

#endif // __UUZ_EVENT_TCP_H
