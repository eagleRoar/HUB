/*
 * @Copyright (c) 2006-2018 RT-Thread Development Team:  
 * @SPDX-License-Identifier: Apache-2.0:  
 * @Date: 2020-01-01 09:23:03
 * @LastEditors  : Zhou Xiaomin
 * @LastEditTime : 2020-01-08 15:39:20
 * @Description:  
 */
#ifndef __UUZ_EVENT_DATA_OPT_H
#define __UUZ_EVENT_DATA_OPT_H

#include "typedefNET.h"
#include "uuzConfigNET.h"

extern rt_mutex_t net_mux;   //网络数据缓存标记
extern u16 map[uuzNET_MAP_MAX];
//extern NetConfig_Typedef_t xNetConfig;    //网络配置数据
//extern NetCache_Typedef_t xNetCache;    //网络配置数据缓存

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 保存设备的网络配置信息
 */
void net_config_save(void);
/**
 * @brief 读取设备的配置信息
 * @param flag
 */
void net_config_init(u8 flag);
int net_data_init(void);
void net_data_thread_entry(void* parameter);

#ifdef __cplusplus
}
#endif

#endif // __UUZ_EVENT_DATA_OPT_H
