/*
 * @Copyright (c) 2006-2018 RT-Thread Development Team:  
 * @SPDX-License-Identifier: Apache-2.0:  
 * @Change Logs: 
 * @Date: 2020-01-01 09:23:03
 * @LastEditors: Zhou Xiaomin
 * @LastEditTime: 2020-01-17 04:49:54
 * @Description:  
 */
#ifndef __TYPEDEF_NET_H
#define __TYPEDEF_NET_H

#include "typedefINIT.h"
#include "uuzOpt.h"

typedef struct __net_config
{
    u8 mode;   //type:0-manual|1-auto dns
    u8 ip[4];   //IP:192.168.0.100
    u8 gw[4];   //GATEWAY:192.168.0.1
    u8 mask[4];   //MASK:255.255.0.0
    u8 serverip[4];   //SERVERIP:212.13.9.192
    u32 cloud;      //云端服务器类型:0-AMAZON|1-AYIYUN|2-手动设置
    u32 serverport;     //服务器目标端口:PORT:6800
    u32 lport;       //监听PORT:6800

    u16 end;    //末尾CRC标记(0xBB+0xBB)

} NetConfig_Typedef_t;

typedef struct __net_cache
{
    u8 ip[4];   //IP:192.168.0.100
    u8 gw[4];   //GATEWAY:192.168.0.1
    u8 mask[4];   //MASK:255.255.0.0

} NetCache_Typedef_t;

#endif // __TYPEDEF_NET_H
