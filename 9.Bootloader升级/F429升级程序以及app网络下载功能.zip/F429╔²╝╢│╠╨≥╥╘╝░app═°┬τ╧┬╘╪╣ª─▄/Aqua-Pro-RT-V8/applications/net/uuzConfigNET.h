/*
 * @Copyright (c) 2006-2018 RT-Thread Development Team:  
 * @SPDX-License-Identifier: Apache-2.0:  
 * @Date: 2020-01-01 09:23:03
 * @LastEditors  : Zhou Xiaomin
 * @LastEditTime : 2020-01-17 04:55:09
 * @Description:  
 */
#ifndef __UUZ_CONFIG_NET_H
#define __UUZ_CONFIG_NET_H

#define uuzNET_MAP_MAX (192U)

#define uuzNET_CLOUD_DEFAULT "192.168.0.128"
#define uuzNET_CLOUD_AMAZON "guardian.pro-leaf.com"
#define uuzNET_CLOUD_ALIYUN "120.78.138.133"

typedef enum net_status
{
    _N_SYNC = 0U,
    _N_DATA = 1U,
    _N_NULL = 2U

} ENMU_NET_STATUS;

#endif // __UUZ_CONFIG_NET_H
