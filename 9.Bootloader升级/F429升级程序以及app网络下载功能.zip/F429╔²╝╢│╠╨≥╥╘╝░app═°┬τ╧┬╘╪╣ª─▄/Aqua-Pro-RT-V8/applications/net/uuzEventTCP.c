/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020-08-28   ZhouXiaomin     first version
 */
/*include*****************************************************************************/
#include "uuzOpt.h"
#include <finsh.h>
#include <netdb.h>
#include <rtthread.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h> /* 使用BSD socket，需要包含socket.h头文件 */
/******************************************************************************/
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
#include "uuzConfigUART.h"
#include "uuzConfigEEPROM.h"
/******************************************************************************/
#include "uuzRTC.h"
#include "uuzEEPROM.h"
#include "typedefNET.h"
#include "uuzDevCFG.h"
#include "uuzEventTCP.h"
#include "uuzEventHMI.h"
#include "uuzHMI_UI.h"
#include "uuzOPT.h"
#include "uuzEventDataOPT.h"
/******************************************************************************/
#define DBG_ENABLE
#define DBG_SECTION_NAME "TCP "
#define DBG_LEVEL DBG_LOG
#define DBG_COLOR
#include <rtdbg.h>
/******************************************************************************/
#if 0
NetCache_Typedef_t xNetCache;    //网络配置数据缓存
NetConfig_Typedef_t xNetConfig;//网络配置数据
u16 map[uuzNET_MAP_MAX];//网络缓存数据
rt_mutex_t net_mux = RT_NULL;//网络数据缓存标记
u32 is_connect_sock_flag = RT_FALSE;
#endif

/******************************************************************************/
//#define uuzNET_RBT_MAX (300U)
//#define uuzNET_RBT_LIMIT (1000U)
/******************************************************************************/
/** @brief  Net的缓存数据 */
/**
 * @brief:  int net_opt_init(void)
 * @note:  初始化TCP接收端口
 * @returns:  int
 * @Author: Zhou Xiaomin
 * @Date: 2020-01-03 16:25:53
 */
int net_opt_init(void)
{
    rt_err_t ret = RT_ERROR;
    char ip[20];
    //获取网卡信息
    if (netdev_list_get() == RT_TRUE) {        //获取网卡信息
        //初始化网络标记
        if (xNetConfig.cloud == 2) {
            rt_sprintf(
                    ip,
                    "%d.%d.%d.%d",
                    xNetConfig.serverip[0],
                    xNetConfig.serverip[1],
                    xNetConfig.serverip[2],
                    xNetConfig.serverip[3]);
            start_tcp(xNetConfig.serverport, ip);
        } else if (xNetConfig.cloud == 1) {
            start_tcp(xNetConfig.serverport, uuzNET_CLOUD_ALIYUN);
        } else {
            start_tcp(xNetConfig.serverport, uuzNET_CLOUD_AMAZON);
        }
        LOG_D("Cloud Mode:[%d]", xNetConfig.cloud);

#if 0
        ret = RT_EOK;
        rt_thread_t thread;
        //准备互斥锁
        if (ret == RT_EOK) {
            /* 创建 serial 线程 */
            thread = rt_thread_create("tcp_net", net_opt_thread_entry,
                    RT_NULL, 4096, 16, 20);

            /* 创建成功则启动线程 */
            if (thread != RT_NULL) {
                rt_thread_startup(thread);
                LOG_I("start Thread [net tcp] success.");
            } else {
                LOG_E("start Thread [net tcp] failed.");
                ret = RT_ERROR;
            }
        }
#endif
    }

    return ret;
}

#if 0
char recv_data[1024];
int sock;
int send_sock = RT_FALSE;
struct sockaddr_in server_addr;
struct sockaddr_in send_addr;
#endif
void net_opt_thread_entry(void* parameter)
{
#if 0
    static u32 opt_count = 0;   //初始化网络计数标记
    int bytes_received;
    u16 usUhCRC;
    u16 usRdCRC;
    u16 usWrCRC;
    char send_data[1024];
    /* 数据读取位置 */
    u8 ret_err = 0;
    u16 cmd_addr = 0;
    u16 cmd_len = 0;
    u16 cmd_num = 0;
    u8 lenCommand = 0;
    u8 cmd_data[uuzUART_LEN];
    u16 dataCommand[uuzUART_LEN];
    u16 saveState = uuzFALSE;

    net_data_connect(0x00);  //发生注册指令
    while (1) {
        /* 客户端连接的处理 */
        while (opt_count < uuzNET_RBT_LIMIT) {
            if (opt_count >= uuzNET_RBT_MAX) {      //计数超过30秒,中断连接重新开始
                opt_count = uuzNET_RBT_LIMIT;
                closesocket(send_sock);
                LOG_D("Socket: %d | Time Out, reboot Register", send_sock);
                is_connect_sock_flag = RT_FALSE;
            } else {
                /* 从connected socket中接收数据，接收buffer是1024大小，但并不一定能够收到1024大小的数据 */
                if (is_connect_sock_flag == RT_TRUE) {
                    LOG_D("Ready To Recvice Data:%d", opt_count);
                    bytes_received = recv(send_sock, recv_data, 1024, 0);   //接收无数据为（-1）
                    LOG_D("Socket: %d | Received bytes:%d", send_sock, bytes_received);
                    if (bytes_received < 0) {
                        /* 接收失败，关闭这个connected socket */
                        opt_count++;    //每秒延时计数
                    } else if (bytes_received == 0) {
                        /* 打印recv函数返回值为0的警告信息 */
                        LOG_W("Received warning,recv function return 0.");
                        opt_count++;    //每秒延时计数
                        rt_thread_mdelay(1000);
                    } else {
                        opt_count = 0;                //清除延时

                        /* 有接收到数据，把末端清零 */
                        recv_data[bytes_received] = '\0';
#if 0
                        LOG_D("TCP[%d]:", bytes_received);
                        for (u8 index = 0; index < bytes_received; index++) {
                            if ((index != 0) && ((index % 24) == 0)) {
                                LOG_D("\r\n");
                            }
                            LOG_D("%c ", recv_data[index]);
                        }
                        LOG_D("\r\n");
#endif
                        if (recv_data[0] == 0xFE) {
                            /* 在控制终端显示收到的数据 */
#if 1
                            /* 显示特定数据 */
                            if ((recv_data[1] == uuzMBR_WRITE_MULTIPLE_REGISTERS)
                                    || (recv_data[1] == uuzMBR_READ_HOLDING_REGISTER)) {
                                LOG_D("TCP[%d]:", bytes_received);
                                for (u8 index = 0; index < bytes_received; index++) {
                                    if ((index != 0) && ((index % 24) == 0)) {
                                        LOG_D("\r\n");
                                    }
                                    LOG_D("%02X ", recv_data[index]);
                                }
                                LOG_D("\r\n");
                            }
#endif
                            //判断CRC是否正常
                            //达到检测长度，进行CRC16对比（LSB）
                            usUhCRC = usModbusRTU_CRC((u8*) recv_data, (bytes_received - 2));//计算当前的CRC16
                            usRdCRC = usU8ToU16((u8*) (recv_data + (bytes_received - 2)), uuzLSB);//读取协议中的CRC16

                            if (usUhCRC == usRdCRC) {
                                if (recv_data[1] == uuzMBR_READ_HOLDING_REGISTER) {
                                    //读取相关数据
                                    cmd_addr = usU8ToU16((u8*) (recv_data + 2), uuzMSB);
                                    cmd_len = usU8ToU16((u8*) (recv_data + 4), uuzMSB);
                                    LOG_D("ADDR:%d", cmd_addr);
                                    if (cmd_addr < uuzNET_MAP_MAX) {  //判断内存地址范围
                                        get_data_to_modbus_rtu(cmd_data, (map + cmd_addr), cmd_len);//获取相关数据
#if 0
                                        LOG_D("MAP[%d]-L[%d]:", cmd_addr, cmd_len);
                                        for (u8 index = 0; index < cmd_len; index++) {
                                            if ((index != 0) && ((index % 24) == 0)) {
                                                LOG_D("\r\n");
                                            }
                                            LOG_D("%d ", map[cmd_addr + index]);
                                        }
                                        LOG_D("\r\n");
                                        LOG_D("CMD[%d]:", cmd_len * 2);
                                        for (u8 index = 0; index < cmd_len * 2; index++) {
                                            if ((index != 0) && ((index % 24) == 0)) {
                                                LOG_D("\r\n");
                                            }
                                            LOG_D("%02X ", cmd_data[index]);
                                        }
                                        LOG_D("\r\n");
#endif
                                        lenCommand = 0;
                                        send_data[lenCommand++] = recv_data[0];  //Modbus-ID
                                        send_data[lenCommand++] = recv_data[1];//Code
                                        send_data[lenCommand++] = cmd_len * 2;
                                        rt_memcpy(send_data + lenCommand, cmd_data, cmd_len * 2);
                                        lenCommand += cmd_len * 2;
                                        usWrCRC = usModbusRTU_CRC((u8*) send_data, lenCommand);
                                        vU16ToU8((u8*) (send_data + lenCommand), usWrCRC, uuzLSB);
                                        lenCommand += 2;
                                        ret_err = send_data_to_tcp(send_sock, (u8*) send_data, lenCommand);
                                    } else {
                                        LOG_E("MAP is Address Out");
                                    }
                                } else if (recv_data[1] == uuzMBR_WRITE_REGISTER) {
                                    LOG_D("CRC Success!");
                                    lenCommand = 2;
                                    //设置相关数据
                                    cmd_addr = usU8ToU16((u8*) (recv_data + lenCommand), uuzMSB);//数据地址
                                    lenCommand += 2;
                                    if (cmd_addr < uuzNET_MAP_MAX) {  //判断内存地址范围
                                        dataCommand[0] = usU8ToU16((u8*) (recv_data + lenCommand), uuzMSB);//数据数量
                                        lenCommand += 2;
                                        rt_mutex_take(net_mux, RT_WAITING_FOREVER);//上锁
                                        saveState = net_single_data_setting(cmd_addr, dataCommand[0], saveState);//刷新单个数据
                                        net_data_save(saveState);//检查是否保存标记
                                        rt_mutex_release(net_mux);//解锁
                                        ret_err = reply_data_to_tcp(
                                                send_sock,
                                                recv_data[1],
                                                (u8*) recv_data,
                                                bytes_received);
                                    } else {
                                        LOG_E("MAP is Address Out");
                                    }
                                } else if (recv_data[1] == uuzMBR_WRITE_MULTIPLE_REGISTERS) {
                                    LOG_D("Multi CRC Success!");
                                    lenCommand = 2;
                                    //设置相关数据
                                    cmd_addr = usU8ToU16((u8*) (recv_data + lenCommand), uuzMSB);//数据地址
                                    lenCommand += 2;
                                    if (cmd_addr < uuzNET_MAP_MAX) {  //判断内存地址范围
                                        cmd_num = usU8ToU16((u8*) (recv_data + lenCommand), uuzMSB);//数据数量
                                        lenCommand += 2;
                                        cmd_len = recv_data[lenCommand++];//数据长度
                                        rt_mutex_take(net_mux, RT_WAITING_FOREVER);//上锁
                                        saveState = 0;
                                        //更新数据
                                        for (u16 index = 0; index < cmd_len;
                                                index += 2, cmd_addr++, lenCommand += 2) {
                                            dataCommand[index] = usU8ToU16(
                                                    (u8*) (recv_data + lenCommand),
                                                    uuzMSB);  //数据数量
                                            saveState = net_single_data_setting(
                                                    cmd_addr,
                                                    dataCommand[index],
                                                    saveState);//刷新单个数据
                                        }
                                        LOG_I("saveState:%d", saveState);
                                        net_data_save(saveState);   //检查是否保存标记
                                        rt_mutex_release(net_mux);//解锁
                                        //更新实际数据
                                        ret_err = reply_data_to_tcp(
                                                send_sock,
                                                recv_data[1],
                                                (u8*) recv_data,
                                                bytes_received);
                                    } else {
                                        LOG_E("MAP is Address Out");
                                    }
                                }

                                if (ret_err < 0) {
                                    closesocket(send_sock);
                                    is_connect_sock_flag = RT_FALSE;
                                    opt_count = uuzNET_RBT_LIMIT;                        //发生连接错误，关闭SOCK
                                    LOG_E("send error,close the socket.");
                                } else if (ret_err == 0) {
                                    LOG_W("Send warning,send function return 0.");
                                }
                            }
                        }
                    }
                }
                if (is_connect_sock_flag == RT_FALSE) {
                    closesocket(send_sock);
                    opt_count = uuzNET_RBT_LIMIT;                        //发生连接错误，关闭SOCK
                    LOG_D("Socket: %d | Time Out, reboot Change Server", send_sock);
                }
            }
        }  //while opt need close
        net_data_connect(0x00);//发生注册指令
        opt_count = 0;
        rt_thread_mdelay(1000);
    }
#else
    rt_thread_mdelay(1000);
#endif
}

#if 0
void net_data_connect(u16 alarm)
{
    if (is_connect_sock_flag == RT_FALSE) {

        /* 创建一个socket，类型是SOCKET_STREAM，TCP类型 */
        if ((send_sock = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
            /* 创建socket失败 */
            LOG_D("Socket error Send");
        }

        if (send_sock != (-1)) {    //sock数据有效
            //添加阻塞延时等待
            struct timeval tv_out;
            tv_out.tv_sec = 3;
            tv_out.tv_usec = 0;
            setsockopt(send_sock, SOL_SOCKET, SO_RCVTIMEO, &tv_out, sizeof(tv_out));
#if 1
            //端口复用设置,断线重连
            int opt = 1;
            setsockopt(send_sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
#endif
            LOG_I("Open Socket Send Success");
        }

        /* 连接到服务端 */
        if (connect(send_sock, (struct sockaddr *) &send_addr, sizeof(struct sockaddr)) == (-1)) {
            /* 连接失败 */
            LOG_D("Connect fail!");
            //closesocket(send_sock);
            is_connect_sock_flag = RT_FALSE;
        } else {
            /* 连接成功 */
            LOG_D("Connect successful:%0x02X", send_sock);
            is_connect_sock_flag = RT_TRUE;
        }
    }

    if (is_connect_sock_flag == RT_TRUE) {
        sync_data_to_server();                                //发送服务器同步数据
    }

    return;
}

/**
 *
 * @brief 打开TCP端口连接
 * @param port:需要监听的端口
 * @param url:需要处理 的解析地址
 * @return
 */
rt_err_t start_tcp(u32 port, char * url)
{
    struct hostent * host;
    /* 通过函数入口参数url获得host地址（如果是域名，会做域名解析） */
    //char * tmp_url = url;
    //tmp_url = "50.18.69.89";
    host = gethostbyname(url);
    LOG_D("SERVERIP:%s", url);

    /* 初始化服务端地址 */
    send_addr.sin_family = AF_INET;
    send_addr.sin_port = htons(port); /* 服务端工作的端口 */
    send_addr.sin_addr = *((struct in_addr *) host->h_addr);
    rt_memset(&(send_addr.sin_zero), 0, sizeof(send_addr.sin_zero));

    is_connect_sock_flag = RT_FALSE;

    return RT_TRUE;
}
/**
 * @brief 重新打开TCP端口
 * @param port:需要监听的端口
 * @param url:需要处理 的解析地址
 * @return
 */
rt_err_t reboot_tcp(u32 port, char * url)
{
    struct hostent * host;

    LOG_D("%s", url);
    if (is_connect_sock_flag == RT_TRUE) {
        /* 通过函数入口参数url获得host地址（如果是域名，会做域名解析） */
        host = gethostbyname(url);

        /* 初始化服务端地址 */
        send_addr.sin_family = AF_INET;
        send_addr.sin_port = htons(port); /* 服务端工作的端口 */
        send_addr.sin_addr = *((struct in_addr *) host->h_addr);
        rt_memset(&(send_addr.sin_zero), 0, sizeof(send_addr.sin_zero));

        is_connect_sock_flag = RT_FALSE;    //关闭TCP连接状态
    }

    return RT_TRUE;
}

/**
 * @brief 判断设备地址是否有效
 * @return
 */
rt_err_t modbus_rtu_addr_is_assert(u16 addr)
{
    return (addr < uuzNET_MAP_MAX) ? (RT_TRUE) : (RT_FALSE);    //判断地址是否正确
}

/**
 * @brief 判断读取数据长度是否有效
 * @param len
 * @return 返回数据长度是否OK
 */
rt_err_t modbus_rtu_len_is_assert(u16 addr, u16 len)
{
    return ((addr + len) < uuzNET_MAP_MAX) ? (RT_TRUE) : (RT_FALSE);    //判断地址是否正确
}

/**
 * @brief 回复相关Modbus-RTU相关数据
 * @param code  命令
 * @param data  数据
 * @param len   长度
 */
u8 reply_data_to_tcp(u8 connected, u8 code, u8 * data, u8 len)
{
    u8 tmpCommand[uuzUART_LEN];
    u8 lenCommand = 0;
    u16 crcModbus = 0;
    u8 ret_err = 0;

    lenCommand = 0;
    if (code == uuzMBR_WRITE_MULTIPLE_REGISTERS) {
        rt_memcpy(tmpCommand, data, 6);
        lenCommand += 6;
        //CRC16
        crcModbus = usModbusRTU_CRC(tmpCommand, lenCommand);
        vU16ToU8((tmpCommand + lenCommand), crcModbus, uuzLSB);
        lenCommand += 2;
    } else if (code == uuzMBR_WRITE_REGISTER) {
        rt_memcpy(tmpCommand, data, len);
        lenCommand = len;
    }

//回复相关数据
    ret_err = send_data_to_tcp(connected, tmpCommand, lenCommand);
    return ret_err;
}

/**
 *
 * @param 发送服务器同步数据
 */
void sync_data_to_server(void)
{
    u8 send_data[32];
    u16 crcModbus = 0xFFFFU;
    u16 lenCommand = 0;

    LOG_D("Sync Connect State");
//发送通讯协议
    send_data[lenCommand++] = 0xFEU;//id
    send_data[lenCommand++] = 0x03U;//cmd
    send_data[lenCommand++] = 0x08U;//len
    send_data[lenCommand++] = 0x00U;//addr
    send_data[lenCommand++] = 0xEFU;
    send_data[lenCommand++] = xDeviceConfig.xSystemInfo.ucID[0];//Device ID
    send_data[lenCommand++] = xDeviceConfig.xSystemInfo.ucID[1];
    send_data[lenCommand++] = xDeviceConfig.xSystemInfo.ucID[2];
    send_data[lenCommand++] = xDeviceConfig.xSystemInfo.ucID[3];
    vU16ToU8((send_data + lenCommand), map[13], uuzLSB);//Alarm
    lenCommand += 2;
    crcModbus = usModbusRTU_CRC(send_data, lenCommand);//CRC16
    vU16ToU8((send_data + lenCommand), crcModbus, uuzLSB);
    lenCommand += 2;

    send_data_to_tcp(send_sock, send_data, lenCommand);//发送数据给TCP

}

/**
 * @brief 发送TCP数据
 * @param connected
 * @param data
 * @param len
 * @return
 */
rt_err_t send_data_to_tcp(u8 connected, const u8* data, u8 len)
{
    rt_err_t ret_err;

#if 0
    if ((data[1] == uuzMBR_WRITE_MULTIPLE_REGISTERS)
            || (data[1] == uuzMBR_READ_HOLDING_REGISTER)) {
        LOG_D("TCPS[%d]", len);
        for (u8 index = 0; index < len; index++) {
            if ((index != 0) && ((index % 24) == 0)) {
                LOG_D("\r\n");
            }
            LOG_D("%02X ", data[index]);
        }
        LOG_D("\r\n");
    }
#endif

    ret_err = send(connected, (const void *) data, len, 0);  //发送数据

    return ret_err;
}
#endif

#include <netdev.h>
#include <netdev_ipaddr.h>
extern struct netdev * netdev_list;
char ip[20];
u8 netdev_list_get(void)
{
#define NETDEV_IFCONFIG_MAC_MAX_LEN    6
#define NETDEV_IFCONFIG_IEMI_MAX_LEN   8

    u8 state = 0;
    rt_ubase_t index;
    rt_slist_t *node = RT_NULL;
    struct netdev *netdev = RT_NULL;
    struct netdev *cur_netdev_list = netdev_list;

    if (cur_netdev_list == RT_NULL) {
        LOG_D("ifconfig: network interface device list error.");
        return state;
    }

    for (node = &(cur_netdev_list->list); node; node = rt_slist_next(node)) {
        netdev = rt_list_entry(node, struct netdev, list);

        LOG_D("network interface device: %.*s%s",
        RT_NAME_MAX, netdev->name,
                (netdev == netdev_default) ? " (Default)" : "");
        LOG_D("MTU: %d", netdev->mtu);

        /* 6 - MAC address, 8 - IEMI */
        if (netdev->hwaddr_len == NETDEV_IFCONFIG_MAC_MAX_LEN) {
            LOG_D("MAC: %X:%X:%X %X:%X:%X",
                    netdev->hwaddr[0],netdev->hwaddr[1],netdev->hwaddr[2],
                    netdev->hwaddr[3],netdev->hwaddr[4],netdev->hwaddr[5]);
        } else if (netdev->hwaddr_len == NETDEV_IFCONFIG_IEMI_MAX_LEN) {
            LOG_D("IMEI: ");
            for (index = 0; index < netdev->hwaddr_len; index++) {
                /* two numbers are displayed at one time*/
                if (netdev->hwaddr[index] < 10 && index != netdev->hwaddr_len - 1) {
                    rt_kprintf("0");
                }
                rt_kprintf("%d", netdev->hwaddr[index]);
            }
        }

        rt_kprintf("FLAGS:");
        if (netdev->flags & NETDEV_FLAG_UP) {
            rt_kprintf(" UP");
        } else {
            rt_kprintf(" DOWN");
        }
        if (netdev->flags & NETDEV_FLAG_LINK_UP) {
            rt_kprintf(" LINK_UP");
        } else {
            rt_kprintf(" LINK_DOWN");
        }
        if (netdev->flags & NETDEV_FLAG_INTERNET_UP) {
            rt_kprintf(" INTERNET_UP");
        } else {
            rt_kprintf(" INTERNET_DOWN");
        }
        if (netdev->flags & NETDEV_FLAG_DHCP) {
            rt_kprintf(" DHCP_ENABLE");
        } else {
            rt_kprintf(" DHCP_DISABLE");
        }
        if (netdev->flags & NETDEV_FLAG_ETHARP) {
            rt_kprintf(" ETHARP");
        }
        if (netdev->flags & NETDEV_FLAG_BROADCAST) {
            rt_kprintf(" BROADCAST");
        }
        if (netdev->flags & NETDEV_FLAG_IGMP) {
            rt_kprintf(" IGMP");
        }
        rt_kprintf("\n");
        LOG_D("ip address: %s", inet_ntoa(netdev->ip_addr));
        LOG_D("gw address: %s", inet_ntoa(netdev->gw));
        LOG_D("net mask  : %s", inet_ntoa(netdev->netmask));
#if NETDEV_IPV6
        ip_addr_t *addr;
        int i;

        addr = &netdev->ip6_addr[0];

        if (!ip_addr_isany(addr)) {
            LOG_D("ipv6 link-local: %s %s", inet_ntoa(*addr),
                    !ip_addr_isany(addr) ? "VALID" : "INVALID");

            for (i = 1; i < NETDEV_IPV6_NUM_ADDRESSES; i++) {
                addr = &netdev->ip6_addr[i];
                LOG_D("ipv6[%d] address: %s %s", i, inet_ntoa(*addr),
                        !ip_addr_isany(addr) ? "VALID" : "INVALID");
            }
        }
#endif /* NETDEV_IPV6 */

        for (index = 0; index < NETDEV_DNS_SERVERS_NUM; index++) {
            LOG_D("dns server #%d: %s", index, inet_ntoa(netdev->dns_servers[index]));
        }

        if (rt_slist_next(node)) {
            LOG_D("\n");
        }
    }
    return state;
}

/**
 * @brief 将IP数据转换成HEX模式
 *
 * @param hex_ip 数据模式的IP
 * @param string_ip 字符串模式的IP
 */
void ip_string_to_hex(u8* hex_ip, char* ip)
{
    int i;
    int j = 0;
    int k = 0;
    int l = 0;
    u8 tmpIP[4][3];
    int s_len = rt_strlen(ip);

    if (ip != NULL) {
        //清空缓存数据
        rt_memset(tmpIP, 0x00, 12);
        //转移IP数据
        for (i = 0, k = 0, l = 0; i < s_len; i++) {
            if (ip[i] != '.') {
                tmpIP[l][k] = ip[i];
                k++;
            } else {
                l++;
                k = 0;
            }
        }

        for (i = 0; i < 4; i++) {
            for (j = 0, l = 0; j < 3; j++) {
                if (tmpIP[i][2 - j] == 0x00) {
                    l++;
                }
            }
            if (l == 0) {
                hex_ip[i] = (tmpIP[i][0] - '0') * 100 + (tmpIP[i][1] - '0') * 10 + (tmpIP[i][2] - '0');
            } else if (l == 1) {
                hex_ip[i] = (tmpIP[i][0] - '0') * 10 + (tmpIP[i][1] - '0');
            } else {
                hex_ip[i] = tmpIP[i][0] - '0';
            }
        }
    }
}
