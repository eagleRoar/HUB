/*
 * Copyright (c) 2006-2018, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author           Notes
 * 2020-02-10    ZhouXiaomin      first edition.
 */
/*
 * 程序清单：SD使用例程
 * 程序功能：程序通过设备名称查找看门狗设备，然后初始化设备并设置看门狗设备溢出时间。
 *           然后设置空闲线程回调函数，在回调函数里会喂狗。
 */

//rt-include-------------------------------------------------------
#include <rtdevice.h>
#include <rtthread.h>
//user-include-------------------------------------------------------
#include "typedefBASE.h"
#include "typedefLOG.h"
#include "uuzConfigSD.h"
#include "uuzInit.h"
#include "uuzLOG.h"
#include "uuzOpt.h"
#include "uuzRTC.h"
#include "uuzSD.h"
/*log---------------------------------------------*/
#define DBG_TAG "u.log"
#define DBG_LVL DBG_INFO
//#define DBG_LVL DBG_LOG
#include <rtdbg.h>
//extern-------------------------------------------------------------
LOGS_Typedef_t logs[_LOGS_MAX];
//u8 tLogs[uuzLOGS_T_LEN];
//---------------------------------------------------------------------
/**
 * @brief 获取文件的数据数量
 *
 * @param tlog 需要获取的输入类型
 * @param y 年份+1900
 * @param m 月份
 * @param d 天
 * @param id 设备ID
 * @return 返回设备数据
 */
u32 file_list_num_get(u8 tlog, int y, int m, int d, int id)
{
    u8 num[2];
    u16 list_num = 0;

    //获取文件名称filename赋值
    char filename[24];
    get_file_name(tlog, y, m, d, id, filename);
    //读取相关设备的数据->num[2]
    read_log_data(filename, num, 2);
    //转换读取到的数据长度
    list_num = usU8ToU16(num, uuzLSB);
    //打印调试日志
    LOG_D("f:%s:%d", filename, list_num);

    return list_num;
}

/**
 * @brief Get the sys date object
 * 
 * @param rTm 
 * @return char* 
 */
void get_sys_data(u8* cmd, struct tm* _Tm)
{
    cmd[0] = '#';
    cmd[1] = _Tm->tm_mon + 1;
    cmd[2] = _Tm->tm_mday;
    cmd[3] = _Tm->tm_hour;
    cmd[4] = _Tm->tm_min;
    cmd[5] = _Tm->tm_sec;
}

/**
 * @brief 获取操作信息
 * @param cmd
 * @param _Tm
 */
void get_opt_data(u8* cmd, struct tm* _Tm)
{
    cmd[0] = '#';
    cmd[1] = _Tm->tm_mday;
    cmd[2] = _Tm->tm_hour;
    cmd[3] = _Tm->tm_min;
    cmd[4] = _Tm->tm_sec;
}

/**
 * @brief 获取实时数据信息
 * @param cmd 返回的文件头
 * @param _Tm 输入的时间
 */
void get_data(u8* cmd, struct tm* _Tm)
{
    cmd[0] = '#';
    cmd[1] = _Tm->tm_hour;
    cmd[2] = _Tm->tm_min;
    cmd[3] = _Tm->tm_sec;
}

/**
 * @brief Get the file name object
 *
 * @param tlog log类型
 * @param y 年份
 * @param m 月份
 * @param d 天数据
 * @param id 设备编号
 * @param name 返回的文件名
 */
void get_file_name(u8 tlog, int y, int m, int d, int id, char* name)
{
    switch (tlog) {
    case _LOGS_SYS:
        //system info
        rt_sprintf(name, "logs/s%04d.txt", y);
        break;
    case _LOGS_OPT:
        //device opt
        rt_sprintf(name, "logs/o%04d%02d.txt", y, m);
        break;
    case _LOGS_DEV1:
        //ec-ph-ta data
        rt_sprintf(name, "data/d%d%04d%02d%02d.txt", id, y, m, d);
        break;
    case _LOGS_LV1:
    case _LOGS_LV2:
    case _LOGS_LV3:
        //水位数据
        rt_sprintf(name, "data/l%d%04d%02d%02d.txt", id, y, m, d);
        break;
    case _LOGS_ALM:
        //alarm
        rt_sprintf(name, "alarm/a_%04d%02d.txt", y, m);
        break;
    default:
        break;
    }
    LOG_D(name);
}

/**
 * @brief 保存相关记录系统数据生成
 *
 * @param state: 0-poweroff;1-reboot
 * @return 返回是否保存成功记录,成功为RT_EOK
 */
u8 save_data_by_sys(u8 state)
{
    char filename[16];
    u8 tlog = _LOGS_SYS;
    //给filename赋值
    get_file_name(tlog, (rTm.tm_year + 1900), 0, 0, 0, filename);
    //读取文件长度
    if (length_file(filename) >= 2) {
        logs[tlog].n = file_list_num_get(tlog, (rTm.tm_year + 1900), rTm.tm_mon, rTm.tm_mday, 0);
    } else {
        logs[tlog].n = 0;
        create_log_data(filename, (u8*)&logs[tlog], (2 + uuzLOG_D_LEN * logs[tlog].n));
    }

    //判断信息数量,如果达到信息末尾，则回到第一条
    if (logs[tlog].n >= uuzLOGS_LIST_MAX) {
        logs[tlog].n = 0;
    }

    //写入实时数据
    get_sys_data(&logs[tlog].d[logs[tlog].n][0], &rTm);
    logs[tlog].d[logs[tlog].n][6] = state;
    logs[tlog].n++;
    write_log_data(filename, (u8*)&logs[tlog], (2 + uuzLOG_D_LEN * logs[tlog].n));

    //读取当前的信息数据
    LOG_D("[%d]W-List:%d", tlog, logs[tlog].n);

    return RT_EOK;
}

/**
 * @brief 读取相关系统相关数据
 *
 * @param y:年份
 * @return 返回是否保存成功记录,成功为RT_EOK
 */
u8 read_data_by_sys(u32 y)
{
    char filename[16];
    u8 tlog = _LOGS_SYS;

    //给filename赋值
    get_file_name(tlog, y, 0, 0, 0, filename);

    //读取文件长度
    if (length_file(filename) >= 2) {
        logs[tlog].n = file_list_num_get(tlog, y, 0, 0, 0);
    } else {
        logs[tlog].n = 0;
        create_log_data(filename, (u8*)&logs[tlog], (2 + uuzLOG_D_LEN * logs[tlog].n));
    }
    LOG_D("[%d]List:%d", tlog, logs[tlog].n);
    if (logs[tlog].n < uuzLOGS_LIST_MAX) {
        //读取实际文件内容
        read_log_data(filename, (u8*)&logs[tlog], (2 + logs[tlog].n * uuzLOG_D_LEN));
        LOG_D("[%d]R-Len:%d", tlog, (2 + logs[tlog].n * uuzLOG_D_LEN));
        return RT_EOK;
    } else {
        LOG_E("[%d]R-Len:%d", tlog, (2 + logs[tlog].n * uuzLOG_D_LEN));
        return RT_ERROR;
    }
}

/**
 * @brief 保存相关记录操作数据生成
 *
 * @param opt:01-Dosing/02-220V/03-24V
 * @param state:00-OFF/01-ON
 * @return 返回是否保存成功记录,成功为RT_EOK
 */
u8 save_data_by_opt(u8 opt, u8 state)
{
    char filename[16];
    u8 tlog = _LOGS_OPT;

    //给filename赋值
    get_file_name(tlog, (rTm.tm_year + 1900), rTm.tm_mon, 0, 0, filename);
    //读取文件长度
    if (length_file(filename) >= 2) {
        logs[tlog].n = file_list_num_get(tlog, (rTm.tm_year + 1900), rTm.tm_mon, rTm.tm_mday, 0);
    } else {
        logs[tlog].n = 0;
        create_log_data(filename, (u8*)&logs[tlog], (2 + uuzLOG_D_LEN * logs[tlog].n));
    }

    //判断信息数量,如果达到信息末尾，则回到第一条
    if (logs[tlog].n >= uuzLOGS_LIST_MAX) {
        logs[tlog].n = 0;
    }

    //写入实时数据
    get_opt_data(&logs[tlog].d[logs[tlog].n][0], &rTm);
    logs[tlog].d[logs[tlog].n][5] = opt;
    logs[tlog].d[logs[tlog].n][6] = state;
    logs[tlog].n++;
    write_log_data(filename, (u8*)&logs[tlog], (2 + uuzLOG_D_LEN * logs[tlog].n));

    //读取当前的信息数据
    LOG_D("[%d]W-List:%d", tlog, logs[tlog].n);

    return RT_EOK;
}

/**
 * @brief 读取相关操作数据
 *
 * @param y:年份
 * @param m:月份
 * @return 返回是否保存成功记录,成功为RT_EOK
 */
u8 read_data_by_opt(u32 y, u32 m)
{
    char filename[16];
    u8 tlog = _LOGS_OPT;

    //给filename赋值
    get_file_name(tlog, y, m, 0, 0, filename);
    //读取文件长度
    if (length_file(filename) >= 2) {
        logs[tlog].n = file_list_num_get(tlog, y, m, 0, 0);
    } else {
        logs[tlog].n = 0;
        create_log_data(filename, (u8*)&logs[tlog], (2 + uuzLOG_D_LEN * logs[tlog].n));
    }
    LOG_D("[%d]List:%d", tlog, logs[tlog].n);
    //读取实际文件内容
    if (logs[tlog].n < uuzLOGS_LIST_MAX) {
        read_log_data(filename, (u8*)&logs[tlog], (2 + logs[tlog].n * uuzLOG_D_LEN));
        LOG_D("[%d]R-Len:%d", tlog, (2 + logs[tlog].n * uuzLOG_D_LEN));
    } else {
        LOG_E("[%d]R-Len:%d", tlog, (2 + logs[tlog].n * uuzLOG_D_LEN));
        return RT_ERROR;
    }

    return RT_EOK;
}

/**
 * @brief 保存相关记录报警数据生成
 *
 * @param alm
 * @param state:00-OFF/01-ON
 * @return 返回是否保存成功记录,成功为RT_EOK
 */
u8 save_data_by_alm(u8 alm, u8 state)
{
    char filename[16];
    u8 tlog = _LOGS_ALM;

    //给filename赋值
    get_file_name(tlog, (rTm.tm_year + 1900), rTm.tm_mon, 0, 0, filename);
    //读取文件长度
    if (length_file(filename) >= 2) {
        logs[tlog].n = file_list_num_get(tlog, (rTm.tm_year + 1900), rTm.tm_mon, rTm.tm_mday, 0);
    } else {
        logs[tlog].n = 0;
        create_log_data(filename, (u8*)&logs[tlog], (2 + uuzLOG_D_LEN * logs[tlog].n));
    }

    //判断信息数量,如果达到信息末尾，则回到第一条
    if (logs[tlog].n >= uuzLOGS_LIST_MAX) {
        logs[tlog].n = 0;
    }

    //写入实时数据
    get_opt_data(&logs[tlog].d[logs[tlog].n][0], &rTm);
    logs[tlog].d[logs[tlog].n][5] = alm;
    logs[tlog].d[logs[tlog].n][6] = state;
    logs[tlog].n++;
    write_log_data(filename, (u8*)&logs[tlog], (2 + uuzLOG_D_LEN * logs[tlog].n));

    //读取当前的信息数据
    LOG_D("[%d]W-List:%d", tlog, logs[tlog].n);

    return RT_EOK;
}

/**
 * @brief 读取相关报警数据
 *
 * @param y:年份
 * @param m:月份
 * @return 返回是否保存成功记录,成功为RT_EOK
 */
u8 read_data_by_alm(u32 y, u32 m)
{
    char filename[16];
    u8 tlog = _LOGS_ALM;

    //给filename赋值
    get_file_name(tlog, y, m, 0, 0, filename);
    //读取文件长度
    if (length_file(filename) >= 2) {
        logs[tlog].n = file_list_num_get(tlog, y, m, 0, 0);
    } else {
        logs[tlog].n = 0;
        create_log_data(filename, (u8*)&logs[tlog], (2 + uuzLOG_D_LEN * logs[tlog].n));
    }
    LOG_D("[%d]List:%d", tlog, logs[tlog].n);
    //读取实际文件内容
    if (logs[tlog].n < uuzLOGS_LIST_MAX) {
        read_log_data(filename, (u8*)&logs[tlog], (2 + logs[tlog].n * uuzLOG_D_LEN));
        LOG_D("[%d]R-Len:%d", tlog, (2 + logs[tlog].n * uuzLOG_D_LEN));
    } else {
        LOG_E("[%d]R-Len:%d", tlog, (2 + logs[tlog].n * uuzLOG_D_LEN));
        return RT_ERROR;
    }

    return RT_EOK;
}

/**
 * @brief 保存相关设备的实时数据
 *
 * @param addr：设备的编号
 * @param xValue:EC/pH/水Ta温度相关
 * @return
 */
u8 save_data_by_dev(u8 addr, PHECB2_Value_Typedef_t* xValue)
{
    char filename[16];
    u8 tlog = _LOGS_DEV1 + addr;

    //给filename赋值
    get_file_name(tlog, (rTm.tm_year + 1900), rTm.tm_mon, rTm.tm_mday, addr, filename);
    //读取文件长度
    if (length_file(filename) >= 2) {
        logs[tlog].n = file_list_num_get(tlog, (rTm.tm_year + 1900), rTm.tm_mon, rTm.tm_mday, addr);
    } else {
        logs[tlog].n = 0;
        create_log_data(filename, (u8*)&logs[tlog], (2 + uuzLOG_D_LEN * logs[tlog].n));
    }

    //判断信息数量,如果达到信息末尾，则回到第一条
    if (logs[tlog].n >= uuzLOGS_LIST_MAX) {
        logs[tlog].n = 0;
    }

    //写入实时数据
    get_data(&logs[tlog].d[logs[tlog].n][0], &rTm);
    vU16ToU8(logs[tlog].d[logs[tlog].n] + 4, xValue->usVal_ec, uuzLSB);
    vU16ToU8(logs[tlog].d[logs[tlog].n] + 6, xValue->usVal_pH, uuzLSB);
    vU16ToU8(logs[tlog].d[logs[tlog].n] + 8, xValue->usVal_Tp, uuzLSB);
    logs[tlog].n++;
    write_log_data(filename, (u8*)&logs[tlog], (2 + uuzLOG_D_LEN * logs[tlog].n));

    //读取当前的信息数据
    LOG_D("[%d]W-List:%d", tlog, logs[tlog].n);

    return RT_EOK;
}

/**
 * @brief 读取相关设备实时数据
 *
 * @param y:年份
 * @param m:月份
 * @param m:月份
 * @param m:月份
 * @return 返回是否保存成功记录,成功为RT_EOK
 */
u8 read_data_by_dev(u8 addr, u32 y, u32 m, u32 d)
{
    char filename[16];
    u8 tlog = _LOGS_DEV1 + addr;

    //给filename赋值
    get_file_name(tlog, y, m, d, addr, filename);
    //读取文件长度
    if (length_file(filename) >= 2) {
        logs[tlog].n = file_list_num_get(tlog, y, m, d, addr);
    } else {
        logs[tlog].n = 0;
        create_log_data(filename, (u8*)&logs[tlog], (2 + uuzLOG_D_LEN * logs[tlog].n));
    }
    LOG_D("[%d]List:%d", tlog, logs[tlog].n);
    //读取实际文件内容
    if (logs[tlog].n < uuzLOGS_LIST_MAX) {
        read_log_data(filename, (u8*)&logs[tlog], (2 + logs[tlog].n * uuzLOG_D_LEN));
        LOG_D("[%d]R-Len:%d", tlog, (2 + logs[tlog].n * uuzLOG_D_LEN));
    } else {
        LOG_E("[%d]R-Len:%d", tlog, (2 + logs[tlog].n * uuzLOG_D_LEN));
        return RT_ERROR;
    }

    return RT_EOK;
}
