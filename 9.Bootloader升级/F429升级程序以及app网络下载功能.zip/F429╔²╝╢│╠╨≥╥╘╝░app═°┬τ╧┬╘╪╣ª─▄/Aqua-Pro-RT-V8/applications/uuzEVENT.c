/* Includes ------------------------------------------------------------------*/
#include "uuzEVENT.h"
#include "uuzEventTEST.h"
/* event ---------------------------------------------*/
rt_event_t eventALM = NULL;
rt_event_t eventDATA = NULL;
rt_event_t eventOPT = NULL;
rt_event_t eventVALVE = NULL;
#if (_TEST_DATA)
rt_event_t eventTEST = NULL;
#endif
/*-----------------------------------------------------------------*/
