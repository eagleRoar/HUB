﻿/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-02   ZhouXiaomin     first version
 */
#ifndef __UUZ_BBL_H
#define __UUZ_BBL_H

#include <board.h>
#include "typedefBASE.h"

#ifdef __cplusplus
extern "C" {
#endif

u8 protocol_head_is_assert(u8 ucHead, u8 ucUart);

#ifdef __cplusplus
}
#endif
#endif // __UUZ_BBL_H
