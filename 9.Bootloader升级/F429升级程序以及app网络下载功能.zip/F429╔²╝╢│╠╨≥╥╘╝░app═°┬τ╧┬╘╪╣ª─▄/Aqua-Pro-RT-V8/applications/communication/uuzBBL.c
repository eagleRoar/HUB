/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-02   ZhouXiaomin     first version
 */
/* Includes ------------------------------------------------------------------*/
/******************************************************************************/
#include <string.h>
/******************************************************************************/
#include "typedefBASE.h"
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
/******************************************************************************/
#include "uuzInit.h"
#include "uuzOpt.h"
/******************************************************************************/
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
/* ---------------------------------------------------------------------------*/
u8 protocol_head_is_assert(u8 ucHead, u8 ucUart)
{
    // BBL: 1  MBR : 2  NULL: 0
    u8 ucProtocol = uuzPROTOCOL_NULL;

    //获取协议头
    if (ucHead == uuzBBL_HEAD) {
        ucProtocol = uuzPROTOCOL_BBL;
    } else {
        if ((id_is_exist(ucHead, ucUart) == uuzTRUE)
                || (((ucHead == 0xEFU) || (ucHead == 0x01U)) && (ucUart == uuzUART_7)))  //传感器界面
                {
            ucProtocol = uuzPROTOCOL_MBR;
        }
    }

    return ucProtocol;
}

/*-----------------------------------------------------------------*/
