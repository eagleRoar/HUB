﻿/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-03   ZhouXiaomin     first version
 */
#ifndef __UUZ_MBR_H
#define __UUZ_MBR_H

#include "typedefBASE.h"
#include "typedefINIT.h"
#include "uuzConfigUART.h"


#ifdef __cplusplus
extern "C" {
#endif

void uuz_vCmd_Send(DevID_Typedef_t * xDev, u8 uart, u8 cmd, u16 addr, u16 data);

#ifdef __cplusplus
}
#endif
#endif // __UUZ_MBR_H
