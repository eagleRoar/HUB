/*
 * @Copyright (c) 2006-2018 RT-Thread Development Team:  
 * @SPDX-License-Identifier: Apache-2.0:  
 * @Date: 2020-01-01 09:23:03
 * @LastEditors  : Zhou Xiaomin
 * @LastEditTime : 2020-01-11 10:36:15
 * @Description:  
 */
#ifndef _TYPEDEF_MBR_H
#define _TYPEDEF_MBR_H

#include "board.h"
#include "typedefBASE.h"

//R/W State
enum
{
    _CODE_R = 0,
    _CODE_W = 1,
    _CODE_RW = 2
};

//operatre code
enum
{
    _MBR_GET_ID = 0,
    _MBR_R_VALUE,
    _MBR_SET_ID,
    _MBR_SET_ZERO,
    _MBR_SET_UINT
};

typedef struct modbus_rtu_code
{
    u8 cmd;  //R/W/RW
    u16 code;   //addr:0x0000U~0xFFFFU
    u16 n;  //max:0~64
} MODBUS_RTU_CODE;

#endif // _TYPEDEF_MBR_H
