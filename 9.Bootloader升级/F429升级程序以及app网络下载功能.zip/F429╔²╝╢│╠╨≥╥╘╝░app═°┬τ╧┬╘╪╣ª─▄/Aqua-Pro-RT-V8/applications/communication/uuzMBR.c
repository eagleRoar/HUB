/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-02   ZhouXiaomin     first version
 */
/* Includes ------------------------------------------------------------------*/
#include "uuzConfigMBR.h"
#include "uuzOpt.h"
#include "uuzMBR.h"
#include "uuzDevID.h"
/* ---------------------------------------------------------------------------*/
/**
 * @brief 通用串口发送函数
 * @param xDev 设备相关信息
 * @param uart 设备对应串口
 * @param cmd 串口发送命令
 * @param addr 串口发送地址
 * @param data 需要发送的数据
 */
void uuz_vCmd_Send(DevID_Typedef_t * xDev, u8 uart, u8 cmd, u16 addr, u16 data)
{
    u8 ucDataCommand[uuzUART_LEN / 2];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Device ID
    ucDataCommand[ucLenCommand++] = xDev->id;
    ucDataCommand[ucLenCommand++] = cmd;
    //Address
    vU16ToU8(ucDataCommand + ucLenCommand, addr, uuzMSB);
    ucLenCommand += 2U;
    vU16ToU8(ucDataCommand + ucLenCommand, data, uuzMSB);
    ucLenCommand += 2U;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;
    uuz_vDevCommandSend(uart, (u8*) ucDataCommand, ucLenCommand);
    //N次读取无数据，将连接状态切断
    if (xDev->count < uuzDEV_CONNECT_ERR) {
        //连接计数
        xDev->count++;
    }
}
/*-----------------------------------------------------------------*/
