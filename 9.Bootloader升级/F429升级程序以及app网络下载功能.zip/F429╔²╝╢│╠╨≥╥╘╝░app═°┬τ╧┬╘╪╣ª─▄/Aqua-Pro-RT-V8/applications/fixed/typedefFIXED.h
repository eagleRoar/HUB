/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_FIXED_H
#define __TYPEDEF_FIXED_H

// include ---------------------------------------------
#include "typedefBASE.h"
#include "typedefDEVID.h"
//#include "typedefPROG.h"
#include "uuzConfigDEV.h"
#include "uuzOpt.h"
// ------- ---------------------------------------------
#define uuzFIXED_DATA_MAX (6U)

typedef struct fixed_single_t
{
    u32 volume;  //单池容量
    u16 uint;    //0-Gal/1-L/2-ml
    u16 en[uuzDEV_DOS_MAX];  //是否开启蠕动泵(0-关闭|1-开启)
    u16 dos[uuzDEV_DOS_MAX];  //单位工作比例,每1单位需要多少ml配液(max:10000ml)
    u16 t[uuzDEV_DOS_MAX];   //持续时间

    u16 end;

}__attribute__ ((__packed__)) Fixed_Single_Typedef_t;
#define uuzFIXED_SINGLE_CONFIG_LEN (sizeof(Fixed_Single_Typedef_t))

typedef struct fixed_cache_t
{
    u16 en[uuzDEV_DOS_MAX];  //是否开启蠕动泵(0-关闭|1-开启)
    u16 t[uuzDEV_DOS_MAX];   //已经工作持续时间

} Fixed_Cache_Typedef_t;

#endif // __TYPEDEF_FIXED_H
