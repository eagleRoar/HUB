/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __UUZ_FIXED_EVENT_H
#define __UUZ_FIXED_EVENT_H

#include "typedefMBR.h"
#include "typedefFIXED.h"
#include <time.h>

extern Fixed_Cache_Typedef_t fixedCache;

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 设置Fixed表零时缓存的初始相关数据
 */
void fixed_cache_init(void);

/**
 * @brief 设置Fixed表的初始相关数据
 */
void fixed_config_init(Fixed_Single_Typedef_t * xFixed);

#ifdef __cplusplus
}
#endif

#endif // __UUZ_FIXED_EVENT_H
