/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
/*include*****************************************************************************/
#include <math.h>
#include <string.h>
/******************************************************************************/
#include "uuzCalendar.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzRTC.h"
/******************************************************************************/
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
/******************************************************************************/
#include "typedefDEVID.h"
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
/******************************************************************************/
#include "uuzEventFIXED.h"
/*log*************************************************************************/
#define DBG_TAG "e.fix"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/******************************************************************************/
Fixed_Cache_Typedef_t fixedCache;
/******************************************************************************/
/**
 * @brief 设置Fixed表零时缓存的初始相关数据
 */
void fixed_cache_init(void)
{
    rt_memset(&fixedCache, 0x00U, sizeof(Fixed_Cache_Typedef_t));
}

/**
 * @brief 设置Fixed表的初始相关数据
 */
void fixed_config_init(Fixed_Single_Typedef_t * xFixed)
{
    u16 index = 0;

    xFixed->volume = 500;   //数据容量(500L)
    xFixed->uint = 0;     //数据单位：0-L|1-Gal|2-ml
    for (index = 0; index < uuzDEV_DOS_MAX; index++) {
        xFixed->en[index] = 1;  //1-开启端口
        xFixed->dos[index] = 10;  //每1单位10ml/sec
        xFixed->t[index] = 25;   //持续时间:25sec(默认200ml/min)
    }
    xFixed->end = 0xBBBBU;  //结束符
}
