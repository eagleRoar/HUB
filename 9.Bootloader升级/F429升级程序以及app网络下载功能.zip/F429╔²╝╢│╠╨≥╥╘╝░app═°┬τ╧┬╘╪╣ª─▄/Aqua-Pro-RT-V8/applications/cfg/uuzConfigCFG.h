#ifndef __UUZ_CONFIG_CFG_H
#define __UUZ_CONFIG_CFG_H

enum
{
    _MAP_NULL = 0,  //没有类型数据
    _MAP_BRD,   //电源板配置
    _MAP_IRR,   //灌溉程序配置
    _MAP_LGT,   //灯光程序配置
    _MAP_WLS,   //回水程序配置
    _MAP_FIX,  //定量配置类型
    _MAP_NUT,  //动态配置类型
    _MAP_DOS,  //蠕动泵配置类型
    _MAP_SCH,  //周期表配置类型
    _MAP_TIM,  //定时配置类型

    _MAP_MAX    //最大配置列表数据
};

//-------------(0U)     //电源输出板端口配置
//-------------(1U)     //灌溉程序数据配置
//-------------(2U)     //灯光端口程序数据配置
//-------------(4U)     //回水端口程序数据配置
//-------------(8U)     //定量配肥数据配置
//-------------(16U)    //动态配肥数据配置
//-------------(32U)    //蠕动泵数据配置
//-------------(64U)    //周期表数据配置
//-------------(128U)   //定时数据配置
//-------------(XU)     //其他

#define _S_CFG_BRD (0x01U)  //电源输出板端口配置
#define _S_CFG_IRR (0x01U << 1)  //灌溉程序配置
#define _S_CFG_LGT (0x01U << 2)  //灯光程序配置
#define _S_CFG_WLS (0x01U << 3)  //回水程序配置
#define _S_CFG_FIX (0x01U << 4)  //定量程序配置
#define _S_CFG_NUT (0x01U << 5)  //动态程序配置
#define _S_CFG_DOS (0x01U << 6)  //蠕动泵程序配置
#define _S_CFG_SCH (0x01U << 7)  //周期表程序配置
#define _S_CFG_TIM (0x01U << 8)  //定时程序配置

#endif // __UUZ_CONFIG_CFG_H
