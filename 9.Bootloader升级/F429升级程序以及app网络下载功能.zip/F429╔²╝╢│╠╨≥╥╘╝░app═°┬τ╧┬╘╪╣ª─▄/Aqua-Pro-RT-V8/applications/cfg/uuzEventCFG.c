/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
/*include*****************************************************************************/
#include <math.h>
#include <rtdevice.h>
#include <rtthread.h>
#include <string.h>
/******************************************************************************/
#include "uuzEVENT.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzRTC.h"
/******************************************************************************/
#include "uuzConfigDEV.h"
#include "uuzConfigEEPROM.h"
#include "uuzConfigCFG.h"
/******************************************************************************/
#include "uuzEEPROM.h"
#include "uuzDevID.h"
#include "uuzEventBRD.h"
#include "uuzEventCFG.h"
/******************************************************************************/
#include "typedefIRR.h"
#include "typedefLGT.h"
#include "typedefWLS.h"
#include "typedefFIXED.h"
#include "typedefPHEC.h"
#include "typedefDOSING.h"
/******************************************************************************/
#include "uuzEventTIM.h"
#include "uuzEventLGT.h"
#include "uuzEventIRR.h"
#include "uuzEventWLS.h"
#include "uuzEventPROG.h"
#include "uuzEventSCH.h"
#include "uuzEventFIXED.h"
#include "uuzEventPHEC.h"
#include "uuzEventDOSING.h"
/*log---------------------------------------------*/
#define DBG_TAG "e.cfg"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/******************************************************************************/
Config_Data_Typedef_t xConfigMap;  //最多保存满设备的配置数据,保存数据的地址列表,保存配置数据的长度
/******************************************************************************/
/**
 * @brief 清除配置地址数据
 * @param map
 */
void config_map_empty(Config_Map_Typedef_t* map)
{
    if (map != RT_NULL) {
        map->en = RT_FALSE;  //清除数据
        map->sta = RT_FALSE;    //清除配置状态
        map->t = _MAP_NULL;  //清除数据类型
        map->addr = RT_NULL;  //清空内存地址数据
    }
}

/**
 * @brief 更新配置地址数据
 * @param map
 */
u32 config_map_sync(Config_Map_Typedef_t* map,
        u16 t, u16 sta, u16 index, u32 len, u32 last_len,
        void* addr)
{
    u32 length = last_len;

    if (map != RT_NULL) {
        map->en = RT_TRUE;  //使能数据配置区
        map->t = t;  //IRR-Config|Lgt-Config
        map->sta = sta;  //对应配置的状态
        map->id = index;  //对应配置表
        map->n = length;  //对应数据内存区的起始地址
        map->addr = addr;  //获取相关数据地址
        if (sta == RT_TRUE) {   //如果有相关数据
            length += len;  //计算内存区的总长度
        }
    }

    return length;
}

/**
 * @brief 获取新的空配置数据
 * @return 返回配置位置数据
 */
int config_map_new(void)
{
    for (int index = 0; index < uuzDEV_MAX; index++) {
        if (xConfigMap.map[index].en == RT_FALSE) {
            return index;
        }
    }

    return uuzDEV_MAX;
}

/**
 * @brief 配置列表数据读取
 */
void config_map_read(void)
{
    //EEPROM的数据长度读取
    eeprom_to_config(uuzEEPROM_ADDR_CFG, (u8*) (&xConfigMap), uuzCONFIG_DATA_LEN);
    rt_thread_delay(20);
}

/**
 * @brief 配置列表数据写入
 */
void config_map_save(void)
{
    //向EEPROM写入相关配置数据
    config_to_eeprom(uuzEEPROM_ADDR_CFG, (u8*) (&xConfigMap), uuzCONFIG_DATA_LEN);
    rt_thread_mdelay(50);
}

/**
 * @brief 保存设备系统的相关配置
 * @param type:需要保存的数据类型
 * @param index:需要对应的程序编号
 */
void config_data_save(u32 type, u16 s_index)
{
    int lenCommand = 0;
    int lenData = 0;
    int index = 0;

    if ((type == 0xFFFF) || (type & _S_CFG_BRD)) {  //Board相关控制数据
        config_to_eeprom(uuzEEPROM_ADDR_DATA + lenCommand, (u8*) (xBoardCFG), uuzBRD_CONFIG_LEN);
        rt_thread_mdelay(10);
        LOG_D("Save Board Data");
        //配置位置电源输出板数据
        lenData = config_map_sync(
                &xConfigMap.map[index],
                _MAP_BRD,
                RT_TRUE,
                index,
                uuzBRD_CONFIG_LEN,
                lenData,
                RT_NULL);
    }
    index++;
    lenCommand += uuzBRD_CONFIG_LEN;
    LOG_D("1-Board - Length[%d]", lenCommand);

    if ((type == 0xFFFF) || (type & _S_CFG_IRR)) {  //Irrigation Program相关控制数据
        config_to_eeprom((uuzEEPROM_ADDR_DATA + lenCommand), (u8*) (xIrrPro), uuzIRR_PRO_LEN);
        rt_thread_mdelay(10);
        LOG_D("Save Irrigation Data");
        //配置位置灌溉程序相关数据
        lenData = config_map_sync(&xConfigMap.map[index], _MAP_IRR, RT_TRUE, index, uuzIRR_PRO_LEN, lenData, RT_NULL);
    }
    index++;
    lenCommand += uuzIRR_PRO_LEN;
    LOG_D("2-Irrigation - Length[%d]", lenCommand);

    for (int count = 0; count < _LGT_CFG_MAX; count++, index++) {  //灯光的配置数据
        if ((type == 0xFFFF) || (type & _S_CFG_LGT)) {  //灯光配置数据
            if ((s_index == count) || (s_index == 0xFFFF)) {
                LOG_D("Save Light Data[%d]--Index[%d]", count, index);
                config_to_eeprom(
                        (uuzEEPROM_ADDR_DATA + lenCommand),
                        (u8*) (xLgtPro.cfg[count]),
                        uuzLGT_CFG_LEN);
                rt_thread_mdelay(10);
                //配置位置定量配肥程序相关数据
                lenData = config_map_sync(
                        &xConfigMap.map[index],
                        _MAP_LGT,
                        RT_TRUE,
                        index,
                        uuzLGT_CFG_LEN,
                        lenData,
                        RT_NULL);
            }
        }
        lenCommand += uuzLGT_CFG_LEN;
    }
    LOG_D("3-Light - Length[%d]", lenCommand);

    if ((type == 0xFFFF) || (type & _S_CFG_WLS)) {  //Water Level Program相关控制数据
        config_to_eeprom((uuzEEPROM_ADDR_DATA + lenCommand), (u8*) (xWlsPro), uuzWLS_PRO_LEN);
        rt_thread_mdelay(10);
        LOG_D("Save Water Level Data");
        //配置位置灌溉程序相关数据
        lenData = config_map_sync(&xConfigMap.map[index], _MAP_WLS, RT_TRUE, index, uuzWLS_PRO_LEN, lenData, RT_NULL);
    }
    index++;
    lenCommand += uuzWLS_PRO_LEN;
    LOG_D("4-Water L - Length[%d]", lenCommand);

    for (int count = 0; count < uuzPROG_MAX; count++, index++) {  //有定量配肥的配置数据
        if ((type == 0xFFFF) || (type & _S_CFG_FIX)) {  //定量配肥数据
            if ((s_index == count) || (s_index == 0xFFFF)) {
                LOG_D("Save Fixed Data[%d]--Index[%d]", count, index);
                config_to_eeprom(
                        (uuzEEPROM_ADDR_DATA + lenCommand),
                        (u8*) (xProgCFG.xFixed[count]),
                        uuzFIXED_SINGLE_CONFIG_LEN);
                rt_thread_mdelay(10);
                //配置位置定量配肥程序相关数据
                lenData = config_map_sync(
                        &xConfigMap.map[index],
                        _MAP_FIX,
                        RT_TRUE,
                        index,
                        uuzFIXED_SINGLE_CONFIG_LEN,
                        lenData,
                        RT_NULL);
            }
        }
        lenCommand += uuzFIXED_SINGLE_CONFIG_LEN;
    }
    LOG_D("5-Fixed - Length[%d]", lenCommand);

    for (int count = 0; count < uuzPROG_MAX; count++, index++) {  //有动态配肥的配置数据
        if ((type == 0xFFFF) || (type & _S_CFG_NUT)) {  //动态配肥数据
            if ((s_index == count) || (s_index == 0xFFFF)) {
                LOG_D("Save Nut Data[%d]--Index[%d]", count, index);
                config_to_eeprom(
                        (uuzEEPROM_ADDR_DATA + lenCommand),
                        (u8*) (xProgCFG.xDynamic[count]),
                        uuzDYNAMIC_CONFIG_LEN);
                rt_thread_mdelay(10);
                //配置位置动态配肥程序相关数据
                lenData = config_map_sync(
                        &xConfigMap.map[index],
                        _MAP_NUT,
                        RT_TRUE,
                        index,
                        uuzDYNAMIC_CONFIG_LEN,
                        lenData,
                        RT_NULL);
            }
        }
        lenCommand += uuzDYNAMIC_CONFIG_LEN;
    }
    LOG_D("5-Dynamic - Length[%d]", lenCommand);

    if ((type == 0xFFFF) || (type & _S_CFG_DOS)) {  //蠕动泵配置相关控制数据
        config_to_eeprom((uuzEEPROM_ADDR_DATA + lenCommand), (u8 *) (xDosCFG), uuzDOS_PRO_LEN);
        rt_thread_mdelay(10);
        LOG_D("Save Dos Config Data");
        //配置位置灌溉程序相关数据
        lenData = config_map_sync(
                &xConfigMap.map[index],
                _MAP_DOS,
                RT_TRUE,
                index,
                uuzDOS_PRO_LEN,
                lenData,
                RT_NULL);
    }
    index++;
    lenCommand += uuzDOS_PRO_LEN;
    LOG_D("6-Dosing - Length[%d]", lenCommand);

    if ((type == 0xFFFF) || (type & _S_CFG_SCH)) {  //蠕动泵配置相关控制数据
        config_to_eeprom((uuzEEPROM_ADDR_DATA + lenCommand), (u8 *) (xSchCFG), uuzSCH_CONFIG_LEN);
        rt_thread_mdelay(10);
        LOG_D("Save Schedule Config Data");
        //配置位置灌溉程序相关数据
        lenData = config_map_sync(
                &xConfigMap.map[index],
                _MAP_SCH,
                RT_TRUE,
                index,
                uuzSCH_CONFIG_LEN,
                lenData,
                RT_NULL);
    }
    index++;
    lenCommand += uuzSCH_CONFIG_LEN;
    LOG_D("7-Schedule - Length[%d]", lenCommand);

    for (int count = 0; count < _TIM_CFG_MAX; count++, index++) {  //定时的配置数据
        if ((type == 0xFFFF) || (type & _S_CFG_TIM)) {  //灯光配置数据
            if ((s_index == count) || (s_index == 0xFFFF)) {
                LOG_D("Save Timer Data[%d]--Index[%d]", count, index);
                config_to_eeprom(
                        (uuzEEPROM_ADDR_DATA + lenCommand),
                        (u8*) (xTimPro.cfg[count]),
                        uuzTIM_CFG_LEN);
                rt_thread_mdelay(10);
                //配置定时相关数据
                lenData = config_map_sync(
                        &xConfigMap.map[index],
                        _MAP_TIM,
                        RT_TRUE,
                        index,
                        uuzTIM_CFG_LEN,
                        lenData,
                        RT_NULL);
            }
        }
        lenCommand += uuzTIM_CFG_LEN;
    }
    LOG_D("8-Timer - Length[%d]", lenCommand);

    if ((type == 0xFFFF) || (xConfigMap.len != lenCommand)) {
        xConfigMap.len = lenCommand;    //更新内存长度数据
        config_to_eeprom(uuzEEPROM_ADDR_CFG, (u8*) (&xConfigMap), uuzCONFIG_DATA_LEN);
        rt_thread_mdelay(10);
    }
    LOG_D("End- Save Data for Config");
}

/**
 * @brief 读取设备系统的相关配置
 */
u8 config_data_read(void)
{
    u8 result = RT_FALSE;

    if (xConfigMap.len) {  //有配置相关数据
        if (xSysSTA.addr_config != RT_NULL) {
            rt_free(xSysSTA.addr_config);   //释放内存数据
            xSysSTA.addr_config = RT_NULL;
        }

        if (xSysSTA.addr_config == RT_NULL) {
            xSysSTA.addr_config = rt_malloc(xConfigMap.len);  //标记内存地址
            LOG_D("Read Length[%d]", xConfigMap.len);
        }

        if (xSysSTA.addr_config != RT_NULL) {
            eeprom_to_config(uuzEEPROM_ADDR_DATA, (u8*) (xSysSTA.addr_config), xConfigMap.len);  //读取数据到当前内存
#if 0
                    int index = 0;
                    u8 data[2048];
                    rt_memcpy(data, (u8*) xSysSTA.addr_config, xConfigMap.len);
                    LOG_D("|||--------------------------------------");
                    for (index = 0; index < xConfigMap.len; index++) {
                        if ((index % 18 == 0) && (index != 0)) {
                            rt_kprintf("\r\n");
                        }
                        rt_kprintf("%02X ", data[index]);
                    }
                    rt_kprintf("\r\n");
                    LOG_D("|||--------------------------------------");
#endif
            LOG_D("Read Data for Config-Data[%d]", xConfigMap.len);
            result = RT_TRUE;
        } else {
            LOG_E("MALLOC DATA FAIL!");
        }
    }

    return result;
}

/**
 * @brief 保存设备(根据设备类型)的基本配置文件
 */
void config_map_data_save(u8 type, u8* data)
{
    for (int index = 0; index < uuzDEV_MAX; index++) {
        if (xConfigMap.map[index].en) {
            LOG_D("EN[%d]--IN[%d]--T[%d]", xConfigMap.map[index].en, index, xConfigMap.map[index].t);
            if (type == xConfigMap.map[index].t) {
                config_to_eeprom((uuzEEPROM_ADDR_CFG + xConfigMap.map[index].n), data, uuzBRD_CONFIG_LEN);
                rt_thread_mdelay(20);  //保存相关类型的数据
            }
        }
    }
}

/**
 * @brief 配置数据列表地址初始化
 */
void config_addr_init(u8 mark)
{
    int index = 0;
    u8 result = RT_FALSE;
    int cfg_data_error = RT_TRUE;
    int lenCommand = 0;
    int count_lgt = 0;    //灯光数据位
    int count_tim = 0;    //定时数据位

    //------------------>阶段一 读取配置列表数据<------------------------
    config_map_read();  //从EERPOM读取相关配置数据
    if ((xConfigMap.end != 0xBBBBU) || (mark)) {  //结束符错误或强制重置标记
        LOG_E("Reset Data for Config-Map");
        index = 0;  //初始化位置标记
        //初始化电源输出板数据
        lenCommand = config_map_sync(
                &xConfigMap.map[index],
                _MAP_BRD,
                RT_TRUE,
                index,
                uuzBRD_CONFIG_LEN,
                lenCommand,
                RT_NULL);
        index++;
        //初始化灌溉程序相关数据
        lenCommand = config_map_sync(
                &xConfigMap.map[index],
                _MAP_IRR,
                RT_TRUE,
                index,
                uuzIRR_PRO_LEN,
                lenCommand,
                RT_NULL);
        index++;
        //初始化灯光配置程序相关数据
        count_lgt = index;        //缓存当前序号数据
        for (; index < (count_lgt + _LGT_CFG_MAX); index++) {  //默认初始化1组BRD配置Light数据区
            lenCommand = config_map_sync(
                    &xConfigMap.map[index],
                    _MAP_LGT,
                    RT_TRUE,
                    index,
                    uuzLGT_CFG_LEN,
                    lenCommand,
                    RT_NULL);
        }
        //初始化回水程序相关数据
        lenCommand = config_map_sync(
                &xConfigMap.map[index],
                _MAP_WLS,
                RT_TRUE,
                index,
                uuzWLS_PRO_LEN,
                lenCommand,
                RT_NULL);
        index++;
        //初始化定量配肥配置程序相关数据
        count_lgt = index;        //缓存当前序号数据
        for (; index < (count_lgt + uuzPROG_MAX); index++) {  //默认初始化9组配肥配置数据区
            lenCommand = config_map_sync(
                    &xConfigMap.map[index],
                    _MAP_FIX,
                    RT_TRUE,
                    index,
                    uuzFIXED_SINGLE_CONFIG_LEN,
                    lenCommand,
                    RT_NULL);
        }
        //初始化动态定时配置程序相关数据
        count_lgt = index;        //缓存当前序号数据
        for (; index < (count_lgt + uuzPROG_MAX); index++) {  //默认初始化9组配肥配置数据区
            lenCommand = config_map_sync(
                    &xConfigMap.map[index],
                    _MAP_NUT,
                    RT_TRUE,
                    index,
                    uuzDYNAMIC_CONFIG_LEN,
                    lenCommand,
                    RT_NULL);
        }
        //初始化蠕动泵配置程序相关数据
        lenCommand = config_map_sync(
                &xConfigMap.map[index],
                _MAP_DOS,
                RT_TRUE,
                index,
                uuzDOS_PRO_LEN,
                lenCommand,
                RT_NULL);
        index++;
        //初始化周期表配置程序相关数据
        lenCommand = config_map_sync(
                &xConfigMap.map[index],
                _MAP_SCH,
                RT_TRUE,
                index,
                uuzSCH_CONFIG_LEN,
                lenCommand,
                RT_NULL);
        index++;
        //初始化灯光配置程序相关数据
        count_tim = index;        //缓存当前序号数据
        for (; index < (count_tim + _TIM_CFG_MAX); index++) {  //默认初始化2组BRD配置Timer数据区
            lenCommand = config_map_sync(
                    &xConfigMap.map[index],
                    _MAP_TIM,
                    RT_TRUE,
                    index,
                    uuzTIM_CFG_LEN,
                    lenCommand,
                    RT_NULL);
        }
        //初始化无效数据
        for (; index < uuzDEV_MAX; index++) {  //初始化相关数据
            lenCommand = config_map_sync(
                    &xConfigMap.map[index],
                    _MAP_NULL,
                    RT_FALSE,
                    index,
                    0,
                    lenCommand,
                    RT_NULL);
        }
        xConfigMap.len = lenCommand;  //实际数据长度h
        xConfigMap.end = 0xBBBBU;
        config_map_save();  //保存Config Map数据
    } else {
        LOG_D("Read Data for Config-Map, Data length:%d", xConfigMap.len);
    }

    //------------------>阶段二 读取配置具体数据区并分配相关配置地址<------------------------
    result = config_data_read();  //分配内存-配置的相关数据
    if (result == RT_TRUE) {  //有读取到相关数据
        for (index = 0; index < uuzDEV_MAX; index++) {
            if (xConfigMap.map[index].en == RT_TRUE) {
                if ((xConfigMap.map[index].t == _MAP_BRD)
                        || (xConfigMap.map[index].t == _MAP_IRR)
                        || (xConfigMap.map[index].t == _MAP_LGT)
                        || (xConfigMap.map[index].t == _MAP_WLS)
                        || (xConfigMap.map[index].t == _MAP_FIX)
                        || (xConfigMap.map[index].t == _MAP_NUT)
                        || (xConfigMap.map[index].t == _MAP_DOS)
                        || (xConfigMap.map[index].t == _MAP_SCH)
                        || (xConfigMap.map[index].t == _MAP_TIM)
                        ) {
                    LOG_D(
                            "|||--CFG[%02d]:ID-%02d|Num-%05d|Sta-%02d|Type-%02d",
                            index + 1,
                            xConfigMap.map[index].id,
                            xConfigMap.map[index].n,
                            xConfigMap.map[index].sta,
                            xConfigMap.map[index].t);
                }
                count_lgt = 0;    //灯光类数据位
                //有相关配置数据,先分配内存后并读取配置位置的数据
                if (xConfigMap.map[index].t == _MAP_BRD) {  //类型1的数据
                    xConfigMap.map[index].addr = xSysSTA.addr_config + xConfigMap.map[index].n;
                    xBoardCFG = (Board_Config_Typedef_t*) (xConfigMap.map[index].addr);
                } else if (xConfigMap.map[index].t == _MAP_IRR) {  //类型3的数据
                    xConfigMap.map[index].addr = xSysSTA.addr_config + xConfigMap.map[index].n;
                    xIrrPro = (Irr_Pro_Typedef_t*) (xConfigMap.map[index].addr);
                } else if (xConfigMap.map[index].t == _MAP_LGT) {  //类型4的数据
                    xConfigMap.map[index].addr = xSysSTA.addr_config + xConfigMap.map[index].n;
                    xLgtPro.cfg[index - 2] = (Lgt_Config_Typedef_t*) (xConfigMap.map[index].addr);
                } else if (xConfigMap.map[index].t == _MAP_WLS) {  //类型5的数据
                    xConfigMap.map[index].addr = xSysSTA.addr_config + xConfigMap.map[index].n;
                    xWlsPro = (Wls_Pro_Typedef_t*) (xConfigMap.map[index].addr);
                } else if (xConfigMap.map[index].t == _MAP_FIX) {  //类型6的数据
                    xConfigMap.map[index].addr = xSysSTA.addr_config + xConfigMap.map[index].n;
                    xProgCFG.xFixed[index - 2 - 1 - _LGT_CFG_MAX] =
                            (Fixed_Single_Typedef_t*) (xConfigMap.map[index].addr);
                } else if (xConfigMap.map[index].t == _MAP_NUT) {  //类型7的数据
                    xConfigMap.map[index].addr = xSysSTA.addr_config + xConfigMap.map[index].n;
                    xProgCFG.xDynamic[index - 2 - 1 - _LGT_CFG_MAX - uuzPROG_MAX] =
                            (Dynamic_Single_Typedef_t*) (xConfigMap.map[index].addr);
                } else if (xConfigMap.map[index].t == _MAP_DOS) {  //类型8的数据
                    xConfigMap.map[index].addr = xSysSTA.addr_config + xConfigMap.map[index].n;
                    xDosCFG = (Dosing_Config_Typedef_t*) (xConfigMap.map[index].addr);
                } else if (xConfigMap.map[index].t == _MAP_SCH) {  //类型9的数据
                    xConfigMap.map[index].addr = xSysSTA.addr_config + xConfigMap.map[index].n;
                    xSchCFG = (Sch_Config_Typedef_t*) (xConfigMap.map[index].addr);
                } else if (xConfigMap.map[index].t == _MAP_TIM) {  //类型10的数据
                    xConfigMap.map[index].addr = xSysSTA.addr_config + xConfigMap.map[index].n;
                    xTimPro.cfg[index - 2 - 1 - _LGT_CFG_MAX - uuzPROG_MAX - uuzPROG_MAX - 1 - 1] =
                            (Tim_Config_Typedef_t*) (xConfigMap.map[index].addr);
                }
            }
        }
    } else {  //重建全部标准配置数据
        //重置Board Config相关数据
    }
    u16 dataCount = 0;
    u16 optStep = 1;
    //------------------>阶段三 检查电源输出板数据并判断是否需要重置<------------------------
    if ((xBoardCFG->end != 0xBBBBU) || (xBoardCFG->ver != uuzDEVICE_TYPE) || (mark)) {  //数据错误重建相关数据
        board_config_init();  //复位数据
        cfg_data_error = RT_FALSE;
    }
    dataCount++;
    LOG_D("%d-{%d}--Flag[%d]", optStep, dataCount, cfg_data_error);
    optStep++;
    //------------------>阶段四 检查电源输出板数据并判断是否需要重置<------------------------
    if ((xIrrPro->end != 0xBBBBU) || (xIrrPro->ver != uuzDEVICE_TYPE) || (mark)) {  //数据错误重建相关数据
        irr_mode_config_init();
        cfg_data_error = RT_FALSE;
    }
    dataCount++;
    LOG_D("%d-{%d}--Flag[%d]", optStep, dataCount, cfg_data_error);
    optStep++;
    //------------------>阶段五 检查灯光输出板数据并判断是否需要重置<------------------------
    for (index = 0; index < _LGT_CFG_MAX; index++) {  //按顺序计算数据
        if ((xLgtPro.cfg[index]->end != 0xBBBBU) || (mark)) {  //数据错误重建相关数据
            xLgtPro.cfg[index] = rt_malloc(uuzLGT_CFG_LEN);  //分配相关数据
            lgt_config_add(xLgtPro.cfg[index]);  //初始化内存数据
            cfg_data_error = RT_FALSE;
        }
    }
    dataCount += _LGT_CFG_MAX;
    LOG_D("%d-{%d}--Flag[%d]", optStep,dataCount, cfg_data_error);
    optStep++;
    //------------------>阶段六 检查回水配置数据并判断是否需要重置<------------------------
    if ((xWlsPro->end != 0xBBBBU) || (mark)) {  //数据错误重建相关数据
        xWlsPro = rt_malloc(uuzWLS_PRO_LEN);  //分配相关数据
        wls_mode_config_init();
        cfg_data_error = RT_FALSE;
    }
    dataCount++;
    LOG_D("%d-{%d}--Flag[%d]", optStep, dataCount, cfg_data_error);
    optStep++;
    //------------------>阶段七 检查定量配肥数据并判断是否需要重置<------------------------
    for (index = 0; index < uuzPROG_MAX; index++) {  //按顺序计算数据
        if (xConfigMap.map[index + dataCount].sta == RT_TRUE) {  //有实际配置数据
            if ((xProgCFG.xFixed[index]->end != 0xBBBBU) || (mark)) {  //数据错误重建相关数据
                xProgCFG.xFixed[index] = rt_malloc(uuzFIXED_SINGLE_CONFIG_LEN);  //分配相关数据
                fixed_config_init(xProgCFG.xFixed[index]);  //初始化内存数据
                cfg_data_error = RT_FALSE;
            }
        }
    }
    dataCount += uuzPROG_MAX;
    LOG_D("%d-{%d}--Flag[%d]", optStep, dataCount, cfg_data_error);
    optStep++;
    //------------------>阶段八 检查动态配肥数据并判断是否需要重置<------------------------
    for (index = 0; index < uuzPROG_MAX; index++) {  //按顺序计算数据
        if (xConfigMap.map[index + dataCount].sta == RT_TRUE) {  //有实际配置数据
            if ((xProgCFG.xDynamic[index]->end != 0xBBBBU) || (mark)) {  //数据错误重建相关数据
                xProgCFG.xDynamic[index] = rt_malloc(uuzDYNAMIC_CONFIG_LEN);  //分配相关数据
                dynamic_config_init(xProgCFG.xDynamic[index]);  //初始化内存数据
                cfg_data_error = RT_FALSE;
            }
        }
    }
    dataCount += uuzPROG_MAX;
    LOG_D("%d-{%d}--Flag[%d]", optStep, dataCount, cfg_data_error);
    optStep++;
    //------------------>阶段九 检查蠕动泵配置数据并判断是否需要重置<------------------------
    if ((xDosCFG->end != 0xBBBBU) || (xDosCFG->ver != uuzDEVICE_TYPE) || (mark)) {  //数据错误重建相关数据
        xDosCFG = rt_malloc(uuzDOS_PRO_LEN);  //分配相关数据
        dosing_single_config_init(xDosCFG);  //初始化配置数据
        cfg_data_error = RT_FALSE;
    }
    dataCount++;
    LOG_D("%d-{%d}--Flag[%d]", optStep, dataCount, cfg_data_error);
    optStep++;
    //------------------>阶段十 检查周期表配置数据并判断是否需要重置<------------------------
    if ((xSchCFG->crc != 0xBBBBU) || (mark)) {  //数据错误重建相关数据
        xSchCFG = rt_malloc(uuzSCH_CONFIG_LEN);  //分配相关数据
        schedule_config_init(xSchCFG);  //初始化配置数据
        cfg_data_error = RT_FALSE;
    }
    dataCount++;
    LOG_D("%d-{%d}--Flag[%d]", optStep, dataCount, cfg_data_error);
    optStep++;
    //------------------>阶段十一 检查灯光输出板数据并判断是否需要重置<------------------------
    for (index = 0; index < _TIM_CFG_MAX; index++) {  //按顺序计算数据
        if ((xTimPro.cfg[index]->end != 0xBBBBU) || (mark)) {  //数据错误重建相关数据
            xTimPro.cfg[index] = rt_malloc(uuzTIM_CFG_LEN);  //分配相关数据
            tim_config_add(xTimPro.cfg[index]);  //初始化内存数据
            cfg_data_error = RT_FALSE;
        }
    }
    dataCount += _TIM_CFG_MAX;
    LOG_D("%d-{%d}--Flag[%d]", optStep, dataCount, cfg_data_error);
    optStep++;
    //------------------------------->阶段结束<-----------------------------------------
    if (cfg_data_error == RT_FALSE) {   //内部数据有更新，更新相关数据
        config_data_save(0xFFFF, 0xFFFF);
    }
    //------------------------------->更新数据<-----------------------------------------
    //---------------------------------->END<-------------------------------------------
}
