/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __UUZ_EVENT_CFG_H
#define __UUZ_EVENT_CFG_H

#include "typedefCFG.h"
#include "uuzConfigCFG.h"

extern Config_Data_Typedef_t xConfigMap;  //最多保存满设备的配置数据,保存数据的地址列表,保存配置数据的长度

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 清除配置地址数据
 * @param map
 */
void config_map_empty(Config_Map_Typedef_t * map);

/**
 * @brief 更新配置地址数据
 * @param map
 */
u32 config_map_sync(Config_Map_Typedef_t* map,
        u16 t, u16 sta, u16 index, u32 len, u32 last_len,
        void* addr);
/**
 * @brief 配置列表数据读取
 */
void config_map_read(void);

/**
 * @brief 配置列表数据写入
 */
void config_map_save(void);

/**
 * @brief 保存设备系统的相关配置
 * @param type:需要保存的数据类型
 * @param index:需要对应的程序编号
 */
void config_data_save(u32 type, u16 index);

/**
 * @brief 读取设备系统的相关配置
 */
u8 config_data_read(void);

/**
 * @brief 配置数据列表地址初始化
 */
void config_addr_init(u8 mark);

#ifdef __cplusplus
}
#endif

#endif // __UUZ_EVENT_CFG_H
