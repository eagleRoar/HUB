/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-03   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_CFG_H
#define __TYPEDEF_CFG_H
// include ------------------------------------------------
#include "typedefBASE.h"
#include "typedefINIT.h"
#include "uuzConfigDEV.h"
// ------------------------------------------------
typedef struct config_addr_t   //配置数据地址信息
{
    u32 en;    //配置的位的数据是否有效(RT_TRUE|RT_FALSE)
    u32 sta;    //配置的位对应是否有相关数据
    u32 t;    //配置相关类型数据(配置类型编号)
    u32 id;    //配置相关模块ID/配置行动对应的位置
    u32 n;    //配置数据的起始位置
    void *addr;    //配置数据相关指针位置

}__attribute__ ((__packed__)) Config_Map_Typedef_t;
#define uuzCONFIG_ADDR_LEN (sizeof(Config_Map_Typedef_t))

typedef struct config_data_t   //配置数据列表界面
{
    Config_Map_Typedef_t map[uuzDEV_MAX];   //数据记录
    u32 len;    //配置数据长度
    //结尾符号
    u32 end;    //0xBBBBU

}__attribute__ ((__packed__)) Config_Data_Typedef_t;
#define uuzCONFIG_DATA_LEN (sizeof(Config_Data_Typedef_t))

#endif // __TYPEDEF_CFG_H
