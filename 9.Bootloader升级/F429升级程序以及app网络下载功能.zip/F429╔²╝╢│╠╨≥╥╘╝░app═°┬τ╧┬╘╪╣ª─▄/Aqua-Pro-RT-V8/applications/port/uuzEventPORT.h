#ifndef __UUZ_PORT_EVENT_H
#define __UUZ_PORT_EVENT_H

#include "typedefPORT.h"
#include "uuzConfigPORT.h"
#include <board.h>
#if 1

/**
 * @brief 检测端口的类型数据是否正确
 * @param ucPort
 * @param ucType
 */
u8 port_type_is_assert(u16 type);
#else

extern Class_Port_Typedef_t xPortCache;   //端口相关缓存数据

#ifdef __cplusplus
extern "C" {
#endif

    /**
     * @brief 初始化配置相关数据
     */
    void uuz_vPort_Default_Init(void);

    /**
     * @brief 初始化端口相关缓存数据
     */
    void uuz_vPort_Init(void);

    /**
     * @brief 批量操作同类型的端口
     *
     * @param xType ENMU_TYPE_PORT
     * @param ucSta PIN_HIGH | PIN_LOW
     * @param ulDelay 0:无延时；>0:有延时
     * @return int  RT_EOK | RT_ERROR
     */
    int uuz_lPort_Group_Opt(ENMU_TYPE_PORT xType, u8 ucSta, u32 ulDelay);

    /**
     * @brief 端口有效性设置
     *
     * @param xPort 当前端口
     * @param ucSta 端口有效性
     */
    void uuz_vPort_Enable(u8 ucPort, u8 ucSta);

    /**
     * @brief 设置端口的类型数据
     * @param ucPort 端口编号
     * @param ucType
     */
    void uuz_vPort_SetType(u8 ucPort, u8 ucType);

    /**
     * @brief 端口开关状态设置
     * @param ucPort 端口编号
     * @param ucSta
     */
    void uuz_vPort_Opt(u8 ucPort, u8 ucSta);

    /**
     * @brief 读取串口信息
     * @param ucPort 端口编号
     * @return
     */
    u8 uuz_ucPort_Read(u8 ucPort);

    /**
     * @brief 设置定时的有效性
     *
     * @param ucPort 对应端口
     * @param ucSel 对应选项
     * @param usData 数据:RT_FALSE|RT_TRUE
     */
    void uuz_vPort_Timer_SetEN(u8 ucPort, u8 ucSel, u16 usData);

    /**
     * @brief 设置定时的开启数据
     *
     * @param ucPort 对应端口
     * @param ucSel 对应选项
     * @param usData 数据 0 - 24 * 60
     */
    void uuz_vPort_Timer_SetON(u8 ucPort, u8 ucSel, u16 usData);

    /**
     * @brief 设置定时的关闭数据
     *
     * @param ucPort 对应端口
     * @param ucSel 对应选项
     * @param usData 数据 0 - 24 * 60
     */
    void uuz_vPort_Timer_SetOFF(u8 ucPort, u8 ucSel, u16 usData);

    /**
     * @brief 端口处理初始化
     * @return
     */
    int port_opt_init(void);

    /**
     * @brief 端口处理线程
     * @param parameter
     * @return
     */
    void port_opt_thread_entry(void* parameter);

#ifdef __cplusplus
}
#endif
#endif

#endif // __UUZ_PORT_EVENT_H
