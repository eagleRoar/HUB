/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-03   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_PORT_H
#define __TYPEDEF_PORT_H

#if 0
#include "uuzInit.h"
#include "uuzConfigPORT.h"

typedef struct port_t
{

    u8 ucEnable;
    u8 ucType;
    u8 ucTemp[2];

    TimerConfig_Typedef_t xTimer[uuzPORT_TIMER_MAX];  //时间表达:480min=480/60=8:00, 1230=1230/60=20:30m

}Port_Typedef_t;

#define uuzPORT_LEN (sizeof(Port_Typedef_t))    //端口的数据长度

typedef struct class_port_t
{
    //端口信息相关数据
    Port_Typedef_t *port[uuzPORT_MAX];//对应端口的指针组
    //端口操作方法的类
    void (*enable)(u8, u8);//设置端口的有效性
    void (*set)(u8, u8);//设置端口的类型
    void (*opt)(u8, u8);//设置端口状态
    u8 (*state)(u8);//读取端口状态
    //端口定时器的操作类
    void (*set_en)(u8, u8, u16);
    void (*set_on)(u8, u8, u16);
    void (*set_off)(u8, u8, u16);

}Class_Port_Typedef_t;  //端口的类操作
#endif

#endif // __TYPEDEF_DEV_ID_H
