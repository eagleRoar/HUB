/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-28   ZhouXiaomin     first version
 */
//-------------------------------------------------------------------
#include "uuzOpt.h"
//-------------------------------------------------------------------
#include <rtthread.h>
#include <string.h>
#include <rtdevice.h>
//-------------------------------------------------------------------
#include "uuzEventPORT.h"
#include "uuzDevCFG.h"
//#include "uuzEventDEV.h"
#include "uuzRTC.h"
#include "uuzEventHMI.h"
/******************************************************************************/
//Debug Log Config
#define DBG_ENABLE
#define DBG_SECTION_NAME "PORT"
#define DBG_LEVEL DBG_LOG
#define DBG_COLOR
#include <rtdbg.h>
/******************************************************************************/
//Class_Port_Typedef_t xPortCache;   //端口相关缓存数据
/******************************************************************************/
#if 1
/**
 * @brief 检测端口的类型数据是否正确
 * @param ucPort
 * @param ucType
 */
u8 port_type_is_assert(u16 type)
{
    if ((type == uuzPORT_CO2)
            || (type == uuzPORT_HEAT)
            || (type == uuzPORT_COOL)
            || (type == uuzPORT_HUMI)
            || (type == uuzPORT_DEHUMI)
            || (type == uuzPORT_LIGHT)
            || (type == uuzPORT_ALARM)
            || (type == uuzPORT_FAN_L)
            || (type == uuzPORT_FAN_M)
            || (type == uuzPORT_FAN_H)
            || (type == uuzPORT_IRR_FLOOD)
            || (type == uuzPORT_IRR_DRAIN)
            || (type == uuzPORT_IRR_IN)
            || (type == uuzPORT_IRR_QUALITY)
            || (type == uuzPORT_IRR_MIX)
            || (type == uuzPORT_TIMER)
            || (type == uuzPORT_CYCLE)
            || (type == uuzPORT_FAN)
            ) {  //端口的类型判断
        return RT_TRUE;
    } else {
        return RT_FALSE;
    }
}
#else
/**
 * @brief 初始化配置相关数据
 */
void uuz_vPort_Default_Init(void)
{
    u8 ucIndex, ucIndey;
    //HYDRO-Pro 端口默认配置
    u16 usDefaultProType[uuzPORT_MAX] =
    {
        uuzPORT_HEAT, uuzPORT_COOL,
        uuzPORT_HUMI, uuzPORT_HUMI,
        uuzPORT_DEHUMI, uuzPORT_DEHUMI,
        uuzPORT_LIGHT, uuzPORT_CH2_LIGHT,
        uuzPORT_ALARM, uuzPORT_ALARM
    };

    //HYDRO-Plus 端口默认配置
    u16 usDefaultPlusType[uuzPORT_MAX] =
    {
        uuzPORT_HEAT, uuzPORT_COOL,
        uuzPORT_HUMI, uuzPORT_DEHUMI,
        uuzPORT_IRR_FLOOD, uuzPORT_IRR_DRAIN,
        uuzPORT_IRR_IN, uuzPORT_LIGHT,
        uuzPORT_CH2_LIGHT, uuzPORT_ALARM
    };

    //端口定时器默认配置
    TimerConfig_Typedef_t xDefaultTimer =
    {   uuzDEV_UNREG, 480, 960};

    for (ucIndex = 0; ucIndex < uuzPORT_MAX; ucIndex++) {   //端口信息初始化
        rt_memset(&xDevCFG.xPortConfig[ucIndex], 0x00, uuzPORT_LEN);//清零数据
        xDevCFG.xPortConfig[ucIndex].ucEnable = uuzDEV_REG_OK;
        if (xDeviceCache.usHmiDeviceType == uuzDEVICE_PLUS) {   //是PLUS版本
            xDevCFG.xPortConfig[ucIndex].ucType = usDefaultPlusType[ucIndex];
        } else {    //是默认的PRO版本
            xDevCFG.xPortConfig[ucIndex].ucType = usDefaultProType[ucIndex];
        }
        for (ucIndey = 0; ucIndey < uuzPORT_TIMER_MAX; ucIndey++) {    //定时数据初始化
            rt_memcpy(&xDevCFG.xPortConfig[ucIndex].xTimer[ucIndey],
                    &xDefaultTimer,
                    sizeof(TimerConfig_Typedef_t));
        }
    }
}

/**
 * @brief 初始化端口相关缓存数据
 */
void uuz_vPort_Init(void)
{
    u8 ucIndex;

    for (ucIndex = 0; ucIndex < uuzPORT_MAX; ucIndex++) {   //加载端口数据指针
        xPortCache.port[ucIndex] = &xDevCFG.xPortConfig[ucIndex];
        xPortCache.enable = uuz_vPort_Enable;
        xPortCache.set = uuz_vPort_SetType;
        xPortCache.opt = uuz_vPort_Opt;
        xPortCache.state = uuz_ucPort_Read;
        xPortCache.set_en = uuz_vPort_Timer_SetEN;
        xPortCache.set_on = uuz_vPort_Timer_SetON;
        xPortCache.set_off = uuz_vPort_Timer_SetOFF;
    }
}

/**
 * @brief 批量操作同类型的端口
 * 
 * @param xType ENMU_TYPE_PORT
 * @param ucSta PIN_HIGH | PIN_LOW
 * @param ulDelay (0):无延时；(>0):有延时
 * @return int  RT_EOK | RT_ERROR
 */
int uuz_lPort_Group_Opt(ENMU_TYPE_PORT xType, u8 ucSta, u32 ulDelay)
{
    u8 ucResult = 0;

    for (int ucIndex = 0; ucIndex < uuzPORT_MAX; ucIndex++) {   //组群操作
        if (xDevCFG.xPortConfig[ucIndex].ucEnable == uuzDEV_REG_OK) {    //如果端口被打开，且类型符合要求
            if (xType == xDevCFG.xPortConfig[ucIndex].ucType) {    //读取端口的当前状态是否符合
                if (xPortCache.state(ucIndex) != ucSta) {
                    if (xDeviceCache.test_flag == 0) {  //不是端口测试模式
                        xPortCache.opt(ucIndex, ucSta);//端口操作
                        uuz_vPortStaToHmi(ucIndex);//发送信息到HMI
                        if (ulDelay) {  //如果有设置延时时间
                            rt_thread_mdelay(ulDelay);//启动延时
                        }
                    }
                }
            }
            ucResult = 1;
        }
    }

    return ucResult;
}

/**
 * @brief 端口有效性设置
 *
 * @param ucPort 当前端口
 * @param ucSta 端口
 */
void uuz_vPort_Enable(u8 ucPort, u8 ucSta)
{
    if (ucPort < uuzPORT_MAX) {  //符合端口位置
        if (ucSta == uuzDEV_REG_OK || ucSta == uuzDEV_UNREG) {  //符合端口状态
            xPortCache.port[ucPort]->ucEnable = ucSta;//设置端口状态
        }
    }
}

/**
 * @brief 设置端口的类型数据
 * @param ucPort
 * @param ucType
 */
void uuz_vPort_SetType(u8 ucPort, u8 ucType)
{
    if (ucPort < uuzPORT_MAX) {  //符合端口位置
        if ((ucType == uuzPORT_CO2)
                || (ucType == uuzPORT_HEAT)
                || (ucType == uuzPORT_COOL)
                || (ucType == uuzPORT_HUMI)
                || (ucType == uuzPORT_DEHUMI)
                || (ucType == uuzPORT_LIGHT)
                || (ucType == uuzPORT_CH2_LIGHT)
                || (ucType == uuzPORT_ALARM)
                || (ucType == uuzPORT_FAN_L)
                || (ucType == uuzPORT_FAN_M)
                || (ucType == uuzPORT_FAN_H)
                || (ucType == uuzPORT_IRR_FLOOD)
                || (ucType == uuzPORT_IRR_DRAIN)
                || (ucType == uuzPORT_IRR_IN)
                || (ucType == uuzPORT_IRR_QUALITY)
                || (ucType == uuzPORT_IRR_MIX)
                || (ucType == uuzPORT_TIMER)
        ) {  //端口的类型判断
            xPortCache.port[ucPort]->ucType = ucType;//设置端口类型
        }
    }
}

/**
 * @brief 端口开关状态设置
 * @param ucPort
 * @param ucSta
 */
void uuz_vPort_Opt(u8 ucPort, u8 ucSta)
{
    if (ucPort == 0) {
        rt_pin_write(EXT1_PIN, ucSta);
    } else if (ucPort == 1) {
        rt_pin_write(EXT2_PIN, ucSta);
    } else if (ucPort == 2) {
        rt_pin_write(EXT3_PIN, ucSta);
    } else if (ucPort == 3) {
        rt_pin_write(EXT4_PIN, ucSta);
    } else if (ucPort == 4) {
        rt_pin_write(EXT5_PIN, ucSta);
    } else if (ucPort == 5) {
        rt_pin_write(EXT6_PIN, ucSta);
    } else if (ucPort == 6) {
        rt_pin_write(EXT7_PIN, ucSta);
    } else if (ucPort == 7) {
        rt_pin_write(EXT8_PIN, ucSta);
    } else if (ucPort == 8) {
        rt_pin_write(EXT9_PIN, ucSta);
    } else if (ucPort == 9) {
        rt_pin_write(EXT10_PIN, ucSta);
    }
}

/**
 * @brief 读取串口信息
 * @param ucPort
 * @return
 */
u8 uuz_ucPort_Read(u8 ucPort)
{
    u8 xSta;

    if (ucPort == 0) {
        xSta = rt_pin_read(EXT1_PIN);
    } else if (ucPort == 1) {
        xSta = rt_pin_read(EXT2_PIN);
    } else if (ucPort == 2) {
        xSta = rt_pin_read(EXT3_PIN);
    } else if (ucPort == 3) {
        xSta = rt_pin_read(EXT4_PIN);
    } else if (ucPort == 4) {
        xSta = rt_pin_read(EXT5_PIN);
    } else if (ucPort == 5) {
        xSta = rt_pin_read(EXT6_PIN);
    } else if (ucPort == 6) {
        xSta = rt_pin_read(EXT7_PIN);
    } else if (ucPort == 7) {
        xSta = rt_pin_read(EXT8_PIN);
    } else if (ucPort == 8) {
        xSta = rt_pin_read(EXT9_PIN);
    } else if (ucPort == 9) {
        xSta = rt_pin_read(EXT10_PIN);
    }

    return xSta;
}

/**
 * @brief 设置定时的有效性
 *
 * @param ucPort 对应端口 (0 - 10)
 * @param ucSel 对应选项(0 - 10)
 * @param usData 数据:RT_FALSE|RT_TRUE
 */
void uuz_vPort_Timer_SetEN(u8 ucPort, u8 ucSel, u16 usData)
{
    if (ucPort < uuzPORT_MAX) {  //符合端口位置
        if (ucSel < uuzPORT_TIMER_MAX) {  //符合定时器位置
            xPortCache.port[ucPort]->xTimer[ucSel].usEn = usData;
        }
    }
}

/**
 * @brief 设置定时的开启数据
 *
 * @param ucPort 对应端口
 * @param ucSel 对应选项
 * @param usData 数据 0 - 24 * 60
 */
void uuz_vPort_Timer_SetON(u8 ucPort, u8 ucSel, u16 usData)
{
    if (ucPort < uuzPORT_MAX) {  //符合端口位置
        if (ucSel < uuzPORT_TIMER_MAX) {  //符合定时器位置
            xPortCache.port[ucPort]->xTimer[ucSel].usOn = usData;
        }
    }
}

/**
 * @brief 设置定时的关闭数据
 *
 * @param ucPort 对应端口
 * @param ucSel 对应选项
 * @param usData 数据 0 - 24 * 60
 */
void uuz_vPort_Timer_SetOFF(u8 ucPort, u8 ucSel, u16 usData)
{
    if (ucPort < uuzPORT_MAX) {  //符合端口位置
        if (ucSel < uuzPORT_TIMER_MAX) {  //符合定时器位置
            xPortCache.port[ucPort]->xTimer[ucSel].usOff = usData;
        }
    }
}

/**
 * @brief 判断是否有定时端口操作
 */
void uuz_vPort_Timer_Opt(void)
{
    u8 ucIndex, ucIndey;
    u16 usOn = 0, usOff = 0;
    u8 ucOpt = PIN_HIGH;    //高电平
    u16 usCurrT = uuz_usRTC_GetMinutes();//获取当前的时间

    for (ucIndex = 0; ucIndex < uuzPORT_MAX; ucIndex++) {

        if ((xPortCache.port[ucIndex]->ucType == uuzPORT_FAN_L)  //低风速
                || (xPortCache.port[ucIndex]->ucType == uuzPORT_FAN_M)//中风速
                || (xPortCache.port[ucIndex]->ucType == uuzPORT_FAN_H)//高风速
                || (xPortCache.port[ucIndex]->ucType == uuzPORT_TIMER)//普通定时器
        ) {

            ucOpt = PIN_HIGH;   //初始化开灯动作
            for (ucIndey = 0; ucIndey < uuzPORT_TIMER_MAX; ucIndey++) {  //读取端口定时器数据
                if (xPortCache.port[ucIndex]->xTimer[ucIndey].usEn == RT_TRUE) {    //该定时器被打开
                    usOn = xPortCache.port[ucIndex]->xTimer[ucIndey].usOn;//开启时间
                    usOff = xPortCache.port[ucIndex]->xTimer[ucIndey].usOff;//关闭时间
                    if (usOn < usOff) {  //如果是正向时间
                        if ((usCurrT >= usOn) && (usCurrT <= usOff)) {
                            ucOpt = PIN_LOW;    //有有效动作开灯
                            ucIndey = uuzPORT_TIMER_MAX;//跳出循环
                        }
                    } else if (usOn > usOff) {   //如果是反向时间
                        if ((usCurrT <= usOff) || (usCurrT >= usOn)) {
                            ucOpt = PIN_LOW;    //有有效动作开灯
                            ucIndey = uuzPORT_TIMER_MAX;//跳出循环
                        }
                    }  //其他状态下，不动作
                }
            }
            //LOG_D("Ready OPT PORT[%d]:%d", ucIndex, ucOpt);
            if (xPortCache.state(ucIndex) != ucOpt) {   //如果状态不相同
                if (xDeviceCache.test_flag == 0) {  //不是端口测试模式
                    //LOG_D("OPT PORT[%d]:%d", ucIndex, ucOpt);
                    xPortCache.opt(ucIndex, ucOpt);//操作端口状态
                    uuz_vPortStaToHmi(ucIndex);//发送信息到HMI
                    rt_thread_mdelay(10);//操作端口延时
                }
            }
        }
    }
}

/**
 * @brief 端口处理线程
 * @return
 */
void port_opt_thread_entry(void* parameter)
{
    uuz_vPort_Init();   //初始化端口状态
    while (1) {
        //等待工作稳定状态,开启启动定时器工作
        if (xDeviceCache.usStartupWatingMask == 1) {
            uuz_vPort_Timer_Opt();  //每秒一次端口数据判断
        }
        //每1000ms一次
        rt_thread_mdelay(1000);
    }
}

/**
 * @brief 端口处理初始化
 * @param parameter
 * @return
 */
int port_opt_init(void)
{
    rt_err_t ret = RT_EOK;
    /* 创建 serial 线程 */
    rt_thread_t thread = rt_thread_create("port_opt", port_opt_thread_entry,
            RT_NULL, 1024, 20, 100);

    /* 创建成功则启动线程 */
    if (thread != RT_NULL) {
        rt_thread_startup(thread);
        LOG_I("start Thread [port opt]");
    } else {
        LOG_E("start Thread [port opt] failed");
        ret = RT_ERROR;
    }

    return ret;
}
#endif
