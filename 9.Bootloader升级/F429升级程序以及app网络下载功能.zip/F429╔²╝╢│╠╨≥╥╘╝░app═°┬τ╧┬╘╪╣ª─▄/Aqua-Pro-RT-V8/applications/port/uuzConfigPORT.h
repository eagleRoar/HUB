#ifndef __UUZ_CONFIG_PORT_H
#define __UUZ_CONFIG_PORT_H

//最大10个输出
#define uuzPORT_MAX (10U)
#define uuzPORT_TIMER_MAX (10U)

typedef enum
{
    uuzPORT_CO2 = 0x00U,  //输出CO2
    uuzPORT_HEAT = 0x01U,  //输出加热
    uuzPORT_COOL = 0x02U,  //输出制冷
    uuzPORT_HUMI = 0x03U,  //输出加湿
    uuzPORT_DEHUMI = 0x04U,  //输出除湿
    uuzPORT_LIGHT = 0x05U,  //输出灯光
    uuzPORT_ALARM = 0x07U,  //输出报警
    uuzPORT_FAN_L = 0x08U,  //输出低速风扇
    uuzPORT_FAN_M = 0x09U,  //输出中速风扇
    uuzPORT_FAN_H = 0x0AU,  //输出高速风扇
    //灌溉相关
    uuzPORT_IRR_FLOOD = 0x10U,  //输出灌溉阀/泵
    uuzPORT_IRR_DRAIN = 0x11U,  //输出回水阀/泵
    uuzPORT_IRR_IN = 0x12U,  //输出清水阀/泵
    uuzPORT_IRR_QUALITY = 0x13U,  //输出检验阀/泵
    uuzPORT_IRR_MIX = 0x14U,  //输出检验阀/泵
    //定时器输出
    uuzPORT_TIMER = 0x80U,  //输出定时器
    uuzPORT_CYCLE = 0x81U,  //输出循环器
    uuzPORT_FAN = 0x82U  //输出风扇
} ENMU_TYPE_PORT;

#endif // __UUZ_CONFIG_PORT_H
