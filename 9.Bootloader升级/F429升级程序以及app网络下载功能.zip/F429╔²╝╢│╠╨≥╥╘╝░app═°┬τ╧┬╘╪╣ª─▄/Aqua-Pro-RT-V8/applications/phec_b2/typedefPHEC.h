/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_PHEC_B2_H
#define __TYPEDEF_PHEC_B2_H

// include ---------------------------------------------
#include "typedefDEVID.h"
#include "typedefBASE.h"
#include "uuzConfigDEV.h"
#include "uuzOpt.h"
// ------- ---------------------------------------------
typedef struct phecb2config_t
{

    //EC相关设置数据
    u16 ec_t;
    u16 ec_d;
    u16 ec_h;
    u16 ec_l;
    u16 ec_en;

    //pH相关设置数据
    u16 pH_t;
    u16 pH_d;
    u16 pH_h;
    u16 pH_l;
    u16 pH_en;

    //温度相关设置数据
    u16 ta_h;
    u16 ta_en;

} Phec_Single_Typedef_t;
#define uuzPHEC_CONFIG_LEN (sizeof(Phec_Single_Typedef_t))

typedef struct phecb2value_t
{
    //实时数据
    u16 usVal_ec;
    u16 usVal_pH;
    u16 usVal_Tp;

    //上一次实时数据
    u16 usVal_p_ec;
    u16 usVal_p_pH;
    u16 usVal_p_Tp;

    //数据不变计数
    u16 usCount_ec;
    u16 usCount_pH;
    u16 usCount_Tp;

    u16 usState_ec;
    u16 usState_p_ec;
    u16 usCount_s_ec;

    u16 usState_pH;
    u16 usState_p_pH;
    u16 usCount_s_pH;

} PHECB2_Value_Typedef_t;

#endif // __TYPEDEF_PHEC_B2_H
