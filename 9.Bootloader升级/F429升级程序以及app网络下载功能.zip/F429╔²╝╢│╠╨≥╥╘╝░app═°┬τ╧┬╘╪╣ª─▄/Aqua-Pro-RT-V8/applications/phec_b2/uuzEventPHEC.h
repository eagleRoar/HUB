/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __UUZ_PHEC_B2_EVENT_H
#define __UUZ_PHEC_B2_EVENT_H

#include "typedefPHEC.h"
#include "typedefMBR.h"
#include "typedefPROG.h"

#ifdef __cplusplus
extern "C" {
#endif

extern MODBUS_RTU_CODE phec_opt_code[3];
//缓存数据
extern PHECB2_Value_Typedef_t xPhecB2Value[uuzDEV_PHEC_B2_MAX];

/**
 * @brief PHEC-B2设备的缓存参数初始化
 * 
 */
void phec_value_init(void);
/**
 * @brief PHEC-B2设备的配置参数初始化
 * 
 * @param id 需要处理的设备相对数据地址
 */
void phec_config_init(u8 id);
/**
 * @brief PHEC-B2设备读取数据动作
 * 
 * @param id 需要处理的设备相对数据地址
 */

void phec_value_read(u8 id);
/**
 * @brief PHEC-B2设备实时数据处理
 * 
 * @param id 需要处理的设备相对数据地址
 * @param data 需要处理的设备实时数据
 */
void phec_value_resolve(u8 id, u8* data);
/**
 * @brief 重置PHEC-B2的ID为默认值
 */
void phec_id_reset(void);
/**
 * @brief PHEC-B2的运行模式操作设置
 * 
 * @param id 需要处理的设备相对数据地址
 * @param opt  要操作的状态 0-OFF/1-ON
 */
void phec_dosing_opt(u8 id, u16 opt);
/**
 * @brief PHEC-B2的配置单独更新
 * 
 * @param id 需要处理的设备相对数据地址
 * @param addr_t 需要处理的命令地址
 * @param data 需要修改的数据内容
 */
void phec_config_single_set(u8 id, u16 addr_t, u16 data);

#ifdef __cplusplus
}
#endif

#endif // __UUZ_PHEC_B2_EVENT_H
