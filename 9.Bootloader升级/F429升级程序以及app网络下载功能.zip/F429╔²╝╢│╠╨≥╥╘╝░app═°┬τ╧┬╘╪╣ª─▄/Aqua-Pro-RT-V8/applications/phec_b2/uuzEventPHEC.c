/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
/*include*****************************************************************************/
#include <math.h>
#include <string.h>
/******************************************************************************/
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzTEMP.h"
#include "uuzEVENT.h"
/******************************************************************************/
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
/******************************************************************************/
#include "typedefDEVID.h"
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
/******************************************************************************/
#include "uuzEventPHEC.h"
#include "uuzEventSR.h"
/*log---------------------------------------------*/
#define DBG_TAG "e.phec"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/******************************************************************************/
//PHEC-B2的缓存数据
PHECB2_Value_Typedef_t xPhecB2Value[uuzDEV_PHEC_B2_MAX];
MODBUS_RTU_CODE phec_opt_code[3] =
            {
                        { _CODE_R, 0x0011U, 0x0001U },  //Get Modbus-ID
                        { _CODE_RW, 0x0000U, 0x0003U },  //Read Value
                        { _CODE_RW, 0x0036U, 0x0001U }  //Set Modbus-ID
            };
/******************************************************************************/
/**
 * @brief PHEC-B2设备的缓存参数初始化
 * 
 */
void phec_value_init(void)
{
    for (u8 index = 0; index < uuzDEV_PHEC_B2_MAX; index++) {
        //清空缓存,同时将标记清零
        rt_memset(&xPhecB2Value[index], 0x00, sizeof(PHECB2_Value_Typedef_t));
    }
}

/**
 * @brief 读取PHEC-B2的实时数据
 * 
 * @param id 
 */
void phec_value_read(u8 id)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Device ID
    ucDataCommand[ucLenCommand++] = xDevSTA.xB2[id].id;
    //ucDataCommand[ucLenCommand++] = 0xEF;
    ucDataCommand[ucLenCommand++] = uuzMBR_READ_HOLDING_REGISTER;
    vU16ToU8(ucDataCommand + ucLenCommand, phec_opt_code[_MBR_R_VALUE].code, uuzMSB);
    ucLenCommand += 2U;
    //连续读取3组数据
    vU16ToU8(ucDataCommand + ucLenCommand, phec_opt_code[_MBR_R_VALUE].n, uuzMSB);
    ucLenCommand += 2U;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;

    //LOG_D("[%d]:U-%d:D-%02X:L-%d", id, xDevSTA.xB2[id].uart, ucDataCommand[0], ucLenCommand);
    cmd_set(xDevSTA.xB2[id].uart, (u8*) ucDataCommand, ucLenCommand);

    //N次读取无数据，将连接状态切断
    if (xDevSTA.xB2[id].count < uuzDEV_CONNECT_ERR) {
        //连接计数
        xDevSTA.xB2[id].count++;
    }
}

/**
 * @brief PHEC-B2设备实时数据处理
 * 
 * @param id 需要处理的设备相对数据地址
 * @param data 需要处理的设备实时数据
 */
void phec_value_resolve(u8 id, u8* data)
{
    u16 ucLenCommand = 3;

    if (data != NULL) {
        //EC-Current-D0
        xPhecB2Value[id].usVal_ec = usU8ToU16(data + ucLenCommand, uuzMSB);
        ucLenCommand += 2;
        //pH-Current-D1
        xPhecB2Value[id].usVal_pH = usU8ToU16(data + ucLenCommand, uuzMSB);
        ucLenCommand += 2;
        //Temperature-Current-D2
        xPhecB2Value[id].usVal_Tp = usU8ToU16(data + ucLenCommand, uuzMSB);
        ucLenCommand += 2;
        //C->F
        if (xSysCFG.unit_ta == uuzTA_F) {
            xPhecB2Value[id].usVal_Tp = uuz_usTempC2F_ConvCplt(xPhecB2Value[id].usVal_Tp);
        }

        //如果是主显示PEHC-B2的数据
        if (xSysCFG.pehc_id == id) {
            //是初始刷新的数据
            if (xSysSTA.sync_phec == 0) {
                //发送刷新数据
                rt_event_send(eventDATA, UI_DATA_SYNC);
                xSysSTA.sync_phec = 1;
            } else {
                u8 is_need_update = 0;
                //如果接收数据和缓存数据不一致
                if (xPhecB2Value[id].usVal_ec != xPhecB2Value[id].usVal_p_ec) {
                    xPhecB2Value[id].usVal_p_ec = xPhecB2Value[id].usVal_ec;
                    is_need_update = 1;
                }
                if (xPhecB2Value[id].usVal_pH != xPhecB2Value[id].usVal_p_pH) {
                    xPhecB2Value[id].usVal_p_pH = xPhecB2Value[id].usVal_pH;
                    is_need_update = 1;
                }
                if (xPhecB2Value[id].usVal_Tp != xPhecB2Value[id].usVal_p_Tp) {
                    xPhecB2Value[id].usVal_p_Tp = xPhecB2Value[id].usVal_Tp;
                    is_need_update = 1;
                }
                //需要更新数据发送相关信号
                if (is_need_update == 1) {
                    rt_event_send(eventDATA, UI_DATA_SYNC);
                }
            }

        }
    }
}

/**
 * @brief 重置PHEC-B2的ID为默认值(0x02)
 */
void phec_id_reset(void)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    LOG_D("Reset PHEC-B2 Modbus-ID.");

    //Device ID
    ucDataCommand[ucLenCommand++] = 0xEFU;  //万能ID
    ucDataCommand[ucLenCommand++] = uuzMBR_WRITE_REGISTER;
    //Code
    vU16ToU8(ucDataCommand + ucLenCommand, phec_opt_code[_MBR_SET_ID].code, uuzMSB);
    ucLenCommand += 2U;
    vU16ToU8(ucDataCommand + ucLenCommand, uuzDEV_BASE_ID, uuzMSB);
    ucLenCommand += 2U;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;

    uuz_vDevCommandSend(uuzUART_7, ucDataCommand, ucLenCommand);
}
