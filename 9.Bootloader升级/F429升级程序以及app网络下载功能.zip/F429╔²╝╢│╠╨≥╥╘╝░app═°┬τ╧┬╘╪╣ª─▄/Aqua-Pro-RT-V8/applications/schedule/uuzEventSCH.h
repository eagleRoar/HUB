/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __UUZ_SCH_EVENT_H
#define __UUZ_SCH_EVENT_H

#include "typedefMBR.h"
#include "typedefSCH.h"
#include <time.h>

extern Sch_Config_Typedef_t *xSchCFG;  //Schedule周期表配置

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 设置Schedule周期表的初始相关数据
 */
void schedule_config_init(Sch_Config_Typedef_t * sch);

/**
 * @brief 根据时间获取年月日
 * @param day
 * @param t
 */
void all_days_to_time(u32 day, u16* t);

/**
 * @brief 根据当前时间，获取是否处于周期表范围内
 * 
 * @return u8 返回数据指针位置，0~(uuzPROG_MAX-1)为有效，uuzPROG_MAX失败
 */
u8 schedule_curr_program_get(void);

#ifdef __cplusplus
}
#endif

#endif // __UUZ_SCH_EVENT_H
