/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
/*include*****************************************************************************/
#include <math.h>
#include <string.h>
/******************************************************************************/
#include "uuzCalendar.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzRTC.h"
/******************************************************************************/
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
/******************************************************************************/
#include "typedefDEVID.h"
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
/******************************************************************************/
#include "uuzEventSCH.h"
/*log---------------------------------------------*/
#define DBG_TAG "e.sch"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/******************************************************************************/
Sch_Config_Typedef_t *xSchCFG;  //Schedule周期表配置
/******************************************************************************/
/**
 * @brief 设置Schedule周期表的初始相关数据
 */
void schedule_config_init(Sch_Config_Typedef_t * sch)
{
    //开始的时间
    if (sch != RT_NULL) {
        sch->start[0] = rTm.tm_year + 1900;
        sch->start[1] = rTm.tm_mon + 1;
        sch->start[2] = rTm.tm_mday;
        //结束的时间
        sch->end[0] = sch->start[0];
        sch->end[1] = sch->start[1];
        sch->end[2] = sch->start[2];

        for (u8 index = 0; index < uuzSCH_DATA_MAX; index++) {
            sch->en[index] = 0;  //无数据
            sch->day[index] = 7;  //1周
            sch->prog[index] = index + 1;  //1-6
        }

        sch->crc = 0xBBBB;
    }
}

/**
 * @brief 根据当前时间，获取是否处于周期表范围内
 * 
 * @return u8 返回数据指针位置，0~(uuzPROG_MAX-1)为有效，uuzPROG_MAX失败
 */
u8 schedule_curr_program_get(void)
{
    u16 currT[3];  //年-月-日
    currT[0] = rTm.tm_year + 1900;
    currT[1] = rTm.tm_mon + 1;
    currT[2] = rTm.tm_mday;

    u32 currDay = allDays2Curr(currT[0], currT[1], currT[2]);   //当前时间
    u32 startDay = allDays2Curr(xSchCFG->start[0], xSchCFG->start[1], xSchCFG->start[2]);   //启动时间
    u32 endDay = allDays2Curr(xSchCFG->end[0], xSchCFG->end[1], xSchCFG->end[2]);   //结束时间
    u32 middleDay = startDay;

    if (currDay >= startDay && currDay <= endDay) {  //在周期表运行范围内
        for (u8 index = 0; index < uuzSCH_DATA_MAX; index++) {
            if (xSchCFG->en[index] == 1) {
                middleDay += xSchCFG->day[index];  //获取结束时间
                if (currDay < middleDay) {  //如果当前时间在该段时间内，附指针后，结束判断
                    return xSchCFG->prog[index];
                }
            }
        }
    }

    return 0;
}

/**
 * @brief 从天数解析为RTC持续时间
 * @param day:当前天数(1900到输入的时间模式)
 * @param t:输出的RTC时间
 */
void all_days_to_time(u32 day, u16* t)
{
    u32 d2000 = allDays2Year(2000);  //到2000年前的天数
    u32 d1900 = allDays2Year(1900);

    u32 index = 0;
    u32 tYear = 1999;
    u32 tDay = 0;
    u32 cDay = day;  //当前天数
    u16 tmpT[3];

    if (cDay > d2000) {
        //为2000后的时间
        tDay = d2000;
    } else {
        //为2000前的时间,从1900年开始计算
        tDay = d1900;
    }
    //计算年
    while (cDay > tDay) {
        tYear++;
        //到年底的时间
        tDay = allDays2Year(tYear + 1);
    }
    //获取当前年数据
    tmpT[0] = tYear;
    //获取今年的剩余时间
    cDay -= allDays2Year(tYear);
    //获取月启动天数
    index = 1;
    tDay = allDays(tYear, index + 1, 0);
    LOG_D("%d-cDay:%d-tDay:%d", index, cDay, tDay);
    while (cDay > tDay) {
        index++;
        tDay = allDays(tYear, index + 1, 0);
        LOG_D("%d-cDay:%d-tDay:%d", index, cDay, tDay);
    }
    //时间-月
    tmpT[1] = index;
    //时间-天
    if (index > 1) {
        tmpT[2] = cDay - allDays(tYear, index, 0);
    } else {
        tmpT[2] = cDay;
    }
    rt_memcpy(t, tmpT, 3 * sizeof(u16));
    LOG_D("all-days-tm:%04d-%02d-%02d", tmpT[0], tmpT[1], tmpT[2]);
}
