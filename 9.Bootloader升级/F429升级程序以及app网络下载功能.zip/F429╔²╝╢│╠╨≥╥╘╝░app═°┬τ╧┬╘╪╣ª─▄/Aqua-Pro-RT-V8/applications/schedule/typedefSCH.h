/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_SCH_H
#define __TYPEDEF_SCH_H

// include ---------------------------------------------
#include "typedefBASE.h"
#include "typedefDEVID.h"
#include "uuzConfigDEV.h"
#include "uuzOpt.h"
// ------- ---------------------------------------------
#define uuzSCH_DATA_MAX (6U)

typedef struct schedule_config_t
{

    u16 start[3];  //启动日期 1900年开始
    u16 end[3];  //结束日期 start+day年开始

    u16 en[uuzSCH_DATA_MAX];  //阶段有效性:0-Disable/1-Enable
    u16 day[uuzSCH_DATA_MAX];  //阶段的天数:10天
    u16 prog[uuzSCH_DATA_MAX];  //对应工作程序编号(1-9)

    u16 crc;    //0xBBBBU

} Sch_Config_Typedef_t;

#define uuzSCH_CONFIG_LEN (sizeof(Sch_Config_Typedef_t))

#endif // __TYPEDEF_SCH_H
