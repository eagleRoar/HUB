/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-29   ZhouXiaomin     first version
 */
/* system Includes ------------------------------------------------------------------*/
#include "rtthread.h"
/* user Includes ------------------------------------------------------------------*/
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
#include "uuzEEPROM.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzRTC.h"
/* Externl Includes ------------------------------------------------------------------*/
#include "uuzEventDOSING.h"
#include "uuzEventHMI.h"
#include "uuzEventIRR.h"
#include "uuzEventLGT.h"
#include "uuzEventP260.h"
#include "uuzEventPHEC.h"
#include "uuzEventPROG.h"
#include "uuzEventSCH.h"
#include "uuzEventVALVE.h"
#include "uuzEventBRD.h"
#include "uuzEventIRR.h"
/*log----------------------------------------------------------*/
#define DBG_TAG "c.dev"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/* ----------------------------------------------------------------*/
ProgConfig_Typedef_t xProgConfig;  //运行程序数据日志
Valve_Config_Typedef_t xValveConfig;  //端口配置信息
//Sch_Config_Typedef_t xSchConfig;  //Schedule周期表配置
/* ----------------------------------------------------------------*/
/**
 * @brief 保存设备系统的相关配置
 */
void system_config_save(void)
{
    //向EEPROM写入Device ID相关数据
    config_to_eeprom(uuzEEPROM_ADDR_SYSTEM, (u8*) (&xSysCFG), _UUZ_SYSTEM_CONFIG_LEN);
    rt_thread_mdelay(20);
}

/**
 * @brief 读取设备系统的相关配置
 */
void system_config_read(void)
{
    //从EERPOM读取Device Info相关数据
    eeprom_to_config(uuzEEPROM_ADDR_SYSTEM, (u8*) (&xSysCFG), _UUZ_SYSTEM_CONFIG_LEN);
    rt_thread_delay(20);
}

/**
 * @brief 保存设备(程序数据)的基本配置文件
 * 
 */
void program_config_save(void)
{
    config_to_eeprom(uuzEEPROM_ADDR_PROG, (u8*) (&xProgConfig), uuzPROG_CONFIG_LEN);
    rt_thread_mdelay(40);
}
/**
 * @brief 保存设备（1组程序数据）的基本配置文件
 * 
 * @param id 需要保存设备程序配置编号
 */
void prog_single_config_save(u8 id)
{
    u16 addr = (uuzEEPROM_ADDR_PROG + uuzPROG_SINGLE_LEN * id);
    config_to_eeprom(addr, ((u8*) (&xProgConfig) + uuzPROG_SINGLE_LEN * id), uuzPROG_SINGLE_LEN);
    rt_thread_mdelay(10);
}

/**
 * @brief 保存蠕动泵重置相关数据 
 */
void program_cycle_config_save(void)
{
    u16 addr = (uuzEEPROM_ADDR_PROG + uuzPROG_SINGLE_LEN * uuzPROG_MAX);
    config_to_eeprom(addr, ((u8*) (&xProgConfig) + uuzPROG_SINGLE_LEN * uuzPROG_MAX), sizeof(u16) * 6);
    rt_thread_mdelay(10);
}

/**
 * @brief 
 * @note 将编号转换成对应的实时值的位置
 * 
 * @param usID  需要判断的设备ID
 * @param ucType 设备的类型
 * @param ucUart 设备使用的串口编号
 * @return u8 返回的具体位置，如果返回0xFF表示没有找到数据
 */
u8 ucIDtoVal(u16 usID, u16 ucType, u8 ucUart)
{
    u8 ucRepeat = uuzDEV_TEST;
    u8 index = 0;

    switch (ucType) {
        case uuzDEV_SL_PHECB2:
            //PHEC-B2相关设备
            for (index = 0; index < uuzDEV_PHEC_B2_MAX; index++) {
                //是对应的PHEC-B2的模块数据
                if (xDevSTA.xB2[index].en == uuzDEV_REG_OK) {
                    if (xDevSTA.xB2[index].uart == ucUart) {
                        if (xDevSTA.xB2[index].id == usID) {
                            //获取对应设备的位置
                            ucRepeat = index;
                            break;
                        }
                    }
                }
            }
            break;
        case uuzDEV_SL_P260:
            //水位传感器SIN-P260相关设备
            for (index = 0; index < uuzDEV_SIN_P260_MAX; index++) {
                //是对应的压力传感器的模块数据
                if (xDevSTA.xP260[index].en == uuzDEV_REG_OK) {
                    if (xDevSTA.xP260[index].uart == ucUart) {
                        if (xDevSTA.xP260[index].id == usID) {
                            //获取对应设备的位置
                            ucRepeat = index;
                            break;
                        }
                    }
                }
            }
            break;
        case uuzDEV_SL_BRD:
            //内部开关板设备
            for (index = 0; index < uuzDEV_BRD_MAX; index++) {
                //是对应的内电源板的模块数据
                if (xDevSTA.xBrd[index].en == uuzDEV_REG_OK) {
                    if (xDevSTA.xBrd[index].uart == ucUart) {
                        if (xDevSTA.xBrd[index].id == usID) {
                            //获取对应设备的位置
                            ucRepeat = index;
                            break;
                        }
                    }
                }
            }
            break;
        case uuzDEV_SL_DOS:
            //蠕动泵设备
            for (index = 0; index < uuzDEV_DOS_MAX; index++) {
                //是对应的蠕动泵的模块数据
                if (xDevSTA.xDos[index].en == uuzDEV_REG_OK) {
                    if (xDevSTA.xDos[index].uart == ucUart) {
                        if (xDevSTA.xDos[index].id == usID) {
                            //获取对应设备的位置
                            ucRepeat = index;
                            break;
                        }
                    }
                }
            }
            break;
        default:
            break;
    }

    //如果是0xFF为读取到错误数据
    return ucRepeat;
}

/**
 * @brief usValtoID
 * @note 转换对应实时位置到编号
 * @param ucVal
 * @param ucUart
 * @return
 */
u16 usValtoID(u8 ucVal, u8 ucUart)
{
    for (u8 index = 0; index < uuzDEV_MAX; index++) {
        if (xDevIDs[index].en == uuzDEV_REG_OK) {
            if (xDevIDs[index].uart == ucUart) {
                if (xDevIDs[index].id == ucVal) {
                    //获取对应设备的位置
                    return index;
                }
            }
        }
    }

    //如果是0xFF为读取到错误数据
    return uuzDEV_TEST;
}

/*-----------------------------------------------------------------*/
