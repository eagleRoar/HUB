/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-02   ZhouXiaomin     first version
 */
/* Includes ------------------------------------------------------------------*/
#include "board.h"
#include <string.h>
/**************************************************************/
#include "uuzDevID.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzUART.h"
#include "uuzEventUART.h"
/**************************************************************/
#include "uuzConfigBBL.h"
#include "uuzConfigDEV.h"
#include "uuzConfigMBR.h"
/**************************************************************/
#include "uuzHmiTFT.h"
#include "uuzUart2.h"
#include "uuzUart3.h"
#include "uuzUart7.h"
#include "uuzUart8.h"
/* ----------------------------------------------------------------*/
/**
 * @brief Device communication information sending function, using RS485
 * @note 发送通讯协议给不同的端口
 * @param  u8 pucCommand : Data Content
 *         u8 ucLen : Data length
 * @retval None
 */
void uuz_vDevCommandSend(u8 ucUsart, const u8* pucCommand, u8 ucLen)
{
    if (pucCommand != NULL) {
        //是否打开发送日志
        if (xUartE.uart[ucUsart].log_tx == RT_TRUE) {
            rt_kprintf("SEND-%d:", ucUsart);
            for (u8 index = 0; index < ucLen; index++) {
                //一行最大长度24
                if ((index != 0) && ((index % 24) == 0)) {
                    rt_kprintf("\r\n");
                }
                rt_kprintf("%02X ", pucCommand[index]);
            }
            rt_kprintf("\r\n");
        }
        //发送数据
        rt_uart_send(&xUartE.uart[ucUsart], pucCommand, ucLen);
    }
}

/**
 * @brief Device uses BBL custom protocol send function
 * @note 发送BBL的标准协议给不同的从机设备
 * @brief uuz_vCommandSendToUSART
 * @param ucUsart   :0x00/0x01/0x02/0x03
 * @param ucCommand :Command
 * @param ucSta     :Ack/Reply
 * @param ucTargetID :目标设备ID
 * @param ucLen     :Data Length
 * @param ucData    :Data
 */
void uuz_vCommandSendToUSART(u8 ucUsart, u8 ucCommand, u8 ucSta, u8* ucTargetID, u8 ucLen, u8* ucData)
{
    u8 ucTmpCommand[uuzUART_LEN];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Head
    ucTmpCommand[ucLenCommand++] = uuzBBL_HEAD;
    //Ack/Reply + Order
    ucTmpCommand[ucLenCommand++] = (ucCommand | ucSta);
    //Target Device ID
    rt_memcpy(ucTmpCommand + ucLenCommand, ucTargetID, 4);
    ucLenCommand += 4;
    //Length
    ucTmpCommand[ucLenCommand++] = ucLen;
    //Data
    rt_memcpy(ucTmpCommand + ucLenCommand, ucData, ucLen);
    ucLenCommand += ucLen;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucTmpCommand, ucLenCommand);
    vU16ToU8((ucTmpCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2;

    cmd_set(xDevSTA.xDos[0].uart, ucTmpCommand, ucLenCommand);   //连接到默认AC端口
}

/**
 * @brief Proactively initiate read ID protocol
 * @brief uuz_vIDCheck
 * @param ucUsart :
 *        0x00: SENSOR
 *        0x01: DEVICE
 *        0x02: LINE-1
 *        0x03: LINE-2
 */
void uuz_vIDCheck(u8 ucUsart)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;
    u8 ucTargetID[4];

    // Target ID
    rt_memset(ucTargetID, 0xFF, 4);
    // Device Type
    ucDataCommand[ucLenCommand++] = uuzDEV_MT;
    ucDataCommand[ucLenCommand++] = uuzDEV_SL_MASTAR;
    // Own Device ID
    rt_memcpy((ucDataCommand + ucLenCommand), xSysCFG.dev.cpuid, 4);
    ucLenCommand += 4;

    uuz_vCommandSendToUSART(ucUsart, uuzBBL_SEND_ID_REG, uuzBBL_ACK, ucTargetID, ucLenCommand, ucDataCommand);
}

/**
 * @brief 总线主机重复提示
 * @param None
 * @retval None
 */
void uuz_vIDTipErr(u8 ucUsart, u8* ucTargetID)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;

    // Device Type
    ucDataCommand[ucLenCommand++] = uuzDEV_MT;
    ucDataCommand[ucLenCommand++] = uuzDEV_SL_MASTAR;

    rt_memcpy((ucDataCommand + ucLenCommand), xSysCFG.dev.cpuid, 4);
    ucLenCommand += 4;

    uuz_vCommandSendToUSART(ucUsart, uuzBBL_SEND_ID_REG, uuzBBL_REPLY, ucTargetID, ucLenCommand, ucDataCommand);
}

/**
 * @brief 从机设备列表已满
 * @param None
 * @retval None
 */
void uuz_vIDRegErr(u8 ucUsart, u8* ucTargetID)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;

    // Device Type
    ucDataCommand[ucLenCommand++] = 0xFF;

    uuz_vCommandSendToUSART(ucUsart, uuzBBL_BROADCAST_ID, uuzBBL_REPLY, ucTargetID, ucLenCommand, ucDataCommand);
}

/**
 * @brief Send ID Registration reply
 * @param ucRxCode: Target ID
 * @retval None
 */
void uuz_vIDReply(u8 ucUsart, u8* ucTargetID, u8 ucSetID)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;

    // Device Type
    ucDataCommand[ucLenCommand++] = ucSetID;
    ucDataCommand[ucLenCommand++] = xSysCFG.dev.id;
    // Own Device ID
    rt_memcpy((ucDataCommand + ucLenCommand), xSysCFG.dev.cpuid, 4);
    ucLenCommand += 4;

    uuz_vCommandSendToUSART(ucUsart, uuzBBL_BROADCAST_ID, uuzBBL_REPLY, ucTargetID, ucLenCommand, ucDataCommand);
}

/**
 * @brief uuz_vIDTest
 * @brief 根据ID定位模块设备
 * @param ucUsart
 * @param ucTargetID
 */
void uuz_vIDTest(u8 ucUsart, u8* ucTargetID)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;

    // Own Device ID
    rt_memcpy((ucDataCommand + ucLenCommand), xSysCFG.dev.cpuid, 4);
    ucLenCommand += 4;

    uuz_vCommandSendToUSART(ucUsart, uuzBBL_SEND_ID_TEST, uuzBBL_ACK, ucTargetID, ucLenCommand, ucDataCommand);
}

/**
 * @brief 发送测试串口连接数据
 * @param ucUsart
 * @param xDev
 */
void uuz_vIDLocation(u8 ucUsart, DevID_Typedef_t* xDev)
{
    u8 ucDataCommand[32];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    if (xDev->en == uuzDEV_REG_OK) {
        //Device ID
        ucDataCommand[ucLenCommand++] = xDev->id;
        ucDataCommand[ucLenCommand++] = uuzMBR_READ_HOLDING_REGISTER;
        vU16ToU8(ucDataCommand + ucLenCommand, uuzADDR_R_TEST_CONNECT, uuzMSB);
        ucLenCommand += 2U;
        vU16ToU8(ucDataCommand + ucLenCommand, 0x0001, uuzMSB);
        ucLenCommand += 2U;
        //CRC16
        usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
        vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
        ucLenCommand += 2U;

        uuz_vDevCommandSend(ucUsart, (u8*) ucDataCommand, ucLenCommand);
    }
}

/*-----------------------------------------------------------------*/
