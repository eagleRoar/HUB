/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-29   ZhouXiaomin     first version
 */
#ifndef _UUZ_DEV_CONFIG_H
#define _UUZ_DEV_CONFIG_H
/* Includes -------------------------------------------------------*/
#include <string.h>
/* ----------------------------------------------------------------*/
#include "typedefBASE.h"
#include "uuzOpt.h"
/* ----------------------------------------------------------------*/
#include "typedefLGT.h"
#include "typedefPROG.h"
#include "typedefSCH.h"
#include "typedefVALVE.h"
#include "uuzConfigDEV.h"
/* ----------------------------------------------------------------*/
extern ProgConfig_Typedef_t xProgConfig;  //运行程序数据日志
//extern Irr_Config_Typedef_t xIrrConfig;  //灌溉相关配置
extern Valve_Config_Typedef_t xValveConfig;  //端口配置信息
//extern Sch_Config_Typedef_t xSchConfig;  //Schedule周期表配置

#ifdef __cplusplus
extern "C" {
#endif

/* ---------------------------------------------------------------*/
/**
 * @brief 保存设备系统的相关配置
 */
void system_config_save(void);
/**
 * @brief 读取设备系统的相关配置
 */
void system_config_read(void);
/* ----------------------------------------------------------------*/

/**
 * @brief 保存设备(程序数据)的基本配置文件
 *
 */
void program_config_save(void);
/**
 * @brief 保存设备（1组程序数据）的基本配置文件
 * 
 * @param id 需要保存设备程序配置编号
 */
void prog_single_config_save(u8 id);
/**
 * @brief 保存蠕动泵重置相关数据 
 */
void program_cycle_config_save(void);
/**
 * @brief 保存设备(灌溉基本数据)的基本配置文件
 *
 */
void irr_config_save(void);

/**
 * @brief 保存设备(灯光设置数据)的基本配置文件
 *
 */
void lgt_custom_save(void);

/**
 * @brief 设备数据配置初始化
 * @param ucMask
 */
void device_config_init(u8 ucMask);
u8 ucIDtoVal(u16 usID, u16 ucType, u8 ucUart);
//u16 usValtoID(u8 ucType, u8 ucVal);
u16 usValtoID(u8 ucVal, u8 ucUart);

#ifdef __cplusplus
}
#endif
#endif // _UUZ_DEV_CONFIG_H
/*-----------------------------------------------------------------*/
