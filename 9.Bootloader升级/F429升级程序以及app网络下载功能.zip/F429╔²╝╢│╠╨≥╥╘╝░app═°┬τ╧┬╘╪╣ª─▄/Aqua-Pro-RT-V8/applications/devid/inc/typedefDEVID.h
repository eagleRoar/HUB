/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-03   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_DEV_ID_H
#define __TYPEDEF_DEV_ID_H
// include ------------------------------------------------
#include "typedefBASE.h"
#include "typedefINIT.h"
#include "uuzConfigDEV.h"
#include "uuzConfigUART.h"
// ------------------------------------------------
typedef struct devcmd_t
{

    u8 ucEnable;
    u8 ucUart;
    u8 ucData[uuzUART_LEN / 2];
    u8 ucLen;

} DevCmd_Typedef_t;
#define uuzDEVICE_CMD_MAX (24U)

#if 0
typedef struct devvalue_t   //端口实时数据
{
    //端口Power Broad板相关设备信息
    u32 count_brd;//设备板相关参数
    u32 state_brd[uuzDEV_BRD_MAX];
} DevValue_Typedef_t;
#endif

typedef struct devstats_t
{
    rt_mutex_t ids_mutex;
    //总设备数
    u16 usCountMax;
    //待注册数量标记
    u16 usCountWaitRegister;  //0x00~uuzDEV_WAIT_REG_MAX
    u16 usWaitRegisterTimeOut;  //注册指令延时发送命令
    DevID_Typedef_t xWaitRegisterID[uuzDEV_WAIT_REG_MAX];  //最多同时保存uuzDEV_WAIT_REG_MAX个重复设备

    //待发送命令
    //最大10x4个数据区
    u16 usCountU7;  //Sensor
    DevCmd_Typedef_t xDevCmd_U7[uuzDEVICE_CMD_MAX];
    u16 usCountU3;  //Board OR IO-Board
    DevCmd_Typedef_t xDevCmd_U3[uuzDEVICE_CMD_MAX];
    u16 usCountU2;  //Dosing
    DevCmd_Typedef_t xDevCmd_U2[uuzDEVICE_CMD_MAX];
    u16 usCountU8;  //Device OR AUX
    DevCmd_Typedef_t xDevCmd_U8[uuzDEVICE_CMD_MAX];

    //线路相关信息
    u16 usCountSR;  //传感器线路总数 (包含PHEC|SIN-P260
    u16 usCountDOS;  //设备线路总数(Dosing
    u16 usCountDEV;  //设备线路总数(Board|Dosing
    u16 usCountAUX;  //设备线路总数(Board|IO-Board|AC Station|AC 4 Station
    u16 usCountVALVE;  //Device Valve总数量(Board|IO-Board|AC Station|AC 4 Station

    //PHEC-B2相关设备信息
    u16 usCountB2;  //内部PHEC-B2设备数据
    DevID_Typedef_t xB2[uuzDEV_PHEC_B2_MAX];

    //水位传感器相关设备信息
    u16 usCountP260;  //水位传感器设备数据Sin-p260
    DevID_Typedef_t xP260[uuzDEV_SIN_P260_MAX];

    //端口Power Broad板相关设备信息
    u16 usCountBrd;  //设备板相关信息
    DevID_Typedef_t xBrd[uuzDEV_BRD_MAX];

    //IO 6 Station相关设备信息
    u16 usCountIO6;  //6路IO Station相关信息
    DevID_Typedef_t xIO6[uuzDEV_IO6_MAX];

    //IO 12 Station相关设备信息
    u16 usCountIO12;  //12路IO Station相关信息
    DevID_Typedef_t xIO12[uuzDEV_IO12_MAX];

    //端口蠕动泵（Dosing)板相关设备信息
    u16 usCountDos;  //设备板相关信息
    DevID_Typedef_t xDos[uuzDEV_DOS_MAX];

    //AC Station相关设备信息
    u16 usCountACS;  //单路AC Station设备相关信息
    DevID_Typedef_t xACS[uuzDEV_ACS_MAX];

    //AC Station 4相关设备信息
    u16 usCountACS4;  //4路AC Station 4相关信息
    DevID_Typedef_t xACS4[uuzDEV_ACS4_MAX];

    //灌溉相关的设备状态信息
    u16 usCountIRROUT;  //灌溉输出的端口相关信息
    IO_Typedef_t xIrrOUT[uuzDEV_IRR_OUT_MAX];
    u16 usCountIRRIN;  //灌溉进水的端口相关信息
    IO_Typedef_t xIrrIN[uuzDEV_IRR_IN_MAX];
    u16 usCountIRRDRAIN;  //灌溉回水的端口相关信息
    IO_Typedef_t xIrrDRAIN[uuzDEV_IRR_DRAIN_MAX];
    //灯光相关的设备状态信息
    u16 usCountLGT;  //灯光端口相关信息
    IO_Typedef_t xLGT[uuzDEV_LGT_MAX];

} DevStats_Typedef_t;

#endif // __TYPEDEF_DEV_ID_H
