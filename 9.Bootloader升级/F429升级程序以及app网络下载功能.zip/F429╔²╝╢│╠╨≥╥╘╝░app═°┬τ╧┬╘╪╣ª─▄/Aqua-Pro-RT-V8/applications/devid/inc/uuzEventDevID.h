/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-02   ZhouXiaomin     first version
 */
#ifndef __UUZ_DEV_ID_EVENT_H
#define __UUZ_DEV_ID_EVENT_H

#include "board.h"

#ifdef __cplusplus
extern "C" {
#endif

void uuz_vIDCheck(u8 ucUsart);
void uuz_vIDTipErr(u8 ucUsart, u8* ucTargetID);
void uuz_vIDRegErr(u8 ucUsart, u8* ucTargetID);
void uuz_vIDReply(u8 ucUsart, u8* ucTargetID, u8 ucSetID);

#if 0
void uuz_vIDTest(u8 ucUsart, u8* ucTargetID);
void uuz_vIDLocation(u8 ucUsart, DevID_Typedef_t *xDev);

void uuz_vDevStaCheck(void);
void cmd_read(u8 ucDevCount);
void uuz_vSensorReceiveFromUSART(u8* ucRxCode, u8 ucLen, u8* ucTxCode, u8 ucTarget);
void uuz_vStationDataRead(u8 ucDevCount);
void uuz_vStationReceiveFromUSART(u8* ucRxCode, u8 ucLen, u8* ucTxCode, u8 ucTarget);
void uuz_vLDA1DataRead(u8 ucDevCount);
void uuz_vLDAReceiveFromUSART(u8* ucRxCode, u8 ucLen, u8* ucTxCode, u8 ucTarget);
#endif

#ifdef __cplusplus
}
#endif
#endif // __UUZ_DEV_ID_EVENT_H
