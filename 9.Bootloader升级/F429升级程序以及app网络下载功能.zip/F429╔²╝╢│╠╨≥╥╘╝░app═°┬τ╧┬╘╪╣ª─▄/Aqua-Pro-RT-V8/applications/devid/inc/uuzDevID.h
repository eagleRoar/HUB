#ifndef __UUZ_DEV_ID_H
#define __UUZ_DEV_ID_H

#include "typedefDEVID.h"
#include "typedefBASE.h"

#ifdef __cplusplus
extern "C" {
#endif

extern DevID_Typedef_t xDevIDs[uuzDEV_MAX];
extern DevStats_Typedef_t xDevSTA;
#define uuzDEVID_LEN (uuzDEV_MAX * _DEV_LEN)    //ID数据总表长度
//默认参数
/**************************************************************/
//相关接口函数
void uuz_vCommandSendToUSART(u8 ucUsart, u8 ucCommand, u8 ucSta, u8* ucTargetID, u8 ucLen, u8* ucData);
void uuz_vDevCommandSend(u8 ucUsart, const u8* pucCommand, u8 ucLen);
//初始化设备ID
void device_single_init(DevID_Typedef_t * xDev);  //单个设备ID信息初始化
void device_map_init(u8 ucMask);
//初始化设备缓存设备
void device_map_state_init(void);
void device_aqua_id_init(void);
//写入单个设备信息
void device_id_single_to_eeprom(u8* xDev, u8 index);
void device_map_save(u8 lock);  //保存设备系统的相关配置
void device_map_read(u8 lock);  //读取设备系统的相关配置
//判断设备ID重复判断
u8 device_index_exist(DevID_Typedef_t * dev, u8 max, u8 id);  //根据缓存队列数据读取设备ID是否存在
void device_id_show(void);  //输出设备列表的LOG到调试区
u8 cpu_id_is_repeat(const u8* ucID);
u8 device_id_is_repeat(u8 ucModbusID, u8 ucUart);
u8 device_id_get(u8 ucModbusID, u8 ucUart);
u8 device_id_add(u8* ucID, u8 ucModbusID, u8 ucSubType, u8 ucUsart);
u8 device_wait_id_is_repeat(const u8* ucID);
void device_id_update(u8 ucType);
DevID_Typedef_t * device_id_list_check(u8 targetType, u8 targetIndex);
u8 id_is_exist(u8 ucHead, u8 ucUart);
//重置设备ID相关信息
void device_connect_reset(DevID_Typedef_t *dev);
u8 device_wait_flag_reset(u8 state);
//未注册待设备数据相关操作
//添加设备数据
u8 device_wait_id_add(u8* ucID, u8 ucModbusID, u8 ucSubType, u8 ucUsart);
//重置设备注册数据
void device_wait_state_reset(u8* ucID);
/**************************************************************/

#ifdef __cplusplus
}
#endif
#endif // __UUZ_DEV_ID_H
