/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-11-30   ZhouXiaomin     first version
 */
/* Includes ------------------------------------------------------------------*/
#include <string.h>
/* ----------------------------------------------------------------*/
#include "typedefINIT.h"
#include "uuzEEPROM.h"
#include "uuzOpt.h"
#include "uuzINIT.h"
/* ----------------------------------------------------------------*/
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
#include "uuzEventDevID.h"
#include "uuzEventBRD.h"
#include "uuzEventTEST.h"
/*log----------------------------------------------------------*/
#define DBG_TAG "id.dev"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/* ----------------------------------------------------------------*/
DevID_Typedef_t xDevIDs[uuzDEV_MAX];  //设备ID索引表
DevStats_Typedef_t xDevSTA;
//Device-Dosing
//Device-Power
//Device-PHEC-B2
//Device-SIN-P260
/* ----------------------------------------------------------------*/
/**
 * @brief 单个设备ID信息初始化
 * @param xDev
 */
void device_single_init(DevID_Typedef_t * xDev)
{
    xDev->en = uuzDEV_UNREG;  //初始化ID数据
    xDev->uart = uuzUART_6;
    xDev->count = uuzDEV_CONNECT_OK;
    xDev->isconnect = uuzDEV_NOCONNECT;
    xDev->id = uuzDEV_TEST;
    xDev->type = uuzDEV_SL_TEST;
    xDev->delay = 0;
    xDev->reg_en = 0;
    xDev->map = 0;
    xDev->cpuid[0] = 0;
    xDev->cpuid[1] = 0;
    xDev->cpuid[2] = 0;
    xDev->cpuid[3] = 0;
    xDev->cmd[0] = 0;
    xDev->cmd[1] = 0;
    xDev->cmd[2] = 0;
}
/**
 * @brief 设备ID列表初始化
 * @brief Initialize Device ID data
 * @param ucMask:0-读取EEPROM初始化；1-强制初始化
 */
void device_map_init(u8 ucMask)
{
    if (!ucMask) {
        device_map_read(1);  //从EERPOM读取Dev ID List相关数据
        LOG_D("Read Device ID Info Success");
    } else {
        rt_mutex_take(xDevSTA.ids_mutex, RT_WAITING_FOREVER);  //LOCK
        //初始化默认配置
        for (u16 index = 0; index < uuzDEV_MAX; index++) {
            device_single_init(&xDevIDs[index]);    //清空数据区内容
        }
        device_aqua_id_init();  //添加默认设备数据
        device_map_save(0);  //向EEPROM写入Device ID相关数据
        LOG_D("Reset Device ID Info Success");
        rt_mutex_release(xDevSTA.ids_mutex);  //UNLOCK
    }

    device_id_show();   //加载调试数据
    device_id_update(0);   //将保存的配置数据更新到数据缓存区
}

/**
 * @brief 初始化设备ID的标记数据
 */
void device_map_state_init(void)
{
    rt_memset(&xDevSTA, 0x00, sizeof(DevStats_Typedef_t));    //初始化设备缓存相关数据
    xDevSTA.ids_mutex = rt_mutex_create("idsmutex", RT_IPC_FLAG_FIFO);    //创建一个动态互斥量
    if (xDevSTA.ids_mutex == RT_NULL) {
        LOG_E("create ids mutex failed.");
    } else {
        LOG_D("create ids mutex success.");
    }
}

/**
 * @brief device_id_single_to_eeprom
 * @param xDev
 * @param index
 */
void device_id_single_to_eeprom(u8* xDev, u8 index)
{
    rt_mutex_take(xDevSTA.ids_mutex, RT_WAITING_FOREVER);
    config_to_eeprom(uuzEEPROM_ADDR_MAP + (index * _DEV_LEN), (u8*) xDev, _DEV_LEN);    //写入某个模块的相关数据Device ID
    rt_mutex_release(xDevSTA.ids_mutex);
}

/**
 * @brief 保存设备系统的相关配置
 * @param lock:是否操作上锁
 */
void device_map_save(u8 lock)
{
    if (lock) {
        rt_mutex_take(xDevSTA.ids_mutex, RT_WAITING_FOREVER);
    }
    config_to_eeprom(uuzEEPROM_ADDR_MAP, (u8*) &xDevIDs[0], uuzDEVID_LEN);    //保存相关数据到EEPROM
    rt_thread_mdelay(20);
    if (lock) {
        rt_mutex_release(xDevSTA.ids_mutex);
    }
}
/**
 * @brief 读取设备系统的相关配置
 */
void device_map_read(u8 lock)
{
    if (lock) {
        rt_mutex_take(xDevSTA.ids_mutex, RT_WAITING_FOREVER);
    }
    eeprom_to_config(uuzEEPROM_ADDR_MAP, (u8*) &xDevIDs[0], uuzDEVID_LEN);    //从EERPOM读取Device Info相关数据
    rt_thread_delay(20);
    if (lock) {
        rt_mutex_release(xDevSTA.ids_mutex);
    }
}

/**
 * @brief 设备ID（4组）盘判断是否重复
 * 
 * @param ucID 输入对比ID
 * @return u8 判断是否一致：一致：uuzFALSE, 不一致：uuzTRUE
 */
u8 cpu_id_is_repeat(const u8* ucID)
{
    u8 ucIsRepeat = 0xFFU;  //默认地址ID
    u8 index = 0;

    for (index = 0; index < uuzDEV_MAX; index++) {
        if (xDevIDs[index].en == uuzDEV_REG_OK) {  //判断是否有注册
            if (rt_memcmp(&xDevIDs[index].cpuid[0], ucID, 4) == 0) {  //判断设备ID列表已经有相关数据
                ucIsRepeat = index;  //返回不一致值
                break;
            }
        }
    }

    return ucIsRepeat;  //返回0xFF表示没有找到相关ID,返回正常值表示找到相关ID
}

/**
 * @brief Modbus-ID重复判断
 * 
 * @param ucModbusID 
 * @param ucUart 
 * @return u8 返回0xFF表示无重复数据，
 */
u8 device_id_is_repeat(u8 ucModbusID, u8 ucUart)
{
    u8 ucIsRepeat = 0xFFU;

    for (u8 index = 0; index < uuzDEV_MAX; index++) {
        //判断是否有注册
        if (xDevIDs[index].en == uuzDEV_REG_OK) {
            if (xDevIDs[index].uart == ucUart) {
                //如果有重复ID数据
                if (xDevIDs[index].id == ucModbusID) {
                    //该头ID已经存在
                    ucIsRepeat = index;
                    break;
                }
            }
        }
    }
    return ucIsRepeat;
}

/**
 * @brief 根据已有Modbus-ID,判断是否需要获取一个新的ModbusID
 * 
 * @param ucModbusID 当前旧ID
 * @param ucUart 需要获取的串口信息ID
 * @return u8 获取设备的ID。如果没有ID，提供一个新ID,如果有ID，则返回该ID
 */
u8 device_id_get(u8 ucModbusID, u8 ucUart)
{
    u8 ucIsRepeat = RT_FALSE;
    u8 ucSetID = 0xFFU;  //如果返回0xFFU的时候表示返回错误
    u8 index = 0;
    u8 ucReIndex = 0;
    u8 ucResetMax = 0;
    u8 ucReSetID[247];

    for (index = 0; index < uuzDEV_MAX; index++) {  //判断是否有注册
        if (xDevIDs[index].en == uuzDEV_REG_OK) {  //判断端口是否相同
            if (xDevIDs[index].uart == ucUart) {  //记录已经配置的相关ID
                ucReSetID[ucReIndex++] = xDevIDs[index].id;
                ucResetMax++;  //添加总数量
                if ((ucIsRepeat == RT_FALSE) && (xDevIDs[index].id == ucModbusID)) {
                    ucIsRepeat = RT_TRUE;  //该ID已经存在，需要提供一个新ID
                }
            }
        }
    }

    LOG_D("[%d]ResetID[%d]|uart[%d]input[%d]", ucIsRepeat, ucResetMax, ucUart, ucModbusID);
    if (ucIsRepeat == RT_TRUE) {  //该ID已经被注册，需要提供一个新ID
        for (index = 0; index < uuzDEV_MAX; index++) {  //预置一个待设置的ID
            ucSetID = uuzDEV_BASE_ID + index;  //和已经设置的数据进行判断
            for (ucReIndex = 0; ucReIndex < ucResetMax; ucReIndex++) {  //判断是否和已注册的iD重复
                if (ucSetID == ucReSetID[ucReIndex]) {  //如果有已注册的数据重复，跳到下一个待设置ID上
                    break;
                }
            }

            if (ucReIndex == ucResetMax) {  //如果检测到全部已注册ID都不一致，就将当前ID返回
                break;
            }
        }
    } else {
        ucSetID = ucModbusID;  //没有在已注册的数据里找到ID，把获取到的ID保存的数据区里
    }

    return ucSetID;  //返回0xFF表示没有找到相关ID,返回正常值表示找到相关ID
}

/**
 * 
 * @brief 判断ID是否已经有记录
 * @param ucHead
 * @param ucUart
 * @return
 */
u8 id_is_exist(u8 ucHead, u8 ucUart)
{
    for (u8 index = 0; index < uuzDEV_MAX; index++) {  //判断是否有注册
        if (xDevIDs[index].en == uuzDEV_REG_OK) {  //判断线路正确
            if (xDevIDs[index].uart == ucUart) {  //判断头MODBUS-ID
                if (xDevIDs[index].id == ucHead) {  //该头ID已经存在
                    return RT_TRUE;
                }
            }
        }
    }
    return RT_FALSE;
}

/**
 * @brief Aqua-Pro设备ID相关参数
 */
void device_aqua_id_init(void)
{
    LOG_D("Init Aqua-Pro default ID Info.");
    //Add PHEC-B2的相关设备
    u8 ucID[4] =
                { 0x01, 0x00, 0x00, 0x02 };
    //添加默认PHEC-B2设备信息
    device_id_add(ucID, (uuzDEV_BASE_ID), uuzDEV_SL_PHECB2, uuzUART_7);
    //Add Sin-P260的相关设备
    ucID[3]++;
    device_id_add(ucID, (uuzDEV_BASE_ID + uuzDEV_PHEC_B2_MAX), uuzDEV_SL_P260, uuzUART_7);
    ucID[3]++;
    device_id_add(ucID, (uuzDEV_BASE_ID + uuzDEV_PHEC_B2_MAX + 1), uuzDEV_SL_P260, uuzUART_7);

    //Add Dosing蠕动泵的相关设备 (Default ID:2/3/4/5/6/7/8/9)
    for (u8 index = 0; index < uuzDEV_DOS_MAX; index++) {
        ucID[3]++;
        device_id_add(ucID, (uuzDEV_ID_DOS + index), uuzDEV_SL_DOS, uuzUART_2);
    }

    //Add Power Broad的相关设备
    ucID[3]++;
    device_id_add(ucID, uuzDEV_ID_BRD, uuzDEV_SL_BRD, uuzUART_3);
}

/**
 * @brief 输出设备列表的LOG到调试区
 */
void device_id_show(void)
{
    u16 index = 0;

    DevID_Typedef_t * dev = &xDevIDs[0];    //初始化列表指针

    LOG_D("[NO]--[UART]--[ ID ]--[TYPE]--[  CPUID ]");
    while (index < uuzDEV_MAX) {
        if (dev->en == uuzDEV_REG_OK) {
            LOG_D("[%02d]--[%04d]--[%04d]--[%04d]--[%02X%02X%02X%02X]",
                    index, dev->uart, dev->id, dev->type,
                    dev->cpuid[0], dev->cpuid[1],
                    dev->cpuid[2], dev->cpuid[3]);
        }
        dev++;
        index++;
    }
    LOG_D("[-----------------END------------------]");
}

/**
 * @brief 根据缓存队列数据读取设备ID是否存在
 * @param dev 设备数据队列指针
 * @param max 该设备队列最大长度
 * @param id  设备MODBUS-ID
 * @return (0~max):返回队列中的相关数据| 没有数据uuzDEV_ID_TEST
 */
u8 device_index_exist(DevID_Typedef_t * dev, u8 max, u8 id)
{
    u8 index = 0;
    u8 result = uuzDEV_SL_TEST;

    while (index < max) {   //判断长度
        if (dev->en == uuzDEV_REG_OK) {  //判断是否注册成功
            if (dev->id == id) {    //有注册队列里是否有相关数据
                result = index;  //已经有数据了，更新队列位置
                break;
            }
        }
        dev++;
        index++;
    }

    return result;   //返回相关数据
}

/**
 * @brief 更新配置的设备ID到数据表
 * 
 * @param ucType 加载数据的类型:
 *               0-全部加载
 *               uuzDEV_SL_PHECB2-判断更新PHEC-B2个数数据
 *               uuzDEV_SL_P260-判断更新Sin-P260个数数据
 *               uuzDEV_SL_BROAD-判断更新电源Power Broad设备数据
 *               uuzDEV_SL_DOS-判断更新蠕动泵数量
 */
void device_id_update(u8 ucType)
{
    u16 usCountB2 = 0;  //外部其他的设备数据PHEC-B2
    u16 usCountP260 = 0;  //外部其他的设备数据Sin-p260
    u16 usCountDos = 0;  //蠕动泵数据
    u16 usCountBrd = 0;  //内部输出端口110V/220V/12V/24V
    u8 index = 0;

    for (index = 0; index < uuzDEV_MAX; index++) {
        if (xDevIDs[index].en == uuzDEV_REG_OK) {   //如果是已经注册的设备
            if ((ucType == 0) || (ucType == uuzDEV_SL_PHECB2)) {  //是全部刷新或者只刷新PHEC-B2
                if (xDevIDs[index].type == uuzDEV_SL_PHECB2) {  //设备类型是PHEC-B2传感器
                    if (usCountB2 < uuzDEV_PHEC_B2_MAX) {  //如果已经记录的PHEC-B2模块数量小于最大值
                        if ((xDevSTA.xB2[usCountB2].en == uuzDEV_UNREG)
                                || (xDevSTA.xB2[usCountB2].id != xDevIDs[index].id)) {  //保存相关记录到缓存配置
                            xDevIDs[index].map = usCountB2;  //添加ID数据位置
                            rt_memcpy(&xDevSTA.xB2[usCountB2], &xDevIDs[index], _DEV_LEN);  //将数据导入到处理区
                        }
                        usCountB2++;
                    }
                }
            }

            if ((ucType == 0) || (ucType == uuzDEV_SL_P260)) {  //是全部刷新或者只刷新SIN-P260模块
                if (xDevIDs[index].type == uuzDEV_SL_P260) {  //设备类型是SIN-P260传感器
                    if (usCountP260 < uuzDEV_SIN_P260_MAX) {  //如果SIN-P260模块数量小于最大值
                        if ((xDevSTA.xP260[usCountP260].en == uuzDEV_UNREG)                    //保存相关记录到缓存配置
                        || (xDevSTA.xP260[usCountP260].id != xDevIDs[index].id)) {
                            xDevIDs[index].map = usCountP260;  //添加ID数据位置
                            rt_memcpy(&xDevSTA.xP260[usCountP260], &xDevIDs[index], _DEV_LEN);             //将数据导入到处理区
                        }
                        usCountP260++;
                    }
                }
            }

            if ((ucType == 0) || (ucType == uuzDEV_SL_BRD)) {             //是全部刷新或者只刷新POWER-Broad模块
                if (xDevIDs[index].type == uuzDEV_SL_BRD) {             //设备类型是Power Broad
                    if (usCountBrd < uuzDEV_BRD_MAX) {             //如果Power Broad模块数量小于最大值
                        if ((xDevSTA.xBrd[usCountBrd].en == uuzDEV_UNREG)
                                || (xDevSTA.xBrd[usCountBrd].id != xDevIDs[index].id)) {             //保存相关记录到缓存配置
                            xDevIDs[index].map = usCountBrd;  //添加ID数据位置
                            rt_memcpy(&xDevSTA.xBrd[usCountBrd], &xDevIDs[index], _DEV_LEN);             //将数据导入到处理区
                        }
                        usCountBrd++;
                    }
                }
            }

            if ((ucType == 0) || (ucType == uuzDEV_SL_DOS)) {             //是全部刷新或者只刷新蠕动泵(Dosing)数量模块
                if (xDevIDs[index].type == uuzDEV_SL_DOS) {             //设备类型是蠕动泵(Dosing)
                    if (usCountDos < uuzDEV_DOS_MAX) {             //如果蠕动泵(Dosing)模块数量小于最大值
                        if ((xDevSTA.xDos[usCountDos].en == uuzDEV_UNREG)
                                || (xDevSTA.xDos[usCountDos].id != xDevIDs[index].id)) {             //保存相关记录到缓存配置
                            xDevIDs[index].map = usCountDos;  //添加ID数据位置
                            rt_memcpy(&xDevSTA.xDos[usCountDos], &xDevIDs[index], _DEV_LEN);             //将数据导入到处理区
                        }
                        usCountDos++;
                    }
                }
            }
        }
    }

    //刷新实时信息
    switch (ucType) {
        case 0:
            //全部刷新数据
            //PHEC-B2设备
            for (index = usCountB2; index < uuzDEV_PHEC_B2_MAX; index++) {
                xDevSTA.xB2[index].en = uuzDEV_UNREG;
            }
            //更新设备实时数据
            xDevSTA.usCountB2 = usCountB2;
            //SIN-P260设备
            for (index = usCountP260; index < uuzDEV_SIN_P260_MAX; index++) {
                xDevSTA.xP260[index].en = uuzDEV_UNREG;
            }
            //更新设备实时数据
            xDevSTA.usCountP260 = usCountP260;
            //Power Broad模块
            for (index = usCountBrd; index < uuzDEV_BRD_MAX; index++) {
                xDevSTA.xBrd[index].en = uuzDEV_UNREG;
            }
            //更新设备实时数据
            xDevSTA.usCountBrd = usCountBrd;
            //蠕动泵(Dosing)模块
            for (index = usCountDos; index < uuzDEV_DOS_MAX; index++) {
                xDevSTA.xDos[index].en = uuzDEV_UNREG;
            }
            //更新设备实时数据
            xDevSTA.usCountDos = usCountDos;
            break;
        case uuzDEV_SL_PHECB2:
            //PHEC-B2设备
            for (index = usCountB2; index < uuzDEV_PHEC_B2_MAX; index++) {
                xDevSTA.xB2[index].en = uuzDEV_UNREG;
            }
            //更新设备实时数据
            xDevSTA.usCountB2 = usCountB2;
            break;
        case uuzDEV_SL_P260:
            //SIN-P260设备
            for (index = usCountP260; index < uuzDEV_SIN_P260_MAX; index++) {
                xDevSTA.xP260[index].en = uuzDEV_UNREG;
            }
            //更新设备实时数据
            xDevSTA.usCountP260 = usCountP260;
            break;
        case uuzDEV_SL_BRD:
            //Power Broad模块
            for (index = usCountBrd; index < uuzDEV_BRD_MAX; index++) {
                xDevSTA.xBrd[index].en = uuzDEV_UNREG;
            }
            //更新设备实时数据
            xDevSTA.usCountBrd = usCountBrd;
            break;
        case uuzDEV_SL_DOS:
            //蠕动泵(Dosing)模块
            for (index = usCountDos; index < uuzDEV_DOS_MAX; index++) {
                xDevSTA.xDos[index].en = uuzDEV_UNREG;
            }
            //更新设备实时数据
            xDevSTA.usCountDos = usCountDos;
            //LOG_D("STA[%d]--usCountDos[%d]",xDevSTA.usCountDos, usCountDos);
            break;
        default:
            break;
    }

    //计算各个线路的模块数据
    xDevSTA.usCountSR = xDevSTA.usCountB2 + xDevSTA.usCountP260;
    xDevSTA.usCountDOS = xDevSTA.usCountDos;
    xDevSTA.usCountDEV = xDevSTA.usCountDos + xDevSTA.usCountBrd;
    xDevSTA.usCountAUX = xDevSTA.usCountBrd;
#if 0
    //计算可以使用的端口数据
    xDevSTA.usCountVALVE = xDevSTA.usCountBrd * uuzDEV_BRD_VALVE_MAX
            + xDevSTA.usCountIO12 * 12
            + xDevSTA.usCountIO6 * 6
            + xDevSTA.usCountACS
            + xDevSTA.usCountACS4;

    value_cache_init();//更新端口相关数据
#endif
}

/**
 * @brief 根据位置获取相关数据
 * @param targetType 需要获取的数据类型
 * @param targetIndex 需要获取的列表位置
 * @return 返回查找到的数据内容
 */
DevID_Typedef_t * device_id_list_check(u8 targetType, u8 targetIndex)
{
    u8 index = 0;
    u16 count = 0;

    DevID_Typedef_t * dev = RT_NULL;    //待返回数据

    if (targetType == 0) {    //检查AUX设备列表的相关数据
        if (targetIndex < xDevSTA.usCountAUX) {
            for (index = 0; index < uuzDEV_BRD_MAX; index++) {
                if (xDevSTA.xBrd[index].en == uuzDEV_REG_OK) {
                    if (count == targetIndex) {  //到达目标数据位
                        return &xDevSTA.xBrd[index];
                    }
                    count++;    //有有效数据才进位
                }
            }
            for (index = 0; index < uuzDEV_IO6_MAX; index++) {
                if (xDevSTA.xIO6[index].en == uuzDEV_REG_OK) {
                    if (count == targetIndex) {  //到达目标数据位
                        return &xDevSTA.xIO6[index];
                    }
                    count++;    //有有效数据才进位
                }
            }
            for (index = 0; index < uuzDEV_IO12_MAX; index++) {
                if (xDevSTA.xIO12[index].en == uuzDEV_REG_OK) {
                    if (count == targetIndex) {  //到达目标数据位
                        return &xDevSTA.xIO12[index];
                    }
                    count++;    //有有效数据才进位
                }
            }
            for (index = 0; index < uuzDEV_ACS_MAX; index++) {
                if (xDevSTA.xACS[index].en == uuzDEV_REG_OK) {
                    if (count == targetIndex) {  //到达目标数据位
                        return &xDevSTA.xACS[index];
                    }
                    count++;    //有有效数据才进位
                }
            }
            for (index = 0; index < uuzDEV_ACS4_MAX; index++) {
                if (xDevSTA.xACS4[index].en == uuzDEV_REG_OK) {
                    if (count == targetIndex) {  //到达目标数据位
                        return &xDevSTA.xACS4[index];
                    }
                    count++;    //有有效数据才进位
                }
            }
        }
    }

    return dev;
}

/**
 * @brief 重置设备状态标记
 * @param dev 设备信息地址
 */
void device_connect_reset(DevID_Typedef_t* dev)
{
    //刷新设备状态
    dev->count = uuzDEV_CONNECT_OK;
    dev->isconnect = uuzDEV_CONNECTED;
}

/**
 * @brief 给新设备添加一个新ID
 * 
 * @param ucUart 输入需要设置的设备连接的UART端口号
 * @param ucModbusID 设备输入的Modbus-ID
 * @return u8  
 */
u8 device_new_id_get(u8 ucUart)
{
    u8 ucIsRepeat = 0xFFU;

    //ID的有效范围(0x10 --- 0xF6)
    //检查是否存在注册或者待注册数据,且检查Modbus-ID数据是否重复
    for (u8 index = 0; index < uuzDEV_MAX; ++index) {
        //记录一个空闲设备位
        if (xDevIDs[index].en == uuzDEV_UNREG) {
            //预存空闲设备ID
            ucIsRepeat = index + uuzDEV_BASE_ID;
            break;
        }
    }

    return ucIsRepeat;
}

/**
 * @brief 将数据添加注册区
 * 
 * @param ucID 待添加设备ID
 * @param ucModbusID  设备Modbus-ID
 * @param ucSubType  子设备类型
 * @param ucUsart 串口编号
 * @return u8 完成状态 Success: RT_TRUE| False: RT_FALSE
 */
u8 device_id_add(u8* ucID, u8 ucModbusID, u8 ucSubType, u8 ucUsart)
{
    u8 ucResult = RT_FALSE;  //添加成功或者失败
    u8 ucResultID = 0xFFU;

    if (cpu_id_is_repeat(ucID) == 0xFFU) {  //设备CPU-ID是否重复
        //NOTE:没有重复数据，添加相关数据
        ucResultID = device_id_is_repeat(ucModbusID, ucUsart);        //获取相关数据

        if (ucResultID == 0xFFU) {        //表示该通道没有相关设备，可以添加
            for (u8 index = 0; index < uuzDEV_MAX; index++) {
                if (xDevIDs[index].en != uuzDEV_REG_OK) {
                    //缓存待注册相关数据
                    xDevIDs[index].en = uuzDEV_REG_OK;
                    xDevIDs[index].uart = ucUsart;
                    xDevIDs[index].count = uuzDEV_CONNECT_OK;
                    xDevIDs[index].isconnect = uuzDEV_CONNECTED;
                    xDevIDs[index].id = ucModbusID;
                    xDevIDs[index].type = ucSubType;
                    xDevIDs[index].delay = 0;
                    xDevIDs[index].reg_en = 0;
                    xDevIDs[index].map = 0;
                    rt_memcpy(&xDevIDs[index].cpuid[0], ucID, 4);
                    rt_memset(&xDevIDs[index].cmd[0], 0x00U, 3);
                    ucResult = index;        //添加待注册数据
                    //LOG_D("List data to prepare the registered area[%d]", index);
                    break;
                }
            }
        } else {
            //NOTE:该通道有相关数据，不重复添加相关数据
            LOG_D("Have Modbus-ID:%d", ucResultID);                    //显示已经存在的ID
        }
    } else {
        //NOTE:有重复数据，不添加相关数据
        LOG_E("Have ID[%d]", cpu_id_is_repeat(ucID));                    //该设备ID已经存在
    }

    return ucResult;
}

/**
 * @brief 判断等待注册ID是否有重复数据
 *
 * @param ucID
 * @return u8
 */
u8 device_wait_id_is_repeat(const u8* ucID)
{
    u8 ucIsRepeat = 0xFFU;  //默认地址ID
    u8 index = 0;

    //表示在设备列表没有找到相关数据，去待注册区进行查找
    if (xDevSTA.usCountWaitRegister) {  //有待注册数据
        for (index = 0; index < uuzDEV_WAIT_REG_MAX; index++) {
            //判断待注册数据状态
            if ((xDevSTA.xWaitRegisterID[index].en == uuzDEV_REG_NOT)
                    || (xDevSTA.xWaitRegisterID[index].en == uuzDEV_REG_WAIT)) {
                if (rt_memcmp(&xDevSTA.xWaitRegisterID[index].cpuid[0], ucID, 4) == 0) {
                    ucIsRepeat = index;    //判断待注册设备ID列表已经有相关数据,返回不一致值
                    break;
                }
            }
        }
    }
    return ucIsRepeat;    //返回0xFF表示没有找到相关ID,返回正常值表示找到相关ID
}

/**
 * @brief 将数据添加到待注册区
 * 
 * @param ucID 待注册设备ID
 * @param ucModbusID  设备Modbus-ID
 * @param ucSubType  子设备类型
 * @param ucUsart 串口编号
 * @return u8 完成状态 Success: RT_TRUE| False: RT_FALSE
 */
u8 device_wait_id_add(u8* ucID, u8 ucModbusID, u8 ucSubType, u8 ucUsart)
{
    u8 ucResult = RT_FALSE;  //添加成功或者失败

    if (xDevSTA.usCountWaitRegister < uuzDEV_WAIT_REG_MAX) {    //待测试注册区未满
        for (u8 index = 0; index < uuzDEV_WAIT_REG_MAX; index++) {  //直接添加数据到待注册区
            if (xDevSTA.xWaitRegisterID[index].en == uuzDEV_UNREG) {  //查找一个未注册的区域位
                xDevSTA.xWaitRegisterID[index].en = uuzDEV_REG_NOT;  //缓存待注册相关数据
                xDevSTA.xWaitRegisterID[index].uart = ucUsart;
                xDevSTA.xWaitRegisterID[index].count = uuzDEV_CONNECT_OK;
                xDevSTA.xWaitRegisterID[index].isconnect = uuzDEV_CONNECTED;
                xDevSTA.xWaitRegisterID[index].id = ucModbusID;
                xDevSTA.xWaitRegisterID[index].type = ucSubType;
                xDevSTA.xWaitRegisterID[index].delay = 0;
                xDevSTA.xWaitRegisterID[index].reg_en = 0;
                xDevSTA.xWaitRegisterID[index].map = 0;
                rt_memcpy(&xDevSTA.xWaitRegisterID[index].cpuid[0], ucID, 4);
                rt_memset(&xDevSTA.xWaitRegisterID[index].cmd[0], 0x00U, 3);

                xDevSTA.usCountWaitRegister++;  //添加待注册数据
                ucResult = RT_TRUE;
                LOG_D("Cache data to prepare the registered area[%d]", index);
                break;
            }
        }
    } else {
        uuz_vIDRegErr(ucUsart, ucID);  //发送错误提示信息
        LOG_E("The unregistered area is full.");
    }

    return ucResult;
}

/**
 * @brief 重置等待状态标记
 * @param state 原等待状态
 * @return
 */
u8 device_wait_flag_reset(u8 state)
{
    //刷新设备状态
    return (state == uuzDEV_REG_WAIT) ? (uuzDEV_REG_NOT) : (state);
}

/**
 * @brief 将已处理的注册数据状态重置
 * @param ucID
 */
void device_wait_state_reset(u8* ucID)
{
    if (xDevSTA.usCountWaitRegister) {  //有待注册数据
        for (u8 index = 0; index < uuzDEV_WAIT_REG_MAX; ++index) {
            //如果已经发送了注册消息未确认，则重新进入发送确认状态
            if (rt_memcmp(ucID, &xDevSTA.xWaitRegisterID[index].cpuid[0], 4) == 0) {
                if (xDevSTA.xWaitRegisterID[index].en == uuzDEV_REG_WAIT) {
                    xDevSTA.xWaitRegisterID[index].en = uuzDEV_REG_NOT;
                    break;
                }
            }
        }
    }
}

/*-----------------------------------------------------------------*/
