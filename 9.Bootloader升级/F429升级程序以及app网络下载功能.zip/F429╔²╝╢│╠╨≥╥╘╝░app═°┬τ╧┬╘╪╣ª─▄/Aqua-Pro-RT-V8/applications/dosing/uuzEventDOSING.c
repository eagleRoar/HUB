/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
/*include*****************************************************************************/
#include <math.h>
#include <string.h>
/******************************************************************************/
#include "uuzEVENT.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzRTC.h"
/******************************************************************************/
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
/******************************************************************************/
#include "typedefDEVID.h"
#include "typedefDOSING.h"
#include "typedefINIT.h"
#include "uuzConfigDEV.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
/******************************************************************************/
#include "uuzEventDOSING.h"
#include "uuzEventSR.h"
/*log---------------------------------------------*/
#define DBG_TAG "e.dos"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/******************************************************************************/
Dosing_State_Typedef_t xDosingState[uuzDEV_DOS_MAX];
Dosing_Config_Typedef_t * xDosCFG;
/******************************************************************************/
/**
 * @brief 蠕动泵的通讯协议
 */
MODBUS_RTU_CODE dosing_opt_code[5] =
            {
                        { _CODE_R, 0x0000U, 0x0001U },  //Dosing Device is Connected
                        { _CODE_R, 0x0000U, 0x0009U },  //蠕动泵相关状态
                        { _CODE_W, 0x000AU, 0x0001U },  //Start/Stop Dosing
                        { _CODE_RW, 0x000BU, 0x0005U },  //设置工作比例（0--100%）/ 模式(CF/VF)/流量/开启时间/等待时间
                        { _CODE_RW, 0x0010U, 0x0001U }  //清除转圈计数（0：无动作/1：清零）
            };
/******************************************************************************/

/**
 * @brief 初始化蠕动泵基本状态
 */
void dosing_state_init(void)
{
    for (u8 index = 0; index < uuzDEV_DOS_MAX; index++) {
        rt_memset(&xDosingState[index], 0x00U, sizeof(Dosing_State_Typedef_t));
    }
}

/**
 * @brief 设置Dosing蠕动泵的初始相关数据
 * 
 * @param xConfig Dosing的指针地址
 */
void dosing_single_config_init(Dosing_Config_Typedef_t* xConfig)
{
    //添加相关设置
    xConfig->mode = 0;  //CF(定频)
    xConfig->speed = 200;  //200ml/min
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
    xConfig->running = 65535;  //持续运行(65535 sec)
    xConfig->waiting = 0;  //不停止工作(0 sec)
#else
    xConfig->running = 10;  //10s
    xConfig->waiting = 30;  //30s
#endif

#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
    xConfig->ver = _DEV_INNOVATION_ONLY;
#elif (uuzDEVICE_TYPE == _DEV_INNOVATION)
    xConfig->ver = _DEV_INNOVATION;
#else
    xConfig->ver = _DEV_BBL;
#endif

    xConfig->end = 0xBBBBU;

    dosing_cycle_reset_time();  //重置RTC时间
}

#if 0
/**
 * @brief 设置Dosing蠕动泵的持续运行相关数据
 *
 * @param xConfig Dosing的指针地址
 */
void dosing_long_config_init(Dosing_Config_Typedef_t* xConfig)
{
    //添加相关设置
    xConfig->mode = 0;  //CF(定频)
    xConfig->speed = xDosCFG->speed;  //200ml/min
    xConfig->running = 65535;  //持续运行
    xConfig->waiting = 0;  //不停止工作
}
#endif

/**
 *
 * @brief 设置单个Dosing蠕动泵的初始相关数据
 *
 * @param xValve:需要设置的蠕动泵起始位数据
 */
void dosing_valve_init(Dosing_Single_Typedef_t* xValve)
{
    //添加相关设置EC-1/2/3/4
    for (u8 index = 0; index < uuzDEV_DOS_MAX; index++) {
        dosing_valve_set(xValve, 1, 100, _DOS_T_EC);
        xValve++;  //移动到下一个数据位
    }
}

/**
 *
 * @brief 设置单个Dosing蠕动泵的数据
 *
 * @param xValve:需要设置的蠕动泵数据
 * @param en:0-无效/1-有效
 * @param ratio:10~100%
 * @param type:0-NONE/1-EC/2-pH+/3-pH-
 */
void dosing_valve_set(Dosing_Single_Typedef_t* xValve, u8 en, u8 ratio, u8 type)
{
    //添加相关设置
    xValve->en = en;
    xValve->ratio = ratio;
    xValve->type = type;
}

/**
 * @brief 初始蠕动圈数设置
 */
void dosing_cycle_group_reset(void)
{
    for (u8 index = 0; index < uuzDEV_DOS_MAX; index++) {
        dosing_cycle_reset(index);
    }
}

/**
 * @brief 蠕动泵循环时间重置
 */
void dosing_cycle_reset_time(void)
{
    //重置蠕动泵的计数清零的时间
    xDosCFG->rtc[0] = rTm.tm_year + 1900;
    xDosCFG->rtc[1] = rTm.tm_mon + 1;
    xDosCFG->rtc[2] = rTm.tm_mday;
    xDosCFG->rtc[3] = rTm.tm_hour;
    xDosCFG->rtc[4] = rTm.tm_min;
    xDosCFG->rtc[5] = rTm.tm_sec;
}

/**
 * @brief 按类型开启蠕动泵
 *
 * @param prog:当前运行的程序数据指针
 * @param type:需要控制的类型 1-EC/2-pH+/3-pH-
 * @param state:运行状态 0-OFF/1-ON
 */
void dosing_opt_group(Dynamic_Single_Typedef_t* prog, ENUM_DOS_TYPE type, u8 state)
{
    //判断数据有效
    if (prog != NULL) {                //执行EC相关参数
        for (u8 index = 0; index < uuzDEV_DOS_MAX; index++) {                //蠕动泵数据读取
            if (prog->dos[index].en == 1) {  //蠕动泵有效
                LOG_D("OPT[%d]-dosing[%d]-sta[%d]", type, index, state);
                if (type == prog->dos[index].type) {  //判断蠕动泵工作类型
                    dosing_opt(index, state);  //执行蠕动泵开启或关闭
                    rt_thread_mdelay(50);
                }
            } else {
                if (state == uuzOPT_ON) {
                    dosing_opt(index, uuzOPT_OFF);  //蠕动泵无效，执行蠕动泵关闭
                    rt_thread_mdelay(50);
                }
            }
        }
    }
}

/**
 * @brief 关闭全部蠕动泵
 */
void dosing_all_close(void)
{
    //判断数据有效
    for (u8 index = 0; index < xSysCFG.dosing_num; index++) {                //蠕动泵数据读取
        if (xDosingState[index].state == uuzOPT_ON) {
            dosing_opt(index, uuzOPT_OFF);  //蠕动泵无效，执行蠕动泵关闭
            rt_thread_mdelay(50);
        }
    }
}

/**
 *
 * @brief 读取蠕动泵配置，并判断是否一致
 * @param xState 读取的状态数据
 * @param xConfig 保存的配置数据
 * @return 判断是否有不一致数据。如果有不一致数据，返回1
 */
u8 dosing_config_is_same(Dosing_State_Typedef_t* xState,
        Dosing_Config_Typedef_t* xConfig)
{
    //判断是否有不一致数据。如果有不一致数据，返回1
    return ((xState->mode != xConfig->mode)
            || (xState->running != xConfig->running)
            || (xState->waiting != xConfig->waiting)
            || (xState->speed != xConfig->speed))
           ? (1U)
             :
             (0U);
}

static u32 sync_cycle = 0;
/**
 * @brief 读取Dosing的实时数据
 *
 * @param id
 */
void dosing_state_read(u8 id)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Device ID
    ucDataCommand[ucLenCommand++] = xDevSTA.xDos[id].id;
    ucDataCommand[ucLenCommand++] = uuzMBR_READ_HOLDING_REGISTER;
    vU16ToU8(ucDataCommand + ucLenCommand, dosing_opt_code[1].code, uuzMSB);
    ucLenCommand += 2U;
    //连续读取3组数据
    if (sync_cycle % 10 == 0) {
        vU16ToU8(ucDataCommand + ucLenCommand, dosing_opt_code[1].n, uuzMSB);
    } else {
        vU16ToU8(ucDataCommand + ucLenCommand, 1, uuzMSB);
    }
    ucLenCommand += 2U;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;

    cmd_set(xDevSTA.xDos[id].uart, (u8*) ucDataCommand, ucLenCommand);

    //N次读取无数据，将连接状态切断
    if (xDevSTA.xDos[id].count < uuzDEV_CONNECT_ERR) {
        xDevSTA.xDos[id].count++;  //连接计数
    }

    if (id == 0) {
        sync_cycle++;
        if (sync_cycle >= 10000) {
            sync_cycle = 0;
        }
    }
}

/**
 * @brief Dosing设备实时数据处理
 *
 * @param id 需要处理的设备相对数据地址
 * @param data 需要处理的设备实时数据
 */
void dosing_state_resolve(u8 id, u8* data)
{
    u16 ucLenCommand = 3;
    u8 ucRecvLenCommand = 1;

    if (data != NULL) {
        ucRecvLenCommand = data[2];
        u16 tmpState = usU8ToU16(data + ucLenCommand, uuzMSB);
        u8 is_need_update = 0;
        u8 is_need_update_dosing = 0;

        u16 recv_data = 0;
        //如果接收数据和缓存数据不一致
        if (tmpState != xDosingState[id].state) {
            is_need_update = 1;
        }
        //加载相关设备数据
        xDosingState[id].state = tmpState;
        ucLenCommand += 2;

        if (ucRecvLenCommand == 0x12U) {    //多数据同步处理
            xDosingState[id].ratio = usU8ToU16(data + ucLenCommand, uuzMSB);
            ucLenCommand += 2;
            xDosingState[id].mode = usU8ToU16(data + ucLenCommand, uuzMSB);
            ucLenCommand += 2;
            recv_data = usU8ToU16(data + ucLenCommand, uuzMSB);
            if (recv_data != xDosCFG->speed) {
                xDosingState[id].speed = xDosCFG->speed;
                is_need_update_dosing = 1;
            } else {
                xDosingState[id].speed = usU8ToU16(data + ucLenCommand, uuzMSB);
            }
            ucLenCommand += 2;
            recv_data = usU8ToU16(data + ucLenCommand, uuzMSB);
            if (recv_data != xDosCFG->running) {
                xDosingState[id].running = xDosCFG->running;
                is_need_update_dosing = 1;
            } else {
                xDosingState[id].running = usU8ToU16(data + ucLenCommand, uuzMSB);
            }
            ucLenCommand += 2;
            recv_data = usU8ToU16(data + ucLenCommand, uuzMSB);
            if (recv_data != xDosCFG->waiting) {
                xDosingState[id].waiting = xDosCFG->waiting;
                is_need_update_dosing = 1;
            } else {
                xDosingState[id].waiting = usU8ToU16(data + ucLenCommand, uuzMSB);
            }
            ucLenCommand += 2;
            xDosingState[id].laps[0] = usU8ToU16(data + ucLenCommand, uuzMSB);
            ucLenCommand += 2;
            xDosingState[id].laps[1] = usU8ToU16(data + ucLenCommand, uuzMSB);
            ucLenCommand += 2;
            xDosingState[id].motor = usU8ToU16(data + ucLenCommand, uuzMSB);
        }

        if (is_need_update_dosing) {
            dosing_config_set(id, xDosingState[id].ratio, xDosCFG);  //发送相关数据
        }

        //需要更新数据发送相关信号
        if (is_need_update == 1) {
            rt_event_send(eventDATA, UI_DATA_SYNC);
        }
    }
}

/**
 * @brief Dosing设备操作数据处理
 *
 * @param id 需要处理的设备相对数据地址
 * @param data 需要处理的设备实时数据
 */
void dosing_state_replay(u8 id, u8* data)
{
    u16 ucLenCommand = 4;

    if (data != NULL) {
        u16 tmpState = usU8ToU16(data + ucLenCommand, uuzMSB);
        u8 is_need_update = 0;
        //如果接收数据和缓存数据不一致
        if (tmpState != xDosingState[id].state) {
            is_need_update = 1;
        }
        xDosingState[id].state = tmpState;
        //需要更新数据发送相关信号
        if (is_need_update == 1) {
            rt_event_send(eventDATA, UI_DATA_SYNC);
        }
    }
}

/**
 * @brief Dosing设备操作数据处理
 *
 * @param id 需要处理的设备相对数据地址
 * @param data 需要处理的设备实时数据
 */
void dosing_ratio_replay(u8 id, u8* data)
{
    u16 ucLenCommand = 4;

    if (data != NULL) {
        u16 tmpRatio = usU8ToU16(data + ucLenCommand, uuzMSB);
        u8 is_need_update = 0;
        //如果接收数据和缓存数据不一致
        if (tmpRatio != xDosingState[id].ratio) {
            is_need_update = 1;
        }
        xDosingState[id].ratio = tmpRatio;
        //需要更新数据发送相关信号
        if (is_need_update == 1) {
            rt_event_send(eventDATA, UI_DATA_SYNC);
        }
    }
}

/**
 * @brief 发送蠕动泵启动命令
 * @param id:需要执行的蠕动泵
 * @param sta:0-OFF/1-ON
 */
void dosing_opt(u8 id, u16 sta)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Device ID
    ucDataCommand[ucLenCommand++] = xDevSTA.xDos[id].id;
    ucDataCommand[ucLenCommand++] = uuzMBR_WRITE_REGISTER;
    vU16ToU8(ucDataCommand + ucLenCommand, dosing_opt_code[2].code, uuzMSB);
    ucLenCommand += 2U;
    //0-OFF/1-ON
    vU16ToU8(ucDataCommand + ucLenCommand, sta, uuzMSB);
    ucLenCommand += 2U;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;

    cmd_set(xDevSTA.xDos[id].uart, (u8*) ucDataCommand, ucLenCommand);

    //N次读取无数据，将连接状态切断
    if (xDevSTA.xDos[id].count < uuzDEV_CONNECT_ERR) {
        xDevSTA.xDos[id].count++;  //连接计数
    }
}

/**
 * @brief 发送蠕动泵圈数清零
 * @param id:需要执行的蠕动泵
 */
void dosing_cycle_reset(u8 id)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Device ID
    ucDataCommand[ucLenCommand++] = xDevSTA.xDos[id].id;
    ucDataCommand[ucLenCommand++] = uuzMBR_WRITE_REGISTER;
    vU16ToU8(ucDataCommand + ucLenCommand, dosing_opt_code[4].code, uuzMSB);
    ucLenCommand += 2U;
    //0:无动作-1:清零
    vU16ToU8(ucDataCommand + ucLenCommand, 1, uuzMSB);
    ucLenCommand += 2U;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;

    cmd_set(xDevSTA.xDos[id].uart, (u8*) ucDataCommand, ucLenCommand);

    //N次读取无数据，将连接状态切断
    if (xDevSTA.xDos[id].count < uuzDEV_CONNECT_ERR) {
        xDevSTA.xDos[id].count++;  //连接计数
    }
}

/**
 * @brief 向蠕动泵发送配置数据
 * @param index 需要设置的蠕动泵指针
 * @param ratio 蠕动泵开关百分比(10%~100%)
 * @param config 蠕动泵的配置数据指针
 */
void dosing_config_set(u8 index, u16 ratio, Dosing_Config_Typedef_t* config)
{
    u8 ucDataCommand[32];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Device ID
    ucDataCommand[ucLenCommand++] = xDevSTA.xDos[index].id;
    ucDataCommand[ucLenCommand++] = uuzMBR_WRITE_MULTIPLE_REGISTERS;
    //Address
    vU16ToU8(ucDataCommand + ucLenCommand, dosing_opt_code[3].code, uuzMSB);
    ucLenCommand += 2U;
    //Number
    vU16ToU8(ucDataCommand + ucLenCommand, dosing_opt_code[3].n, uuzMSB);
    ucLenCommand += 2U;
    ucDataCommand[ucLenCommand++] = dosing_opt_code[3].n * sizeof(u16);
    //Data
    vU16ToU8(ucDataCommand + ucLenCommand, ratio, uuzMSB);
    ucLenCommand += 2U;
    //模式
    vU16ToU8(ucDataCommand + ucLenCommand, config->mode, uuzMSB);
    ucLenCommand += 2U;
    //速度
    if (config->mode == 0) {
        vU16ToU8(ucDataCommand + ucLenCommand, config->speed, uuzMSB);
    } else {
        vU16ToU8(ucDataCommand + ucLenCommand, uuzDOS_SPEED_MAX, uuzMSB);
    }
    ucLenCommand += 2U;
    //开时间
    vU16ToU8(ucDataCommand + ucLenCommand, config->running, uuzMSB);
    ucLenCommand += 2U;
    //关时间
    vU16ToU8(ucDataCommand + ucLenCommand, config->waiting, uuzMSB);
    ucLenCommand += 2U;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;

    cmd_set(xDevSTA.xDos[index].uart, (u8*) ucDataCommand, ucLenCommand);

    //N次读取无数据，将连接状态切断
    if (xDevSTA.xDos[index].count < uuzDEV_CONNECT_ERR) {
        xDevSTA.xDos[index].count++;  //连接计数
    }
}

/**
 * @brief 修改配肥比例
 * @param index
 * @param ratio
 */
void dosing_ratio_set(u8 index, u16 ratio)
{
    u8 ucDataCommand[20];
    u8 ucLenCommand = 0;
    u16 usCrcModbus = 0;

    //Device ID
    ucDataCommand[ucLenCommand++] = xDevSTA.xDos[index].id;
    ucDataCommand[ucLenCommand++] = uuzMBR_WRITE_REGISTER;
    vU16ToU8(ucDataCommand + ucLenCommand, dosing_opt_code[3].code, uuzMSB);
    ucLenCommand += 2U;
    vU16ToU8(ucDataCommand + ucLenCommand, ratio, uuzMSB);
    ucLenCommand += 2U;
    //CRC16
    usCrcModbus = usModbusRTU_CRC(ucDataCommand, ucLenCommand);
    vU16ToU8((ucDataCommand + ucLenCommand), usCrcModbus, uuzLSB);
    ucLenCommand += 2U;

    cmd_set(xDevSTA.xDos[index].uart, (u8*) ucDataCommand, ucLenCommand);

    //N次读取无数据，将连接状态切断
    if (xDevSTA.xDos[index].count < uuzDEV_CONNECT_ERR) {
        xDevSTA.xDos[index].count++;  //连接计数
    }
}
