/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_DOSING_H
#define __TYPEDEF_DOSING_H

// include ---------------------------------------------
#include "typedefDEVID.h"
#include "typedefBASE.h"
#include "uuzConfigDEV.h"
#include "uuzOpt.h"
// ------- ---------------------------------------------
//operatre code
enum
{
    _DOS_IS_CONNECTED = 0,
    _DOS_GET_STATE,
    _DOS_OPT_STATE,
    _DOS_SET_CONFIG,
    _DOS_RESET_CYCLE
};

typedef enum
{
    _DOS_T_NONE = 0,
    _DOS_T_EC,
    _DOS_T_PHA,
    _DOS_T_PHD

} ENUM_DOS_TYPE;

//最大蠕动泵转速(470ml/min)
#define uuzDOS_SPEED_MAX (470U)

typedef struct dosingsingle_t
{
    //蠕动泵配置
    u16 en;     //0-OFF/1-ON
    u16 ratio;  //比例:定频时:由开机时间*D[11];变频时:比例(D[11])*最大速度(470ml/分);
    u16 type;   //0:None/1:EC/2:pH+/3:pH-

} Dosing_Single_Typedef_t;

typedef struct dosingstate_t
{
    //蠕动泵当前状态
    u16 state;  //当前的运行状态:1：配液启动中,0：配液停止
    u16 ratio;  //显示比例: 定频时:由开机时间*D[11] / 变频时:比例(D[11])*最大速度(470ml/分)
    u16 mode;   //显示：模式(0：定频，1：变频)
    u16 speed;  //定频时：是固定速度：**ml/分钟;
    u16 running;  //显示：开时间：0.1秒
    u16 waiting;  //显示：关时间：0.1秒
    u16 laps[2];  //显示：皮管历史圈数；单位：个    //LSB
    u16 motor;  //显示：电机运转状态：0：停止，1：正在工作；

} Dosing_State_Typedef_t;

typedef struct dosingconfig_t
{
    u16 mode;  //(CF:定频/VF:变频):def-0-CF/1-VF
    u16 speed;  //ml/min:def-300,max-470
    u16 running;    //3-180s:def-10s
    u16 waiting;    //10-360s:def-30s

    u16 rtc[6];  //CLEAR INFO:year-mon-day-hour-min-sec

    u16 ver;    //0x0000U:通用版本|0x0001U:定制版本
    u16 end;    //0xBBBBU

} Dosing_Config_Typedef_t;

#define uuzDOS_PRO_LEN (sizeof(Dosing_Config_Typedef_t))

#endif // __TYPEDEF_DOSING_H
