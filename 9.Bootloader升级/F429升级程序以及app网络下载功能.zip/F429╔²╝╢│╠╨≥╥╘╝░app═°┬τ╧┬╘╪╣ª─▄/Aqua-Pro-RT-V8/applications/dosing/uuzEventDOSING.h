/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __UUZ_DOSING_EVENT_H
#define __UUZ_DOSING_EVENT_H

#include "typedefDOSING.h"
#include "typedefMBR.h"
#include "typedefPROG.h"

#ifdef __cplusplus
extern "C" {
#endif

extern MODBUS_RTU_CODE dosing_opt_code[5];
extern Dosing_State_Typedef_t xDosingState[uuzDEV_DOS_MAX];
extern Dosing_Config_Typedef_t * xDosCFG;

/**
 * @brief 设置Dosing蠕动泵的初始相关数据
 *
 * @param xConfig Dosing的指针地址
 */
void dosing_single_config_init(Dosing_Config_Typedef_t* xConfig);

#if 0
/**
 * @brief 设置Dosing蠕动泵的持续运行相关数据
 *
 * @param xConfig Dosing的指针地址
 */
void dosing_long_config_init(Dosing_Config_Typedef_t* xConfig);
#endif

/**
 *
 * @brief 设置单个Dosing蠕动泵的初始相关数据
 *
 * @param xValve:需要设置的蠕动泵数据
 */
void dosing_valve_init(Dosing_Single_Typedef_t* xValve);

/**
 *
 * @brief 设置单个Dosing蠕动泵的数据
 *
 * @param xValve:需要设置的蠕动泵数据
 * @param en:0-无效/1-有效
 * @param ratio:10~100%
 * @param type:0-NONE/1-EC/2-pH+/3-pH-
 */
void dosing_valve_set(Dosing_Single_Typedef_t* xValve, u8 en, u8 ratio, u8 type);

/**
 * @brief 蠕动泵循环时间重置
 */
void dosing_cycle_reset_time(void);
/**
 * @brief 初始组群设置蠕动圈数设置
 */
void dosing_cycle_group_reset(void);

/**
 * @brief 按类型开启蠕动泵
 *
 * @param prog:当前运行的程序数据指针
 * @param type:需要控制的类型 1-EC/2-pH+/3-pH-
 * @param state:运行状态 0-OFF/1-ON
 */
void dosing_opt_group(Dynamic_Single_Typedef_t* prog, ENUM_DOS_TYPE type, u8 state);

/**
 *
 * @brief 读取蠕动泵配置，并判断是否一致
 * @param xState 读取的状态数据
 * @param xConfig 保存的配置数据
 * @return 判断是否有不一致数据。如果有不一致数据，返回1
 */
u8 dosing_config_is_same(Dosing_State_Typedef_t* xState,
        Dosing_Config_Typedef_t* xConfig);

/**
 * @brief 读取Dosing的实时数据
 *
 * @param id
 */
void dosing_state_read(u8 id);

/**
 * @brief Dosing设备实时数据处理
 *
 * @param id 需要处理的设备相对数据地址
 * @param data 需要处理的设备实时数据
 */
void dosing_state_resolve(u8 id, u8* data);

/**
 * @brief Dosing设备操作数据处理
 *
 * @param id 需要处理的设备相对数据地址
 * @param data 需要处理的设备实时数据
 */
void dosing_state_replay(u8 id, u8* data);

/**
 * @brief 发送蠕动泵启动命令
 * @param id:需要执行的蠕动泵
 * @param sta:0-OFF/1-ON
 */
void dosing_opt(u8 id, u16 sta);

/**
 * @brief 发送蠕动泵圈数清零
 * @param id:需要执行的蠕动泵
 */
void dosing_cycle_reset(u8 id);

/**
 * @brief 向蠕动泵发送配置数据
 * @param index
 * @param ratio
 * @param config
 */
void dosing_config_set(u8 index, u16 ratio, Dosing_Config_Typedef_t* config);

/**
 * @brief 关闭全部蠕动泵
 */
void dosing_all_close(void);

/**
 * @brief 修改配肥比例
 * @param index
 * @param ratio
 */
void dosing_ratio_set(u8 index, u16 ratio);

/**
 * @brief Dosing设备操作数据处理
 *
 * @param id 需要处理的设备相对数据地址
 * @param data 需要处理的设备实时数据
 */
void dosing_ratio_replay(u8 id, u8* data);

#ifdef __cplusplus
}
#endif

#endif // __UUZ_PHEC_B2_EVENT_H
