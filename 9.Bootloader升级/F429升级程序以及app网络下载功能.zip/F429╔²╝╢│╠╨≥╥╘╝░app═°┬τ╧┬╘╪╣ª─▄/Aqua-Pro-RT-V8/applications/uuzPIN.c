/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-01   ZhouXiaomin     first version
 */
/* Includes ------------------------------------------------------------------*/
#include "rtdef.h"
#include "uuzPIN.h"
#include "uuzDevCfg.h"
#include "uuzEventHMI.h"
#include "uuzConfigHMI.h"
/*Log---------------------------------------------*/
#define DBG_TAG "e.pin"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
/* Private---------------------------------------------------------------------------*/
/* ---------------------------------------------------------------------------*/
/**
 * @brief 设置锁定屏幕密码
 */
void unlock_pin_set(u32 newpin)
{
    u8 f_save = 0;
    LOG_D("PIN<%04d>", newpin);
    if (newpin != xSysCFG.lock_pin) {
        xSysCFG.lock_pin = newpin;  //更新数据
        f_save = 1;
    }

    if (f_save) {
        system_config_save();  //密码修改，保存数据
    }
}

/**
 * @brief 检查自动锁定逻辑
 */
void auto_lock_sync(void)
{
    if (xCurrUI.ucPageID == uuzHMI_UI_MAIN) {
        if (xSysSTA.is_lock == 0) {    //处于解锁状态
            if (xSysSTA.tim_lock < uuzPIN_TIM_MAX) {
                xSysSTA.tim_lock++;
            } else {
                xSysSTA.is_lock = 1;  //自动锁定修改状态
                xSysSTA.tim_lock = 0;    //清除锁定状态
                hmi_auto_lock_sync();   //上报相关数据
            }
        }
    }
}
/*-----------------------------------------------------------------*/
