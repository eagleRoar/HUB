/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __UUZ_PROG_EVENT_H
#define __UUZ_PROG_EVENT_H

#include "typedefMBR.h"
#include "typedefPROG.h"

/**
 * @brief 正常处理的数据缓冲区
 */
extern ProgCache_Typedef_t progCache;
/**
 * @brief 正在运行的工作程序
 */
//extern PROG_Single_Typedef_t* xProgRunning;
//extern Dynamic_Single_Typedef_t * xProgDynamic;
//extern Fixed_Single_Typedef_t * xProgFixed;
/**
 * @brief 数据配置指针地址
 */
extern Prog_Config_Typedef_t xProgCFG;

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Program的动态PHEC配置参数初始化
 */
void dynamic_config_init(Dynamic_Single_Typedef_t* config);
/**
 * @brief 在加载配置后，对蠕动泵发送配置数据
 */
void prog_dosing_config_sync(void);
/**
 * @brief 读取蠕动泵的相关配置
 */
void prog_dosing_state_sync(void);
/**
 * @brief 蠕动泵获取配肥运行程序编程数据
 */
void prog_dosing_running_sync(void);
/**
 * @brief 运行过程判断计数
 */
void prog_cache_init(void);
/**
 * @brief 更新相关数据(报警）
 */
void alarm_cache_init(void);

/**
 * @brief 根据程序的配置读取判断报警相关处理
 */
u16 prog_alarm_data_judge(Dynamic_Single_Typedef_t* prog, u16 ec, u16 pH, u16 ta);
/**
 * @brief 根据程序的配置读取判断phec相关处理
 */
void prog_dynamic_data_judge(Dynamic_Single_Typedef_t* prog, u16 ec, u16 pH);
/**
 * @brief 根据程序的配置读取判断phec相关处理
 */
void prog_fixed_data_judge(Fixed_Single_Typedef_t* prog);

/**
 * @brief 程序数据修改同步
 * @param prog:待修改初始化
 * @param en:有效性
 * @param id:对应位置ID
 * @param t:对应配肥类型
 * @param tim:对应时间
 * @param addr:对应数据类型
 */
void prog_data_sync(Prog_Cache_Typedef_t * prog, u8 en, u8 id, u8 t, u32 tim, void * addr);

/**
 * @brief 主动运行程序判断
 */
void prog_running_event(void);

#ifdef __cplusplus
}
#endif

#endif // __UUZ_PHEC_B2_EVENT_H
