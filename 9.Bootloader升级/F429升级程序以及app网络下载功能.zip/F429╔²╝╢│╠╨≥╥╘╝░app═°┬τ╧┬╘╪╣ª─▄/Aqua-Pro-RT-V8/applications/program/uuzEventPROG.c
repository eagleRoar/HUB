/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
/*include*****************************************************************************/
#include <math.h>
#include <string.h>
/******************************************************************************/
#include "uuzEVENT.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzTEMP.h"
/******************************************************************************/
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
/******************************************************************************/
#include "typedefDEVID.h"
#include "typedefINIT.h"
#include "typedefPHEC.h"
#include "uuzConfigDEV.h"
#include "uuzConfigPORT.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
/******************************************************************************/
#include "uuzEventHMI.h"
#include "uuzConfigHMI.h"
/******************************************************************************/
#include "uuzEventDOSING.h"
#include "uuzEventPHEC.h"
#include "uuzEventPROG.h"
#include "uuzEventSCH.h"
#include "uuzEventP260.h"
#include "uuzEventWLS.h"
#include "uuzEventFIXED.h"
#include "uuzEventIRR.h"
/*log---------------------------------------------*/
#define DBG_TAG "e.prog"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/******************************************************************************/
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
static u8 t_need_mix = 0;
static u8 f_need_mix = 0;
#endif
/**
 * @brief 正常处理的数据缓冲区
 */
ProgCache_Typedef_t progCache;
ProgCache_Typedef_t alarmCache;
/**
 * @brief 正在运行的工作程序
 */
//PROG_Single_Typedef_t* xProgRunning;
//Dynamic_Single_Typedef_t * xProgDynamic;
//Fixed_Single_Typedef_t * xProgFixed;
/**
 * @brief 数据配置指针地址
 */
Prog_Config_Typedef_t xProgCFG;
//最大校验数据
#define uuzPROG_EC_MAX (3U)
#define uuzPROG_PH_MAX (3U)
/******************************************************************************/
/**
 * @brief Program的动态PHEC配置参数初始化
 */
void dynamic_config_init(Dynamic_Single_Typedef_t* config)
{
    //更新设备默认配置数据
    //EC默认数据
    config->cfg.ec_t = 180U;  //EC-Target:1.80
    config->cfg.ec_d = 20U;  //EC-Target:1.80
    config->cfg.ec_h = 300U;  //EC-High-Alarm:3.00
    config->cfg.ec_l = 50U;  //EC-Low-Alarm:0.50
    config->cfg.ec_en = 1U;  //EC-Alarm:1-ON/0-OFF

    //pH默认数据
    config->cfg.pH_t = 686U;  //pH-Target:6.86
    config->cfg.pH_d = 20U;  //pH-deadband:0.20
    config->cfg.pH_h = 1000U;  //pH-High:10.00
    config->cfg.pH_l = 400U;  //pH-Low:4.00
    config->cfg.pH_en = 1U;  //pH-Alarm:1-ON/0-OFF

    //温度默认数据
    config->cfg.ta_h = 350U;  //Ta-High:35.0C
    config->cfg.ta_en = 1U;  //Ta-Alarm:1-ON/0-OFF

    //初始化-蠕动泵单个端口信息
    //添加相关设置EC-1/2/3/4
    for (u8 index = 0; index < uuzDEV_DOS_MAX; index++) {
        dosing_valve_set(&config->dos[index], 1, 100, _DOS_T_EC);
    }

    config->end = 0xBBBBU;  //默认结束符
}

/**
 * @brief 更新相关数据(报警）
 */
void alarm_cache_init(void)
{
    rt_memset(&alarmCache, 0x00, sizeof(ProgCache_Typedef_t));

    //报警数据判断防抖
    alarmCache.alm_ec.max = uuzPROG_EC_MAX * 2;
    alarmCache.alm_pH.max = uuzPROG_PH_MAX * 2;
    alarmCache.alm_ta.max = uuzPROG_EC_MAX * 2;
}

/**
 * @brief 运行过程判断计数
 */
void prog_cache_init(void)
{
    //清空缓存数据
    rt_memset(&progCache, 0x00, sizeof(ProgCache_Typedef_t));

    //pH，EC数据判断防抖
    progCache.ec.max = uuzPROG_EC_MAX;
    progCache.pH.max = uuzPROG_PH_MAX;
}

/**
 * @brief 程序数据修改同步
 * @param prog:待修改初始化
 * @param en:有效性
 * @param id:对应位置ID
 * @param t:对应配肥类型
 * @param tim:对应时间
 * @param addr:对应数据地址
 */
void prog_data_sync(Prog_Cache_Typedef_t * prog, u8 en, u8 id, u8 t, u32 tim, void * addr)
{
    if (prog != RT_NULL) {
        prog->en = en;    //执行动作：0-不执行|1-执行
        prog->id = id;    //实际执行编号（0-8）
        prog->t = t;      //执行类型
        prog->tim = tim;
        prog->addr = addr;
    }
}

#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
/**
 * @brief 蠕动泵获取配肥运行程序编程数据
 */
void prog_dosing_running_sync(void)
{
#if 0
    u16 progRunning = 0;
    //NOTE:有2种执行模式，一种是自动模式，使用Fixed数据
    //NOTE:定量模式，使用Fixed相关数据,该模式必须手动运行,或加水后自动运行
    //获取配肥运行程序编程数据
    if (xSysCFG.running_mode == 2) {  //如果是周期表运行模式,判断加载数据
        progRunning = schedule_curr_program_get();  //加载临时数据
        if (progRunning != xSysSTA.progRunning) {
            prog_cache_init();  //清除缓存数据
            dosing_all_close();  //关闭当前数据
        }
        xSysSTA.progRunning = progRunning;
        xSysSTA.progType = _PROG_STA_SCH;   //表示是周期表
    } else if (xSysCFG.running_mode == 1) {  //如果是独立运行模式,读取数据
        xSysSTA.progRunning = xSysCFG.fixed_id;  //范围0-9：0为不工作
        xSysSTA.progType = _PROG_STA_FIXED;   //表示是动态配肥
    } else {
        xSysSTA.progRunning = 0;   //范围0-9：0为不工作
        xSysSTA.progType = _PROG_STA_NONE;   //表示是动态配肥
    }

    LOG_D("Program[%d]", xSysSTA.progRunning);
    u8 isProg = 0;
    if ((xSysSTA.progType == _PROG_STA_FIXED) || (xSysSTA.progType == _PROG_STA_SCH)) {
        if ((xSysSTA.progRunning >= 1) && (xSysSTA.progRunning <= uuzPROG_MAX)) {
            prog_data_sync(&progCache.prog, 1, xSysSTA.progRunning - 1, xSysSTA.progType, 0,
                    ((void *) xProgCFG.xFixed[xSysSTA.progRunning - 1]));
            isProg = 1;
        }
    }

    if (isProg == 0) {   //错误数据，加载空数据
        prog_data_sync(&progCache.prog, RT_FALSE, uuzPROG_MAX, _PROG_STA_NONE, 0, RT_NULL);
    }
    LOG_D("Running[%d]--Type[%d]", xSysSTA.progRunning, xSysSTA.progType);
#else
    //NOTE:按顺序将工作插入到一个队列中去（多个灌溉逻辑）
    u16 progRunning = 0;
    //NOTE:有2种执行模式，一种是自动模式，使用Fixed数据
    //NOTE:定量模式，使用Fixed相关数据,该模式必须手动运行,或加水后自动运行
    //获取配肥运行程序编程数据
    if (xSysCFG.running_mode == 2) {  //如果是周期表运行模式,判断加载数据
        progRunning = schedule_curr_program_get();  //加载临时数据
        xSysSTA.progRunning = progRunning;
        xSysSTA.progType = _PROG_STA_SCH;   //表示是周期表
    } else if (xSysCFG.running_mode == 1) {  //如果是独立运行模式,读取数据
        xSysSTA.progRunning = xSysCFG.fixed_id;  //范围0-9：0为不工作
        xSysSTA.progType = _PROG_STA_FIXED;   //表示是动态配肥
    } else {
        xSysSTA.progRunning = 0;   //范围0-9：0为不工作
        xSysSTA.progType = _PROG_STA_NONE;   //表示是动态配肥
    }

    LOG_D("Program[%d]", xSysSTA.progRunning);
    u8 isProg = 0;
    if ((xSysSTA.progType == _PROG_STA_FIXED) || (xSysSTA.progType == _PROG_STA_SCH)) {
        if ((xSysSTA.progRunning >= 1) && (xSysSTA.progRunning <= uuzPROG_MAX)) {
            prog_data_sync(&progCache.prog, 1, xSysSTA.progRunning - 1, xSysSTA.progType, 0,
                    ((void *) xProgCFG.xFixed[xSysSTA.progRunning - 1]));
            isProg = 1;
        }
    }

    if (isProg == 0) {   //错误数据，加载空数据
        prog_data_sync(&progCache.prog, RT_FALSE, uuzPROG_MAX, _PROG_STA_NONE, 0, RT_NULL);
    }
    LOG_D("Running[%d]--Type[%d]", xSysSTA.progRunning, xSysSTA.progType);
#endif
}
#else
/**
 * @brief 蠕动泵获取配肥运行程序编程数据
 */
void prog_dosing_running_sync(void)
{
    u16 progRunning = 0;
    //NOTE:有2种执行模式，一种是自动模式，使用Dynamic数据
    //NOTE:另一种是定量模式，使用Fixed相关数据,该模式必须手动运行,或加水后自动运行
    //获取配肥运行程序编程数据
    if (xSysCFG.running_mode == 2) {  //如果是周期表运行模式,判断加载数据
        progRunning = schedule_curr_program_get();//加载临时数据
        if (progRunning != xSysSTA.progRunning) {
            prog_cache_init();  //清除缓存数据
            dosing_all_close();//关闭当前数据
        }
        xSysSTA.progRunning = progRunning;
        xSysSTA.progType = _PROG_STA_SCH;   //表示是周期表
    } else if (xSysCFG.running_mode == 1) {  //如果是独立运行模式,读取数据
        xSysSTA.progRunning = xSysCFG.dynamic_id;  //范围0-9：0为不工作
                xSysSTA.progType = _PROG_STA_DYNC;//表示是动态配肥
    } else {
        xSysSTA.progRunning = 0;   //范围0-9：0为不工作
        xSysSTA.progType = _PROG_STA_NONE;   //表示是动态配肥
    }

    LOG_D("Program[%d]", xSysSTA.progRunning);
    u8 isProg = 0;
    if ((xSysSTA.progType == _PROG_STA_DYNC) || (xSysSTA.progType == _PROG_STA_SCH)) {
        if ((xSysSTA.progRunning >= 1) && (xSysSTA.progRunning <= uuzPROG_MAX)) {
            prog_data_sync(&progCache.prog, 1, xSysSTA.progRunning - 1, xSysSTA.progType, 0,
                    ((void *) xProgCFG.xDynamic[xSysSTA.progRunning - 1]));
            isProg = 1;
        }
    }

    if (isProg == 1) {   //错误数据，加载空数据
        u32 ratio = 100;
        for (u8 index = 0; index < xSysCFG.dosing_num; index++) {  //初次同步蠕动泵数据
            ratio = ((Dynamic_Single_Typedef_t *) (progCache.prog.addr))->dos[index].ratio;
            if (xDosingState[index].ratio != ratio) {   //比例一致,不重新同步，如果不一样，则重新同步
                dosing_ratio_set(index, ratio);  //发送相关数据
            }
        }
    } else {
        prog_data_sync(&progCache.prog, RT_FALSE, uuzPROG_MAX, _PROG_STA_NONE, 0, RT_NULL);
    }
    prog_dosing_state_sync();    //蠕动泵工作状态
    LOG_D("Running[%d]--Type[%d]", xSysSTA.progRunning, xSysSTA.progType);
}
#endif

/**
 * @brief 在加载配置后，对蠕动泵发送配置数据
 */
void prog_dosing_config_sync(void)
{
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
    u8 is_dosing_sync = 0;
    if (xSysCFG.running_mode == 1) {  //如果是独立运行模式,读取数据
        if (xSysCFG.single_mode == 0) {  //是定量工作模式
            Dosing_Config_Typedef_t dosConfig;
            //dosing_long_config_init(&dosConfig);    //修改为常开状态参数
            for (u8 index = 0; index < xSysCFG.dosing_num; index++) {  //初次同步蠕动泵数据
                //dosing_opt(index, uuzOPT_OFF);  //先关闭蠕动泵
                if (xDevSTA.xDos[index].en == 1) {  //发送蠕动泵配置数据
                    dosing_config_set(index, 100, &dosConfig);  //发送相关数据
                }
            }
            is_dosing_sync = 1;  //已经同步蠕动泵状态
        }
    }

    if (is_dosing_sync == 0) {  //设置动态配肥蠕动泵的详细参数
        for (u8 index = 0; index < xSysCFG.dosing_num; index++) {  //初次同步蠕动泵数据
            //dosing_opt(index, uuzOPT_OFF);  //先关闭蠕动泵
            if (xDevSTA.xDos[index].en == 1) {  //发送蠕动泵配置数据
                dosing_config_set(index, 100, xDosCFG);  //发送相关数据
            }
        }
        is_dosing_sync = 1;  //已经同步蠕动泵状态
    }
#else
    for (u8 index = 0; index < xSysCFG.dosing_num; index++) {  //初次同步蠕动泵数据
        if (xDevSTA.xDos[index].en == 1) {  //发送蠕动泵配置数据
            dosing_config_set(index, 100, xDosCFG);  //发送相关数据
            rt_thread_mdelay(100);
        }
    }
#endif
}

/**
 * @brief 读取蠕动泵的相关配置
 */
void prog_dosing_state_sync(void)
{
    u8 ec_en = 0;
    u8 pha_en = 0;
    u8 phd_en = 0;
    u8 is_running_state = 0;

    if (progCache.prog.en) {    //有工作数据
        if ((progCache.prog.t == _PROG_STA_SCH)
                || (progCache.prog.t == _PROG_STA_DYNC)) {  //周期表模式|动态工作模式
            Dynamic_Single_Typedef_t *addr = (Dynamic_Single_Typedef_t *) progCache.prog.addr;  //加载数据地址
            for (u8 index = 0; index < xSysCFG.dosing_num; index++) {  //有蠕动泵相关信息
                if (addr->dos[index].en == 1) {  //加载相关功能信息
                    if (addr->dos[index].type == _DOS_T_EC) {
                        ec_en++;
                    } else if (addr->dos[index].type == _DOS_T_PHA) {
                        pha_en++;
                    } else if (addr->dos[index].type == _DOS_T_PHD) {
                        phd_en++;
                    }
                }
            }
            xSysSTA.dosing_ec_dynamic_opt = ec_en;  //EC动态配肥
            xSysSTA.dosing_pha_dynamic_opt = pha_en;  //pH+动态配肥
            xSysSTA.dosing_phd_dynamic_opt = phd_en;  //pH-动态配肥
            is_running_state = 1;
        }
    }
    if (is_running_state == 0) {    //清空数据
        xSysSTA.dosing_ec_dynamic_opt = 0;  //EC动态配肥
        xSysSTA.dosing_pha_dynamic_opt = 0;  //pH+动态配肥
        xSysSTA.dosing_phd_dynamic_opt = 0;  //pH-动态配肥
    }
}

/**
 * @brief 根据程序的配置读取判断phec相关处理
 */
void prog_fixed_data_judge(Fixed_Single_Typedef_t* prog)
{
    //NOTE:更新Fixed相关数据
    if (xSysSTA.need_dosing_fixed == 1) {
        if (prog != RT_NULL) {
            //加载工作状态
            for (u8 index = 0; index < xSysCFG.dosing_num; index++) {
                if ((xDevSTA.xDos[index].en == uuzDEV_REG_OK) && (prog->en[index] == 1)) {  //工作状态有效
                    if (xSysSTA.dosing_en[index] == 0) {    //没有开始工作状态
                        xSysSTA.dosing_max[index] = prog->t[index];  //获取最大蠕动泵工作时间
                        xSysSTA.dosing_tim[index] = 0;  //蠕动泵工作时间状态
                        xSysSTA.dosing_sta[index] = uuzRUN_OFF;  //还没开始进入工作状态
                        xSysSTA.dosing_en[index] = 1;  //有需要EC工作状态
                    }
                } else {
                    xSysSTA.dosing_max[index] = 0;  //获取最大蠕动泵工作时间
                    xSysSTA.dosing_tim[index] = 0;  //蠕动泵工作时间状态
                    xSysSTA.dosing_sta[index] = uuzRUN_OFF;  //还没开始进入工作状态
                    xSysSTA.dosing_en[index] = 0;  //不需要EC工作状态
                }
            }
        }

        for (u8 index = 0; index < xSysCFG.dosing_num; index++) {
            if (xDevSTA.xDos[index].en == uuzDEV_REG_OK) {
                if (xSysSTA.dosing_en[index] == 1) {    //需要开始Dosing工作
                    if (xSysSTA.dosing_tim[index] == 0) {  //时间为0，准备启动工作状态
                        if (xSysSTA.dosing_sta[index] == uuzRUN_OFF) {   //没进入蠕动泵工作状态
                            xSysSTA.dosing_sta[index] = uuzRUN_ON;  //切换蠕动泵工作状态
                            dosing_opt(index, uuzOPT_ON);  //开启蠕动泵
                            rt_thread_mdelay(50);
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
                            t_need_mix++;
#endif
                        }
                        xSysSTA.dosing_tim[index]++;  //开启加肥
                    } else if (xSysSTA.dosing_tim[index] >= xSysSTA.dosing_max[index]) {    //没有达到目标时间
                        if (xSysSTA.dosing_sta[index] == uuzRUN_ON) {   //处于蠕动泵工作状态
                            xSysSTA.dosing_sta[index] = uuzRUN_OFF;  //切换蠕动泵工作状态
                            dosing_opt(index, uuzOPT_OFF);  //关闭蠕动泵
                            rt_thread_mdelay(50);
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
                            t_need_mix--;
#endif
                        }
                        xSysSTA.dosing_tim[index] = 0;  //停止加肥
                        xSysSTA.dosing_en[index] = 0;  //关闭加液动作
                    } else {
                        if (xSysSTA.dosing_sta[index] == uuzRUN_ON) {   //处于蠕动泵工作状态
                            xSysSTA.dosing_tim[index]++;  //持续计算
                        }
                    }
                    LOG_I("<%d>-EN[%d]-TIM[%d]-STA[%d]-MAX[%d]", index,
                            xSysSTA.dosing_en[index],
                            xSysSTA.dosing_tim[index],
                            xSysSTA.dosing_sta[index],
                            xSysSTA.dosing_max[index]
                            );

                }
            }
        }

#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
        //打开混合泵
        if (f_need_mix == 0) {
            if (t_need_mix) {
                irr_opt_mix(&xIrrPro->pro[0], uuzPORT_IRR_MIX, uuzOPT_ON);
                f_need_mix = 1;
            }
        } else {
            if (t_need_mix == 0) {
                irr_opt_mix(&xIrrPro->pro[0], uuzPORT_IRR_MIX, uuzOPT_OFF);
                f_need_mix = 0;
            }
        }
#endif

        u8 isDosing_f = 0;
        for (u8 d_index = 0; d_index < xSysCFG.dosing_num; d_index++) {
            if (xSysSTA.dosing_en[d_index] == 1) {    //需要开始Dosing工作
                isDosing_f = 1;  //收集全部数据,清除工作状态
            }
        }
        xSysSTA.need_dosing_fixed = isDosing_f;
    } else {
        for (u8 index = 0; index < xSysCFG.dosing_num; index++) {
            if (xSysSTA.dosing_en[index] == 1) {    //需要开始Dosing工作
                if (xSysSTA.dosing_sta[index] == uuzRUN_ON) {   //处于蠕动泵工作状态
                    xSysSTA.dosing_sta[index] = uuzRUN_OFF;  //切换蠕动泵工作状态
                    dosing_opt(index, uuzOPT_OFF);  //关闭蠕动泵
                    rt_thread_mdelay(50);
                }
                xSysSTA.dosing_tim[index] = 0;  //停止加肥
                xSysSTA.dosing_en[index] = 0;  //关闭加液动作
            }
        }
    }
    LOG_I("Need Dosing Fixed:%d", xSysSTA.need_dosing_fixed);
    //在补水界面上,显示数据
    if (xCurrUI.ucPageID == uuzHMI_UI_NUT4) {
        if (xSysSTA.need_dosing_fixed == 1) {

        } else {

        }
    }
}

/**
 * @brief 根据程序的配置读取判ph,ec的报警数据
 */
u16 prog_alarm_data_judge(Dynamic_Single_Typedef_t* prog, u16 ec, u16 pH, u16 ta)
{
    u16 valve = RT_TRUE;

    if (prog != RT_NULL) {

        u8 alarm_Ec = 0;

        if (prog->cfg.ec_en) {  //有报警需求
            if (ec > prog->cfg.ec_h) {  //EC数据高
                alarm_Ec = 1;  //ec当前值高于报警值，停止配肥
            } else {
                alarm_Ec = 0;   //回到正常状态
            }

            item_analysis(&alarmCache.alm_ec, alarm_Ec);  //防抖数据判断

            //LOG_D("A-OPT[%d]-STA[%d]-TIME[%d]-ALARM-EC[%d]",alarmCache.alm_ec.opt,
            //alarmCache.alm_ec.sta,alarmCache.alm_ec.time,alarm_Ec);

            if (alarmCache.alm_ec.opt == 1) {  //执行操作数据
                if (alarmCache.alm_ec.sta == 0) {  //当前为无报警状态
                    if (alarm_Ec == 1) {  //触发报警
                        alarmCache.alm_ec.sta = 1;  //保存状态
                        alarmCache.alm_ec.time = 0;  //初始化计算工作时间
                        rt_event_send(eventALM, EC_H_EVENT);  //发送高报警
                        valve = RT_FALSE;
                    }
                } else if (alarmCache.alm_ec.sta == 1) {  //已经处于报警状态
                    if (alarm_Ec == 0) {  //解除报警
                        alarmCache.alm_ec.sta = 0;   //清除状态
                        alarmCache.alm_ec.time = 0;
                        rt_event_send(eventALM, EC_NULL_EVENT);  //发送无报警
                    }
                }
            } else {
                if (alarmCache.alm_ec.sta == 1) {    //如果处于报警状态
                    if (alarm_Ec == 1) {    //且仍然是报警状态
                        valve = RT_FALSE;   //保持停止状态
                    }
                }
            }

            //LOG_D("B-OPT[%d]-STA[%d]-TIME[%d]-ALARM-EC[%d]",
            //       alarmCache.alm_ec.opt,
            //      alarmCache.alm_ec.sta,
            //     alarmCache.alm_ec.time,
            //    alarm_Ec);
        } else {
            if (alarmCache.alm_ec.sta == 1) {  //已经处于报警状态
                if (alarm_Ec == 0) {  //解除报警
                    alarmCache.alm_ec.sta = 0;   //清除状态
                    alarmCache.alm_ec.time = 0;
                    rt_event_send(eventALM, EC_NULL_EVENT);  //发送无报警
                }
            }
        }

        u8 alarm_pH = 0;

        if (prog->cfg.pH_en) {  //有报警需求
            if (pH > prog->cfg.pH_h) {  //pH数据高
                alarm_pH = 2;  //ph当前值高于报警值，停止配肥
            } else if (pH < prog->cfg.pH_l) {  //pH数据低
                alarm_pH = 1;  //ph当前值高于报警值，停止配肥
            }

            item_analysis(&alarmCache.alm_pH, alarm_pH);  //防抖数据判断

            if (alarmCache.alm_pH.opt == 1) {  //执行操作数据
                if (alarmCache.alm_pH.sta == 0) {  //当前为空闲状态
                    if (alarm_pH == 2) {  //记录当前状态
                        alarmCache.alm_pH.sta = 2;  //清除延时计数
                        alarmCache.alm_pH.time = 0;  //初始化工作时间
                        rt_event_send(eventALM, PH_H_EVENT);  //发送高报警
                        valve = RT_FALSE;
                    } else if (alarm_pH == 1) {  //没有执行状态，清除相关数据
                        alarmCache.alm_pH.sta = 1;
                        alarmCache.alm_pH.time = 0;
                        rt_event_send(eventALM, PH_L_EVENT);  //发送无报警
                        valve = RT_FALSE;
                    }
                } else if (alarmCache.alm_pH.sta == 1) {  //当前为低报警状态
                    if (alarm_pH == 2) {  //记录当前状态
                        alarmCache.alm_pH.sta = 2;  //清除延时计数
                        alarmCache.alm_pH.time = 0;  //初始化工作时间
                        rt_event_send(eventALM, PH_H_EVENT);  //发送高报警
                        valve = RT_FALSE;
                    } else if (alarm_pH == 1) {  //没有执行状态，清除相关数据
                        valve = RT_FALSE;
                    } else if (alarm_pH == 0) {  //没有执行状态，清除相关数据
                        alarmCache.alm_pH.sta = 0;
                        alarmCache.alm_pH.time = 0;
                        rt_event_send(eventALM, PH_NULL_EVENT);  //发送无报警
                    }
                } else if (alarmCache.alm_pH.sta == 2) {  //当前为低报警状态
                    if (alarm_pH == 2) {  //记录当前状态
                        valve = RT_FALSE;
                    } else if (alarm_pH == 1) {  //没有执行状态，清除相关数据
                        alarmCache.alm_pH.sta = 1;
                        alarmCache.alm_pH.time = 0;
                        rt_event_send(eventALM, PH_L_EVENT);  //发送无报警
                        valve = RT_FALSE;
                    } else if (alarm_pH == 0) {  //没有执行状态，清除相关数据
                        alarmCache.alm_pH.sta = 0;
                        alarmCache.alm_pH.time = 0;
                        rt_event_send(eventALM, PH_NULL_EVENT);  //发送无报警
                    }
                } else {    //无效数据
                    alarmCache.alm_pH.sta = 0;
                    alarmCache.alm_pH.time = 0;
                    rt_event_send(eventALM, PH_NULL_EVENT);  //发送无报警
                }
            } else {
                if (alarmCache.alm_pH.sta == 1) {    //如果处于报警状态
                    if (alarm_pH == 1) {
                        valve = RT_FALSE;
                    } else if (alarm_pH == 2) {
                        alarmCache.alm_pH.sta = 2;  //清除延时计数
                        alarmCache.alm_pH.time = 0;  //初始化工作时间
                        rt_event_send(eventALM, PH_H_EVENT);  //发送高报警
                        valve = RT_FALSE;
                    }
                } else if (alarmCache.alm_pH.sta == 2) {
                    if (alarm_pH == 2) {
                        valve = RT_FALSE;
                    } else if (alarm_pH == 1) {
                        alarmCache.alm_pH.sta = 1;  //清除延时计数
                        alarmCache.alm_pH.time = 0;  //初始化工作时间
                        rt_event_send(eventALM, PH_L_EVENT);  //发送高报警
                        valve = RT_FALSE;
                    }
                }
            }

            LOG_D("C-OPT[%d]-STA[%d]-TIME[%d]-ALARM-PH[%d]",
                    alarmCache.alm_pH.opt,
                    alarmCache.alm_pH.sta,
                    alarmCache.alm_pH.time,
                    alarm_pH);
        } else {
            if (alarmCache.alm_pH.sta) {
                if (alarm_pH == 0) {
                    alarmCache.alm_pH.sta = 0;
                    alarmCache.alm_pH.time = 0;
                    rt_event_send(eventALM, PH_NULL_EVENT);  //发送无报警
                }
            }
        }

        u8 alarm_Ta = 0;

        if (prog->cfg.ta_en) {  //有报警需求
            u16 alarm_cfg_ta_h = prog->cfg.ta_h;
            if (xSysCFG.unit_ta == uuzTA_F) {   //如果是华氏度，需要转换后处理
                alarm_cfg_ta_h = uuz_usTempC2F_ConvCplt(alarm_cfg_ta_h);
            }

            if (ta > alarm_cfg_ta_h) {  //Ta.数据高
                alarm_Ta = 1;  //Ta.当前值高于报警
            } else {
                alarm_Ta = 0;  //
            }

            item_analysis(&alarmCache.alm_ta, alarm_Ta);  //防抖数据判断

            if (alarmCache.alm_ta.opt == 1) {  //执行操作数据
                if (alarmCache.alm_ta.sta == 0) {
                    if (alarm_Ta == 1) {  //记录当前状态
                        alarmCache.alm_ta.sta = 1;  //清除延时计数
                        alarmCache.alm_ta.time = 0;  //初始化工作时间
                        rt_event_send(eventALM, TA_H_EVENT);  //发送高报警
                    }
                } else if (alarmCache.alm_ta.sta == 1) {
                    if (alarm_Ta == 0) {
                        alarmCache.alm_ta.sta = 0;
                        alarmCache.alm_ta.time = 0;
                        rt_event_send(eventALM, TA_NULL_EVENT);  //发送无报警
                    }
                }
            } else {
                if (alarmCache.alm_ta.sta == 1) {
                    if (alarm_Ta == 0) {
                        alarmCache.alm_ta.sta = 0;
                        alarmCache.alm_ta.time = 0;
                        rt_event_send(eventALM, TA_NULL_EVENT);  //发送无报警
                    }
                }
            }
            //LOG_D("EC:Sta[%d]-Opt[%d]-Time[%d]", sta_Ec, progCache.ec.opt, progCache.ec.time);
        } else {
            if (alarmCache.alm_ta.sta == 1) {
                if (alarm_Ta == 0) {
                    alarmCache.alm_ta.sta = 0;
                    alarmCache.alm_ta.time = 0;
                    rt_event_send(eventALM, TA_NULL_EVENT);  //发送无报警
                }
            }
        }
    } else {
        LOG_D("Aqua-Pro_RT!!!!");
    }

    return valve;
}


/**
 * @brief 根据程序的配置读取判断phec相关处理
 */
void prog_dynamic_data_judge(Dynamic_Single_Typedef_t* prog, u16 ec, u16 pH)
{
    if (prog != RT_NULL) {

        u8 sta_Ec = 0;
        if (xSysSTA.dosing_ec_dynamic_opt) {  //有EC的蠕动泵

            if (ec < (prog->cfg.ec_t - prog->cfg.ec_d)) {  //EC相关判断
                sta_Ec = 1;  //ec当前值小于目标县,进入EC执行状态
            }
            if (progCache.ec.sta == 1) {  //在EC工作状态中
                if (ec >= prog->cfg.ec_t) {  //达到目标值
                    sta_Ec = 0;  //结束EC工作状态
                } else if (ec < prog->cfg.ec_t) {
                    sta_Ec = 1;  //在工作状态中，但是未达到目标值
                }
            }

            LOG_D("ec.sta:%d,sta_ec:%d, ec:%d, ec_t:%d",
                    progCache.ec.sta, sta_Ec, ec, (prog->cfg.ec_t - prog->cfg.ec_d));

            item_analysis(&progCache.ec, sta_Ec);  //读取相关数据

            if (progCache.ec.opt == 1) {  //执行操作数据
                if (progCache.ec.sta == 0) {  //当前为空闲状态
                    if (sta_Ec == 1) {  //记录当前状态
                        progCache.ec.sta = sta_Ec;  //清除延时计数
                        progCache.ec.time = 0;  //初始化工作时间
                        rt_event_send(eventOPT, OPT_EC_ON);  //执行EC的Dosing动作
                    } else if (sta_Ec == 0) {  //没有执行状态，清除相关数据
                        progCache.ec.opt = 0;
                        progCache.ec.time = 0;
                    }
                } else {
                    if (sta_Ec == 1) {  //已经在工作状态，记录持续时间，清除工作标记
                        progCache.ec.opt = 0;
                        progCache.ec.time++;  //工作计数
                    } else if (sta_Ec == 0) {  //记录当前状态
                        progCache.ec.sta = sta_Ec;  //清除延时计数
                        progCache.ec.time = 0;
                        rt_event_send(eventOPT, OPT_EC_OFF);  //达到目标值，关闭Dosing动作
                        //TODO:保存相关数据到log
                    }
                }
            }
        } else {
            if (progCache.ec.sta) {
                progCache.ec.sta = 0;  //清除工作状态
                progCache.ec.opt = 0;
                progCache.ec.time = 0;
                rt_event_send(eventOPT, OPT_EC_OFF);  //达到目标值，关闭Dosing动作
                //TODO:保存相关数据到log
            }
        }
        LOG_D("EC:Sta[%d]-Opt[%d]-Time[%d]", sta_Ec, progCache.ec.opt, progCache.ec.time);

        u8 sta_pH = 0;                //pH相关判断

        if (xSysSTA.dosing_pha_dynamic_opt) {                //如果pH+是工作状态
            if ((sta_pH == 0) && (pH < (prog->cfg.pH_t - prog->cfg.pH_d))) {
                sta_pH = 1;                //pH当前值小于目标值，增加pH值,加碱
            }
        }

        if (xSysSTA.dosing_phd_dynamic_opt) {                //如果pH-是工作状态
            if ((sta_pH == 0) && (pH > (prog->cfg.pH_t + prog->cfg.pH_d))) {
                sta_pH = 2;                //pH当前值大于目标值，减少pH值,加酸
            }
        }

        if ((xSysSTA.dosing_pha_dynamic_opt) || (xSysSTA.dosing_phd_dynamic_opt)) {
            if (progCache.pH.sta == 1) {                //如果当前处于pH+(加碱)状态,需要判断大于目标值为停止
                if (pH >= prog->cfg.pH_t) {
                    sta_pH = 3;
                } else if (pH < prog->cfg.pH_t) {                //如果在加液过程中，判断未达到目标值，继续补液
                    sta_pH = 1;
                }
            } else if (progCache.pH.sta == 2) {
                if (pH <= prog->cfg.pH_t) {                //如果当前处于pH-(加酸)状态,需要判断小于目标值为停止
                    sta_pH = 3;
                } else if (pH > prog->cfg.pH_t) {                //如果在加液过程中，判断未达到目标值，继续补液
                    sta_pH = 2;
                }
            }

            LOG_D("ph.sta:%d,sta_ph:%d, pH:%d, pH_t:%d, pH_d:%d",
                    progCache.pH.sta, sta_pH, pH, prog->cfg.pH_t, prog->cfg.pH_d);
            //读取相关数据
            item_analysis(&progCache.pH, sta_pH);

            if (progCache.pH.opt == 1) {                //执行操作数据
                if (progCache.pH.sta == 0) {                //当前为空闲状态
                    if (sta_pH == 1) {                //记录当前状态
                        progCache.pH.sta = sta_pH;                //清除延时计数
                        progCache.pH.time = 0;
                        rt_event_send(eventOPT, OPT_PHA_ON);                //执行pH+的Dosing动作
                    } else if (sta_pH == 2) {
                        progCache.pH.sta = sta_pH;                //记录当前状态
                        progCache.pH.time = 0;                //清除延时计数
                        rt_event_send(eventOPT, OPT_PHD_ON);                //执行pH-的Dosing动作
                    } else if (sta_pH == 0) {                //没有执行状态，清除相关数据
                        progCache.pH.opt = 0;
                        progCache.pH.time = 0;
                    }
                } else if (progCache.pH.sta == 1) {                //当前是pH+状态
                    if (sta_pH == 1) {                //已经在工作状态，清除立即指令
                        progCache.pH.opt = 0;                //清除延时计数
                        progCache.pH.time++;
                    } else if (sta_pH == 2) {                //切换加酸（pH-)状态
                        progCache.pH.sta = sta_pH;                //记录当前状态
                        progCache.pH.time = 0;                //清除延时计数
                        rt_event_send(eventOPT, OPT_PHD_ON);                //执行pH-的Dosing动作
                    } else if (sta_pH == 3) {                //关闭运行状态
                        progCache.pH.sta = 0;                //记录当前状态
                        progCache.pH.time = 0;                //清除延时计数
                        rt_event_send(eventOPT, OPT_PH_OFF);                //关闭pH的Dosing动作
                        //TODO:保存相关数据到log
                    }
                } else if (progCache.pH.sta == 2) {                        //当前是pH-状态
                    if (sta_pH == 1) {                        //切换加碱状态
                        progCache.pH.sta = sta_pH;                        //记录当前状态
                        progCache.pH.time = 0;                        //清除延时计数
                        rt_event_send(eventOPT, OPT_PHA_ON);                        //执行pH+的Dosing动作
                    } else if (sta_pH == 2) {                        //已经在工作状态，清除立即指令
                        progCache.pH.opt = 0;                        //清除延时计数
                        progCache.pH.time++;
                    } else if (sta_pH == 3) {                        //关闭运行状态
                        progCache.pH.sta = 0;                        //记录当前状态
                        progCache.pH.time = 0;                        //清除延时计数
                        rt_event_send(eventOPT, OPT_PH_OFF);                        //关闭pH的Dosing动作
                        //TODO:保存相关数据到log
                    }
                } else {                        //当前是pH+状态
                    if (sta_pH == 1 || sta_pH == 2) {                        //已经在工作状态，清除立即指令
                        progCache.pH.opt = 0;                        //清除延时计数
                        progCache.pH.time++;
                    } else if (sta_pH == 3) {
                        progCache.pH.sta = 0;                        //清除延时计数
                        progCache.pH.time = 0;
                        rt_event_send(eventOPT, OPT_PH_OFF);                        //关闭pH的Dosing动作
                        //TODO:保存相关数据到log
                    }
                }
            }
        } else {
            if (progCache.pH.sta) {                        //清除工作状态
                progCache.pH.sta = 0;
                progCache.pH.opt = 0;
                progCache.pH.time = 0;
                rt_event_send(eventOPT, OPT_PH_OFF);                        //关闭pH的Dosing动作
                //TODO:保存相关数据到log
            }
        }
        LOG_D("pH:Sta[%d]-Opt[%d]-Time[%d]", sta_pH, progCache.pH.opt, progCache.pH.time);

        if ((progCache.ec.sta == 1) || (progCache.pH.sta == 1) || (progCache.pH.sta == 2)) {
            rt_event_send(eventDATA, UI_STA_SYNC);                //添加发送界面刷新计数
        }
    } else {    //没有相关运行数据,关闭动作
        prog_cache_init();  //清除缓存数据
        dosing_all_close();  //关闭所有蠕动泵
    }
}

/**
 * @brief 主动运行程序判断
 */
void prog_running_event(void)
{
    //u8 phecRun = xSysCFG.pehc_id;
    u8 phecRun = 0;
    u16 currProgram = 0;
    u16 p260_index = 0;  //默认水池
    u8 level_status = RT_TRUE;  //水位状态
    u16 temperature = 0;

    prog_dosing_running_sync();  //运行程序解析处理
    LOG_D("Index[%d]--Run[%d]", phecRun, xSysSTA.progRunning);

    if (progCache.prog.en) {    //有实际运行程序
        if ((progCache.prog.t == _PROG_STA_SCH) || (progCache.prog.t == _PROG_STA_DYNC)) {    //如果是周期表模式
            //NOTE:判断水位状态(有水位的情况下）;如果是低水位，则自动停止配肥
            if (xDevSTA.xP260[p260_index].isconnect == uuzDEV_CONNECTED) {            //中间桶线路2数据判断
                sinp260_judge(
                        p260_index,
                        xWlsPro->cfg[p260_index].high,
                        xWlsPro->cfg[p260_index].high,
                        xWlsPro->cfg[p260_index].low);
                if (xP260Value[p260_index].out == uuzSINP260_LOW) {
                    level_status = RT_FALSE;   //停止自动配肥
                }
            }

            //NOTE:如果有报警数据，则自动停止配肥
            level_status = prog_alarm_data_judge((Dynamic_Single_Typedef_t *) progCache.prog.addr,
                    xPhecB2Value[phecRun].usVal_ec,
                    xPhecB2Value[phecRun].usVal_pH,
                    xPhecB2Value[phecRun].usVal_Tp);

            if (level_status == RT_TRUE) {  //RT_TRUE表示处理正确，无报警
                prog_dynamic_data_judge(
                        (Dynamic_Single_Typedef_t *) progCache.prog.addr,
                        xPhecB2Value[phecRun].usVal_ec,
                        xPhecB2Value[phecRun].usVal_pH);  //执行运行模式
                currProgram = progCache.prog.id + 1;    //ID<1-9>
            } else {
                prog_cache_init();  //清除缓存数据
                dosing_all_close();  //全部关闭蠕动泵
                currProgram = 0;    //非工作状态
            }
        }
    } else {
        currProgram = 0;    //NoWork
        LOG_D("PrevP[%d]--CurrP[%d]", xSysSTA.prevProgram, xSysSTA.currProgram);
        if (xCurrUI.ucPageID != uuzHMI_UI_DDOS) {   //非调试界面
            if (xSysSTA.prevProgram) {  //如果上一次那个运行状态
                prog_cache_init();  //清除缓存数据
                dosing_all_close();  //全部关闭蠕动泵
                rt_event_send(eventALM, (EC_NULL_EVENT | PH_NULL_EVENT | TA_NULL_EVENT));  //清除当前报警数据
            }
            if (xCurrUI.ucPageID == uuzHMI_UI_NUT00) {
                rt_event_send(eventDATA, UI_STA_SYNC);  //添加发送界面刷新计数
            }
        }
    }

    xSysSTA.currProgram = currProgram;
    LOG_D("Program:P.R[%d]-P[%d]-C[%d]", xSysSTA.progRunning,xSysSTA.prevProgram, xSysSTA.currProgram);
    if (xSysSTA.prevProgram != xSysSTA.currProgram) {  //判断是否有切换数据
        xSysSTA.prevProgram = xSysSTA.currProgram;
        rt_event_send(eventDATA, UI_STA_SYNC);  //添加发送界面刷新计数
    }
}
