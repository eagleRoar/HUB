/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_PROG_H
#define __TYPEDEF_PROG_H

// include ---------------------------------------------
#include "typedefBASE.h"
#include "typedefDEVID.h"
#include "typedefDOSING.h"
#include "typedefINIT.h"
#include "typedefPHEC.h"
#include "typedefPROG.h"
#include "typedefFIXED.h"
#include "uuzConfigDEV.h"
#include "uuzOpt.h"
// ------- ---------------------------------------------
#define uuzPROG_MAX (9U) //1-9的程序相关
// ------- ---------------------------------------------
enum
{
    _PROG_STA_NONE = (0U),  //0-没有运行专题
    _PROG_STA_FIXED,  //1-定量配肥
    _PROG_STA_DYNC,  //2-动态配肥
    _PROG_STA_SCH  //3-程序配肥
};
// ----------------------------------------------------
//UI PAGE CODE
typedef struct dynamic_config_t
{
    Phec_Single_Typedef_t cfg;  //PH EC的相关配置
    Dosing_Single_Typedef_t dos[uuzDEV_DOS_MAX];  //蠕动泵配置(8)

    u16 end;    //结束符

} Dynamic_Single_Typedef_t;
#define uuzDYNAMIC_CONFIG_LEN (sizeof(Dynamic_Single_Typedef_t))

typedef struct program_single_t
{
    Dynamic_Single_Typedef_t *xDynamic[uuzPROG_MAX];  //动态配肥的相关配置
    Fixed_Single_Typedef_t *xFixed[uuzPROG_MAX];  //定时配肥的相关配置

} Prog_Config_Typedef_t;  //程序配置

typedef struct program_cache_t
{
    u8 en;     //是否开启运行
    u8 id;  //对应类型位置
    u8 t;   //正在运行的程序类型
    u32 tim;   //运行的程序时间数据
    void * addr;     //程序运行数据地址
} Prog_Cache_Typedef_t;

typedef struct prog_single_t
{
    Phec_Single_Typedef_t xPhec;  //PH EC的相关配置
    Dosing_Single_Typedef_t xDosing[uuzDEV_DOS_MAX];  //蠕动泵配置(0~12)
    Dosing_Config_Typedef_t xDosingConfig;  //蠕动泵统一设置

} PROG_Single_Typedef_t;

#define uuzPROG_SINGLE_LEN (sizeof(PROG_Single_Typedef_t))

//设备的配置数据
typedef struct progconfig_t
{
    //Program配置
    PROG_Single_Typedef_t xProgram[uuzPROG_MAX];
    u16 resetCyclesRTC[6];  //year-mon-day-hour-min-sec

    u8 ucEnd;

} ProgConfig_Typedef_t;

#define uuzPROG_CONFIG_LEN (sizeof(ProgConfig_Typedef_t))


//设备的缓存数据
typedef struct progcache_t
{
    //执行的缓存计算
    Item_Typedef_t ec;
    Item_Typedef_t pH;

    Item_Typedef_t alm_ec;
    Item_Typedef_t alm_pH;
    Item_Typedef_t alm_ta;

    Prog_Cache_Typedef_t p_prog;  //上一次运行的程序
    Prog_Cache_Typedef_t prog;  //当前运行的程序

} ProgCache_Typedef_t;

#endif // __TYPEDEF_PROG_H
