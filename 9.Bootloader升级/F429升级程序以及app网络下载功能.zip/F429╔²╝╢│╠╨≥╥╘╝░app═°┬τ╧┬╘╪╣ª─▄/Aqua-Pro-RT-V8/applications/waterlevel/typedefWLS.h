/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __TYPEDEF_WLS_H
#define __TYPEDEF_WLS_H

// include ---------------------------------------------
#include "typedefBASE.h"
#include "typedefDEVID.h"
#include "uuzConfigDEV.h"
#include "uuzOpt.h"
// ------- ---------------------------------------------
//#define IRR_HIGH_LEVEL_TIME_MAX (10U)   //超过高水位10秒
#define _WLS_PRO_MAX (2U)   //灌溉程序对应的，罐1是主水箱|罐2是潮汐式水桶
/**
 * @brief 对应的补水工作模式
 */
typedef struct water_level_config_t
{
    u8 en;  //该配置是否开启
    //配置数据
    u8 md;  //工作模式:AUTO|MANUAL
    u8 sta;  //手动状态：0-off/1-on
    u32 high;   //处理高水位数据
    u32 low;    //处理低水位数据
    u32 target;   //处理水位目标值
    u32 limit;    //自动补水最长时间(秒）
    //传感器数据
    u8 id;  //对应的模块Modbus ID
    //执行端数据
    u8 t;   //待输出设置的类型
    u8 bid;  //使用待执行的输出板的ID
    u8 io;  //使用待执行的端口序号

}__attribute__ ((__packed__)) Water_Level_Config_Typedef_t;
#define uuzWLS_CONFIG_LEN (sizeof(Water_Level_Config_Typedef_t))

/**
 * @brief 回水模式记录
 */
typedef struct water_level_pro_t
{
    Water_Level_Config_Typedef_t cfg[_WLS_PRO_MAX];  //回水程序配置数据

    u16 end;    //0xBBBBU

}__attribute__ ((__packed__)) Wls_Pro_Typedef_t;  //模式配置
#define uuzWLS_PRO_LEN (sizeof(Wls_Pro_Typedef_t))

/**
 * @brief 回水缓存记录
 */
typedef struct wls_item
{
    //补水状态记录
    u8 opt;  //执行状态
    u8 sta;  //上次状态
    u32 time;  //工作持续时间(sec)

    //水位状态
    u8 out;  //水位状态

}__attribute__ ((__packed__)) Wls_Item_Typedef_t;  //回水缓冲

#endif // __TYPEDEF_WLS_H
