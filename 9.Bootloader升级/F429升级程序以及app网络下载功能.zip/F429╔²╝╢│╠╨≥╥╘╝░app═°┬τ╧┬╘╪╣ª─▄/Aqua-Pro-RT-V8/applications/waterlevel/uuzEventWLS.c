/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
/*include*****************************************************************************/
#include <math.h>
#include <string.h>
/******************************************************************************/
#include "uuzEVENT.h"
#include "uuzINIT.h"
#include "uuzOpt.h"
#include "uuzEEPROM.h"
#include "uuzRTC.h"
/******************************************************************************/
#include "uuzConfigBBL.h"
#include "uuzConfigMBR.h"
/******************************************************************************/
#include "typedefDEVID.h"
#include "uuzConfigEEPROM.h"
#include "uuzConfigDEV.h"
#include "uuzConfigPORT.h"
#include "uuzDevCfg.h"
#include "uuzDevID.h"
/******************************************************************************/
#include "uuzEventBRD.h"
#include "uuzEventVALVE.h"
#include "typedefWLS.h"
#include "uuzEventWLS.h"
#include "uuzEventP260.h"
/*UI---------------------------------------------*/
#include "uuzConfigHMI.h"
#include "uuzEventHMI.h"
/*log---------------------------------------------*/
#define DBG_TAG "e.wls"
#define DBG_LVL DBG_INFO
#include <rtdbg.h>
/******************************************************************************/
Wls_Pro_Typedef_t *xWlsPro;    //回水程序相关数据地址
Wls_Item_Typedef_t xWlsCache[_WLS_PRO_MAX];  //回水缓存数据
/******************************************************************************/
/**
 * @brief 初始化回水Project配置数据
 */
void wls_mode_config_init(void)
{
    for (u8 index = 0; index < _WLS_PRO_MAX; index++) {   //内部端口设备参数
        wls_config_single_default_init(&xWlsPro->cfg[index]);    //更新相关内容数据
    }

    xWlsPro->end = 0xBBBBU;  //结束符
    LOG_D("Init Wls Data");
}

/**
 * @brief 设置回水配置的初始相关数据
 * 
 * @param config 回水数据的指针地址
 * @param mode
 */
void wls_config_single_default_init(Water_Level_Config_Typedef_t * config)
{
    if (config != RT_NULL) {
        config->en = RT_TRUE;  //RT_TRUE(1)|RT_FALSE(0)
        config->md = _M_MANUAL;  //_M_MANUAL(0)|_M_AUTO(3)
        config->sta = uuzOPT_OFF;   //uuzOPT_ON(1)|uuzOPT_OFF(0)
        config->high = 1000;  //1.0m
        config->low = 100;  //0.1m
        config->target = 500;  //0.5m
        config->limit = 30 * 60;  //30min
        config->bid = xSysCFG.board_id;  //输出板数据
        config->io = 0;  //输出板对应序号
        config->t = uuzDEV_SL_BRD;  //输出板类型
        config->id = 0;  //传感器数据
    }
}

#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
/**
 * 补水自动输出
 * @param pro:程序
 * @param state:状态
 */
void wls_auto_fill_output(u8 pro, u16 state)
{
    if (pro == 1) {  //清水2
#if 0
        if (state == uuzOPT_ON) {
            rt_event_send(eventVALVE, OPT_VLV_4_ON);  //灌溉开
        } else {
            rt_event_send(eventVALVE, OPT_VLV_4_OFF);  //灌溉关
        }
#endif
        valve_opt(0, 3, state);  //独立关闭
    } else {    //营养1
#if 0
        if (state == uuzOPT_ON) {
            rt_event_send(eventVALVE, OPT_VLV_3_ON);  //灌溉开
        } else {
            rt_event_send(eventVALVE, OPT_VLV_3_OFF);  //灌溉关
        }
#endif
        valve_opt(0, 2, state);  //独立关闭
    }
    if (pro < _WLS_PRO_MAX) {
        rt_event_send(eventDATA, UI_DATA_SYNC);  //发送界面刷新
    }
}
#else
/**
 * 补水自动输出
 * @param pro:程序
 * @param state:状态
 */
void wls_auto_fill_output(u8 pro, u16 state)
{
    //当前为进水信号
#if 0
    if (state == uuzOPT_ON) {
        rt_event_send(eventVALVE, OPT_VLV_3_ON);  //灌溉模式
    } else {
        rt_event_send(eventVALVE, OPT_VLV_3_OFF);  //灌溉模式
    }
#endif
    valve_opt(0, 2, state);  //独立关闭
    rt_event_send(eventDATA, UI_DATA_SYNC);  //发送界面刷新
}
#endif

/**
 * @brief 灌溉源液桶自动补水
 */
void wls_auto_fill_judge(u8 index)
{
    u32 opt = RT_FALSE;  //不进行工作

    LOG_D("wls>%d:En[%d]-Md[%d]-Lit[%d]", index, xWlsPro->cfg[index].en, xWlsPro->cfg[index].md, xWlsPro->cfg[index].limit);
    if (xWlsPro->cfg[index].md == _M_AUTO) {   //循环工作模式
        if (xDevSTA.xP260[index].isconnect == uuzDEV_CONNECTED) {   //水位传感器信息
            LOG_D("wls>T[%d]-LIT[%d]", xWlsCache[index].time, xWlsPro->cfg[index].limit);
            if (xWlsCache[index].time >= xWlsPro->cfg[index].limit) {   //未达到补水高水位的最大加水时间
                if (xWlsCache[index].sta == uuzOPT_ON) {
                    xWlsCache[index].sta = uuzOPT_OFF;  //补水状态
                    wls_auto_fill_output(index, uuzOPT_OFF);  //发送关闭自动补水事件
                    xWlsCache[index].opt = uuzRUN_OFF;  //关闭补水程序动作
                }
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
                if (xSysSTA.need_dosing_fixed) {   //如果处于加肥状态，关闭蠕动泵
                    xSysSTA.need_dosing_fixed = 0;
                }
#endif
            } else {
                LOG_D("wls>AUTO:[%d]:Out[%d]", index, xP260Value[index].out);
                if (xP260Value[index].out == uuzSINP260_LOW) {  //低水位触发自动补水
                    if (xWlsCache[index].opt == uuzRUN_OFF) {  //还没有触发补水状态,灌溉补水关闭状态
                        if (xWlsCache[index].sta == uuzOPT_OFF) {  //NOTE:开启补水操作
                            xWlsCache[index].sta = uuzOPT_ON;  //补水状态
                            wls_auto_fill_output(index, uuzOPT_ON);  //发送开启自动补水事件
                        }
                        xWlsCache[index].time = 0;  //清除计时状态
                        xWlsCache[index].opt = uuzRUN_ON;  //开启补水程序动作
                    } else {
                        xWlsCache[index].time++;  //已经处于低水位补水状态了，需要计算工作事件
                    }
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
                    if (xSysSTA.need_dosing_fixed) {   //如果处于加肥状态，关闭蠕动泵
                        xSysSTA.need_dosing_fixed = 0;
                    }
#endif
                } else if (xP260Value[index].out == uuzSINP260_MID) {
                    if (xWlsCache[index].opt == uuzRUN_ON) {  //正在补水状态下,添加补水工作计时
                        if (xWlsCache[index].sta == uuzOPT_ON) {
                            xWlsCache[index].time++;
                        }
                    }
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
                    if (xSysSTA.need_dosing_fixed) {   //如果处于加肥状态，关闭蠕动泵
                        xSysSTA.need_dosing_fixed = 0;
                    }
#endif
                } else if ((xP260Value[index].out == uuzSINP260_TARGET)
                        || (xP260Value[index].out == uuzSINP260_HIGH)) {  //包括处于补水程序状态和非补水程序状态
                    if (xWlsCache[index].sta == uuzOPT_ON) {  //关闭补水动作
                        xWlsCache[index].sta = uuzOPT_OFF;  //补水状态
                        wls_auto_fill_output(index, uuzOPT_OFF);  //发送关闭自动补水事件
                        xWlsCache[index].time = 0;                        //清除计时状态
                        xWlsCache[index].opt = uuzRUN_OFF;                        //关闭补水程序动作
#if (uuzDEVICE_TYPE == _DEV_INNOVATION_ONLY)
                        if (xSysSTA.need_dosing_fixed == 0) {   //刚刚完成加肥动作
                            xSysSTA.need_dosing_fixed = 1;
                        }
#endif
                    }
                }
            }
        }
    } else {    //NOTE:没有水位传感器
        //在手动补水情况下,自动停止加水判断,正在补水状态下,添加补水工作计时
        if (xWlsCache[index].opt == uuzRUN_ON) {    //是否正在运行
            if (xWlsCache[index].sta == uuzOPT_ON) {    //是否开启状态
                xWlsCache[index].time++;
                if ((xP260Value[index].out == uuzSINP260_TARGET)    //NOTE:目标值
                || (xP260Value[index].out == uuzSINP260_HIGH)   //NOTE:高水位值
                        || (xWlsCache[index].time > xWlsPro->cfg[index].limit)) {            //达到高水位时间单位自动停止加水
                    xWlsCache[index].sta = uuzOPT_OFF;            //退出补水状态
                    wls_auto_fill_output(index, uuzOPT_OFF);  //发送关闭自动补水事件
                    xWlsCache[index].time = 0;                        //清除计时状态
                    xWlsCache[index].opt = uuzRUN_OFF;                        //关闭补水程序动作
                }
            }
        }
    }

    //在补水界面上,显示数据
    if (xCurrUI.ucPageID == uuzHMI_UI_WLS) {
        if (xDevSTA.xP260[index].isconnect == uuzDEV_CONNECTED) {   //水位传感器信息
            if ((xSysSTA.curr_wls == index)   //相关数据界面
            || (xWlsCache[index].opt == uuzRUN_ON)) {    //开启状态
                if (xWlsCache[index].time == xWlsPro->cfg[index].limit) {
                    hmi_water_supply_ui_stage(xWlsCache[index].time, 2);  //如果达到补水时间限制
                } else if (xWlsCache[index].time < xWlsPro->cfg[index].limit) {
                    hmi_water_supply_ui_stage(xWlsCache[index].time, 1);  //未达到补水时间限制
                }
            } else {
                hmi_water_supply_ui_stage(xWlsCache[index].time, 0);
            }
        } else {
            hmi_water_supply_ui_stage(xWlsCache[index].time, 3);    //如果未连接传感器
        }
    }
}
