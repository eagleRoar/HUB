/*
 * Copyright (c) 2006-2018 RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-12-18   ZhouXiaomin     first version
 */
#ifndef __UUZ_WLS_EVENT_H
#define __UUZ_WLS_EVENT_H

#include "typedefWLS.h"
#include "typedefMBR.h"

#ifdef __cplusplus
extern "C" {
#endif

extern Wls_Pro_Typedef_t * xWlsPro;    //回水程序相关数据地址
extern Wls_Item_Typedef_t xWlsCache[_WLS_PRO_MAX];  //回水缓存数据

/**
 * @brief 设置回水配置的初始相关数据
 *
 * @param config Data的指针地址
 * @param mode
 */
void wls_config_single_default_init(Water_Level_Config_Typedef_t * config);

/**
 * 补水自动输出
 * @param pro:程序
 * @param state:状态
 */
void wls_auto_fill_output(u8 pro, u16 state);

/**
 * @brief 初始化回水数据配置数据
 */
void wls_mode_config_init(void);

/**
 * @brief 设置回水配置的初始相关数据
 * 
 * @param xConfig Water Level的指针地址
 */
void wls_config_init(void);

/**
 * @brief 回水缓存数据
 * 
 */
void wls_cache_init(void);

/**
 * @brief 灌溉源液桶自动补水
 */
void wls_auto_fill_judge(u8 index);

#ifdef __cplusplus
}
#endif

#endif // __UUZ_WLS_EVENT_H
