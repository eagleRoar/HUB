2019-10:

1.fix bug:if write addr is not 0,write number is wrong

2.fix bug:if write number is over 255,write number is wrong

3.add 16bit addr support
